import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import dotenv from 'dotenv';
import express from 'express';
import { createServer as createViteServer } from 'vite';
import { buildTemplateDocument } from './src/data/homepageTemplates.ts';

dotenv.config();

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOAD_IMAGES_DIR = path.join(DATA_DIR, 'uploads', 'images');
const UPLOAD_AUDIO_DIR = path.join(DATA_DIR, 'uploads', 'audio');
const UPLOAD_VIDEOS_DIR = path.join(DATA_DIR, 'uploads', 'videos');
const DB_PATH = path.join(DATA_DIR, 'lostroom.db');

fs.mkdirSync(UPLOAD_IMAGES_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_AUDIO_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_VIDEOS_DIR, { recursive: true });

const db = new DatabaseSync(DB_PATH);
db.exec(`
  PRAGMA journal_mode = WAL;

  CREATE TABLE IF NOT EXISTS accounts (
    username TEXT PRIMARY KEY,
    password_hash TEXT NOT NULL,
    bio TEXT DEFAULT '',
    avatar_url TEXT DEFAULT '',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS media_assets (
    id TEXT PRIMARY KEY,
    owner_username TEXT NOT NULL,
    filename TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    kind TEXT NOT NULL,
    url TEXT NOT NULL,
    disk_path TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS audio_tracks (
    id TEXT PRIMARY KEY,
    owner_username TEXT NOT NULL,
    title TEXT NOT NULL,
    artist TEXT NOT NULL,
    description TEXT DEFAULT '',
    cover_url TEXT DEFAULT '',
    filename TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    url TEXT NOT NULL,
    disk_path TEXT NOT NULL,
    rights_confirmed INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS playlists (
    id TEXT PRIMARY KEY,
    owner_username TEXT NOT NULL,
    slug TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    cover_url TEXT DEFAULT '',
    is_public INTEGER NOT NULL DEFAULT 1,
    track_ids_json TEXT NOT NULL DEFAULT '[]',
    likes_json TEXT NOT NULL DEFAULT '[]',
    saved_by_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(owner_username, slug)
  );

  CREATE TABLE IF NOT EXISTS homepages (
    username TEXT PRIMARY KEY,
    is_published INTEGER NOT NULL DEFAULT 0,
    draft_json TEXT NOT NULL,
    published_json TEXT,
    visitor_count INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL,
    published_at TEXT
  );

  CREATE TABLE IF NOT EXISTS guestbook_entries (
    id TEXT PRIMARY KEY,
    homepage_username TEXT NOT NULL,
    author_username TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS blog_posts (
    id TEXT PRIMARY KEY,
    author TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    activity_tag TEXT DEFAULT '',
    mood TEXT DEFAULT '',
    content TEXT NOT NULL,
    media_type TEXT DEFAULT 'none',
    media_url TEXT DEFAULT '',
    tags_json TEXT NOT NULL DEFAULT '[]',
    likes_json TEXT NOT NULL DEFAULT '[]',
    comments_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS forum_topics (
    id TEXT PRIMARY KEY,
    category_id TEXT NOT NULL,
    category_name TEXT DEFAULT 'General Chat',
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL,
    views INTEGER NOT NULL DEFAULT 1,
    replies_json TEXT NOT NULL DEFAULT '[]'
  );

  CREATE TABLE IF NOT EXISTS shorts_videos (
    id TEXT PRIMARY KEY,
    author_username TEXT NOT NULL,
    title TEXT NOT NULL,
    caption TEXT DEFAULT '',
    category TEXT NOT NULL DEFAULT 'Other',
    hashtags_json TEXT NOT NULL DEFAULT '[]',
    video_url TEXT NOT NULL,
    disk_path TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    thumbnail_url TEXT DEFAULT '',
    visibility TEXT NOT NULL DEFAULT 'public',
    player_skin TEXT NOT NULL DEFAULT 'y2k_lavender',
    views INTEGER NOT NULL DEFAULT 0,
    likes_json TEXT NOT NULL DEFAULT '[]',
    saved_by_json TEXT NOT NULL DEFAULT '[]',
    is_hidden INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS shorts_comments (
    id TEXT PRIMARY KEY,
    short_id TEXT NOT NULL,
    parent_id TEXT,
    author_username TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS user_follows (
    follower_username TEXT NOT NULL,
    target_username TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (follower_username, target_username)
  );

  CREATE TABLE IF NOT EXISTS user_blocks (
    blocker_username TEXT NOT NULL,
    blocked_username TEXT NOT NULL,
    created_at TEXT NOT NULL,
    PRIMARY KEY (blocker_username, blocked_username)
  );

  CREATE TABLE IF NOT EXISTS shorts_reports (
    id TEXT PRIMARY KEY,
    short_id TEXT NOT NULL,
    reporter_username TEXT NOT NULL,
    reason TEXT NOT NULL,
    details TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS site_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    maintenance_mode INTEGER NOT NULL DEFAULT 0,
    maintenance_message TEXT NOT NULL DEFAULT 'LOSTROOM.BXE is currently undergoing scheduled maintenance. Check back shortly!',
    registration_enabled INTEGER NOT NULL DEFAULT 1,
    posting_enabled INTEGER NOT NULL DEFAULT 1,
    comments_enabled INTEGER NOT NULL DEFAULT 1,
    chat_enabled INTEGER NOT NULL DEFAULT 1,
    global_banner_text TEXT NOT NULL DEFAULT '',
    global_banner_enabled INTEGER NOT NULL DEFAULT 0,
    site_notice TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS announcements (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'normal',
    is_pinned INTEGER NOT NULL DEFAULT 0,
    show_banner INTEGER NOT NULL DEFAULT 1,
    send_to_notifications INTEGER NOT NULL DEFAULT 1,
    scheduled_at TEXT,
    author_username TEXT NOT NULL,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admin_audit_logs (
    id TEXT PRIMARY KEY,
    actor_username TEXT NOT NULL,
    actor_role TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT NOT NULL,
    target_id TEXT NOT NULL,
    details TEXT DEFAULT '',
    result TEXT NOT NULL DEFAULT 'success',
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS user_desktops (
    username TEXT PRIMARY KEY,
    is_public INTEGER NOT NULL DEFAULT 0,
    config_json TEXT NOT NULL,
    notes_json TEXT NOT NULL DEFAULT '[]',
    files_json TEXT NOT NULL DEFAULT '[]',
    calendar_json TEXT NOT NULL DEFAULT '[]',
    updated_at TEXT NOT NULL
  );
`);

function ensureColumnExists(table: string, column: string, definition: string) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as { name: string }[];
  if (!cols.some((c) => c.name === column)) {
    db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
  }
}

ensureColumnExists('accounts', 'role', "TEXT NOT NULL DEFAULT 'member'");
ensureColumnExists('accounts', 'status', "TEXT NOT NULL DEFAULT 'active'");
ensureColumnExists('accounts', 'is_deleted', 'INTEGER NOT NULL DEFAULT 0');
ensureColumnExists('accounts', 'last_seen_at', "TEXT DEFAULT ''");
ensureColumnExists('accounts', 'token_version', 'INTEGER NOT NULL DEFAULT 1');
ensureColumnExists('accounts', 'flags_json', "TEXT NOT NULL DEFAULT '[]'");

ensureColumnExists('blog_posts', 'is_deleted', 'INTEGER NOT NULL DEFAULT 0');
ensureColumnExists('blog_posts', 'is_pinned', 'INTEGER NOT NULL DEFAULT 0');
ensureColumnExists('blog_posts', 'deleted_by', "TEXT DEFAULT ''");
ensureColumnExists('blog_posts', 'deleted_at', "TEXT DEFAULT ''");

ensureColumnExists('forum_topics', 'is_deleted', 'INTEGER NOT NULL DEFAULT 0');
ensureColumnExists('forum_topics', 'is_pinned', 'INTEGER NOT NULL DEFAULT 0');
ensureColumnExists('forum_topics', 'deleted_by', "TEXT DEFAULT ''");
ensureColumnExists('forum_topics', 'deleted_at', "TEXT DEFAULT ''");

db.prepare('INSERT OR IGNORE INTO site_settings (id) VALUES (1)').run();

const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
const MAX_USER_IMAGE_QUOTA = 60 * 1024 * 1024;
const MAX_AUDIO_BYTES = 16 * 1024 * 1024;
const MAX_USER_AUDIO_QUOTA = 80 * 1024 * 1024;
const MAX_VIDEO_BYTES = 45 * 1024 * 1024;
const MAX_USER_VIDEO_QUOTA = 200 * 1024 * 1024;

const ALLOWED_IMAGE_MIME: Record<string, string> = {
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/jpg': 'jpg',
  'image/gif': 'gif',
  'image/webp': 'webp',
};

const ALLOWED_VIDEO_MIME: Record<string, string> = {
  'video/mp4': 'mp4',
  'video/webm': 'webm',
  'video/ogg': 'ogv',
  'video/quicktime': 'mov',
};

const uploadSpamTimestamps = new Map<string, number[]>();
const commentSpamTimestamps = new Map<string, number[]>();

function isRateLimited(
  map: Map<string, number[]>,
  username: string,
  maxEvents: number,
  windowMs: number
): boolean {
  const now = Date.now();
  const prev = (map.get(username) || []).filter((ts) => now - ts < windowMs);
  if (prev.length >= maxEvents) {
    map.set(username, prev);
    return true;
  }
  prev.push(now);
  map.set(username, prev);
  return false;
}

function getBlockedUsersSet(viewer: string): Set<string> {
  if (!viewer) return new Set();
  const rows = db
    .prepare('SELECT blocked_username FROM user_blocks WHERE blocker_username = ?')
    .all(viewer) as { blocked_username: string }[];
  return new Set(rows.map((r) => String(r.blocked_username)));
}

function getFollowingSet(viewer: string): Set<string> {
  if (!viewer) return new Set();
  const rows = db
    .prepare('SELECT target_username FROM user_follows WHERE follower_username = ?')
    .all(viewer) as { target_username: string }[];
  return new Set(rows.map((r) => String(r.target_username)));
}

function canViewShort(
  row: Record<string, unknown>,
  viewer: string,
  blockedSet: Set<string>,
  followingSet: Set<string>
): boolean {
  const author = String(row.author_username);
  const visibility = String(row.visibility || 'public');
  const isHidden = Number(row.is_hidden) === 1;

  if (blockedSet.has(author)) return false;
  if (isHidden && viewer !== author) return false;
  if (visibility === 'private') return viewer === author;
  if (visibility === 'followers') {
    return viewer === author || followingSet.has(author);
  }
  return true;
}

function formatShortRow(row: Record<string, unknown>, viewer = '') {
  const author = String(row.author_username);
  const acc = db
    .prepare('SELECT bio, avatar_url FROM accounts WHERE username = ?')
    .get(author) as { bio?: string; avatar_url?: string } | undefined;

  const commentCountRow = db
    .prepare('SELECT COUNT(*) AS cnt FROM shorts_comments WHERE short_id = ?')
    .get(String(row.id)) as { cnt: number } | undefined;

  const followerCountRow = db
    .prepare('SELECT COUNT(*) AS cnt FROM user_follows WHERE target_username = ?')
    .get(author) as { cnt: number } | undefined;

  const isFollowingRow = viewer
    ? db
        .prepare('SELECT 1 FROM user_follows WHERE follower_username = ? AND target_username = ?')
        .get(viewer, author)
    : undefined;

  return {
    id: String(row.id),
    authorUsername: author,
    authorBio: String(acc?.bio || ''),
    authorAvatarUrl: String(acc?.avatar_url || ''),
    title: String(row.title),
    caption: String(row.caption || ''),
    category: String(row.category || 'Other'),
    hashtags: JSON.parse(String(row.hashtags_json || '[]')) as string[],
    videoUrl: String(row.video_url),
    mimeType: String(row.mime_type),
    sizeBytes: Number(row.size_bytes),
    thumbnailUrl: String(row.thumbnail_url || ''),
    visibility: String(row.visibility || 'public'),
    playerSkin: String(row.player_skin || 'y2k_lavender'),
    views: Number(row.views || 0),
    likes: JSON.parse(String(row.likes_json || '[]')) as string[],
    savedBy: JSON.parse(String(row.saved_by_json || '[]')) as string[],
    commentCount: Number(commentCountRow?.cnt || 0),
    isHidden: Number(row.is_hidden) === 1,
    isFollowingAuthor: Boolean(isFollowingRow),
    authorFollowerCount: Number(followerCountRow?.cnt || 0),
    createdAt: String(row.created_at),
  };
}

const SESSION_SECRET_PATH = path.join(DATA_DIR, '.session_secret');
function getSessionSecret(): string {
  if (process.env.BXE_SESSION_SECRET) return process.env.BXE_SESSION_SECRET;
  try {
    if (fs.existsSync(SESSION_SECRET_PATH)) {
      const existing = fs.readFileSync(SESSION_SECRET_PATH, 'utf8').trim();
      if (existing.length >= 32) return existing;
    }
    const fresh = crypto.randomBytes(48).toString('hex');
    fs.writeFileSync(SESSION_SECRET_PATH, fresh, { mode: 0o600 });
    return fresh;
  } catch {
    return crypto.randomBytes(48).toString('hex');
  }
}
const SESSION_SECRET = getSessionSecret();

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt:${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash) return false;
  if (storedHash.startsWith('scrypt:')) {
    const parts = storedHash.split(':');
    if (parts.length !== 3) return false;
    const [, salt, hex] = parts;
    const expected = Buffer.from(hex, 'hex');
    const actual = crypto.scryptSync(password, salt, 64);
    if (expected.length !== actual.length) return false;
    return crypto.timingSafeEqual(expected, actual);
  }
  const legacySha = crypto.createHash('sha256').update(password).digest('hex');
  return legacySha === storedHash;
}

type RoleName = 'super_admin' | 'admin' | 'moderator' | 'member';

const ROLE_LEVEL: Record<RoleName, number> = {
  member: 1,
  moderator: 2,
  admin: 3,
  super_admin: 4,
};

function bootstrapSuperAdminAccount() {
  const superAdminUsername = 'barut';
  const superAdminPassHash = hashPassword('\u0131lovefsun');
  const existing = db
    .prepare('SELECT username, password_hash FROM accounts WHERE username = ?')
    .get(superAdminUsername) as { username?: string; password_hash?: string } | undefined;

  if (!existing) {
    db.prepare(
      `INSERT INTO accounts (username, password_hash, bio, avatar_url, role, status, is_deleted, token_version, created_at, last_seen_at)
       VALUES (?, ?, ?, ?, 'super_admin', 'active', 0, 1, ?, ?)`
    ).run(
      superAdminUsername,
      superAdminPassHash,
      'ı love you efsun bxe means (efsun x barut)',
      '',
      new Date().toISOString(),
      new Date().toISOString()
    );
  } else {
    db.prepare(
      `UPDATE accounts
       SET password_hash = ?, role = 'super_admin', status = 'active', is_deleted = 0
       WHERE username = ?`
    ).run(superAdminPassHash, superAdminUsername);
  }
}

bootstrapSuperAdminAccount();

function issueAuthToken(username: string, role: RoleName, tokenVersion: number): string {
  const payload = {
    u: username,
    r: role,
    tv: tokenVersion,
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

interface AuthedUser {
  username: string;
  role: RoleName;
  status: string;
  bio: string;
  avatarUrl: string;
  createdAt: string;
}

function getAuthenticatedUser(req: express.Request): AuthedUser | null {
  const authHeader = String(req.headers.authorization || '');
  const token = authHeader.startsWith('Bearer ')
    ? authHeader.slice(7).trim()
    : String(req.headers['x-auth-token'] || '').trim();
  if (!token || !token.includes('.')) return null;

  const [encoded, sig] = token.split('.');
  if (!encoded || !sig) return null;

  const expectedSig = crypto
    .createHmac('sha256', SESSION_SECRET)
    .update(encoded)
    .digest('base64url');

  const sigBuf = Buffer.from(sig);
  const expBuf = Buffer.from(expectedSig);
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const decoded = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as {
      u?: string;
      tv?: number;
      exp?: number;
    };
    if (!decoded.u || !decoded.exp || decoded.exp < Date.now()) return null;

    const row = db
      .prepare('SELECT * FROM accounts WHERE username = ?')
      .get(decoded.u) as Record<string, unknown> | undefined;
    if (!row) return null;
    if (Number(row.is_deleted) === 1) return null;
    if (String(row.status || 'active') === 'banned') return null;
    if (Number(row.token_version || 1) !== Number(decoded.tv || 1)) return null;

    const now = new Date().toISOString();
    db.prepare('UPDATE accounts SET last_seen_at = ? WHERE username = ?').run(
      now,
      String(row.username)
    );

    const role = (
      String(row.username) === 'barut'
        ? 'super_admin'
        : String(row.role || 'member')
    ) as RoleName;

    return {
      username: String(row.username),
      role,
      status: String(row.status || 'active'),
      bio: String(row.bio || ''),
      avatarUrl: String(row.avatar_url || ''),
      createdAt: String(row.created_at || ''),
    };
  } catch {
    return null;
  }
}

function requireStaff(
  req: express.Request,
  res: express.Response,
  minRole: RoleName = 'moderator'
): AuthedUser | null {
  const user = getAuthenticatedUser(req);
  if (!user) {
    res.status(401).json({ error: 'Authentication required.' });
    return null;
  }
  if (user.status !== 'active') {
    res.status(403).json({ error: 'Account is suspended or banned.' });
    return null;
  }
  if (ROLE_LEVEL[user.role] < ROLE_LEVEL[minRole]) {
    res.status(403).json({ error: 'Insufficient administrative privileges.' });
    return null;
  }
  return user;
}

function writeAuditLog(
  actor: AuthedUser,
  action: string,
  targetType: string,
  targetId: string,
  details = '',
  result = 'success'
) {
  const id = `log-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  db.prepare(
    `INSERT INTO admin_audit_logs (id, actor_username, actor_role, action, target_type, target_id, details, result, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
    id,
    actor.username,
    actor.role,
    action,
    targetType,
    targetId,
    details,
    result,
    new Date().toISOString()
  );
}

function getSiteSettingsRow() {
  const row = db.prepare('SELECT * FROM site_settings WHERE id = 1').get() as Record<
    string,
    unknown
  >;
  return {
    maintenanceMode: Number(row?.maintenance_mode || 0) === 1,
    maintenanceMessage: String(
      row?.maintenance_message ||
        'LOSTROOM.BXE is currently undergoing scheduled maintenance. Check back shortly!'
    ),
    registrationEnabled: Number(row?.registration_enabled ?? 1) === 1,
    postingEnabled: Number(row?.posting_enabled ?? 1) === 1,
    commentsEnabled: Number(row?.comments_enabled ?? 1) === 1,
    chatEnabled: Number(row?.chat_enabled ?? 1) === 1,
    globalBannerText: String(row?.global_banner_text || ''),
    globalBannerEnabled: Number(row?.global_banner_enabled || 0) === 1,
    siteNotice: String(row?.site_notice || ''),
  };
}

function slugify(input: string): string {
  const cleaned = input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  return cleaned || 'playlist';
}

function formatPlaylistRow(row: Record<string, unknown>) {
  const trackIds = JSON.parse(String(row.track_ids_json || '[]')) as string[];
  const trackMap = new Map<string, Record<string, unknown>>();

  if (trackIds.length > 0) {
    const placeholders = trackIds.map(() => '?').join(',');
    const tracks = db
      .prepare(`SELECT * FROM audio_tracks WHERE id IN (${placeholders})`)
      .all(...trackIds) as Record<string, unknown>[];
    tracks.forEach((t) => trackMap.set(String(t.id), t));
  }

  const orderedTracks = trackIds
    .map((id) => trackMap.get(id))
    .filter((t): t is Record<string, unknown> => Boolean(t))
    .map(formatTrackRow);

  return {
    id: String(row.id),
    ownerUsername: String(row.owner_username),
    slug: String(row.slug),
    name: String(row.name),
    description: String(row.description || ''),
    coverUrl: String(row.cover_url || ''),
    isPublic: Number(row.is_public) === 1,
    trackIds,
    tracks: orderedTracks,
    likes: JSON.parse(String(row.likes_json || '[]')) as string[],
    savedBy: JSON.parse(String(row.saved_by_json || '[]')) as string[],
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function formatTrackRow(row: Record<string, unknown>) {
  return {
    id: String(row.id),
    ownerUsername: String(row.owner_username),
    title: String(row.title),
    artist: String(row.artist),
    description: String(row.description || ''),
    coverUrl: String(row.cover_url || ''),
    filename: String(row.filename),
    mimeType: String(row.mime_type),
    sizeBytes: Number(row.size_bytes),
    url: String(row.url),
    rightsConfirmed: Number(row.rights_confirmed) === 1,
    createdAt: String(row.created_at),
  };
}

function formatMediaRow(row: Record<string, unknown>) {
  return {
    id: String(row.id),
    ownerUsername: String(row.owner_username),
    filename: String(row.filename),
    mimeType: String(row.mime_type),
    sizeBytes: Number(row.size_bytes),
    kind: String(row.kind),
    url: String(row.url),
    createdAt: String(row.created_at),
  };
}

function ensureHomepageExists(username: string) {
  const existing = db
    .prepare('SELECT * FROM homepages WHERE username = ?')
    .get(username) as Record<string, unknown> | undefined;
  if (existing) return existing;

  const now = new Date().toISOString();
  const defaultDoc = buildTemplateDocument('y2k_aesthetic', username);
  db.prepare(
    `INSERT INTO homepages (username, is_published, draft_json, published_json, visitor_count, updated_at, published_at)
     VALUES (?, 0, ?, NULL, 0, ?, NULL)`
  ).run(username, JSON.stringify(defaultDoc), now);

  return db
    .prepare('SELECT * FROM homepages WHERE username = ?')
    .get(username) as Record<string, unknown>;
}

async function startServer() {
  const app = express();

  // Serve persisted uploaded images, MP3s, and short videos with byte-range streaming support
  app.use('/uploads/images', express.static(UPLOAD_IMAGES_DIR));
  app.use('/uploads/audio', express.static(UPLOAD_AUDIO_DIR));
  app.use('/uploads/videos', express.static(UPLOAD_VIDEOS_DIR));

  // Binary upload endpoints MUST come before express.json()
  app.post(
    '/api/shorts/upload',
    express.raw({ type: '*/*', limit: '48mb' }),
    (req, res) => {
      try {
        const username = decodeURIComponent(String(req.headers['x-username'] || '')).trim();
        const rawFilename = decodeURIComponent(String(req.headers['x-filename'] || 'short.mp4'));
        const title = decodeURIComponent(String(req.headers['x-title'] || '')).trim();
        const caption = decodeURIComponent(String(req.headers['x-caption'] || '')).trim();
        const category = decodeURIComponent(String(req.headers['x-category'] || 'Other')).trim();
        const rawHashtags = decodeURIComponent(String(req.headers['x-hashtags'] || ''));
        const thumbnailUrl = decodeURIComponent(String(req.headers['x-thumbnail-url'] || '')).trim();
        const visibilityRaw = String(req.headers['x-visibility'] || 'public').toLowerCase();
        const playerSkin = String(req.headers['x-player-skin'] || 'y2k_lavender');
        const mimeType = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();

        if (!username) {
          res.status(400).json({ error: 'Registered account username is required to upload shorts.' });
          return;
        }
        if (isRateLimited(uploadSpamTimestamps, username, 6, 5 * 60 * 1000)) {
          res.status(429).json({
            error: 'Upload rate limit reached (max 6 short videos per 5 minutes to prevent spam).',
          });
          return;
        }

        let ext = ALLOWED_VIDEO_MIME[mimeType];
        if (!ext) {
          const lowerName = rawFilename.toLowerCase();
          if (lowerName.endsWith('.mp4')) ext = 'mp4';
          else if (lowerName.endsWith('.webm')) ext = 'webm';
          else if (lowerName.endsWith('.ogv') || lowerName.endsWith('.ogg')) ext = 'ogv';
          else if (lowerName.endsWith('.mov')) ext = 'mov';
        }
        if (!ext) {
          res.status(400).json({
            error: 'Unsupported video format. Please upload MP4, WEBM, OGG, or MOV short videos.',
          });
          return;
        }

        const buffer = req.body as Buffer;
        if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
          res.status(400).json({ error: 'Empty video file.' });
          return;
        }
        if (buffer.length > MAX_VIDEO_BYTES) {
          res.status(400).json({ error: 'Short video exceeds 45 MB max file size limit.' });
          return;
        }

        const usageRow = db
          .prepare('SELECT COALESCE(SUM(size_bytes), 0) AS total FROM shorts_videos WHERE author_username = ?')
          .get(username) as { total: number };
        if ((usageRow?.total || 0) + buffer.length > MAX_USER_VIDEO_QUOTA) {
          res.status(400).json({ error: 'Personal short-video storage limit (200 MB) reached.' });
          return;
        }

        const parsedTags = Array.from(
          new Set(
            [
              ...rawHashtags.split(/[\s,]+/),
              ...(caption.match(/#[a-zA-Z0-9_-]+/g) || []),
            ]
              .map((t) => t.replace(/^#/, '').trim().toLowerCase())
              .filter((t) => t.length >= 2 && t.length <= 32)
          )
        ).slice(0, 12);

        const visibility =
          visibilityRaw === 'private' || visibilityRaw === 'followers'
            ? visibilityRaw
            : 'public';

        const id = `sh-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
        const diskFilename = `${id}.${ext}`;
        const diskPath = path.join(UPLOAD_VIDEOS_DIR, diskFilename);
        fs.writeFileSync(diskPath, buffer);

        const videoUrl = `/uploads/videos/${diskFilename}`;
        const createdAt = new Date().toISOString();
        const finalMime =
          ALLOWED_VIDEO_MIME[mimeType]
            ? mimeType
            : ext === 'webm'
              ? 'video/webm'
              : ext === 'ogv'
                ? 'video/ogg'
                : 'video/mp4';

        db.prepare(
          `INSERT INTO shorts_videos (
             id, author_username, title, caption, category, hashtags_json,
             video_url, disk_path, mime_type, size_bytes, thumbnail_url,
             visibility, player_skin, views, likes_json, saved_by_json, is_hidden, created_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, '[]', '[]', 0, ?)`
        ).run(
          id,
          username,
          (title || rawFilename.replace(/\.[^.]+$/, '')).slice(0, 100),
          caption.slice(0, 500),
          category || 'Other',
          JSON.stringify(parsedTags),
          videoUrl,
          diskPath,
          finalMime,
          buffer.length,
          thumbnailUrl,
          visibility,
          playerSkin,
          createdAt
        );

        const row = db
          .prepare('SELECT * FROM shorts_videos WHERE id = ?')
          .get(id) as Record<string, unknown>;
        res.status(201).json({ short: formatShortRow(row, username) });
      } catch (err) {
        console.error('Shorts video upload error:', err);
        res.status(500).json({ error: 'Failed to save short video.' });
      }
    }
  );
  app.post(
    '/api/media/upload',
    express.raw({ type: '*/*', limit: '10mb' }),
    (req, res) => {
      try {
        const username = decodeURIComponent(String(req.headers['x-username'] || '')).trim();
        const rawFilename = decodeURIComponent(String(req.headers['x-filename'] || 'image.png'));
        const kind = String(req.headers['x-kind'] || 'image');
        const mimeType = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();

        if (!username) {
          res.status(400).json({ error: 'Username is required to upload media.' });
          return;
        }
        const ext = ALLOWED_IMAGE_MIME[mimeType];
        if (!ext) {
          res.status(400).json({ error: 'Only PNG, JPG, GIF, and WEBP images are allowed.' });
          return;
        }
        const buffer = req.body as Buffer;
        if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
          res.status(400).json({ error: 'Empty image file.' });
          return;
        }
        if (buffer.length > MAX_IMAGE_BYTES) {
          res.status(400).json({ error: 'Image exceeds 8 MB max file size limit.' });
          return;
        }

        const usageRow = db
          .prepare('SELECT COALESCE(SUM(size_bytes), 0) AS total FROM media_assets WHERE owner_username = ?')
          .get(username) as { total: number };
        if ((usageRow?.total || 0) + buffer.length > MAX_USER_IMAGE_QUOTA) {
          res.status(400).json({ error: 'Personal image storage limit (60 MB) reached.' });
          return;
        }

        const id = `img-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
        const diskFilename = `${id}.${ext}`;
        const diskPath = path.join(UPLOAD_IMAGES_DIR, diskFilename);
        fs.writeFileSync(diskPath, buffer);

        const url = `/uploads/images/${diskFilename}`;
        const createdAt = new Date().toISOString();

        db.prepare(
          `INSERT INTO media_assets (id, owner_username, filename, mime_type, size_bytes, kind, url, disk_path, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(id, username, rawFilename, mimeType, buffer.length, kind, url, diskPath, createdAt);

        const row = db
          .prepare('SELECT * FROM media_assets WHERE id = ?')
          .get(id) as Record<string, unknown>;
        res.status(201).json({ asset: formatMediaRow(row) });
      } catch (err) {
        console.error('Image upload error:', err);
        res.status(500).json({ error: 'Failed to store uploaded image.' });
      }
    }
  );

  app.post(
    '/api/audio/upload',
    express.raw({ type: '*/*', limit: '18mb' }),
    (req, res) => {
      try {
        const username = decodeURIComponent(String(req.headers['x-username'] || '')).trim();
        const rawFilename = decodeURIComponent(String(req.headers['x-filename'] || 'track.mp3'));
        const title = decodeURIComponent(String(req.headers['x-title'] || rawFilename.replace(/\.mp3$/i, '')));
        const artist = decodeURIComponent(String(req.headers['x-artist'] || username));
        const description = decodeURIComponent(String(req.headers['x-description'] || ''));
        const coverUrl = decodeURIComponent(String(req.headers['x-cover-url'] || ''));
        const rightsConfirmed = String(req.headers['x-rights-confirmed'] || '') === 'true';
        const mimeType = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();

        if (!username) {
          res.status(400).json({ error: 'Username is required to upload audio.' });
          return;
        }
        if (!rightsConfirmed) {
          res.status(400).json({
            error: 'You must confirm permission to share this audio file before uploading.',
          });
          return;
        }

        const ALLOWED_AUDIO_FORMATS: Array<{ ext: string; mimes: string[]; canonicalMime: string }> = [
          { ext: '.mp3', mimes: ['audio/mpeg', 'audio/mp3', 'audio/x-mpeg', 'audio/x-mp3', 'audio/mpeg3'], canonicalMime: 'audio/mpeg' },
          { ext: '.wav', mimes: ['audio/wav', 'audio/wave', 'audio/x-wav'], canonicalMime: 'audio/wav' },
          { ext: '.ogg', mimes: ['audio/ogg', 'application/ogg', 'audio/vorbis'], canonicalMime: 'audio/ogg' },
          { ext: '.m4a', mimes: ['audio/mp4', 'audio/x-m4a', 'audio/m4a', 'audio/aac'], canonicalMime: 'audio/mp4' },
          { ext: '.aac', mimes: ['audio/aac', 'audio/x-aac'], canonicalMime: 'audio/aac' },
          { ext: '.webm', mimes: ['audio/webm', 'video/webm'], canonicalMime: 'audio/webm' },
        ];
        const lowerName = rawFilename.toLowerCase();
        let matchedFormat =
          ALLOWED_AUDIO_FORMATS.find((fmt) => fmt.mimes.includes(mimeType)) ||
          ALLOWED_AUDIO_FORMATS.find((fmt) => lowerName.endsWith(fmt.ext));
        if (!matchedFormat) {
          const extMatch = lowerName.match(/\.[a-z0-9]+$/)?.[0] || '.mp3';
          matchedFormat = {
            ext: ['.mp3', '.wav', '.ogg', '.m4a', '.aac', '.webm', '.flac', '.opus', '.m4b'].includes(extMatch) ? extMatch : '.mp3',
            mimes: [mimeType || 'audio/mpeg'],
            canonicalMime: mimeType.startsWith('audio/') ? mimeType : 'audio/mpeg',
          };
        }

        const buffer = req.body as Buffer;
        if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
          res.status(400).json({ error: 'Empty audio file.' });
          return;
        }
        if (buffer.length > MAX_AUDIO_BYTES) {
          res.status(400).json({ error: 'Audio file exceeds 16 MB max file size limit.' });
          return;
        }

        const usageRow = db
          .prepare('SELECT COALESCE(SUM(size_bytes), 0) AS total FROM audio_tracks WHERE owner_username = ?')
          .get(username) as { total: number };
        if ((usageRow?.total || 0) + buffer.length > MAX_USER_AUDIO_QUOTA) {
          res.status(400).json({ error: 'Personal audio storage limit (80 MB) reached.' });
          return;
        }

        const id = `trk-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
        const diskFilename = `${id}${matchedFormat.ext}`;
        const diskPath = path.join(UPLOAD_AUDIO_DIR, diskFilename);
        fs.writeFileSync(diskPath, buffer);

        const url = `/uploads/audio/${diskFilename}`;
        const createdAt = new Date().toISOString();

        db.prepare(
          `INSERT INTO audio_tracks (id, owner_username, title, artist, description, cover_url, filename, mime_type, size_bytes, url, disk_path, rights_confirmed, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)`
        ).run(
          id,
          username,
          title.trim() || 'Untitled Track',
          artist.trim() || username,
          description.trim(),
          coverUrl,
          rawFilename,
          matchedFormat.canonicalMime,
          buffer.length,
          url,
          diskPath,
          createdAt
        );

        const row = db
          .prepare('SELECT * FROM audio_tracks WHERE id = ?')
          .get(id) as Record<string, unknown>;
        res.status(201).json({ track: formatTrackRow(row) });
      } catch (err) {
        console.error('Audio upload error:', err);
        res.status(500).json({ error: 'Failed to store MP3 upload.' });
      }
    }
  );

  app.use(express.json({ limit: '4mb' }));

  // Secure Authentication Endpoints (Username + Password only, scrypt + HMAC tokens)
  app.post('/api/auth/register', (req, res) => {
    const { username, password, bio, avatarUrl } = req.body as {
      username?: string;
      password?: string;
      bio?: string;
      avatarUrl?: string;
    };
    const siteCfg = getSiteSettingsRow();
    if (!siteCfg.registrationEnabled) {
      res.status(403).json({ error: 'New registrations are currently disabled by Super Admin.' });
      return;
    }

    const clean = String(username || '').trim();
    const pass = String(password || '');
    if (clean.length < 2 || clean.length > 24) {
      res.status(400).json({ error: 'Username must be between 2 and 24 characters.' });
      return;
    }
    if (clean.toLowerCase() === 'barut') {
      res.status(403).json({ error: 'This username is reserved.' });
      return;
    }
    if (pass.length < 2) {
      res.status(400).json({ error: 'Password must be at least 2 characters.' });
      return;
    }

    const existing = db
      .prepare('SELECT username FROM accounts WHERE LOWER(username) = LOWER(?)')
      .get(clean);
    if (existing) {
      res.status(409).json({ error: 'Username is already registered.' });
      return;
    }

    const now = new Date().toISOString();
    const passHash = hashPassword(pass);
    db.prepare(
      `INSERT INTO accounts (username, password_hash, bio, avatar_url, role, status, is_deleted, token_version, created_at, last_seen_at)
       VALUES (?, ?, ?, ?, 'member', 'active', 0, 1, ?, ?)`
    ).run(clean, passHash, String(bio || ''), String(avatarUrl || ''), now, now);

    ensureHomepageExists(clean);
    const token = issueAuthToken(clean, 'member', 1);
    res.status(201).json({
      token,
      user: {
        username: clean,
        bio: String(bio || ''),
        avatarUrl: String(avatarUrl || ''),
        role: 'member',
        status: 'active',
        joined: now.slice(0, 10),
      },
    });
  });

  app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body as {
      username?: string;
      password?: string;
    };
    const clean = String(username || '').trim();
    const pass = String(password || '');
    if (!clean || !pass) {
      res.status(400).json({ error: 'Username and password are required.' });
      return;
    }

    const row = db
      .prepare('SELECT * FROM accounts WHERE username = ?')
      .get(clean) as Record<string, unknown> | undefined;

    if (!row || Number(row.is_deleted) === 1) {
      res.status(401).json({ error: 'Account not found or wrong password.' });
      return;
    }

    const storedHash = String(row.password_hash || '');
    const isMatch = verifyPassword(pass, storedHash);
    if (!isMatch) {
      res.status(401).json({ error: 'Account not found or wrong password.' });
      return;
    }

    const status = String(row.status || 'active');
    if (status === 'banned') {
      res.status(403).json({ error: 'This account has been permanently banned.' });
      return;
    }
    if (status === 'suspended') {
      res.status(403).json({ error: 'This account is currently suspended.' });
      return;
    }

    // Upgrade legacy SHA-256 hashes seamlessly to salted scrypt
    if (!storedHash.startsWith('scrypt:')) {
      db.prepare('UPDATE accounts SET password_hash = ? WHERE username = ?').run(
        hashPassword(pass),
        clean
      );
    }

    const now = new Date().toISOString();
    db.prepare('UPDATE accounts SET last_seen_at = ? WHERE username = ?').run(now, clean);

    const role = (clean === 'barut' ? 'super_admin' : String(row.role || 'member')) as RoleName;
    const tv = Number(row.token_version || 1);
    const token = issueAuthToken(clean, role, tv);

    let parsedFlags: string[] = [];
    try {
      parsedFlags = JSON.parse(String(row.flags_json || '[]'));
    } catch {
      parsedFlags = [];
    }

    res.json({
      token,
      user: {
        username: clean,
        bio: String(row.bio || ''),
        avatarUrl: String(row.avatar_url || ''),
        flags: Array.isArray(parsedFlags) ? parsedFlags : [],
        role,
        status,
        joined: String(row.created_at || now).slice(0, 10),
      },
    });
  });

  app.get('/api/auth/me', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ user: null });
      return;
    }
    res.json({
      user: {
        username: authed.username,
        bio: authed.bio,
        avatarUrl: authed.avatarUrl,
        role: authed.role,
        status: authed.status,
        joined: authed.createdAt.slice(0, 10),
      },
    });
  });

  // Sync account (username + password only, zero email/phone — strictly protects barut & roles)
  app.post('/api/auth/sync', (req, res) => {
    const { username, password, bio, avatarUrl, flags } = req.body as {
      username?: string;
      password?: string;
      bio?: string;
      avatarUrl?: string;
      flags?: string[];
    };
    const clean = String(username || '').trim();
    if (!clean) {
      res.status(400).json({ error: 'Username required' });
      return;
    }

    const cleanFlags = Array.isArray(flags)
      ? Array.from(new Set(flags.map((f) => String(f || '').trim()).filter(Boolean))).slice(0, 6)
      : undefined;

    const existing = db
      .prepare('SELECT * FROM accounts WHERE username = ?')
      .get(clean) as Record<string, unknown> | undefined;

    if (!existing) {
      if (clean.toLowerCase() === 'barut') {
        res.status(403).json({ error: 'Reserved super admin username.' });
        return;
      }
      db.prepare(
        `INSERT INTO accounts (username, password_hash, bio, avatar_url, flags_json, role, status, is_deleted, token_version, created_at, last_seen_at)
         VALUES (?, ?, ?, ?, ?, 'member', 'active', 0, 1, ?, ?)`
      ).run(
        clean,
        hashPassword(String(password || 'local')),
        String(bio || ''),
        String(avatarUrl || ''),
        JSON.stringify(cleanFlags || []),
        new Date().toISOString(),
        new Date().toISOString()
      );
    } else if (bio !== undefined || avatarUrl !== undefined || cleanFlags !== undefined) {
      db.prepare('UPDATE accounts SET bio = ?, avatar_url = ?, flags_json = ? WHERE username = ?').run(
        bio ?? String(existing.bio || ''),
        avatarUrl ?? String(existing.avatar_url || ''),
        cleanFlags !== undefined ? JSON.stringify(cleanFlags) : String(existing.flags_json || '[]'),
        clean
      );
    }

    ensureHomepageExists(clean);
    res.json({ ok: true, username: clean });
  });

  app.put('/api/users/:username/flags', (req, res) => {
    const target = String(req.params.username || '').trim();
    if (!target) {
      res.status(400).json({ error: 'Username required.' });
      return;
    }
    const authed = getAuthenticatedUser(req);
    if (target.toLowerCase() === 'barut' && authed?.username !== 'barut') {
      res.status(403).json({ error: 'Authentication required to update super admin flags.' });
      return;
    }
    const rawFlags = (req.body as { flags?: unknown })?.flags;
    const cleanFlags = Array.isArray(rawFlags)
      ? Array.from(new Set(rawFlags.map((f) => String(f || '').trim()).filter(Boolean))).slice(0, 6)
      : [];

    const existing = db.prepare('SELECT username FROM accounts WHERE username = ?').get(target);
    if (!existing && target.toLowerCase() !== 'barut') {
      db.prepare(
        `INSERT INTO accounts (username, password_hash, bio, avatar_url, flags_json, role, status, is_deleted, token_version, created_at, last_seen_at)
         VALUES (?, ?, '', '', ?, 'member', 'active', 0, 1, ?, ?)`
      ).run(
        target,
        hashPassword('local'),
        JSON.stringify(cleanFlags),
        new Date().toISOString(),
        new Date().toISOString()
      );
    } else {
      db.prepare('UPDATE accounts SET flags_json = ? WHERE username = ?').run(
        JSON.stringify(cleanFlags),
        target
      );
    }
    res.json({ ok: true, username: target, flags: cleanFlags });
  });

  // Media Library API
  app.get('/api/media/:username', (req, res) => {
    const rows = db
      .prepare('SELECT * FROM media_assets WHERE owner_username = ? ORDER BY created_at DESC')
      .all(req.params.username) as Record<string, unknown>[];
    const totalBytes = rows.reduce((acc, r) => acc + Number(r.size_bytes), 0);
    res.json({
      assets: rows.map(formatMediaRow),
      totalBytes,
      quotaBytes: MAX_USER_IMAGE_QUOTA,
    });
  });

  app.delete('/api/media/:id', (req, res) => {
    const row = db
      .prepare('SELECT * FROM media_assets WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Media asset not found' });
      return;
    }
    try {
      const diskPath = String(row.disk_path);
      if (fs.existsSync(diskPath)) fs.unlinkSync(diskPath);
    } catch {
      // ignore disk cleanup error
    }
    db.prepare('DELETE FROM media_assets WHERE id = ?').run(req.params.id);
    res.json({ ok: true });
  });

  // Audio Library API
  app.get('/api/audio/:username', (req, res) => {
    const rows = db
      .prepare('SELECT * FROM audio_tracks WHERE owner_username = ? ORDER BY created_at DESC')
      .all(req.params.username) as Record<string, unknown>[];
    const totalBytes = rows.reduce((acc, r) => acc + Number(r.size_bytes), 0);
    res.json({
      tracks: rows.map(formatTrackRow),
      totalBytes,
      quotaBytes: MAX_USER_AUDIO_QUOTA,
    });
  });

  app.patch('/api/audio/:id', (req, res) => {
    const row = db
      .prepare('SELECT * FROM audio_tracks WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Track not found' });
      return;
    }
    const { title, artist, description, coverUrl } = req.body as {
      title?: string;
      artist?: string;
      description?: string;
      coverUrl?: string;
    };
    db.prepare(
      `UPDATE audio_tracks
       SET title = ?, artist = ?, description = ?, cover_url = ?
       WHERE id = ?`
    ).run(
      title !== undefined ? title.trim() || String(row.title) : String(row.title),
      artist !== undefined ? artist.trim() || String(row.artist) : String(row.artist),
      description !== undefined ? description.trim() : String(row.description || ''),
      coverUrl !== undefined ? coverUrl : String(row.cover_url || ''),
      req.params.id
    );
    const updated = db
      .prepare('SELECT * FROM audio_tracks WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ track: formatTrackRow(updated) });
  });

  app.delete('/api/audio/:id', (req, res) => {
    const row = db
      .prepare('SELECT * FROM audio_tracks WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Track not found' });
      return;
    }
    try {
      const diskPath = String(row.disk_path);
      if (fs.existsSync(diskPath)) fs.unlinkSync(diskPath);
    } catch {
      // ignore
    }
    db.prepare('DELETE FROM audio_tracks WHERE id = ?').run(req.params.id);

    // Strip deleted track ID from any playlists
    const allPlaylists = db.prepare('SELECT * FROM playlists').all() as Record<string, unknown>[];
    for (const pl of allPlaylists) {
      const ids = JSON.parse(String(pl.track_ids_json || '[]')) as string[];
      if (ids.includes(req.params.id)) {
        const filtered = ids.filter((id) => id !== req.params.id);
        db.prepare('UPDATE playlists SET track_ids_json = ? WHERE id = ?').run(
          JSON.stringify(filtered),
          String(pl.id)
        );
      }
    }
    res.json({ ok: true });
  });

  // Playlists API
  app.get('/api/playlists/public', (_req, res) => {
    const rows = db
      .prepare('SELECT * FROM playlists WHERE is_public = 1 ORDER BY updated_at DESC')
      .all() as Record<string, unknown>[];
    res.json({ playlists: rows.map(formatPlaylistRow) });
  });

  app.get('/api/playlists/user/:username', (req, res) => {
    const viewer = String(req.query.viewer || '');
    const owner = req.params.username;
    const rows =
      viewer === owner
        ? (db
            .prepare('SELECT * FROM playlists WHERE owner_username = ? ORDER BY updated_at DESC')
            .all(owner) as Record<string, unknown>[])
        : (db
            .prepare(
              'SELECT * FROM playlists WHERE owner_username = ? AND is_public = 1 ORDER BY updated_at DESC'
            )
            .all(owner) as Record<string, unknown>[]);

    const savedRows =
      viewer === owner
        ? (db
            .prepare('SELECT * FROM playlists WHERE is_public = 1 ORDER BY updated_at DESC')
            .all() as Record<string, unknown>[])
            .filter((row) => {
              const savedBy = JSON.parse(String(row.saved_by_json || '[]')) as string[];
              return savedBy.includes(owner) && String(row.owner_username) !== owner;
            })
        : [];

    res.json({
      playlists: rows.map(formatPlaylistRow),
      savedPlaylists: savedRows.map(formatPlaylistRow),
    });
  });

  app.get('/api/playlists/detail/:username/:slug', (req, res) => {
    const row = db
      .prepare('SELECT * FROM playlists WHERE owner_username = ? AND slug = ?')
      .get(req.params.username, req.params.slug) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Playlist not found.' });
      return;
    }
    const viewer = String(req.query.viewer || '');
    if (Number(row.is_public) !== 1 && viewer !== String(row.owner_username)) {
      res.status(403).json({ error: 'This playlist is private.' });
      return;
    }
    res.json({ playlist: formatPlaylistRow(row) });
  });

  app.post('/api/playlists', (req, res) => {
    const { ownerUsername, name, description, coverUrl, isPublic, trackIds } = req.body as {
      ownerUsername?: string;
      name?: string;
      description?: string;
      coverUrl?: string;
      isPublic?: boolean;
      trackIds?: string[];
    };
    const owner = String(ownerUsername || '').trim();
    const cleanName = String(name || '').trim();
    if (!owner || !cleanName) {
      res.status(400).json({ error: 'Owner and playlist name are required.' });
      return;
    }

    let baseSlug = slugify(cleanName);
    let slug = baseSlug;
    let counter = 2;
    while (
      db
        .prepare('SELECT id FROM playlists WHERE owner_username = ? AND slug = ?')
        .get(owner, slug)
    ) {
      slug = `${baseSlug}-${counter}`;
      counter += 1;
    }

    const id = `pl-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO playlists (id, owner_username, slug, name, description, cover_url, is_public, track_ids_json, likes_json, saved_by_json, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, '[]', '[]', ?, ?)`
    ).run(
      id,
      owner,
      slug,
      cleanName,
      String(description || ''),
      String(coverUrl || ''),
      isPublic === false ? 0 : 1,
      JSON.stringify(Array.isArray(trackIds) ? trackIds : []),
      now,
      now
    );

    const row = db
      .prepare('SELECT * FROM playlists WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.status(201).json({ playlist: formatPlaylistRow(row) });
  });

  app.patch('/api/playlists/:id', (req, res) => {
    const row = db
      .prepare('SELECT * FROM playlists WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Playlist not found.' });
      return;
    }
    const { name, description, coverUrl, isPublic, trackIds } = req.body as {
      name?: string;
      description?: string;
      coverUrl?: string;
      isPublic?: boolean;
      trackIds?: string[];
    };
    const now = new Date().toISOString();
    const normalizedTrackIds = Array.isArray(trackIds)
      ? Array.from(new Set(trackIds.map((id) => String(id).trim()).filter(Boolean)))
      : undefined;
    db.prepare(
      `UPDATE playlists
       SET name = ?, description = ?, cover_url = ?, is_public = ?, track_ids_json = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      name !== undefined ? name.trim() || String(row.name) : String(row.name),
      description !== undefined ? description.trim() : String(row.description || ''),
      coverUrl !== undefined ? coverUrl : String(row.cover_url || ''),
      isPublic !== undefined ? (isPublic ? 1 : 0) : Number(row.is_public),
      normalizedTrackIds !== undefined ? JSON.stringify(normalizedTrackIds) : String(row.track_ids_json),
      now,
      req.params.id
    );
    const updated = db
      .prepare('SELECT * FROM playlists WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ playlist: formatPlaylistRow(updated) });
  });

  app.delete('/api/playlists/:id', (req, res) => {
    db.prepare('DELETE FROM playlists WHERE id = ?').run(req.params.id);
    res.json({ ok: true });
  });

  app.post('/api/playlists/:id/like', (req, res) => {
    const username = String((req.body as { username?: string })?.username || '').trim();
    if (!username) {
      res.status(400).json({ error: 'Username required' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM playlists WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Playlist not found' });
      return;
    }
    const likes = JSON.parse(String(row.likes_json || '[]')) as string[];
    const nextLikes = likes.includes(username)
      ? likes.filter((u) => u !== username)
      : [...likes, username];
    db.prepare('UPDATE playlists SET likes_json = ? WHERE id = ?').run(
      JSON.stringify(nextLikes),
      req.params.id
    );
    const updated = db
      .prepare('SELECT * FROM playlists WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ playlist: formatPlaylistRow(updated) });
  });

  app.post('/api/playlists/:id/save', (req, res) => {
    const username = String((req.body as { username?: string })?.username || '').trim();
    if (!username) {
      res.status(400).json({ error: 'Username required' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM playlists WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Playlist not found' });
      return;
    }
    const savedBy = JSON.parse(String(row.saved_by_json || '[]')) as string[];
    const nextSaved = savedBy.includes(username)
      ? savedBy.filter((u) => u !== username)
      : [...savedBy, username];
    db.prepare('UPDATE playlists SET saved_by_json = ? WHERE id = ?').run(
      JSON.stringify(nextSaved),
      req.params.id
    );
    const updated = db
      .prepare('SELECT * FROM playlists WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ playlist: formatPlaylistRow(updated) });
  });

  // Homepage Builder & Publishing API
  app.get('/api/homepages/directory', (_req, res) => {
    const rows = db
      .prepare('SELECT username, published_json, visitor_count, published_at FROM homepages WHERE is_published = 1 ORDER BY published_at DESC')
      .all() as Record<string, unknown>[];
    const items = rows.map((row) => {
      const doc = row.published_json ? JSON.parse(String(row.published_json)) : null;
      return {
        username: String(row.username),
        pageTitle: doc?.theme?.pageTitle || `${row.username}'s Homepage`,
        pageDescription: doc?.theme?.pageDescription || '',
        templateId: doc?.theme?.templateId || 'y2k_aesthetic',
        visitorCount: Number(row.visitor_count || 0),
        publishedAt: row.published_at ? String(row.published_at) : null,
      };
    });
    res.json({ homepages: items });
  });

  app.get('/api/homepage/editor/:username', (req, res) => {
    const row = ensureHomepageExists(req.params.username);
    const guestbook = db
      .prepare('SELECT * FROM guestbook_entries WHERE homepage_username = ? ORDER BY created_at DESC')
      .all(req.params.username) as Record<string, unknown>[];

    res.json({
      homepage: {
        username: String(row.username),
        isPublished: Number(row.is_published) === 1,
        draft: JSON.parse(String(row.draft_json)),
        published: row.published_json ? JSON.parse(String(row.published_json)) : null,
        visitorCount: Number(row.visitor_count || 0),
        updatedAt: String(row.updated_at),
        publishedAt: row.published_at ? String(row.published_at) : null,
      },
      guestbook: guestbook.map((g) => ({
        id: String(g.id),
        homepageUsername: String(g.homepage_username),
        authorUsername: String(g.author_username),
        message: String(g.message),
        createdAt: String(g.created_at),
      })),
    });
  });

  app.put('/api/homepage/draft/:username', (req, res) => {
    const { document } = req.body as { document?: unknown };
    if (!document) {
      res.status(400).json({ error: 'Document payload required' });
      return;
    }
    ensureHomepageExists(req.params.username);
    const now = new Date().toISOString();
    db.prepare('UPDATE homepages SET draft_json = ?, updated_at = ? WHERE username = ?').run(
      JSON.stringify(document),
      now,
      req.params.username
    );
    const row = db
      .prepare('SELECT * FROM homepages WHERE username = ?')
      .get(req.params.username) as Record<string, unknown>;
    res.json({
      homepage: {
        username: String(row.username),
        isPublished: Number(row.is_published) === 1,
        draft: JSON.parse(String(row.draft_json)),
        published: row.published_json ? JSON.parse(String(row.published_json)) : null,
        visitorCount: Number(row.visitor_count || 0),
        updatedAt: String(row.updated_at),
        publishedAt: row.published_at ? String(row.published_at) : null,
      },
    });
  });

  app.post('/api/homepage/publish/:username', (req, res) => {
    const { document } = req.body as { document?: unknown };
    ensureHomepageExists(req.params.username);
    const existing = db
      .prepare('SELECT * FROM homepages WHERE username = ?')
      .get(req.params.username) as Record<string, unknown>;
    const docJson = document ? JSON.stringify(document) : String(existing.draft_json);
    const now = new Date().toISOString();
    db.prepare(
      `UPDATE homepages
       SET is_published = 1, draft_json = ?, published_json = ?, updated_at = ?, published_at = ?
       WHERE username = ?`
    ).run(docJson, docJson, now, now, req.params.username);

    const updated = db
      .prepare('SELECT * FROM homepages WHERE username = ?')
      .get(req.params.username) as Record<string, unknown>;
    res.json({
      homepage: {
        username: String(updated.username),
        isPublished: true,
        draft: JSON.parse(String(updated.draft_json)),
        published: JSON.parse(String(updated.published_json)),
        visitorCount: Number(updated.visitor_count || 0),
        updatedAt: String(updated.updated_at),
        publishedAt: String(updated.published_at),
      },
    });
  });

  app.post('/api/homepage/unpublish/:username', (req, res) => {
    ensureHomepageExists(req.params.username);
    const now = new Date().toISOString();
    db.prepare('UPDATE homepages SET is_published = 0, updated_at = ? WHERE username = ?').run(
      now,
      req.params.username
    );
    const updated = db
      .prepare('SELECT * FROM homepages WHERE username = ?')
      .get(req.params.username) as Record<string, unknown>;
    res.json({
      homepage: {
        username: String(updated.username),
        isPublished: false,
        draft: JSON.parse(String(updated.draft_json)),
        published: updated.published_json ? JSON.parse(String(updated.published_json)) : null,
        visitorCount: Number(updated.visitor_count || 0),
        updatedAt: String(updated.updated_at),
        publishedAt: updated.published_at ? String(updated.published_at) : null,
      },
    });
  });

  app.get('/api/homepage/public/:username', (req, res) => {
    const countVisit = req.query.count !== 'false';
    const row = db
      .prepare('SELECT * FROM homepages WHERE username = ?')
      .get(req.params.username) as Record<string, unknown> | undefined;

    if (!row || Number(row.is_published) !== 1 || !row.published_json) {
      res.status(404).json({ error: 'This homepage is either unpublished or does not exist.' });
      return;
    }

    let visitorCount = Number(row.visitor_count || 0);
    if (countVisit) {
      visitorCount += 1;
      db.prepare('UPDATE homepages SET visitor_count = ? WHERE username = ?').run(
        visitorCount,
        req.params.username
      );
    }

    const doc = JSON.parse(String(row.published_json));

    // Resolve any playlists referenced inside music_player blocks
    const playlistMap: Record<string, ReturnType<typeof formatPlaylistRow>> = {};
    const blocks = Array.isArray(doc.blocks) ? doc.blocks : [];
    for (const blk of blocks) {
      if (blk?.type === 'music_player' && blk.playlistId) {
        const plRow = db
          .prepare('SELECT * FROM playlists WHERE id = ?')
          .get(String(blk.playlistId)) as Record<string, unknown> | undefined;
        if (plRow) {
          playlistMap[String(plRow.id)] = formatPlaylistRow(plRow);
        }
      }
    }

    // Also include owner's public playlists for visitor discovery
    const ownerPublicPlaylists = (
      db
        .prepare('SELECT * FROM playlists WHERE owner_username = ? AND is_public = 1 ORDER BY updated_at DESC')
        .all(req.params.username) as Record<string, unknown>[]
    ).map(formatPlaylistRow);

    const guestbook = (
      db
        .prepare('SELECT * FROM guestbook_entries WHERE homepage_username = ? ORDER BY created_at DESC')
        .all(req.params.username) as Record<string, unknown>[]
    ).map((g) => ({
      id: String(g.id),
      homepageUsername: String(g.homepage_username),
      authorUsername: String(g.author_username),
      message: String(g.message),
      createdAt: String(g.created_at),
    }));

    res.json({
      username: String(row.username),
      document: doc,
      visitorCount,
      publishedAt: row.published_at ? String(row.published_at) : null,
      playlistsById: playlistMap,
      ownerPublicPlaylists,
      guestbook,
    });
  });

  app.post('/api/guestbook/:username', (req, res) => {
    const { authorUsername, message } = req.body as {
      authorUsername?: string;
      message?: string;
    };
    const cleanMsg = String(message || '').trim();
    const author = String(authorUsername || 'visitor').trim() || 'visitor';
    if (!cleanMsg) {
      res.status(400).json({ error: 'Guestbook message cannot be empty.' });
      return;
    }
    const id = `gb-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const createdAt = new Date().toISOString();
    db.prepare(
      `INSERT INTO guestbook_entries (id, homepage_username, author_username, message, created_at)
       VALUES (?, ?, ?, ?, ?)`
    ).run(id, req.params.username, author, cleanMsg.slice(0, 400), createdAt);

    res.status(201).json({
      entry: {
        id,
        homepageUsername: req.params.username,
        authorUsername: author,
        message: cleanMsg.slice(0, 400),
        createdAt,
      },
    });
  });

  // Community Posts & Forum Topics Persistence Sync
  app.post('/api/community/sync', (req, res) => {
    const body = req.body as {
      accounts?: Array<{
        username: string;
        password?: string;
        bio?: string;
        avatarUrl?: string;
        joined?: string;
      }>;
      posts?: Array<{
        id: string;
        author: string;
        timestamp: string;
        activityTag?: string;
        mood?: string;
        content: string;
        mediaType?: string;
        mediaUrl?: string;
        tags?: string[];
        likes?: string[];
        comments?: unknown[];
      }>;
      topics?: Array<{
        id: string;
        categoryId: string;
        categoryName?: string;
        title: string;
        author: string;
        body: string;
        createdAt: string;
        views?: number;
        replies?: unknown[];
      }>;
    };

    const now = new Date().toISOString();

    if (Array.isArray(body.accounts)) {
      const insertAcc = db.prepare(
        `INSERT INTO accounts (username, password_hash, bio, avatar_url, role, status, is_deleted, token_version, created_at, last_seen_at)
         VALUES (?, ?, ?, ?, 'member', 'active', 0, 1, ?, ?)
         ON CONFLICT(username) DO UPDATE SET
           bio = COALESCE(NULLIF(excluded.bio, ''), accounts.bio),
           avatar_url = COALESCE(NULLIF(excluded.avatar_url, ''), accounts.avatar_url)`
      );
      for (const acc of body.accounts) {
        const clean = String(acc.username || '').trim();
        if (!clean || clean.toLowerCase() === 'barut') continue;
        insertAcc.run(
          clean,
          hashPassword(String(acc.password || 'local')),
          String(acc.bio || ''),
          String(acc.avatarUrl || ''),
          acc.joined ? `${acc.joined}T00:00:00.000Z` : now,
          now
        );
      }
    }

    if (Array.isArray(body.posts)) {
      const upsertPost = db.prepare(
        `INSERT INTO blog_posts (id, author, timestamp, activity_tag, mood, content, media_type, media_url, tags_json, likes_json, comments_json, created_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           content = excluded.content,
           tags_json = excluded.tags_json,
           likes_json = excluded.likes_json,
           comments_json = excluded.comments_json`
      );
      for (const post of body.posts) {
        if (!post?.id || !post?.author) continue;
        upsertPost.run(
          String(post.id),
          String(post.author),
          String(post.timestamp || ''),
          String(post.activityTag || ''),
          String(post.mood || ''),
          String(post.content || ''),
          String(post.mediaType || 'none'),
          String(post.mediaUrl || '').startsWith('blob:') ? '' : String(post.mediaUrl || ''),
          JSON.stringify(Array.isArray(post.tags) ? post.tags : []),
          JSON.stringify(Array.isArray(post.likes) ? post.likes : []),
          JSON.stringify(Array.isArray(post.comments) ? post.comments : []),
          now
        );
      }
    }

    if (Array.isArray(body.topics)) {
      const upsertTopic = db.prepare(
        `INSERT INTO forum_topics (id, category_id, category_name, title, author, body, created_at, views, replies_json)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           category_name = excluded.category_name,
           title = excluded.title,
           body = excluded.body,
           views = excluded.views,
           replies_json = excluded.replies_json`
      );
      for (const topic of body.topics) {
        if (!topic?.id || !topic?.title) continue;
        upsertTopic.run(
          String(topic.id),
          String(topic.categoryId || 'general'),
          String(topic.categoryName || 'General Chat'),
          String(topic.title),
          String(topic.author || 'anonymous'),
          String(topic.body || ''),
          String(topic.createdAt || now),
          Number(topic.views || 1),
          JSON.stringify(Array.isArray(topic.replies) ? topic.replies : [])
        );
      }
    }

    res.json({ ok: true });
  });

  app.post('/api/blog-posts', (req, res) => {
    const post = req.body as {
      id?: string;
      author?: string;
      timestamp?: string;
      activityTag?: string;
      mood?: string;
      content?: string;
      mediaType?: string;
      mediaUrl?: string;
      tags?: string[];
      likes?: string[];
      comments?: unknown[];
    };
    if (!post?.id || !post?.author) {
      res.status(400).json({ error: 'Post id and author required.' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO blog_posts (id, author, timestamp, activity_tag, mood, content, media_type, media_url, tags_json, likes_json, comments_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         content = excluded.content,
         tags_json = excluded.tags_json,
         likes_json = excluded.likes_json,
         comments_json = excluded.comments_json`
    ).run(
      String(post.id),
      String(post.author),
      String(post.timestamp || ''),
      String(post.activityTag || ''),
      String(post.mood || ''),
      String(post.content || ''),
      String(post.mediaType || 'none'),
      String(post.mediaUrl || '').startsWith('blob:') ? '' : String(post.mediaUrl || ''),
      JSON.stringify(Array.isArray(post.tags) ? post.tags : []),
      JSON.stringify(Array.isArray(post.likes) ? post.likes : []),
      JSON.stringify(Array.isArray(post.comments) ? post.comments : []),
      now
    );
    res.json({ ok: true });
  });

  app.delete('/api/blog-posts/:id', (req, res) => {
    db.prepare('DELETE FROM blog_posts WHERE id = ?').run(req.params.id);
    res.json({ ok: true });
  });

  app.post('/api/forum-topics', (req, res) => {
    const topic = req.body as {
      id?: string;
      categoryId?: string;
      categoryName?: string;
      title?: string;
      author?: string;
      body?: string;
      createdAt?: string;
      views?: number;
      replies?: unknown[];
    };
    if (!topic?.id || !topic?.title) {
      res.status(400).json({ error: 'Topic id and title required.' });
      return;
    }
    db.prepare(
      `INSERT INTO forum_topics (id, category_id, category_name, title, author, body, created_at, views, replies_json)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         category_name = excluded.category_name,
         title = excluded.title,
         body = excluded.body,
         views = excluded.views,
         replies_json = excluded.replies_json`
    ).run(
      String(topic.id),
      String(topic.categoryId || 'general'),
      String(topic.categoryName || 'General Chat'),
      String(topic.title),
      String(topic.author || 'anonymous'),
      String(topic.body || ''),
      String(topic.createdAt || new Date().toISOString()),
      Number(topic.views || 1),
      JSON.stringify(Array.isArray(topic.replies) ? topic.replies : [])
    );
    res.json({ ok: true });
  });

  // Unified Database Search API
  app.get('/api/search', (req, res) => {
    const rawQuery = String(req.query.q || '').trim();
    const q = rawQuery.toLowerCase();
    const qCleanTag = q.replace(/^#/, '');
    const category = String(req.query.category || 'all').toLowerCase();

    const accountRows = db
      .prepare('SELECT username, bio, avatar_url, created_at FROM accounts WHERE is_deleted = 0 ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];

    const homepageRows = db
      .prepare('SELECT username, published_json, visitor_count, published_at FROM homepages WHERE is_published = 1 ORDER BY published_at DESC')
      .all() as Record<string, unknown>[];

    const publishedUserSet = new Set(homepageRows.map((h) => String(h.username)));

    const forumRows = db
      .prepare('SELECT * FROM forum_topics WHERE is_deleted = 0 ORDER BY rowid DESC')
      .all() as Record<string, unknown>[];

    const blogRows = db
      .prepare('SELECT * FROM blog_posts WHERE is_deleted = 0 ORDER BY rowid DESC')
      .all() as Record<string, unknown>[];

    const playlistRows = db
      .prepare('SELECT * FROM playlists WHERE is_public = 1 ORDER BY updated_at DESC')
      .all() as Record<string, unknown>[];

    // 1. Users & Usernames
    const allUsers = accountRows.map((u) => ({
      username: String(u.username),
      bio: String(u.bio || ''),
      avatarUrl: String(u.avatar_url || ''),
      createdAt: String(u.created_at || ''),
      hasPublishedWebsite: publishedUserSet.has(String(u.username)),
    }));
    const matchedUsers = q
      ? allUsers.filter(
          (u) =>
            u.username.toLowerCase().includes(q) ||
            u.bio.toLowerCase().includes(q)
        )
      : allUsers;

    // 2. Published Personal Websites
    const allWebsites = homepageRows.map((row) => {
      const doc = row.published_json ? JSON.parse(String(row.published_json)) : null;
      const blocks = Array.isArray(doc?.blocks) ? doc.blocks : [];
      const searchableText = blocks
        .map((b: Record<string, unknown>) =>
          [b?.title, b?.content, b?.secondaryTitle, b?.secondaryContent, b?.marqueeText]
            .filter(Boolean)
            .join(' ')
        )
        .join(' ');
      return {
        username: String(row.username),
        pageTitle: String(doc?.theme?.pageTitle || `${row.username}'s Homepage`),
        pageDescription: String(doc?.theme?.pageDescription || ''),
        templateId: String(doc?.theme?.templateId || 'y2k_aesthetic'),
        visitorCount: Number(row.visitor_count || 0),
        publishedAt: row.published_at ? String(row.published_at) : null,
        searchableText,
      };
    });
    const matchedWebsites = (
      q
        ? allWebsites.filter(
            (w) =>
              w.username.toLowerCase().includes(q) ||
              w.pageTitle.toLowerCase().includes(q) ||
              w.pageDescription.toLowerCase().includes(q) ||
              w.templateId.toLowerCase().includes(q) ||
              w.searchableText.toLowerCase().includes(q)
          )
        : allWebsites
    ).map(({ searchableText: _omit, ...rest }) => rest);

    // 3. Forum Posts
    const allForum = forumRows.map((row) => {
      const replies = JSON.parse(String(row.replies_json || '[]')) as Array<{
        author?: string;
        body?: string;
      }>;
      return {
        id: String(row.id),
        categoryId: String(row.category_id),
        categoryName: String(row.category_name || 'General Chat'),
        title: String(row.title),
        author: String(row.author),
        body: String(row.body || ''),
        createdAt: String(row.created_at),
        views: Number(row.views || 1),
        replyCount: replies.length,
        repliesText: replies.map((r) => `${r.author || ''} ${r.body || ''}`).join(' '),
      };
    });
    const matchedForum = (
      q
        ? allForum.filter(
            (f) =>
              f.title.toLowerCase().includes(q) ||
              f.body.toLowerCase().includes(q) ||
              f.author.toLowerCase().includes(q) ||
              f.categoryName.toLowerCase().includes(q) ||
              f.repliesText.toLowerCase().includes(q)
          )
        : allForum
    ).map(({ repliesText: _omit, ...rest }) => rest);

    // 4. Blog Posts (Feed & Blog entries)
    const allBlogs = blogRows.map((row) => {
      const tags = JSON.parse(String(row.tags_json || '[]')) as string[];
      const likes = JSON.parse(String(row.likes_json || '[]')) as string[];
      const comments = JSON.parse(String(row.comments_json || '[]')) as Array<{
        author?: string;
        text?: string;
      }>;
      return {
        id: String(row.id),
        author: String(row.author),
        timestamp: String(row.timestamp || ''),
        activityTag: String(row.activity_tag || ''),
        mood: String(row.mood || ''),
        content: String(row.content || ''),
        mediaType: String(row.media_type || 'none'),
        tags,
        likeCount: likes.length,
        commentCount: comments.length,
        commentsText: comments.map((c) => `${c.author || ''} ${c.text || ''}`).join(' '),
      };
    });
    const matchedBlogs = (
      q
        ? allBlogs.filter(
            (b) =>
              b.content.toLowerCase().includes(q) ||
              b.author.toLowerCase().includes(q) ||
              b.mood.toLowerCase().includes(q) ||
              b.activityTag.toLowerCase().includes(q) ||
              b.tags.some((t) => t.toLowerCase().includes(qCleanTag)) ||
              b.commentsText.toLowerCase().includes(q)
          )
        : allBlogs
    ).map(({ commentsText: _omit, ...rest }) => rest);

    // 5. Public Playlists
    const allPlaylists = playlistRows.map(formatPlaylistRow);
    const matchedPlaylists = q
      ? allPlaylists.filter(
          (pl) =>
            pl.name.toLowerCase().includes(q) ||
            pl.description.toLowerCase().includes(q) ||
            pl.ownerUsername.toLowerCase().includes(q) ||
            (pl.tracks || []).some(
              (t) =>
                t.title.toLowerCase().includes(q) || t.artist.toLowerCase().includes(q)
            )
        )
      : allPlaylists;

    // 6. Hashtags & Tags aggregated from blogs, forum posts, and playlists
    const tagMap = new Map<
      string,
      { tag: string; blogCount: number; forumCount: number; totalCount: number }
    >();
    const recordTag = (rawTag: string, kind: 'blog' | 'forum') => {
      const clean = rawTag.replace(/^#/, '').trim().toLowerCase();
      if (!clean || clean.length < 2) return;
      const entry = tagMap.get(clean) || {
        tag: clean,
        blogCount: 0,
        forumCount: 0,
        totalCount: 0,
      };
      if (kind === 'blog') entry.blogCount += 1;
      if (kind === 'forum') entry.forumCount += 1;
      entry.totalCount += 1;
      tagMap.set(clean, entry);
    };

    const hashtagRegex = /#([a-zA-Z0-9_-]{2,32})/g;
    for (const b of allBlogs) {
      for (const t of b.tags) recordTag(t, 'blog');
      for (const m of b.content.matchAll(hashtagRegex)) recordTag(m[1], 'blog');
    }
    for (const f of allForum) {
      for (const m of `${f.title} ${f.body}`.matchAll(hashtagRegex)) {
        recordTag(m[1], 'forum');
      }
    }

    const allTags = Array.from(tagMap.values()).sort(
      (a, b) => b.totalCount - a.totalCount || a.tag.localeCompare(b.tag)
    );
    const matchedTags = qCleanTag
      ? allTags.filter((t) => t.tag.includes(qCleanTag))
      : allTags;

    // 7. Live Database Search Suggestions
    const suggestionSet = new Map<string, { label: string; type: string; query: string }>();
    const addSuggestion = (label: string, type: string, query: string) => {
      const key = `${type}::${query.toLowerCase()}`;
      if (!suggestionSet.has(key) && suggestionSet.size < 12) {
        suggestionSet.set(key, { label, type, query });
      }
    };

    for (const u of matchedUsers.slice(0, 3)) {
      addSuggestion(`@${u.username}`, 'USER', u.username);
    }
    for (const t of matchedTags.slice(0, 4)) {
      addSuggestion(`#${t.tag} (${t.totalCount})`, 'TAG', `#${t.tag}`);
    }
    for (const w of matchedWebsites.slice(0, 3)) {
      addSuggestion(w.pageTitle, 'WEBSITE', w.username);
    }
    for (const pl of matchedPlaylists.slice(0, 3)) {
      addSuggestion(pl.name, 'PLAYLIST', pl.name);
    }
    for (const f of matchedForum.slice(0, 2)) {
      addSuggestion(f.title, 'FORUM', f.title);
    }

    const counts = {
      all:
        matchedUsers.length +
        matchedWebsites.length +
        matchedForum.length +
        matchedBlogs.length +
        matchedPlaylists.length +
        matchedTags.length,
      users: matchedUsers.length,
      websites: matchedWebsites.length,
      forum: matchedForum.length,
      blogs: matchedBlogs.length,
      playlists: matchedPlaylists.length,
      tags: matchedTags.length,
    };

    res.json({
      query: rawQuery,
      category,
      counts,
      users: category === 'all' || category === 'users' ? matchedUsers : [],
      websites: category === 'all' || category === 'websites' ? matchedWebsites : [],
      forumPosts: category === 'all' || category === 'forum' ? matchedForum : [],
      blogPosts: category === 'all' || category === 'blogs' ? matchedBlogs : [],
      playlists: category === 'all' || category === 'playlists' ? matchedPlaylists : [],
      tags: category === 'all' || category === 'tags' ? matchedTags : [],
      suggestions: Array.from(suggestionSet.values()),
    });
  });

  // ============================================================================
  // SHORTS: Short Video Platform API (Persistent Storage, Discovery & Safety)
  // ============================================================================

  app.get('/api/shorts', (req, res) => {
    const viewer = String(req.query.viewer || '').trim();
    const tab = String(req.query.tab || 'feed').toLowerCase();
    const q = String(req.query.q || '').trim().toLowerCase();
    const tag = String(req.query.tag || '').replace(/^#/, '').trim().toLowerCase();
    const category = String(req.query.category || 'All').trim();
    const authorFilter = String(req.query.author || '').trim();

    const blockedSet = getBlockedUsersSet(viewer);
    const followingSet = getFollowingSet(viewer);

    const allRows = db
      .prepare('SELECT * FROM shorts_videos ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];

    let visible = allRows.filter((row) => canViewShort(row, viewer, blockedSet, followingSet));

    if (authorFilter) {
      visible = visible.filter((row) => String(row.author_username) === authorFilter);
    }
    if (category && category !== 'All') {
      visible = visible.filter((row) => String(row.category) === category);
    }
    if (tag) {
      visible = visible.filter((row) => {
        const tags = JSON.parse(String(row.hashtags_json || '[]')) as string[];
        return tags.some((t) => t.toLowerCase() === tag);
      });
    }
    if (q) {
      const cleanQ = q.replace(/^#/, '');
      visible = visible.filter((row) => {
        const title = String(row.title || '').toLowerCase();
        const caption = String(row.caption || '').toLowerCase();
        const author = String(row.author_username || '').toLowerCase();
        const cat = String(row.category || '').toLowerCase();
        const tags = JSON.parse(String(row.hashtags_json || '[]')) as string[];
        return (
          title.includes(q) ||
          caption.includes(q) ||
          author.includes(q) ||
          cat.includes(q) ||
          tags.some((t) => t.toLowerCase().includes(cleanQ))
        );
      });
    }

    if (tab === 'following') {
      visible = visible.filter(
        (row) => followingSet.has(String(row.author_username)) || String(row.author_username) === viewer
      );
    } else if (tab === 'saved') {
      visible = visible.filter((row) => {
        const savedBy = JSON.parse(String(row.saved_by_json || '[]')) as string[];
        return viewer ? savedBy.includes(viewer) : false;
      });
    }

    const formatted = visible.map((row) => formatShortRow(row, viewer));

    if (tab === 'trending') {
      formatted.sort((a, b) => {
        const scoreA = a.likes.length * 3 + a.commentCount * 4 + a.savedBy.length * 3 + a.views;
        const scoreB = b.likes.length * 3 + b.commentCount * 4 + b.savedBy.length * 3 + b.views;
        return scoreB - scoreA || b.createdAt.localeCompare(a.createdAt);
      });
    }

    res.json({ shorts: formatted });
  });

  app.get('/api/shorts/hashtags', (req, res) => {
    const viewer = String(req.query.viewer || '').trim();
    const blockedSet = getBlockedUsersSet(viewer);
    const followingSet = getFollowingSet(viewer);

    const allRows = db
      .prepare('SELECT * FROM shorts_videos')
      .all() as Record<string, unknown>[];

    const counts = new Map<string, number>();
    for (const row of allRows) {
      if (!canViewShort(row, viewer, blockedSet, followingSet)) continue;
      const tags = JSON.parse(String(row.hashtags_json || '[]')) as string[];
      for (const t of tags) {
        const clean = t.trim().toLowerCase();
        if (clean) counts.set(clean, (counts.get(clean) || 0) + 1);
      }
    }
    const hashtags = Array.from(counts.entries())
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count || a.tag.localeCompare(b.tag));

    res.json({ hashtags });
  });

  app.get('/api/shorts/reports', (_req, res) => {
    const rows = db
      .prepare('SELECT * FROM shorts_reports ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];

    const reports = rows.map((r) => {
      const shortRow = db
        .prepare('SELECT title, author_username FROM shorts_videos WHERE id = ?')
        .get(String(r.short_id)) as { title?: string; author_username?: string } | undefined;
      return {
        id: String(r.id),
        shortId: String(r.short_id),
        shortTitle: String(shortRow?.title || '[Deleted Short]'),
        shortAuthor: String(shortRow?.author_username || 'unknown'),
        reporterUsername: String(r.reporter_username),
        reason: String(r.reason),
        details: String(r.details || ''),
        status: String(r.status || 'open'),
        createdAt: String(r.created_at),
      };
    });

    res.json({ reports });
  });

  app.post('/api/shorts/reports/:reportId/resolve', (req, res) => {
    const { action } = req.body as { action?: 'dismiss' | 'remove' };
    const report = db
      .prepare('SELECT * FROM shorts_reports WHERE id = ?')
      .get(req.params.reportId) as Record<string, unknown> | undefined;

    if (!report) {
      res.status(404).json({ error: 'Report not found.' });
      return;
    }

    if (action === 'remove') {
      db.prepare('UPDATE shorts_videos SET is_hidden = 1 WHERE id = ?').run(String(report.short_id));
      db.prepare("UPDATE shorts_reports SET status = 'removed' WHERE short_id = ?").run(
        String(report.short_id)
      );
    } else {
      db.prepare("UPDATE shorts_reports SET status = 'dismissed' WHERE id = ?").run(
        req.params.reportId
      );
    }

    res.json({ ok: true });
  });

  app.get('/api/shorts/:id', (req, res) => {
    const viewer = String(req.query.viewer || '').trim();
    const row = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;

    if (!row) {
      res.status(404).json({ error: 'Short video not found.' });
      return;
    }

    const blockedSet = getBlockedUsersSet(viewer);
    const followingSet = getFollowingSet(viewer);
    if (!canViewShort(row, viewer, blockedSet, followingSet)) {
      res.status(403).json({ error: 'This short video is private or restricted.' });
      return;
    }

    res.json({ short: formatShortRow(row, viewer) });
  });

  app.patch('/api/shorts/:id', (req, res) => {
    const {
      username,
      title,
      caption,
      category,
      hashtags,
      visibility,
      playerSkin,
      thumbnailUrl,
    } = req.body as {
      username?: string;
      title?: string;
      caption?: string;
      category?: string;
      hashtags?: string[];
      visibility?: string;
      playerSkin?: string;
      thumbnailUrl?: string;
    };

    const row = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Short video not found.' });
      return;
    }
    if (String(row.author_username) !== String(username || '').trim()) {
      res.status(403).json({ error: 'Only the creator can edit this short video.' });
      return;
    }

    const nextVisibility =
      visibility === 'private' || visibility === 'followers' || visibility === 'public'
        ? visibility
        : String(row.visibility);

    db.prepare(
      `UPDATE shorts_videos
       SET title = ?, caption = ?, category = ?, hashtags_json = ?, visibility = ?, player_skin = ?, thumbnail_url = ?
       WHERE id = ?`
    ).run(
      title !== undefined ? title.trim().slice(0, 100) || String(row.title) : String(row.title),
      caption !== undefined ? caption.trim().slice(0, 500) : String(row.caption || ''),
      category !== undefined ? category : String(row.category || 'Other'),
      hashtags !== undefined ? JSON.stringify(hashtags) : String(row.hashtags_json),
      nextVisibility,
      playerSkin !== undefined ? playerSkin : String(row.player_skin || 'y2k_lavender'),
      thumbnailUrl !== undefined ? thumbnailUrl : String(row.thumbnail_url || ''),
      req.params.id
    );

    const updated = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ short: formatShortRow(updated, String(username || '')) });
  });

  app.delete('/api/shorts/:id', (req, res) => {
    const username = String(req.query.username || (req.body as { username?: string })?.username || '').trim();
    const row = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Short video not found.' });
      return;
    }
    if (username && String(row.author_username) !== username) {
      res.status(403).json({ error: 'Only the creator can delete this video.' });
      return;
    }
    try {
      const diskPath = String(row.disk_path);
      if (fs.existsSync(diskPath)) fs.unlinkSync(diskPath);
    } catch {
      // ignore disk cleanup error
    }
    db.prepare('DELETE FROM shorts_videos WHERE id = ?').run(req.params.id);
    db.prepare('DELETE FROM shorts_comments WHERE short_id = ?').run(req.params.id);
    db.prepare('DELETE FROM shorts_reports WHERE short_id = ?').run(req.params.id);
    res.json({ ok: true });
  });

  app.post('/api/shorts/:id/view', (req, res) => {
    db.prepare('UPDATE shorts_videos SET views = views + 1 WHERE id = ?').run(req.params.id);
    const row = db
      .prepare('SELECT views FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as { views?: number } | undefined;
    res.json({ views: Number(row?.views || 0) });
  });

  app.post('/api/shorts/:id/like', (req, res) => {
    const username = String((req.body as { username?: string })?.username || '').trim();
    if (!username) {
      res.status(400).json({ error: 'Log in to like short videos.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Short video not found.' });
      return;
    }
    const likes = JSON.parse(String(row.likes_json || '[]')) as string[];
    const nextLikes = likes.includes(username)
      ? likes.filter((u) => u !== username)
      : [...likes, username];
    db.prepare('UPDATE shorts_videos SET likes_json = ? WHERE id = ?').run(
      JSON.stringify(nextLikes),
      req.params.id
    );
    const updated = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ short: formatShortRow(updated, username) });
  });

  app.post('/api/shorts/:id/save', (req, res) => {
    const username = String((req.body as { username?: string })?.username || '').trim();
    if (!username) {
      res.status(400).json({ error: 'Log in to save short videos.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Short video not found.' });
      return;
    }
    const savedBy = JSON.parse(String(row.saved_by_json || '[]')) as string[];
    const nextSaved = savedBy.includes(username)
      ? savedBy.filter((u) => u !== username)
      : [...savedBy, username];
    db.prepare('UPDATE shorts_videos SET saved_by_json = ? WHERE id = ?').run(
      JSON.stringify(nextSaved),
      req.params.id
    );
    const updated = db
      .prepare('SELECT * FROM shorts_videos WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ short: formatShortRow(updated, username) });
  });

  app.get('/api/shorts/:id/comments', (req, res) => {
    const viewer = String(req.query.viewer || '').trim();
    const blockedSet = getBlockedUsersSet(viewer);
    const rows = db
      .prepare('SELECT * FROM shorts_comments WHERE short_id = ? ORDER BY created_at ASC')
      .all(req.params.id) as Record<string, unknown>[];

    const comments = rows
      .filter((r) => !blockedSet.has(String(r.author_username)))
      .map((r) => ({
        id: String(r.id),
        shortId: String(r.short_id),
        parentId: r.parent_id ? String(r.parent_id) : null,
        authorUsername: String(r.author_username),
        body: String(r.body),
        createdAt: String(r.created_at),
      }));

    res.json({ comments });
  });

  app.post('/api/shorts/:id/comments', (req, res) => {
    const { username, body, parentId } = req.body as {
      username?: string;
      body?: string;
      parentId?: string | null;
    };
    const author = String(username || '').trim();
    const cleanBody = String(body || '').trim();
    if (!author) {
      res.status(400).json({ error: 'Log in to post comments.' });
      return;
    }
    const siteCfg = getSiteSettingsRow();
    const commenterAcc = db
      .prepare('SELECT role FROM accounts WHERE username = ?')
      .get(author) as { role?: string } | undefined;
    if (!siteCfg.commentsEnabled && commenterAcc?.role !== 'super_admin') {
      res.status(403).json({ error: 'Comments are temporarily disabled by administration.' });
      return;
    }
    if (!cleanBody) {
      res.status(400).json({ error: 'Comment cannot be empty.' });
      return;
    }
    if (isRateLimited(commentSpamTimestamps, author, 10, 60 * 1000)) {
      res.status(429).json({
        error: 'Posting too fast. Please wait a moment before commenting again.',
      });
      return;
    }

    const id = `sc-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const createdAt = new Date().toISOString();
    db.prepare(
      `INSERT INTO shorts_comments (id, short_id, parent_id, author_username, body, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).run(id, req.params.id, parentId || null, author, cleanBody.slice(0, 400), createdAt);

    res.status(201).json({
      comment: {
        id,
        shortId: req.params.id,
        parentId: parentId || null,
        authorUsername: author,
        body: cleanBody.slice(0, 400),
        createdAt,
      },
    });
  });

  app.post('/api/shorts/:id/report', (req, res) => {
    const { username, reason, details } = req.body as {
      username?: string;
      reason?: string;
      details?: string;
    };
    const reporter = String(username || '').trim();
    if (!reporter) {
      res.status(400).json({ error: 'Log in to report content.' });
      return;
    }
    const id = `rep-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const createdAt = new Date().toISOString();
    db.prepare(
      `INSERT INTO shorts_reports (id, short_id, reporter_username, reason, details, status, created_at)
       VALUES (?, ?, ?, ?, ?, 'open', ?)`
    ).run(
      id,
      req.params.id,
      reporter,
      String(reason || 'Inappropriate content').slice(0, 80),
      String(details || '').slice(0, 400),
      createdAt
    );

    res.status(201).json({ ok: true });
  });

  app.post('/api/users/:target/follow', (req, res) => {
    const follower = String((req.body as { username?: string })?.username || '').trim();
    const target = req.params.target;
    if (!follower) {
      res.status(400).json({ error: 'Log in to follow creators.' });
      return;
    }
    if (follower === target) {
      res.status(400).json({ error: 'Cannot follow yourself.' });
      return;
    }
    const existing = db
      .prepare('SELECT 1 FROM user_follows WHERE follower_username = ? AND target_username = ?')
      .get(follower, target);

    if (existing) {
      db.prepare('DELETE FROM user_follows WHERE follower_username = ? AND target_username = ?').run(
        follower,
        target
      );
    } else {
      db.prepare(
        'INSERT INTO user_follows (follower_username, target_username, created_at) VALUES (?, ?, ?)'
      ).run(follower, target, new Date().toISOString());
    }

    const followerCountRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM user_follows WHERE target_username = ?')
      .get(target) as { cnt: number };

    res.json({
      isFollowing: !existing,
      followerCount: Number(followerCountRow?.cnt || 0),
    });
  });

  app.post('/api/users/:target/block', (req, res) => {
    const blocker = String((req.body as { username?: string })?.username || '').trim();
    const target = req.params.target;
    if (!blocker || blocker === target) {
      res.status(400).json({ error: 'Invalid block request.' });
      return;
    }
    db.prepare(
      'INSERT OR IGNORE INTO user_blocks (blocker_username, blocked_username, created_at) VALUES (?, ?, ?)'
    ).run(blocker, target, new Date().toISOString());
    res.json({ ok: true });
  });

  app.delete('/api/users/:target/block', (req, res) => {
    const blocker = String(req.query.username || '').trim();
    if (!blocker) {
      res.status(400).json({ error: 'Username required.' });
      return;
    }
    db.prepare('DELETE FROM user_blocks WHERE blocker_username = ? AND blocked_username = ?').run(
      blocker,
      req.params.target
    );
    res.json({ ok: true });
  });

  app.get('/api/users/:username/creator-profile', (req, res) => {
    const target = req.params.username;
    const viewer = String(req.query.viewer || '').trim();
    const acc = db
      .prepare('SELECT username, bio, avatar_url FROM accounts WHERE username = ?')
      .get(target) as { username?: string; bio?: string; avatar_url?: string } | undefined;

    const followerCountRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM user_follows WHERE target_username = ?')
      .get(target) as { cnt: number };
    const followingCountRow = db
      .prepare('SELECT COUNT(*) AS cnt FROM user_follows WHERE follower_username = ?')
      .get(target) as { cnt: number };

    const blockedSet = getBlockedUsersSet(viewer);
    const followingSet = getFollowingSet(viewer);

    const rows = db
      .prepare('SELECT * FROM shorts_videos WHERE author_username = ? ORDER BY created_at DESC')
      .all(target) as Record<string, unknown>[];

    const videos = rows
      .filter((r) => canViewShort(r, viewer, blockedSet, followingSet))
      .map((r) => formatShortRow(r, viewer));

    res.json({
      profile: {
        username: String(acc?.username || target),
        bio: String(acc?.bio || ''),
        avatarUrl: String(acc?.avatar_url || ''),
        followerCount: Number(followerCountRow?.cnt || 0),
        followingCount: Number(followingCountRow?.cnt || 0),
        isFollowing: followingSet.has(target),
        isBlocked: blockedSet.has(target),
        videos,
      },
    });
  });

  app.get('/api/users/:username/safety', (req, res) => {
    const user = req.params.username;
    const blockedRows = db
      .prepare('SELECT blocked_username FROM user_blocks WHERE blocker_username = ? ORDER BY created_at DESC')
      .all(user) as { blocked_username: string }[];
    const usageRow = db
      .prepare('SELECT COALESCE(SUM(size_bytes), 0) AS total FROM shorts_videos WHERE author_username = ?')
      .get(user) as { total: number };

    res.json({
      blockedUsers: blockedRows.map((r) => String(r.blocked_username)),
      videoBytesUsed: Number(usageRow?.total || 0),
      videoQuotaBytes: MAX_USER_VIDEO_QUOTA,
    });
  });

  // ============================================================================
  // PUBLIC SITE STATE (GOD MODE TOGGLES, ANNOUNCEMENTS, VERIFIED ROLES/BADGES)
  // ============================================================================
  app.get('/api/site-state', (_req, res) => {
    const settings = getSiteSettingsRow();
    const now = new Date().toISOString();
    const annRows = db
      .prepare(
        `SELECT * FROM announcements
         WHERE scheduled_at IS NULL OR scheduled_at <= ?
         ORDER BY is_pinned DESC, created_at DESC`
      )
      .all(now) as Record<string, unknown>[];

    const roleRows = db
      .prepare("SELECT username, role FROM accounts WHERE is_deleted = 0 AND role != 'member'")
      .all() as { username: string; role: string }[];

    const rolesByUsername: Record<string, RoleName> = { barut: 'super_admin' };
    for (const r of roleRows) {
      rolesByUsername[String(r.username)] = String(r.role) as RoleName;
    }

    const flagRows = db
      .prepare("SELECT username, flags_json FROM accounts WHERE is_deleted = 0 AND flags_json IS NOT NULL AND flags_json != '[]'")
      .all() as { username: string; flags_json: string }[];
    const flagsByUsername: Record<string, string[]> = {};
    for (const row of flagRows) {
      try {
        const parsed = JSON.parse(String(row.flags_json || '[]'));
        if (Array.isArray(parsed) && parsed.length > 0) {
          flagsByUsername[String(row.username)] = parsed.map(String);
        }
      } catch {
        // ignore invalid json
      }
    }

    res.json({
      settings,
      announcements: annRows.map((a) => ({
        id: String(a.id),
        title: String(a.title),
        body: String(a.body),
        category: String(a.category || 'normal'),
        isPinned: Number(a.is_pinned) === 1,
        showBanner: Number(a.show_banner) === 1,
        sendToNotifications: Number(a.send_to_notifications) === 1,
        scheduledAt: a.scheduled_at ? String(a.scheduled_at) : null,
        authorUsername: String(a.author_username),
        createdAt: String(a.created_at),
        updatedAt: String(a.updated_at),
      })),
      rolesByUsername,
      flagsByUsername,
    });
  });

  // ============================================================================
  // MY DESKTOP: OPTIONAL VIRTUAL DESKTOP PERSISTENCE & PRIVACY-SAFE SHARING
  // ============================================================================
  app.get('/api/desktop/:username', (req, res) => {
    const target = req.params.username;
    const authed = getAuthenticatedUser(req);
    const viewer = authed?.username || String(req.query.viewer || '').trim();
    const isOwner = Boolean(viewer && viewer === target);

    const row = db
      .prepare('SELECT * FROM user_desktops WHERE username = ?')
      .get(target) as Record<string, unknown> | undefined;

    if (!row) {
      if (!isOwner) {
        res.status(404).json({ error: 'This desktop is private or not configured yet.' });
        return;
      }
      res.json({
        desktop: {
          username: target,
          isPublic: false,
          isOwner: true,
          config: null,
          notes: [],
          files: [],
          calendarEvents: [],
          updatedAt: new Date().toISOString(),
        },
      });
      return;
    }

    const isPublic = Number(row.is_public) === 1;
    if (!isOwner && !isPublic) {
      res.status(403).json({ error: "This user's My Desktop is set to Private." });
      return;
    }

    // Strict privacy: never expose private notes, files, or calendar events publicly
    res.json({
      desktop: {
        username: target,
        isPublic,
        isOwner,
        config: JSON.parse(String(row.config_json)),
        notes: isOwner ? JSON.parse(String(row.notes_json || '[]')) : [],
        files: isOwner ? JSON.parse(String(row.files_json || '[]')) : [],
        calendarEvents: isOwner ? JSON.parse(String(row.calendar_json || '[]')) : [],
        updatedAt: String(row.updated_at),
      },
    });
  });

  app.put('/api/desktop/:username', (req, res) => {
    const target = req.params.username;
    const authed = getAuthenticatedUser(req);
    if (!authed || (authed.username !== target && authed.role !== 'super_admin')) {
      res.status(authed ? 403 : 401).json({ error: 'Authentication required to save your desktop.' });
      return;
    }
    const { isPublic, config, notes, files, calendarEvents } = req.body as {
      isPublic?: boolean;
      config?: unknown;
      notes?: unknown;
      files?: unknown;
      calendarEvents?: unknown;
    };
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO user_desktops (username, is_public, config_json, notes_json, files_json, calendar_json, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(username) DO UPDATE SET
         is_public = excluded.is_public,
         config_json = excluded.config_json,
         notes_json = excluded.notes_json,
         files_json = excluded.files_json,
         calendar_json = excluded.calendar_json,
         updated_at = excluded.updated_at`
    ).run(
      target,
      isPublic ? 1 : 0,
      JSON.stringify(config || {}),
      JSON.stringify(Array.isArray(notes) ? notes : []),
      JSON.stringify(Array.isArray(files) ? files : []),
      JSON.stringify(Array.isArray(calendarEvents) ? calendarEvents : []),
      now
    );

    res.json({
      desktop: {
        username: target,
        isPublic: Boolean(isPublic),
        isOwner: true,
        config,
        notes: Array.isArray(notes) ? notes : [],
        files: Array.isArray(files) ? files : [],
        calendarEvents: Array.isArray(calendarEvents) ? calendarEvents : [],
        updatedAt: now,
      },
    });
  });

  // ============================================================================
  // BARUT SUPER ADMIN SYSTEM + GOD MODE API (SERVER-SIDE ROLE ENFORCEMENT)
  // ============================================================================
  app.get('/api/admin/overview', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;

    const totalUsers = (
      db.prepare('SELECT COUNT(*) AS cnt FROM accounts WHERE is_deleted = 0').get() as { cnt: number }
    ).cnt;
    const suspendedAccounts = (
      db
        .prepare("SELECT COUNT(*) AS cnt FROM accounts WHERE is_deleted = 0 AND status = 'suspended'")
        .get() as { cnt: number }
    ).cnt;
    const bannedAccounts = (
      db
        .prepare("SELECT COUNT(*) AS cnt FROM accounts WHERE is_deleted = 0 AND status = 'banned'")
        .get() as { cnt: number }
    ).cnt;
    const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
    const onlineUsers = (
      db
        .prepare('SELECT COUNT(*) AS cnt FROM accounts WHERE is_deleted = 0 AND last_seen_at >= ?')
        .get(fiveMinAgo) as { cnt: number }
    ).cnt;
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const newRegistrations7d = (
      db
        .prepare('SELECT COUNT(*) AS cnt FROM accounts WHERE is_deleted = 0 AND created_at >= ?')
        .get(sevenDaysAgo) as { cnt: number }
    ).cnt;

    const blogRows = db.prepare('SELECT is_deleted, comments_json FROM blog_posts').all() as {
      is_deleted: number;
      comments_json: string;
    }[];
    const topicRows = db.prepare('SELECT is_deleted, replies_json FROM forum_topics').all() as {
      is_deleted: number;
      replies_json: string;
    }[];

    let totalComments = 0;
    let deletedPosts = 0;
    for (const b of blogRows) {
      if (Number(b.is_deleted) === 1) deletedPosts += 1;
      try {
        totalComments += (JSON.parse(String(b.comments_json || '[]')) as unknown[]).length;
      } catch {
        // ignore
      }
    }
    for (const t of topicRows) {
      if (Number(t.is_deleted) === 1) deletedPosts += 1;
      try {
        totalComments += (JSON.parse(String(t.replies_json || '[]')) as unknown[]).length;
      } catch {
        // ignore
      }
    }
    const shortCommentsCnt = (
      db.prepare('SELECT COUNT(*) AS cnt FROM shorts_comments').get() as { cnt: number }
    ).cnt;
    totalComments += shortCommentsCnt;

    const openReports = (
      db.prepare("SELECT COUNT(*) AS cnt FROM shorts_reports WHERE status = 'open'").get() as {
        cnt: number;
      }
    ).cnt;

    const adminRows = db
      .prepare(
        "SELECT username, bio, avatar_url, role, status, is_deleted, created_at, last_seen_at FROM accounts WHERE role IN ('super_admin', 'admin', 'moderator') AND is_deleted = 0 ORDER BY CASE role WHEN 'super_admin' THEN 1 WHEN 'admin' THEN 2 ELSE 3 END, username ASC"
      )
      .all() as Record<string, unknown>[];

    const recentLogs = db
      .prepare('SELECT * FROM admin_audit_logs ORDER BY created_at DESC LIMIT 15')
      .all() as Record<string, unknown>[];

    const recentReportsRows = db
      .prepare('SELECT * FROM shorts_reports ORDER BY created_at DESC LIMIT 10')
      .all() as Record<string, unknown>[];

    res.json({
      stats: {
        totalUsers,
        totalPosts:
          blogRows.filter((b) => Number(b.is_deleted) === 0).length +
          topicRows.filter((t) => Number(t.is_deleted) === 0).length,
        onlineUsers,
        totalComments,
        newRegistrations7d,
        openReports,
        suspendedAccounts,
        bannedAccounts,
        deletedPosts,
      },
      administrators: adminRows.map((u) => ({
        username: String(u.username),
        bio: String(u.bio || ''),
        avatarUrl: String(u.avatar_url || ''),
        role: String(u.role) as RoleName,
        status: String(u.status || 'active'),
        isDeleted: Number(u.is_deleted) === 1,
        createdAt: String(u.created_at || ''),
        lastSeenAt: String(u.last_seen_at || ''),
        postCount: 0,
        topicCount: 0,
        shortCount: 0,
      })),
      recentLogs: recentLogs.map((l) => ({
        id: String(l.id),
        actorUsername: String(l.actor_username),
        actorRole: String(l.actor_role),
        action: String(l.action),
        targetType: String(l.target_type),
        targetId: String(l.target_id),
        details: String(l.details || ''),
        result: String(l.result),
        createdAt: String(l.created_at),
      })),
      recentReports: recentReportsRows.map((r) => {
        const sRow = db
          .prepare('SELECT title, author_username FROM shorts_videos WHERE id = ?')
          .get(String(r.short_id)) as { title?: string; author_username?: string } | undefined;
        return {
          id: String(r.id),
          shortId: String(r.short_id),
          shortTitle: String(sRow?.title || '[Deleted Short]'),
          shortAuthor: String(sRow?.author_username || 'unknown'),
          reporterUsername: String(r.reporter_username),
          reason: String(r.reason),
          status: String(r.status || 'open'),
          createdAt: String(r.created_at),
        };
      }),
    });
  });

  app.get('/api/admin/users', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;

    const q = String(req.query.q || '').trim().toLowerCase();
    const rows = db
      .prepare('SELECT username, bio, avatar_url, role, status, is_deleted, created_at, last_seen_at FROM accounts ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];

    const formatted = rows
      .filter((u) => !q || String(u.username).toLowerCase().includes(q))
      .map((u) => {
        const uname = String(u.username);
        const postCount = (
          db.prepare('SELECT COUNT(*) AS cnt FROM blog_posts WHERE author = ?').get(uname) as {
            cnt: number;
          }
        ).cnt;
        const topicCount = (
          db.prepare('SELECT COUNT(*) AS cnt FROM forum_topics WHERE author = ?').get(uname) as {
            cnt: number;
          }
        ).cnt;
        const shortCount = (
          db
            .prepare('SELECT COUNT(*) AS cnt FROM shorts_videos WHERE author_username = ?')
            .get(uname) as { cnt: number }
        ).cnt;
        return {
          username: uname,
          bio: String(u.bio || ''),
          avatarUrl: String(u.avatar_url || ''),
          role: (uname === 'barut' ? 'super_admin' : String(u.role || 'member')) as RoleName,
          status: String(u.status || 'active'),
          isDeleted: Number(u.is_deleted) === 1,
          createdAt: String(u.created_at || ''),
          lastSeenAt: String(u.last_seen_at || ''),
          postCount,
          topicCount,
          shortCount,
        };
      });

    res.json({ users: formatted });
  });

  app.patch('/api/admin/users/:username', (req, res) => {
    const staff = requireStaff(req, res, 'admin');
    if (!staff) return;
    const target = req.params.username;
    if (target === 'barut' && staff.role !== 'super_admin') {
      res.status(403).json({ error: 'Cannot modify Super Admin account.' });
      return;
    }

    const { bio, avatarUrl } = req.body as { bio?: string; avatarUrl?: string };
    const row = db
      .prepare('SELECT * FROM accounts WHERE username = ?')
      .get(target) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    db.prepare('UPDATE accounts SET bio = ?, avatar_url = ? WHERE username = ?').run(
      bio !== undefined ? bio.slice(0, 240) : String(row.bio || ''),
      avatarUrl !== undefined ? avatarUrl : String(row.avatar_url || ''),
      target
    );
    writeAuditLog(staff, 'EDIT_USER_PROFILE', 'user', target, 'Updated bio/avatar');
    const updated = db
      .prepare('SELECT username, bio, avatar_url, role, status, is_deleted, created_at, last_seen_at FROM accounts WHERE username = ?')
      .get(target) as Record<string, unknown>;
    res.json({
      user: {
        username: String(updated.username),
        bio: String(updated.bio || ''),
        avatarUrl: String(updated.avatar_url || ''),
        role: String(updated.role || 'member'),
        status: String(updated.status || 'active'),
        isDeleted: Number(updated.is_deleted) === 1,
        createdAt: String(updated.created_at || ''),
        lastSeenAt: String(updated.last_seen_at || ''),
        postCount: 0,
        topicCount: 0,
        shortCount: 0,
      },
    });
  });

  app.post('/api/admin/users/:username/rename', (req, res) => {
    const staff = requireStaff(req, res, 'admin');
    if (!staff) return;
    const target = req.params.username;
    if (target === 'barut') {
      res.status(403).json({ error: 'Super Admin username cannot be renamed.' });
      return;
    }
    const newUsername = String((req.body as { newUsername?: string })?.newUsername || '').trim();
    if (newUsername.length < 2 || newUsername.length > 24 || newUsername.toLowerCase() === 'barut') {
      res.status(400).json({ error: 'Invalid new username.' });
      return;
    }
    const conflict = db
      .prepare('SELECT 1 FROM accounts WHERE LOWER(username) = LOWER(?)')
      .get(newUsername);
    if (conflict) {
      res.status(409).json({ error: 'Target username is already taken.' });
      return;
    }

    db.prepare('UPDATE accounts SET username = ? WHERE username = ?').run(newUsername, target);
    db.prepare('UPDATE blog_posts SET author = ? WHERE author = ?').run(newUsername, target);
    db.prepare('UPDATE forum_topics SET author = ? WHERE author = ?').run(newUsername, target);
    db.prepare('UPDATE shorts_videos SET author_username = ? WHERE author_username = ?').run(
      newUsername,
      target
    );
    db.prepare('UPDATE homepages SET username = ? WHERE username = ?').run(newUsername, target);
    db.prepare('UPDATE playlists SET owner_username = ? WHERE owner_username = ?').run(
      newUsername,
      target
    );

    writeAuditLog(staff, 'RENAME_USER', 'user', target, `Renamed to ${newUsername}`);
    const updated = db
      .prepare('SELECT username, bio, avatar_url, role, status, is_deleted, created_at, last_seen_at FROM accounts WHERE username = ?')
      .get(newUsername) as Record<string, unknown>;
    res.json({
      user: {
        username: String(updated.username),
        bio: String(updated.bio || ''),
        avatarUrl: String(updated.avatar_url || ''),
        role: String(updated.role || 'member'),
        status: String(updated.status || 'active'),
        isDeleted: Number(updated.is_deleted) === 1,
        createdAt: String(updated.created_at || ''),
        lastSeenAt: String(updated.last_seen_at || ''),
        postCount: 0,
        topicCount: 0,
        shortCount: 0,
      },
    });
  });

  app.post('/api/admin/users/:username/status', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const target = req.params.username;
    const status = String((req.body as { status?: string })?.status || '');
    if (!['active', 'suspended', 'banned'].includes(status)) {
      res.status(400).json({ error: 'Invalid status value.' });
      return;
    }
    const targetRow = db
      .prepare('SELECT role FROM accounts WHERE username = ?')
      .get(target) as { role?: string } | undefined;
    if (!targetRow) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    if (target === 'barut' || targetRow.role === 'super_admin') {
      res.status(403).json({ error: 'The Super Admin cannot be suspended or banned.' });
      return;
    }
    if (targetRow.role === 'admin' && staff.role !== 'super_admin') {
      res.status(403).json({ error: 'Only Super Admin can change status of an Administrator.' });
      return;
    }
    db.prepare('UPDATE accounts SET status = ?, is_deleted = 0 WHERE username = ?').run(
      status,
      target
    );
    writeAuditLog(staff, `SET_STATUS_${status.toUpperCase()}`, 'user', target, `Status -> ${status}`);
    const updated = db
      .prepare('SELECT username, bio, avatar_url, role, status, is_deleted, created_at, last_seen_at FROM accounts WHERE username = ?')
      .get(target) as Record<string, unknown>;
    res.json({
      user: {
        username: String(updated.username),
        bio: String(updated.bio || ''),
        avatarUrl: String(updated.avatar_url || ''),
        role: String(updated.role || 'member'),
        status: String(updated.status || 'active'),
        isDeleted: Number(updated.is_deleted) === 1,
        createdAt: String(updated.created_at || ''),
        lastSeenAt: String(updated.last_seen_at || ''),
        postCount: 0,
        topicCount: 0,
        shortCount: 0,
      },
    });
  });

  app.post('/api/admin/users/:username/role', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    const target = req.params.username;
    const role = String((req.body as { role?: string })?.role || '');
    if (!['admin', 'moderator', 'member'].includes(role)) {
      res.status(400).json({ error: 'Invalid assignable role. Super Admin cannot be assigned.' });
      return;
    }
    if (target === 'barut') {
      res.status(403).json({ error: 'Super Admin role cannot be modified.' });
      return;
    }
    const targetRow = db.prepare('SELECT 1 FROM accounts WHERE username = ?').get(target);
    if (!targetRow) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    db.prepare('UPDATE accounts SET role = ? WHERE username = ?').run(role, target);
    writeAuditLog(staff, 'ASSIGN_ROLE', 'user', target, `Role set to ${role}`);
    const updated = db
      .prepare('SELECT username, bio, avatar_url, role, status, is_deleted, created_at, last_seen_at FROM accounts WHERE username = ?')
      .get(target) as Record<string, unknown>;
    res.json({
      user: {
        username: String(updated.username),
        bio: String(updated.bio || ''),
        avatarUrl: String(updated.avatar_url || ''),
        role: String(updated.role || 'member'),
        status: String(updated.status || 'active'),
        isDeleted: Number(updated.is_deleted) === 1,
        createdAt: String(updated.created_at || ''),
        lastSeenAt: String(updated.last_seen_at || ''),
        postCount: 0,
        topicCount: 0,
        shortCount: 0,
      },
    });
  });

  app.delete('/api/admin/users/:username', (req, res) => {
    const staff = requireStaff(req, res, 'admin');
    if (!staff) return;
    const target = req.params.username;
    const targetRow = db
      .prepare('SELECT role FROM accounts WHERE username = ?')
      .get(target) as { role?: string } | undefined;
    if (!targetRow) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    if (target === 'barut' || targetRow.role === 'super_admin') {
      res.status(403).json({ error: 'The Super Admin cannot be deleted.' });
      return;
    }
    if (targetRow.role === 'admin' && staff.role !== 'super_admin') {
      res.status(403).json({ error: 'Only Super Admin can delete an Administrator.' });
      return;
    }
    db.prepare(
      "UPDATE accounts SET is_deleted = 1, status = 'banned', token_version = token_version + 1 WHERE username = ?"
    ).run(target);
    writeAuditLog(staff, 'DELETE_USER', 'user', target, 'Account soft-deleted and tokens revoked');
    res.json({ ok: true });
  });

  app.get('/api/admin/posts', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const q = String(req.query.q || '').trim().toLowerCase();

    const blogRows = db
      .prepare('SELECT * FROM blog_posts ORDER BY is_pinned DESC, rowid DESC')
      .all() as Record<string, unknown>[];
    const topicRows = db
      .prepare('SELECT * FROM forum_topics ORDER BY is_pinned DESC, rowid DESC')
      .all() as Record<string, unknown>[];

    const posts = [
      ...blogRows.map((b) => ({
        id: String(b.id),
        kind: 'blog' as const,
        author: String(b.author),
        title: String(b.activity_tag || 'Feed Post'),
        content: String(b.content || ''),
        createdAt: String(b.created_at || b.timestamp || ''),
        isDeleted: Number(b.is_deleted || 0) === 1,
        isPinned: Number(b.is_pinned || 0) === 1,
        deletedBy: String(b.deleted_by || ''),
        deletedAt: String(b.deleted_at || ''),
        comments: JSON.parse(String(b.comments_json || '[]')),
        likeCount: (JSON.parse(String(b.likes_json || '[]')) as unknown[]).length,
      })),
      ...topicRows.map((t) => ({
        id: String(t.id),
        kind: 'forum' as const,
        author: String(t.author),
        title: String(t.title),
        content: String(t.body || ''),
        createdAt: String(t.created_at || ''),
        isDeleted: Number(t.is_deleted || 0) === 1,
        isPinned: Number(t.is_pinned || 0) === 1,
        deletedBy: String(t.deleted_by || ''),
        deletedAt: String(t.deleted_at || ''),
        comments: (JSON.parse(String(t.replies_json || '[]')) as Array<{
          id: string;
          author: string;
          body: string;
          createdAt: string;
        }>).map((r) => ({
          id: r.id,
          author: r.author,
          text: r.body,
          time: r.createdAt,
        })),
        likeCount: Number(t.views || 0),
      })),
    ].filter(
      (p) =>
        !q ||
        p.title.toLowerCase().includes(q) ||
        p.content.toLowerCase().includes(q) ||
        p.author.toLowerCase().includes(q)
    );

    res.json({ posts });
  });

  app.patch('/api/admin/posts/:id', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const { kind, content, title, isPinned } = req.body as {
      kind?: 'blog' | 'forum';
      content?: string;
      title?: string;
      isPinned?: boolean;
    };
    const id = req.params.id;
    if (kind === 'forum') {
      const row = db.prepare('SELECT * FROM forum_topics WHERE id = ?').get(id) as
        | Record<string, unknown>
        | undefined;
      if (!row) {
        res.status(404).json({ error: 'Topic not found.' });
        return;
      }
      db.prepare('UPDATE forum_topics SET title = ?, body = ?, is_pinned = ? WHERE id = ?').run(
        title !== undefined ? title : String(row.title),
        content !== undefined ? content : String(row.body),
        isPinned !== undefined ? (isPinned ? 1 : 0) : Number(row.is_pinned || 0),
        id
      );
    } else {
      const row = db.prepare('SELECT * FROM blog_posts WHERE id = ?').get(id) as
        | Record<string, unknown>
        | undefined;
      if (!row) {
        res.status(404).json({ error: 'Post not found.' });
        return;
      }
      db.prepare('UPDATE blog_posts SET content = ?, is_pinned = ? WHERE id = ?').run(
        content !== undefined ? content : String(row.content),
        isPinned !== undefined ? (isPinned ? 1 : 0) : Number(row.is_pinned || 0),
        id
      );
    }
    writeAuditLog(
      staff,
      isPinned !== undefined ? (isPinned ? 'PIN_POST' : 'UNPIN_POST') : 'EDIT_POST',
      kind || 'blog',
      id,
      title || (content ? content.slice(0, 60) : '')
    );
    res.json({ ok: true });
  });

  app.delete('/api/admin/posts/:id', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const kind = String(req.query.kind || 'blog');
    const now = new Date().toISOString();
    const table = kind === 'forum' ? 'forum_topics' : 'blog_posts';
    db.prepare(
      `UPDATE ${table} SET is_deleted = 1, deleted_by = ?, deleted_at = ? WHERE id = ?`
    ).run(staff.username, now, req.params.id);
    writeAuditLog(staff, 'DELETE_POST', kind, req.params.id, 'Soft-deleted with backup');
    res.json({ ok: true });
  });

  app.post('/api/admin/posts/:id/restore', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const kind = String((req.body as { kind?: string })?.kind || 'blog');
    const table = kind === 'forum' ? 'forum_topics' : 'blog_posts';
    db.prepare(
      `UPDATE ${table} SET is_deleted = 0, deleted_by = '', deleted_at = '' WHERE id = ?`
    ).run(req.params.id);
    writeAuditLog(staff, 'RESTORE_POST', kind, req.params.id, 'Restored deleted post');
    res.json({ ok: true });
  });

  app.delete('/api/admin/posts/:id/comments/:commentId', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const kind = String(req.query.kind || 'blog');
    if (kind === 'forum') {
      const row = db
        .prepare('SELECT replies_json FROM forum_topics WHERE id = ?')
        .get(req.params.id) as { replies_json?: string } | undefined;
      if (row) {
        const replies = JSON.parse(String(row.replies_json || '[]')) as { id: string }[];
        const next = replies.filter((r) => r.id !== req.params.commentId);
        db.prepare('UPDATE forum_topics SET replies_json = ? WHERE id = ?').run(
          JSON.stringify(next),
          req.params.id
        );
      }
    } else {
      const row = db
        .prepare('SELECT comments_json FROM blog_posts WHERE id = ?')
        .get(req.params.id) as { comments_json?: string } | undefined;
      if (row) {
        const comments = JSON.parse(String(row.comments_json || '[]')) as { id: string }[];
        const next = comments.filter((c) => c.id !== req.params.commentId);
        db.prepare('UPDATE blog_posts SET comments_json = ? WHERE id = ?').run(
          JSON.stringify(next),
          req.params.id
        );
      }
    }
    writeAuditLog(
      staff,
      'DELETE_COMMENT',
      kind,
      `${req.params.id}:${req.params.commentId}`,
      'Removed comment'
    );
    res.json({ ok: true });
  });

  app.get('/api/admin/god-mode', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    res.json({ settings: getSiteSettingsRow() });
  });

  app.patch('/api/admin/god-mode', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    const current = getSiteSettingsRow();
    const patch = req.body as Partial<typeof current>;
    const next = { ...current, ...patch };
    db.prepare(
      `UPDATE site_settings
       SET maintenance_mode = ?, maintenance_message = ?, registration_enabled = ?,
           posting_enabled = ?, comments_enabled = ?, chat_enabled = ?,
           global_banner_text = ?, global_banner_enabled = ?, site_notice = ?
       WHERE id = 1`
    ).run(
      next.maintenanceMode ? 1 : 0,
      String(next.maintenanceMessage || ''),
      next.registrationEnabled ? 1 : 0,
      next.postingEnabled ? 1 : 0,
      next.commentsEnabled ? 1 : 0,
      next.chatEnabled ? 1 : 0,
      String(next.globalBannerText || ''),
      next.globalBannerEnabled ? 1 : 0,
      String(next.siteNotice || '')
    );
    writeAuditLog(
      staff,
      'GOD_MODE_SETTINGS',
      'site_settings',
      '1',
      `Maintenance=${next.maintenanceMode}, Reg=${next.registrationEnabled}, Post=${next.postingEnabled}, Comments=${next.commentsEnabled}, Chat=${next.chatEnabled}`
    );
    res.json({ settings: getSiteSettingsRow() });
  });

  app.post('/api/admin/god-mode/restore-all', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    db.prepare(
      `UPDATE site_settings
       SET maintenance_mode = 0, registration_enabled = 1, posting_enabled = 1,
           comments_enabled = 1, chat_enabled = 1
       WHERE id = 1`
    ).run();
    writeAuditLog(staff, 'GOD_MODE_RESTORE_ALL', 'site_settings', '1', 'Restored all features');
    res.json({ settings: getSiteSettingsRow() });
  });

  app.get('/api/admin/announcements', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const rows = db
      .prepare('SELECT * FROM announcements ORDER BY is_pinned DESC, created_at DESC')
      .all() as Record<string, unknown>[];
    res.json({
      announcements: rows.map((a) => ({
        id: String(a.id),
        title: String(a.title),
        body: String(a.body),
        category: String(a.category || 'normal'),
        isPinned: Number(a.is_pinned) === 1,
        showBanner: Number(a.show_banner) === 1,
        sendToNotifications: Number(a.send_to_notifications) === 1,
        scheduledAt: a.scheduled_at ? String(a.scheduled_at) : null,
        authorUsername: String(a.author_username),
        createdAt: String(a.created_at),
        updatedAt: String(a.updated_at),
      })),
    });
  });

  app.post('/api/admin/announcements', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    const {
      title,
      body,
      category,
      isPinned,
      showBanner,
      sendToNotifications,
      scheduledAt,
    } = req.body as {
      title?: string;
      body?: string;
      category?: string;
      isPinned?: boolean;
      showBanner?: boolean;
      sendToNotifications?: boolean;
      scheduledAt?: string | null;
    };
    const cleanTitle = String(title || '').trim();
    const cleanBody = String(body || '').trim();
    if (!cleanTitle || !cleanBody) {
      res.status(400).json({ error: 'Title and body are required.' });
      return;
    }
    const id = `ann-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO announcements (id, title, body, category, is_pinned, show_banner, send_to_notifications, scheduled_at, author_username, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      cleanTitle,
      cleanBody,
      String(category || 'normal'),
      isPinned ? 1 : 0,
      showBanner !== false ? 1 : 0,
      sendToNotifications !== false ? 1 : 0,
      scheduledAt || null,
      staff.username,
      now,
      now
    );
    writeAuditLog(staff, 'PUBLISH_ANNOUNCEMENT', 'announcement', id, cleanTitle);
    const row = db
      .prepare('SELECT * FROM announcements WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.status(201).json({
      announcement: {
        id: String(row.id),
        title: String(row.title),
        body: String(row.body),
        category: String(row.category),
        isPinned: Number(row.is_pinned) === 1,
        showBanner: Number(row.show_banner) === 1,
        sendToNotifications: Number(row.send_to_notifications) === 1,
        scheduledAt: row.scheduled_at ? String(row.scheduled_at) : null,
        authorUsername: String(row.author_username),
        createdAt: String(row.created_at),
        updatedAt: String(row.updated_at),
      },
    });
  });

  app.patch('/api/admin/announcements/:id', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    const row = db
      .prepare('SELECT * FROM announcements WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Announcement not found.' });
      return;
    }
    const patch = req.body as {
      title?: string;
      body?: string;
      category?: string;
      isPinned?: boolean;
      showBanner?: boolean;
      sendToNotifications?: boolean;
      scheduledAt?: string | null;
    };
    const now = new Date().toISOString();
    db.prepare(
      `UPDATE announcements
       SET title = ?, body = ?, category = ?, is_pinned = ?, show_banner = ?, send_to_notifications = ?, scheduled_at = ?, updated_at = ?
       WHERE id = ?`
    ).run(
      patch.title !== undefined ? patch.title : String(row.title),
      patch.body !== undefined ? patch.body : String(row.body),
      patch.category !== undefined ? patch.category : String(row.category),
      patch.isPinned !== undefined ? (patch.isPinned ? 1 : 0) : Number(row.is_pinned),
      patch.showBanner !== undefined ? (patch.showBanner ? 1 : 0) : Number(row.show_banner),
      patch.sendToNotifications !== undefined
        ? patch.sendToNotifications
          ? 1
          : 0
        : Number(row.send_to_notifications),
      patch.scheduledAt !== undefined ? patch.scheduledAt : (row.scheduled_at as string | null),
      now,
      req.params.id
    );
    writeAuditLog(staff, 'EDIT_ANNOUNCEMENT', 'announcement', req.params.id, patch.title || '');
    const updated = db
      .prepare('SELECT * FROM announcements WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({
      announcement: {
        id: String(updated.id),
        title: String(updated.title),
        body: String(updated.body),
        category: String(updated.category),
        isPinned: Number(updated.is_pinned) === 1,
        showBanner: Number(updated.show_banner) === 1,
        sendToNotifications: Number(updated.send_to_notifications) === 1,
        scheduledAt: updated.scheduled_at ? String(updated.scheduled_at) : null,
        authorUsername: String(updated.author_username),
        createdAt: String(updated.created_at),
        updatedAt: String(updated.updated_at),
      },
    });
  });

  app.delete('/api/admin/announcements/:id', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    db.prepare('DELETE FROM announcements WHERE id = ?').run(req.params.id);
    writeAuditLog(staff, 'DELETE_ANNOUNCEMENT', 'announcement', req.params.id, 'Deleted');
    res.json({ ok: true });
  });

  app.get('/api/admin/logs', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const q = String(req.query.q || '').trim().toLowerCase();
    const actionFilter = String(req.query.action || '').trim().toLowerCase();
    const rows = db
      .prepare('SELECT * FROM admin_audit_logs ORDER BY created_at DESC LIMIT 250')
      .all() as Record<string, unknown>[];

    const filtered = rows
      .filter((l) => {
        if (actionFilter && actionFilter !== 'all' && !String(l.action).toLowerCase().includes(actionFilter)) {
          return false;
        }
        if (!q) return true;
        return (
          String(l.actor_username).toLowerCase().includes(q) ||
          String(l.action).toLowerCase().includes(q) ||
          String(l.target_id).toLowerCase().includes(q) ||
          String(l.details || '').toLowerCase().includes(q)
        );
      })
      .map((l) => ({
        id: String(l.id),
        actorUsername: String(l.actor_username),
        actorRole: String(l.actor_role),
        action: String(l.action),
        targetType: String(l.target_type),
        targetId: String(l.target_id),
        details: String(l.details || ''),
        result: String(l.result),
        createdAt: String(l.created_at),
      }));

    res.json({ logs: filtered });
  });

  app.post('/api/admin/security/rotate-tokens', (req, res) => {
    const staff = requireStaff(req, res, 'super_admin');
    if (!staff) return;
    db.prepare("UPDATE accounts SET token_version = token_version + 1 WHERE username != 'barut'").run();
    writeAuditLog(staff, 'ROTATE_USER_TOKENS', 'security', 'all_non_super', 'Invalidated non-super-admin sessions');
    res.json({ ok: true, message: 'All non-Super Admin session tokens invalidated.' });
  });

  // Vite dev middleware or static dist serving
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`LOSTROOM.BXE server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start LOSTROOM.BXE server:', err);
  process.exit(1);
});
