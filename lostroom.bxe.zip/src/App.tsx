import React, { useCallback, useEffect, useState } from 'react';
import { BarutBadge } from './components/BarutBadge';
import { MyDesktopModal } from './components/MyDesktopModal';
import {
  DeskAdminIcon,
  DeskChatIcon,
  DeskDesktopIcon,
  DeskExploreIcon,
  DeskFeedIcon,
  DeskForumIcon,
  DeskHomepageIcon,
  DeskMusicIcon,
  DeskPortalIcon,
  DeskSearchIcon,
  DeskShortsIcon,
  DeskThemeIcon,
  DeskUploadIcon,
} from './components/PixelIcons';
import { PrivateChatPanel } from './components/PrivateChatPanel';
import { AvatarBox } from './components/RetroMedia';
import { DEFAULT_FORUM_CATEGORIES } from './data/seedData';
import { AdminDashboardPage } from './pages/AdminDashboardPage';
import { ExplorePage } from './pages/ExplorePage';
import { ForumPage } from './pages/ForumPage';
import { FriendsPage } from './pages/FriendsPage';
import { HomeFeedPage } from './pages/HomeFeedPage';
import { LandingPage } from './pages/LandingPage';
import { MyHomepagePage } from './pages/MyHomepagePage';
import { PlaylistsPage } from './pages/PlaylistsPage';
import { ProfilePage } from './pages/ProfilePage';
import { PublicHomepageView } from './pages/PublicHomepageView';
import { PublicPlaylistPage } from './pages/PublicPlaylistPage';
import { PublicShortView } from './pages/PublicShortView';
import { SearchPage } from './pages/SearchPage';
import { SettingsPage } from './pages/SettingsPage';
import { ShortsPage } from './pages/ShortsPage';
import { DEFAULT_THEME_VARIABLES, ThemeEditorPage } from './pages/ThemeEditorPage';
import { UploadPage } from './pages/UploadPage';
import { SitePublicState } from './types/admin';
import {
  fetchSessionMe,
  fetchSiteState,
  loginWithServer,
  registerWithServer,
  setAuthToken,
} from './utils/adminApi';
import {
  deleteBlogPostFromDb,
  saveUserFlags,
  syncAccount,
  syncCommunityToDatabase,
  upsertBlogPostToDb,
  upsertForumTopicToDb,
} from './utils/homepageApi';
import { clearAllVideoBlobs, deleteVideoBlob } from './utils/mediaDb';
import {
  ChatMessage,
  ForumCategory,
  ForumTopic,
  FriendRequest,
  NotificationItem,
  PageId,
  PostItem,
  ThemeVariables,
  UserAccount,
  UserRole,
} from './types/lostroom';

const STORAGE_KEY = 'lostroom_bxe_clean_node_v3';

interface PersistedState {
  currentUser: string | null;
  activeView: PageId;
  portalTab: 'login' | 'register';
  viewingProfileUsername: string | null;
  activeChatPartner: string;
  chatSeenStatus: boolean;
  crtEnabled: boolean;
  strictPixelFont: boolean;
  users: Record<string, UserAccount>;
  posts: PostItem[];
  categories: ForumCategory[];
  topics: ForumTopic[];
  friendRequests: FriendRequest[];
  conversations: Record<string, ChatMessage[]>;
  notifications: NotificationItem[];
}

interface ToastItem {
  id: string;
  msg: string;
  type: 'info' | 'error';
}

function getDefaultState(): PersistedState {
  return {
    currentUser: null,
    activeView: 'landing',
    portalTab: 'login',
    viewingProfileUsername: null,
    activeChatPartner: '',
    chatSeenStatus: true,
    crtEnabled: true,
    strictPixelFont: false,
    users: {},
    posts: [],
    categories: DEFAULT_FORUM_CATEGORIES,
    topics: [],
    friendRequests: [],
    conversations: {},
    notifications: [],
  };
}

function loadInitialState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return getDefaultState();
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    const defaults = getDefaultState();
    const users = parsed.users || {};
    const validUser =
      parsed.currentUser && users[parsed.currentUser] ? parsed.currentUser : null;

    return {
      ...defaults,
      ...parsed,
      users,
      currentUser: validUser,
      activeView:
        validUser && parsed.activeView === 'landing'
          ? 'feed'
          : !validUser
            ? 'landing'
            : parsed.activeView || 'landing',
      posts: parsed.posts || [],
      categories:
        parsed.categories && parsed.categories.length > 0
          ? parsed.categories
          : defaults.categories,
      topics: parsed.topics || [],
      friendRequests: parsed.friendRequests || [],
      conversations: parsed.conversations || {},
      notifications: parsed.notifications || [],
    };
  } catch {
    return getDefaultState();
  }
}

function getConversationKey(userA: string, userB: string) {
  return [userA, userB].sort().join('::');
}

const TaskbarClock: React.FC = () => {
  const [clockText, setClockText] = useState(() =>
    new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    })
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setClockText(
        new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <span className="font-pixel-ui text-[11px] text-[var(--text-bright)] tabular-nums">
      {clockText}
    </span>
  );
};

export default function App() {
  const [initial] = useState<PersistedState>(() => loadInitialState());

  const [currentUser, setCurrentUser] = useState<string | null>(initial.currentUser);
  const [activeView, setActiveView] = useState<PageId>(initial.activeView);
  const [portalTab, setPortalTab] = useState<'login' | 'register'>(initial.portalTab);
  const [viewingProfileUsername, setViewingProfileUsername] = useState<string | null>(
    initial.viewingProfileUsername
  );
  const [exploreTagFilter, setExploreTagFilter] = useState<string>('all');
  const [exploreSearchQuery, setExploreSearchQuery] = useState<string>('');
  const [selectedTopicId, setSelectedTopicId] = useState<string | null>(null);

  const [activeChatPartner, setActiveChatPartner] = useState<string>(initial.activeChatPartner);
  const [chatSeenStatus, setChatSeenStatus] = useState<boolean>(initial.chatSeenStatus);
  const [showMobileChat, setShowMobileChat] = useState<boolean>(false);

  const [crtEnabled, setCrtEnabled] = useState<boolean>(initial.crtEnabled);
  const [strictPixelFont, setStrictPixelFont] = useState<boolean>(initial.strictPixelFont);

  const [users, setUsers] = useState<Record<string, UserAccount>>(initial.users);
  const [posts, setPosts] = useState<PostItem[]>(initial.posts);
  const [categories, setCategories] = useState<ForumCategory[]>(initial.categories);
  const [topics, setTopics] = useState<ForumTopic[]>(initial.topics);
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>(initial.friendRequests);
  const [conversations, setConversations] = useState<Record<string, ChatMessage[]>>(
    initial.conversations
  );
  const [notifications, setNotifications] = useState<NotificationItem[]>(initial.notifications);

  const [draftTheme, setDraftTheme] = useState<ThemeVariables>(() => ({
    ...DEFAULT_THEME_VARIABLES,
    ...(initial.currentUser ? initial.users[initial.currentUser]?.themeOverrides : undefined),
  }));

  const [showNotifications, setShowNotifications] = useState(false);
  const [showStartMenu, setShowStartMenu] = useState(false);
  const [showMyDesktop, setShowMyDesktop] = useState(false);
  const [dismissedAnnouncementIds, setDismissedAnnouncementIds] = useState<string[]>([]);
  const [siteState, setSiteState] = useState<SitePublicState>({
    settings: {
      maintenanceMode: false,
      maintenanceMessage: '',
      registrationEnabled: true,
      postingEnabled: true,
      commentsEnabled: true,
      chatEnabled: true,
      globalBannerText: '',
      globalBannerEnabled: false,
      siteNotice: '',
    },
    announcements: [],
    rolesByUsername: {},
  });
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [routePath, setRoutePath] = useState<string>(() => window.location.pathname || '/');

  const rolesMap = siteState.rolesByUsername;
  const flagsMap = siteState.flagsByUsername || {};
  const currentUserRole: UserRole = currentUser
    ? rolesMap[currentUser] || users[currentUser]?.role || 'member'
    : 'member';
  const isStaff =
    currentUserRole === 'super_admin' ||
    currentUserRole === 'admin' ||
    currentUserRole === 'moderator';
  const isAdminOrHigher = currentUserRole === 'super_admin' || currentUserRole === 'admin';

  const refreshSiteState = useCallback(async () => {
    try {
      const next = await fetchSiteState();
      setSiteState(next);
      const notifyAnns = next.announcements.filter((a) => a.sendToNotifications);
      if (notifyAnns.length > 0) {
        setNotifications((prev) => {
          const existingIds = new Set(prev.map((n) => n.id));
          const toAdd: NotificationItem[] = [];
          for (const a of notifyAnns) {
            const nid = `ann-${a.id}`;
            if (!existingIds.has(nid)) {
              toAdd.push({
                id: nid,
                targetUser: null,
                text: `[${a.category.toUpperCase()}] ${a.title}`,
                time: a.createdAt.slice(11, 16) || 'NOW',
                read: false,
              });
            }
          }
          return toAdd.length > 0 ? [...toAdd, ...prev] : prev;
        });
      }
    } catch {
      // ignore background poll failures
    }
  }, []);

  // Verify existing Bearer token session & load site state on mount
  useEffect(() => {
    refreshSiteState();
    const pollTimer = setInterval(refreshSiteState, 30000);

    fetchSessionMe()
      .then((res) => {
        if (res.user) {
          const serverUser = res.user;
          setUsers((prev) => {
            const existing = prev[serverUser.username];
            return {
              ...prev,
              [serverUser.username]: {
                username: serverUser.username,
                password: '',
                avatarType: existing?.avatarType || (serverUser.avatarUrl ? 'custom' : 'preset'),
                avatarValue: existing?.avatarValue || serverUser.avatarUrl || 'cat_void',
                bio: serverUser.bio || existing?.bio || 'sometime, everytime...',
                flags: serverUser.flags && serverUser.flags.length > 0 ? serverUser.flags : existing?.flags || [],
                joined: serverUser.joined || existing?.joined || new Date().toISOString().slice(0, 10),
                themeOverrides: existing?.themeOverrides,
                role: serverUser.role,
                status: serverUser.status,
              },
            };
          });
          setCurrentUser(serverUser.username);
        }
      })
      .catch(() => {});

    return () => clearInterval(pollTimer);
  }, [refreshSiteState]);

  // Browser URL routing for /user/:username and /playlist/:username/:slug
  useEffect(() => {
    const onPopState = () => {
      setRoutePath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  // Ensure current logged-in non-super-admin account profile is synced to SQLite backend
  useEffect(() => {
    if (currentUser && users[currentUser]) {
      const acc = users[currentUser];
      syncAccount({
        username: acc.username,
        password: acc.password || undefined,
        bio: acc.bio,
      }).catch(() => {});
    }
  }, [currentUser]);

  // Sync accounts, blog/feed posts, and forum topics to SQLite database for live search
  useEffect(() => {
    const categoryNameMap = new Map(categories.map((c) => [c.id, c.name]));
    syncCommunityToDatabase({
      accounts: Object.values(users).map((u) => ({
        username: u.username,
        password: u.password || undefined,
        bio: u.bio,
        joined: u.joined,
      })),
      posts: posts.map((p) => ({
        ...p,
        mediaUrl: p.mediaUrl && p.mediaUrl.startsWith('blob:') ? '' : p.mediaUrl,
      })),
      topics: topics.map((t) => ({
        ...t,
        categoryName: categoryNameMap.get(t.categoryId) || 'General Chat',
      })),
    }).catch(() => {});
  }, [users, posts, topics, categories]);

  // Sync CSS variable overrides live to :root
  useEffect(() => {
    const rootStyle = document.documentElement.style;
    (Object.keys(draftTheme) as (keyof ThemeVariables)[]).forEach((varName) => {
      rootStyle.setProperty(varName, draftTheme[varName]);
    });
  }, [draftTheme]);

  // Sync body font toggle
  useEffect(() => {
    document.body.classList.toggle('strict-pixel-font', strictPixelFont);
  }, [strictPixelFont]);

  // Persist local browser state
  useEffect(() => {
    try {
      const safePosts = posts.map((p) => ({
        ...p,
        mediaUrl: p.mediaUrl && p.mediaUrl.startsWith('blob:') ? '' : p.mediaUrl,
        mediaType: p.mediaUrl && p.mediaUrl.startsWith('blob:') ? ('none' as const) : p.mediaType,
      }));
      const snapshot: PersistedState = {
        currentUser,
        activeView,
        portalTab,
        viewingProfileUsername,
        activeChatPartner,
        chatSeenStatus,
        crtEnabled,
        strictPixelFont,
        users,
        posts: safePosts,
        categories,
        topics,
        friendRequests,
        conversations,
        notifications,
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshot));
    } catch {
      // Ignore storage quota warning
    }
  }, [
    currentUser,
    activeView,
    portalTab,
    viewingProfileUsername,
    activeChatPartner,
    chatSeenStatus,
    crtEnabled,
    strictPixelFont,
    users,
    posts,
    categories,
    topics,
    friendRequests,
    conversations,
    notifications,
  ]);

  const showToast = useCallback((msg: string, type: 'info' | 'error' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`;
    setToasts((prev) => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 3600);
  }, []);

  const pushActivityNotification = (targetUser: string | null, text: string) => {
    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`,
        targetUser,
        text,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        read: false,
      },
      ...prev,
    ]);
  };

  const openPublicUrl = useCallback((path: string) => {
    const target = path.startsWith('/') ? path : `/${path}`;
    window.history.pushState({}, '', target);
    setRoutePath(target);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const navigateTo = (view: PageId) => {
    setShowStartMenu(false);
    if (routePath !== '/') {
      window.history.pushState({}, '', '/');
      setRoutePath('/');
    }
    if (
      !currentUser &&
      view !== 'landing' &&
      view !== 'playlists' &&
      view !== 'search' &&
      view !== 'shorts'
    ) {
      showToast('Please log in or register an account first.');
      setActiveView('landing');
      return;
    }
    setActiveView(view);
  };

  const openMyProfile = () => {
    setShowStartMenu(false);
    if (!currentUser) {
      navigateTo('landing');
      return;
    }
    setViewingProfileUsername(currentUser);
    setActiveView('profile');
  };

  const viewProfile = (username: string) => {
    if (!currentUser) {
      navigateTo('landing');
      return;
    }
    if (!users[username]) {
      showToast('User not found.', 'error');
      return;
    }
    setViewingProfileUsername(username);
    setActiveView('profile');
  };

  // Auth handlers (username + password only, backed by server hash verification + JWT/HMAC token)
  const handleLogin = async (username: string, password: string): Promise<string | null> => {
    const clean = username.trim();
    if (!clean || !password) return 'Enter username and password.';

    try {
      const res = await loginWithServer(clean, password);
      const serverUser = res.user;
      const existing = users[serverUser.username];
      const mergedAccount: UserAccount = {
        username: serverUser.username,
        password: '',
        avatarType: existing?.avatarType || (serverUser.avatarUrl ? 'custom' : 'preset'),
        avatarValue: existing?.avatarValue || serverUser.avatarUrl || 'cat_void',
        bio: serverUser.bio || existing?.bio || 'sometime, everytime...',
        flags: serverUser.flags && serverUser.flags.length > 0 ? serverUser.flags : existing?.flags || [],
        joined: serverUser.joined || existing?.joined || new Date().toISOString().slice(0, 10),
        themeOverrides: existing?.themeOverrides,
        role: serverUser.role,
        status: serverUser.status,
      };
      setUsers((prev) => ({ ...prev, [serverUser.username]: mergedAccount }));
      setCurrentUser(serverUser.username);
      setViewingProfileUsername(serverUser.username);
      setDraftTheme({
        ...DEFAULT_THEME_VARIABLES,
        ...(mergedAccount.themeOverrides || {}),
      });
      await refreshSiteState();
      setActiveView(serverUser.role === 'super_admin' ? 'feed' : 'feed');
      showToast(
        serverUser.role === 'super_admin'
          ? `Connected as SUPER ADMIN (${serverUser.username})`
          : `Connected as ${serverUser.username}`
      );
      return null;
    } catch (err) {
      // Legacy local account migration fallback (never applies to super_admin username)
      const localAcc = users[clean];
      if (
        clean.toLowerCase() !== 'barut' &&
        localAcc &&
        localAcc.password &&
        localAcc.password === password
      ) {
        try {
          await syncAccount({
            username: localAcc.username,
            password: localAcc.password,
            bio: localAcc.bio,
          });
          await loginWithServer(localAcc.username, password);
          setCurrentUser(localAcc.username);
          setViewingProfileUsername(localAcc.username);
          setDraftTheme({
            ...DEFAULT_THEME_VARIABLES,
            ...(localAcc.themeOverrides || {}),
          });
          setActiveView('feed');
          await refreshSiteState();
          showToast(`Connected as ${localAcc.username}`);
          return null;
        } catch {
          // fall through to error message
        }
      }
      return err instanceof Error
        ? err.message
        : 'Account not found or wrong password.';
    }
  };

  const handleRegister = async (payload: {
    username: string;
    password: string;
    avatarType: 'preset' | 'custom';
    avatarValue: string;
    bio: string;
  }): Promise<string | null> => {
    const clean = payload.username.trim();
    if (clean.length < 2) return 'Username must be at least 2 characters.';
    if (payload.password.length < 2) return 'Password must be at least 2 characters.';

    try {
      const res = await registerWithServer({
        username: clean,
        password: payload.password,
        bio: payload.bio.trim() || 'sometime, everytime...',
        avatarUrl: payload.avatarType === 'custom' ? payload.avatarValue : '',
      });
      const serverUser = res.user;
      const newAccount: UserAccount = {
        username: serverUser.username,
        password: '',
        avatarType: payload.avatarType,
        avatarValue: payload.avatarValue,
        bio: serverUser.bio,
        joined: serverUser.joined,
        role: serverUser.role,
        status: serverUser.status,
      };
      setUsers((prev) => ({ ...prev, [serverUser.username]: newAccount }));
      setCurrentUser(serverUser.username);
      setViewingProfileUsername(serverUser.username);
      setDraftTheme(DEFAULT_THEME_VARIABLES);
      await refreshSiteState();
      setActiveView('feed');
      pushActivityNotification(null, `${serverUser.username} joined LOSTROOM.BXE`);
      showToast(`Account '${serverUser.username}' created! Zero email/phone collected.`);
      return null;
    } catch (err) {
      return err instanceof Error ? err.message : 'Registration failed.';
    }
  };

  const handleLogout = () => {
    setAuthToken('');
    setCurrentUser(null);
    setShowMyDesktop(false);
    setDraftTheme(DEFAULT_THEME_VARIABLES);
    setActiveView('landing');
    setShowStartMenu(false);
    showToast('Logged out. Switch or register another account anytime.');
  };

  // Theme Editor handlers
  const handleSaveThemeToAccount = (vars: ThemeVariables) => {
    if (!currentUser) {
      showToast('Sign in to save custom theme colors to an account.', 'error');
      return;
    }
    setUsers((prev) => ({
      ...prev,
      [currentUser]: {
        ...prev[currentUser],
        themeOverrides: { ...vars },
      },
    }));
    setDraftTheme(vars);
    showToast(`Saved custom theme to ${currentUser}'s account settings!`);
  };

  const handleResetThemeToDefault = () => {
    setDraftTheme(DEFAULT_THEME_VARIABLES);
    if (currentUser) {
      setUsers((prev) => ({
        ...prev,
        [currentUser]: {
          ...prev[currentUser],
          themeOverrides: undefined,
        },
      }));
    }
    showToast('Restored default LOSTROOM.BXE purple/lavender palette.');
  };

  // Posts, Likes & Comments
  const handleCreatePost = (payload: {
    content: string;
    mood: string;
    tags: string[];
    mediaType: 'none' | 'image' | 'video';
    mediaUrl: string;
  }) => {
    if (!currentUser) return;
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const newPost: PostItem = {
      id: `post-${Date.now()}`,
      author: currentUser,
      timestamp: `TODAY · ${timeStr}`,
      activityTag:
        payload.mediaType === 'image'
          ? `${currentUser} added a photo`
          : payload.mediaType === 'video'
            ? `${currentUser} uploaded a video`
            : '',
      mood: payload.mood,
      content: payload.content,
      mediaType: payload.mediaType,
      mediaUrl: payload.mediaUrl,
      tags: payload.tags,
      likes: [],
      comments: [],
    };
    setPosts((prev) => [newPost, ...prev]);
    upsertBlogPostToDb(newPost).catch(() => {});
    setActiveView('feed');
    showToast('Published to Public Feed!');
  };

  const handleDeletePost = (postId: string) => {
    const target = posts.find((p) => p.id === postId);
    if (target && target.mediaUrl.startsWith('idb://')) {
      deleteVideoBlob(target.mediaUrl.slice('idb://'.length)).catch(() => {});
    }
    setPosts((prev) => prev.filter((p) => p.id !== postId));
    deleteBlogPostFromDb(postId).catch(() => {});
    showToast('Post deleted.');
  };

  const handleToggleLike = (postId: string) => {
    if (!currentUser) return;
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        const already = post.likes.includes(currentUser);
        const nextLikes = already
          ? post.likes.filter((u) => u !== currentUser)
          : [...post.likes, currentUser];
        if (!already && post.author !== currentUser) {
          pushActivityNotification(post.author, `${currentUser} liked your post`);
        }
        const updated = { ...post, likes: nextLikes };
        upsertBlogPostToDb(updated).catch(() => {});
        return updated;
      })
    );
  };

  const handleAddComment = (postId: string, text: string) => {
    if (!currentUser) return;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id !== postId) return post;
        if (post.author !== currentUser) {
          pushActivityNotification(post.author, `${currentUser} commented on your post`);
        }
        const updated = {
          ...post,
          comments: [...post.comments, { id: `c-${Date.now()}`, author: currentUser, text, time }],
        };
        upsertBlogPostToDb(updated).catch(() => {});
        return updated;
      })
    );
  };

  // Forum handlers
  const handleCreateCategory = (
    name: string,
    description: string,
    icon: ForumCategory['icon']
  ) => {
    if (!currentUser) return;
    const newCat: ForumCategory = {
      id: `cat-${Date.now()}`,
      name,
      description,
      icon,
      createdBy: currentUser,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setCategories((prev) => [...prev, newCat]);
    showToast(`Created category "${name}"`);
  };

  const handleCreateTopic = (categoryId: string, title: string, body: string) => {
    if (!currentUser) return;
    const newTopic: ForumTopic = {
      id: `topic-${Date.now()}`,
      categoryId,
      title,
      author: currentUser,
      body,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      views: 1,
      replies: [],
    };
    setTopics((prev) => [newTopic, ...prev]);
    const catName = categories.find((c) => c.id === categoryId)?.name || 'General Chat';
    upsertForumTopicToDb({ ...newTopic, categoryName: catName }).catch(() => {});
    setSelectedTopicId(newTopic.id);
    showToast('Forum topic published!');
  };

  const handleSelectTopic = (topicId: string | null) => {
    setSelectedTopicId(topicId);
    if (topicId) {
      setTopics((prev) =>
        prev.map((t) => (t.id === topicId ? { ...t, views: t.views + 1 } : t))
      );
    }
  };

  const handleAddTopicReply = (topicId: string, body: string) => {
    if (!currentUser) return;
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setTopics((prev) =>
      prev.map((t) => {
        if (t.id !== topicId) return t;
        if (t.author !== currentUser) {
          pushActivityNotification(t.author, `${currentUser} replied to your forum topic`);
        }
        const updated = {
          ...t,
          replies: [
            ...t.replies,
            { id: `rep-${Date.now()}`, author: currentUser, body, createdAt: time },
          ],
        };
        const catName = categories.find((c) => c.id === updated.categoryId)?.name || 'General Chat';
        upsertForumTopicToDb({ ...updated, categoryName: catName }).catch(() => {});
        return updated;
      })
    );
  };

  // Friends handlers
  const confirmedFriends = currentUser
    ? friendRequests
        .filter(
          (r) =>
            r.status === 'accepted' && (r.from === currentUser || r.to === currentUser)
        )
        .map((r) => (r.from === currentUser ? r.to : r.from))
        .filter((name, idx, arr) => arr.indexOf(name) === idx && Boolean(users[name]))
    : [];

  const incomingFriendRequestsCount = currentUser
    ? friendRequests.filter((r) => r.to === currentUser && r.status === 'pending').length
    : 0;

  const handleSendFriendRequest = (toUsername: string) => {
    if (!currentUser || toUsername === currentUser) return;
    const existing = friendRequests.find(
      (r) =>
        r.status !== 'declined' &&
        ((r.from === currentUser && r.to === toUsername) ||
          (r.from === toUsername && r.to === currentUser))
    );
    if (existing) {
      showToast('Friend request or friendship already exists.');
      return;
    }
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const req: FriendRequest = {
      id: `fr-${Date.now()}`,
      from: currentUser,
      to: toUsername,
      status: 'pending',
      time,
    };
    setFriendRequests((prev) => [req, ...prev]);
    pushActivityNotification(toUsername, `${currentUser} sent you a friend request`);
    showToast(`Friend request sent to ${toUsername}`);
  };

  const handleRespondFriendRequest = (
    requestId: string,
    action: 'accepted' | 'declined'
  ) => {
    const target = friendRequests.find((r) => r.id === requestId);
    if (!target || !currentUser) return;
    setFriendRequests((prev) =>
      prev.map((r) => (r.id === requestId ? { ...r, status: action } : r))
    );
    if (action === 'accepted') {
      pushActivityNotification(target.from, `${currentUser} accepted your friend request`);
      showToast(`You and ${target.from} are now friends!`);
    } else {
      showToast(`Declined request from ${target.from}`);
    }
  };

  const handleCancelFriendRequest = (requestId: string) => {
    setFriendRequests((prev) => prev.filter((r) => r.id !== requestId));
    showToast('Friend request cancelled.');
  };

  const handleRemoveFriend = (friendUsername: string) => {
    if (!currentUser) return;
    setFriendRequests((prev) =>
      prev.filter(
        (r) =>
          !(
            r.status === 'accepted' &&
            ((r.from === currentUser && r.to === friendUsername) ||
              (r.to === currentUser && r.from === friendUsername))
          )
      )
    );
    showToast(`Removed ${friendUsername} from your friends list.`);
  };

  // Private Chat handlers (100% real registered users, zero bots)
  const handleOpenChatWith = (partner: string) => {
    if (!currentUser) {
      showToast('Log in first to send private messages.');
      return;
    }
    if (partner === currentUser) return;
    setActiveChatPartner(partner);
    setShowMobileChat(true);
  };

  const handleSendChat = (partner: string, text: string) => {
    if (!currentUser || !users[partner]) return;
    const convKey = getConversationKey(currentUser, partner);
    const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const msg: ChatMessage = {
      id: `dm-${Date.now()}`,
      sender: currentUser,
      text,
      time,
    };
    setConversations((prev) => ({
      ...prev,
      [convKey]: [...(prev[convKey] || []), msg],
    }));
    pushActivityNotification(partner, `New private message from ${currentUser}`);
  };

  // Settings handlers
  const handleSaveProfile = (updates: {
    avatarType: 'preset' | 'custom';
    avatarValue: string;
    bio: string;
    flags?: string[];
  }) => {
    if (!currentUser) return;
    const nextFlags = updates.flags !== undefined ? updates.flags : users[currentUser]?.flags || [];
    setUsers((prev) => ({
      ...prev,
      [currentUser]: {
        ...prev[currentUser],
        avatarType: updates.avatarType,
        avatarValue: updates.avatarValue,
        bio: updates.bio,
        flags: nextFlags,
      },
    }));
    syncAccount({
      username: currentUser,
      bio: updates.bio,
      flags: nextFlags,
    }).catch(() => {});
    saveUserFlags(currentUser, nextFlags)
      .then(() => refreshSiteState())
      .catch(() => {});
    showToast('Profile, PFP & Flags updated!');
  };

  const handleSaveFlags = (nextFlags: string[]) => {
    if (!currentUser) return;
    setUsers((prev) => ({
      ...prev,
      [currentUser]: {
        ...prev[currentUser],
        flags: nextFlags,
      },
    }));
    saveUserFlags(currentUser, nextFlags)
      .then(() => refreshSiteState())
      .catch(() => {});
    showToast(nextFlags.length > 0 ? `Saved ${nextFlags.length} flag(s) to your profile!` : 'Cleared profile flags.');
  };

  const handleWipeLocalData = () => {
    localStorage.removeItem(STORAGE_KEY);
    clearAllVideoBlobs().catch(() => {});
    const fresh = getDefaultState();
    setCurrentUser(null);
    setDraftTheme(DEFAULT_THEME_VARIABLES);
    setActiveView('landing');
    setUsers(fresh.users);
    setPosts(fresh.posts);
    setCategories(fresh.categories);
    setTopics(fresh.topics);
    setFriendRequests(fresh.friendRequests);
    setConversations(fresh.conversations);
    setNotifications(fresh.notifications);
    showToast('All local browser data cleared.');
  };

  const relevantNotifications = notifications.filter(
    (n) => !n.targetUser || n.targetUser === currentUser
  );
  const unreadCount = relevantNotifications.filter((n) => !n.read).length;

  const activeChatKey =
    currentUser && activeChatPartner
      ? getConversationKey(currentUser, activeChatPartner)
      : '';
  const activeChatMessages = activeChatKey ? conversations[activeChatKey] || [] : [];

  const viewMeta: Record<PageId, { title: string; addr: string; short: string }> = {
    landing: {
      title: 'LOSTROOM.BXE — PORTAL_GATE',
      addr: 'bxe://lostroom.net/portal/index.html',
      short: 'PORTAL_GATE',
    },
    feed: {
      title: 'LOSTROOM.BXE — PUBLIC_FEED.DAT',
      addr: 'bxe://lostroom.net/stream/public_feed.dat',
      short: 'PUBLIC_FEED.DAT',
    },
    forum: {
      title: 'LOSTROOM.BXE — FORUM_BOARDS.DIR',
      addr: 'bxe://lostroom.net/forum/boards.dir',
      short: 'FORUM_BOARDS.DIR',
    },
    friends: {
      title: 'LOSTROOM.BXE — FRIENDS_LIST.SYS',
      addr: 'bxe://lostroom.net/friends/list.sys',
      short: 'FRIENDS_LIST.SYS',
    },
    explore: {
      title: 'LOSTROOM.BXE — EXPLORE_USERS.SYS',
      addr: `bxe://lostroom.net/explore?tag=${exploreTagFilter}`,
      short: 'EXPLORE_USERS.SYS',
    },
    search: {
      title: 'LOSTROOM.BXE — GLOBAL_SEARCH.DB',
      addr: 'bxe://lostroom.net/search',
      short: 'SEARCH.DB',
    },
    profile: {
      title: `LOSTROOM.BXE — USER://${viewingProfileUsername || ''}`,
      addr: `bxe://lostroom.net/u/${viewingProfileUsername || ''}`,
      short: `USER://${viewingProfileUsername || ''}`,
    },
    upload: {
      title: 'LOSTROOM.BXE — UPLOAD_MEDIA.EXE',
      addr: 'bxe://lostroom.net/upload/transmit.exe',
      short: 'UPLOAD_MEDIA.EXE',
    },
    settings: {
      title: 'LOSTROOM.BXE — SYSTEM_SETTINGS.CFG',
      addr: 'bxe://lostroom.net/config/settings.cfg',
      short: 'SYSTEM_SETTINGS.CFG',
    },
    theme: {
      title: 'LOSTROOM.BXE — COLOR_THEME_EDITOR.CSS',
      addr: 'bxe://lostroom.net/config/theme_editor.css',
      short: 'THEME_EDITOR.CSS',
    },
    homepage: {
      title: 'LOSTROOM.BXE — MY_HOMEPAGE_BUILDER.HTM',
      addr: `bxe://lostroom.net/user/${currentUser || 'me'}`,
      short: 'MY_HOMEPAGE.HTM',
    },
    playlists: {
      title: 'LOSTROOM.BXE — PLAYLIST_ARCHIVE.M3U',
      addr: 'bxe://lostroom.net/music/playlists.m3u',
      short: 'PLAYLISTS.M3U',
    },
    shorts: {
      title: 'LOSTROOM.BXE — SHORTyes_TV.MOV',
      addr: 'bxe://lostroom.net/shorts',
      short: 'SHORTS.MOV',
    },
    admin: {
      title: 'LOSTROOM.BXE — BARUT_ADMIN_CONSOLE.SYS',
      addr: 'bxe://lostroom.net/admin/console',
      short: 'ADMIN_PANEL',
    },
  };

  const currentMeta = viewMeta[activeView];
  const allUsersList = Object.values(users);

  // Check standalone visitor routes: /user/:username, /playlist/:username/:slug, or /shorts/:id
  const userRouteMatch = routePath.match(/^\/user\/([^/]+)\/?$/);
  const playlistRouteMatch = routePath.match(/^\/playlist\/([^/]+)\/([^/]+)\/?$/);
  const shortRouteMatch = routePath.match(/^\/shorts\/([^/]+)\/?$/);

  if (userRouteMatch) {
    const targetUsername = decodeURIComponent(userRouteMatch[1]);
    return (
      <div className="min-h-screen relative">
        {crtEnabled && (
          <>
            <div className="crt-overlay" aria-hidden="true" />
            <div className="crt-vignette" aria-hidden="true" />
          </>
        )}
        <PublicHomepageView
          username={targetUsername}
          currentViewerUsername={currentUser}
          onReturnToLostroom={() => {
            window.history.pushState({}, '', '/');
            setRoutePath('/');
          }}
          onEditMyHomepage={() => {
            window.history.pushState({}, '', '/');
            setRoutePath('/');
            setActiveView('homepage');
          }}
          onNavigateInternal={openPublicUrl}
          onToast={showToast}
        />
      </div>
    );
  }

  if (playlistRouteMatch) {
    const plOwner = decodeURIComponent(playlistRouteMatch[1]);
    const plSlug = decodeURIComponent(playlistRouteMatch[2]);
    return (
      <div className="min-h-screen relative">
        {crtEnabled && (
          <>
            <div className="crt-overlay" aria-hidden="true" />
            <div className="crt-vignette" aria-hidden="true" />
          </>
        )}
        <PublicPlaylistPage
          username={plOwner}
          slug={plSlug}
          currentViewerUsername={currentUser}
          onReturnToLostroom={() => {
            window.history.pushState({}, '', '/');
            setRoutePath('/');
          }}
          onOpenUserHomepage={(uname) => openPublicUrl(`/user/${uname}`)}
          onToast={showToast}
        />
      </div>
    );
  }

  if (shortRouteMatch) {
    const targetShortId = decodeURIComponent(shortRouteMatch[1]);
    return (
      <div className="min-h-screen relative">
        {crtEnabled && (
          <>
            <div className="crt-overlay" aria-hidden="true" />
            <div className="crt-vignette" aria-hidden="true" />
          </>
        )}
        <PublicShortView
          shortId={targetShortId}
          currentViewerUsername={currentUser}
          users={users}
          onReturnToShorts={() => {
            window.history.pushState({}, '', '/');
            setRoutePath('/');
            setActiveView('shorts');
          }}
          onReturnToLostroom={() => {
            window.history.pushState({}, '', '/');
            setRoutePath('/');
          }}
          onOpenUserHomepage={(uname) => openPublicUrl(`/user/${uname}`)}
          onToast={showToast}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen relative">
      {/* CRT Scanlines & Vignette Overlay */}
      {crtEnabled && (
        <>
          <div className="crt-overlay" aria-hidden="true" />
          <div className="crt-vignette" aria-hidden="true" />
        </>
      )}

      {/* Toast Container */}
      <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-xs pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="win-box p-2.5 pointer-events-auto text-sm bg-[var(--bg-void)]"
            style={{
              borderColor:
                t.type === 'error' ? 'var(--pink-love)' : 'var(--green-online)',
            }}
          >
            <div
              className="font-pixel-ui text-[10px] mb-0.5"
              style={{
                color: t.type === 'error' ? 'var(--pink-love)' : 'var(--green-online)',
              }}
            >
              [BXE]
            </div>
            <div className="text-[var(--text-bright)] text-base">{t.msg}</div>
          </div>
        ))}
      </div>

      {/* Top Retro Marquee Status Bar */}
      <div className="bg-[var(--bg-void)] border-b-2 border-[var(--bevel-mid)] px-3 py-1 flex items-center justify-between text-sm overflow-hidden">
        <div className="flex items-center gap-2 shrink-0 pr-3 border-r border-[var(--bevel-mid)]">
          <span className="inline-block w-2.5 h-2.5 bg-[var(--green-online)] border border-black" />
          <span className="font-pixel-ui text-xs text-[var(--accent-lavender)]">
            LOSTROOM.BXE
          </span>
        </div>
        <div className="overflow-hidden flex-1 mx-2">
          <div className="marquee-track text-[var(--accent-lavender)] text-base">
            ★ LOSTROOM.BXE — &quot;sometime, everytime... when you need privacy a bit...&quot; ★
            &quot;ı love you efsun bxe means (efsun x barut)&quot; ★
            USERNAME + PASSWORD ONLY (NO EMAIL / NO PHONE) ★
          </div>
        </div>
        <button
          type="button"
          onClick={() => setCrtEnabled((prev) => !prev)}
          className="win-btn px-2 py-0.5 text-[11px] shrink-0 text-[var(--text-bright)]"
        >
          CRT:{crtEnabled ? 'ON' : 'OFF'}
        </button>
      </div>

      {/* Main Desktop Workspace */}
      <div className="max-w-7xl mx-auto px-2 sm:px-4 pt-3 pb-8">
        {/* Desktop Shortcuts Strip */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 mb-3 px-1">
          <button
            type="button"
            onClick={() => navigateTo('landing')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskPortalIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--text-bright)] mt-1">
              PORTAL.EXE
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('feed')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskFeedIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--text-bright)] mt-1">
              FEED.DAT
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('forum')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskForumIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--text-bright)] mt-1">
              FORUM.DIR
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('friends')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskExploreIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--green-online)] mt-1">
              FRIENDS.SYS
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('explore')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskExploreIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--text-bright)] mt-1">
              EXPLORE.SYS
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('upload')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskUploadIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--text-bright)] mt-1">
              UPLOAD.EXE
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('theme')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskThemeIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--pink-love)] mt-1">
              THEME.CSS
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('homepage')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskHomepageIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--green-online)] mt-1">
              MY_HOME.HTM
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('playlists')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskMusicIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--accent-lavender)] mt-1">
              MUSIC.M3U
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('shorts')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskShortsIcon />
            <span className="font-pixel-ui text-[10px] text-[#ff6bd6] mt-1">
              SHORTS.MOV
            </span>
          </button>

          <button
            type="button"
            onClick={() => navigateTo('search')}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskSearchIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--green-online)] mt-1">
              SEARCH
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowMobileChat((prev) => !prev)}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[var(--accent-lavender)]/50 cursor-pointer"
          >
            <DeskChatIcon />
            <span className="font-pixel-ui text-[10px] text-[var(--text-bright)] mt-1">
              PRIV_CHAT
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowMyDesktop(true)}
            className="flex flex-col items-center p-1.5 hover:bg-[var(--accent-violet)]/20 border border-transparent hover:border-[#52ff94]/50 cursor-pointer"
          >
            <DeskDesktopIcon />
            <span className="font-pixel-ui text-[10px] text-[#52ff94] mt-1">
              MY_DESKTOP
            </span>
          </button>

          {isStaff && (
            <button
              type="button"
              onClick={() => navigateTo('admin')}
              className="flex flex-col items-center p-1.5 hover:bg-[#3b0764]/40 border border-transparent hover:border-[#ffd700] cursor-pointer"
            >
              <DeskAdminIcon />
              <span className="font-pixel-ui text-[10px] text-[#ffd700] mt-1">
                ADMIN.SYS
              </span>
            </button>
          )}
        </div>

        {/* Always-Visible Main Navigation Bar */}
        <nav
          aria-label="Main Navigation"
          className="win-box px-2.5 py-2 mb-3 flex flex-wrap items-center gap-1.5"
        >
          <button
            type="button"
            onClick={() => navigateTo('feed')}
            className={`win-btn px-3 py-1.5 text-xs ${
              activeView === 'feed' ? 'win-btn-primary' : ''
            }`}
          >
            BLOGS / FEED
          </button>
          <button
            type="button"
            onClick={() => navigateTo('forum')}
            className={`win-btn px-3 py-1.5 text-xs ${
              activeView === 'forum' ? 'win-btn-primary' : ''
            }`}
          >
            FORUM
          </button>
          <button
            type="button"
            onClick={() => setShowMobileChat((prev) => !prev)}
            className={`win-btn px-3 py-1.5 text-xs ${showMobileChat ? 'active-tab' : ''}`}
          >
            CHATROOM
          </button>
          <button
            type="button"
            onClick={() => navigateTo('homepage')}
            className={`win-btn px-3 py-1.5 text-xs ${
              activeView === 'homepage' ? 'win-btn-primary' : 'text-[var(--green-online)]'
            }`}
          >
            MY HOMEPAGE
          </button>
          <button
            type="button"
            onClick={() => navigateTo('playlists')}
            className={`win-btn px-3 py-1.5 text-xs ${
              activeView === 'playlists' ? 'win-btn-primary' : ''
            }`}
          >
            PLAYLISTS
          </button>
          <button
            type="button"
            onClick={() => navigateTo('shorts')}
            className={`win-btn px-3.5 py-1.5 text-xs font-bold ${
              activeView === 'shorts'
                ? 'win-btn-primary'
                : 'text-[#ff6bd6] border-[#ff6bd6]'
            }`}
          >
            SHORTS
          </button>
          <button
            type="button"
            onClick={() => navigateTo('friends')}
            className={`win-btn px-3 py-1.5 text-xs ${
              activeView === 'friends' ? 'win-btn-primary' : ''
            }`}
          >
            FRIENDS
          </button>
          <button
            type="button"
            onClick={() => navigateTo('search')}
            className={`win-btn px-3.5 py-1.5 text-xs font-bold ${
              activeView === 'search'
                ? 'win-btn-primary'
                : 'text-[#52ff94] border-[#52ff94]'
            }`}
          >
            SEARCH
          </button>
          <button
            type="button"
            onClick={() => setShowMyDesktop(true)}
            className={`win-btn px-3 py-1.5 text-xs font-bold ${
              showMyDesktop ? 'win-btn-primary' : 'text-[#7dd3fc] border-[#38bdf8]'
            }`}
            title="Open optional My Desktop virtual OS popup"
          >
            My Desktop
          </button>
          {isStaff && (
            <button
              type="button"
              onClick={() => navigateTo('admin')}
              className={`win-btn px-3 py-1.5 text-xs font-bold ${
                activeView === 'admin'
                  ? 'win-btn-primary'
                  : 'text-[#ffd700] border-[#ffd700] bg-[#2e0648]'
              }`}
            >
              ADMIN PANEL
            </button>
          )}
        </nav>

        {/* Global Banner, Site Notice & Published Announcements */}
        {((siteState.settings.globalBannerEnabled && siteState.settings.globalBannerText) ||
          siteState.settings.siteNotice ||
          siteState.announcements.some(
            (a) => (a.isPinned || a.showBanner) && !dismissedAnnouncementIds.includes(a.id)
          )) && (
          <div className="space-y-2 mb-3">
            {siteState.settings.globalBannerEnabled && siteState.settings.globalBannerText && (
              <div className="win-box px-3 py-2 border-[#ffd700] bg-[#241038] flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-[#ffd700] font-pixel-ui">
                  <span>★ GLOBAL NOTICE:</span>
                  <span className="text-white font-sans text-sm">
                    {siteState.settings.globalBannerText}
                  </span>
                </div>
              </div>
            )}

            {siteState.settings.siteNotice && (
              <div className="win-inset px-3 py-1.5 text-xs text-[#c8b4f8] flex items-center gap-2">
                <span className="font-pixel-ui text-[10px] text-[#52ff94]">[SITE NOTICE]</span>
                <span>{siteState.settings.siteNotice}</span>
              </div>
            )}

            {siteState.announcements
              .filter(
                (a) => (a.isPinned || a.showBanner) && !dismissedAnnouncementIds.includes(a.id)
              )
              .map((ann) => (
                <div
                  key={ann.id}
                  className="win-box p-2.5 flex flex-wrap items-start justify-between gap-2 bg-[#160b26]"
                  style={{
                    borderColor:
                      ann.category === 'maintenance'
                        ? '#ff6bd6'
                        : ann.category === 'important'
                          ? '#ffd700'
                          : ann.category === 'event'
                            ? '#52ff94'
                            : 'var(--accent-violet)',
                  }}
                >
                  <div className="space-y-0.5 min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      <span className="font-pixel-ui text-[10px] px-1.5 py-0.5 bg-black border border-current text-[#ffd700]">
                        {ann.isPinned ? 'PINNED · ' : ''}
                        {ann.category.toUpperCase()}
                      </span>
                      <strong className="font-pixel-ui text-xs text-white">{ann.title}</strong>
                      <span className="text-[11px] text-[#a690d6]">by {ann.authorUsername}</span>
                      <BarutBadge username={ann.authorUsername} rolesMap={rolesMap} compact />
                    </div>
                    <p className="text-sm text-[#e6dcff] whitespace-pre-wrap">{ann.body}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      setDismissedAnnouncementIds((prev) => [...prev, ann.id])
                    }
                    className="win-btn px-2 py-0.5 text-[10px] shrink-0"
                    title="Dismiss announcement"
                  >
                    ✕
                  </button>
                </div>
              ))}
          </div>
        )}

        {/* PRIMARY 3-COLUMN RETRO DESKTOP LAYOUT */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
          {/* LEFT SIDEBAR: User Session, Directory Tree & Registered Humans */}
          <aside className="lg:col-span-3 flex flex-col gap-4">
            {/* User Session Card */}
            <div className="win-box">
              <div className="win-titlebar">
                <span className="font-pixel-ui text-xs text-white flex items-center gap-1.5">
                  <span className="inline-block w-2 h-2 bg-[var(--accent-lavender)]" />
                  <span>USER_SESSION.INI</span>
                </span>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => navigateTo('settings')}
                    className="win-ctrl-btn"
                    title="Settings"
                  >
                    *
                  </button>
                </div>
              </div>

              <div className="p-3">
                {!currentUser ? (
                  <div className="text-center space-y-2.5">
                    <div className="win-inset p-2 text-sm text-[var(--accent-lavender)]">
                      STATUS:{' '}
                      <span className="text-[var(--pink-love)] font-pixel-ui text-xs">
                        OFFLINE
                      </span>
                      <br />
                      <span className="text-xs text-[var(--text-muted)]">
                        Username + password only.
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          setPortalTab('login');
                          setActiveView('landing');
                        }}
                        className="win-btn win-btn-primary py-1.5 text-xs"
                      >
                        LOGIN
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setPortalTab('register');
                          setActiveView('landing');
                        }}
                        className="win-btn py-1.5 text-xs"
                      >
                        REGISTER
                      </button>
                    </div>
                  </div>
                ) : (
                  (() => {
                    const user = users[currentUser];
                    return (
                      <div>
                        <div className="flex items-center gap-2.5 mb-2.5">
                          <AvatarBox user={user} sizeClass="w-12 h-12" />
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              <span className="font-pixel-ui text-xs text-[var(--text-bright)] truncate">
                                {user.username}
                              </span>
                              <BarutBadge
                                username={user.username}
                                role={currentUserRole}
                                rolesMap={rolesMap}
                                compact
                              />
                            </div>
                            <div className="inline-block bg-[var(--bg-royal)] border border-[var(--accent-violet)] px-1.5 font-pixel-ui text-[10px] text-[var(--green-online)] mt-0.5">
                              ONLINE {currentUserRole !== 'member' ? `· ${currentUserRole.toUpperCase()}` : ''}
                            </div>
                            <div className="text-xs text-[var(--text-muted)] mt-0.5">
                              JOINED {user.joined}
                            </div>
                          </div>
                        </div>
                        <p className="win-inset p-2 text-sm text-[var(--accent-lavender)] mb-2.5 break-words">
                          &quot;{user.bio}&quot;
                        </p>
                        <div className="grid grid-cols-2 gap-1.5">
                          <button
                            type="button"
                            onClick={openMyProfile}
                            className="win-btn py-1 text-[11px]"
                          >
                            PROFILE
                          </button>
                          <button
                            type="button"
                            onClick={handleLogout}
                            className="win-btn py-1 text-[11px] text-[var(--pink-love)]"
                          >
                            LOGOUT
                          </button>
                        </div>
                      </div>
                    );
                  })()
                )}
              </div>
            </div>

            {/* Navigation Directory Window */}
            <div className="win-box">
              <div className="win-titlebar">
                <span className="font-pixel-ui text-xs text-white">DIRECTORY_TREE</span>
                <span className="font-pixel-ui text-[10px] text-[var(--accent-lavender)]">
                  C:\BXE
                </span>
              </div>
              <div className="p-2 flex flex-col gap-1.5">
                {[
                  {
                    id: 'landing' as PageId,
                    label: '> 00_PORTAL_GATE',
                    badge: '[AUTH]',
                    color: 'text-[var(--accent-lavender)]',
                  },
                  {
                    id: 'feed' as PageId,
                    label: '> 01_PUBLIC_FEED',
                    badge: 'STREAM',
                    color: 'text-[var(--green-online)]',
                  },
                  {
                    id: 'forum' as PageId,
                    label: '> 02_FORUM_BOARDS',
                    badge: 'THREADS',
                    color: 'text-[var(--accent-lavender)]',
                  },
                  {
                    id: 'friends' as PageId,
                    label: '> 03_FRIENDS_LIST',
                    badge:
                      incomingFriendRequestsCount > 0
                        ? `${incomingFriendRequestsCount} REQ`
                        : `${confirmedFriends.length}`,
                    color:
                      incomingFriendRequestsCount > 0
                        ? 'text-[var(--pink-love)]'
                        : 'text-[var(--green-online)]',
                  },
                  {
                    id: 'explore' as PageId,
                    label: '> 04_EXPLORE_USERS',
                    badge: 'SEARCH',
                    color: 'text-[var(--accent-lavender)]',
                  },
                  {
                    id: 'upload' as PageId,
                    label: '> 05_UPLOAD_MEDIA',
                    badge: '+POST',
                    color: 'text-[var(--pink-love)]',
                  },
                  {
                    id: 'profile' as PageId,
                    label: '> 06_MY_PROFILE',
                    badge: 'PFP/BIO',
                    color: 'text-[var(--accent-lavender)]',
                  },
                  {
                    id: 'settings' as PageId,
                    label: '> 07_SYS_SETTINGS',
                    badge: 'CFG',
                    color: 'text-[var(--accent-lavender)]',
                  },
                  {
                    id: 'theme' as PageId,
                    label: '> 08_THEME_EDITOR',
                    badge: 'CSS',
                    color: 'text-[var(--pink-love)]',
                  },
                  {
                    id: 'homepage' as PageId,
                    label: '> 09_MY_HOMEPAGE',
                    badge: 'BUILDER',
                    color: 'text-[var(--green-online)]',
                  },
                  {
                    id: 'playlists' as PageId,
                    label: '> 10_PLAYLISTS_MP3',
                    badge: 'AUDIO',
                    color: 'text-[var(--accent-lavender)]',
                  },
                  {
                    id: 'search' as PageId,
                    label: '> 11_SEARCH_DB',
                    badge: 'FIND',
                    color: 'text-[var(--green-online)]',
                  },
                  {
                    id: 'shorts' as PageId,
                    label: '> 12_SHORTS_TV',
                    badge: 'VIDEO',
                    color: 'text-[#ff6bd6]',
                  },
                  ...(isStaff
                    ? [
                        {
                          id: 'admin' as PageId,
                          label: '> 13_ADMIN_PANEL',
                          badge: 'GOD',
                          color: 'text-[#ffd700]',
                        },
                      ]
                    : []),
                ].map((nav) => (
                  <button
                    key={nav.id}
                    type="button"
                    onClick={() => (nav.id === 'profile' ? openMyProfile() : navigateTo(nav.id))}
                    className={`win-btn px-2.5 py-2 text-left flex items-center justify-between ${
                      activeView === nav.id ? 'win-btn-primary' : ''
                    }`}
                  >
                    <span className="truncate">{nav.label}</span>
                    <span className={`${nav.color} text-[10px] shrink-0`}>{nav.badge}</span>
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setShowMyDesktop(true)}
                  className="win-btn px-2.5 py-2 text-left flex items-center justify-between text-[#7dd3fc]"
                >
                  <span className="truncate">&gt; 14_MY_DESKTOP</span>
                  <span className="text-[10px] shrink-0">OS</span>
                </button>
              </div>
            </div>

            {/* Real Registered Users Roster (Zero Bots) */}
            <div className="win-box">
              <div className="win-titlebar">
                <span className="font-pixel-ui text-xs text-white">
                  REGISTERED_USERS ({allUsersList.length})
                </span>
                <span className="w-2 h-2 bg-[var(--green-online)] inline-block" />
              </div>
              <div className="p-2.5 flex flex-col gap-2 text-base">
                {allUsersList.length === 0 ? (
                  <div className="win-inset p-2.5 text-sm text-[var(--text-muted)] text-center">
                    No registered accounts yet.
                    <br />
                    <span className="text-xs">Create the first account in Portal Gate.</span>
                  </div>
                ) : (
                  allUsersList.map((u) => {
                    const isMe = u.username === currentUser;
                    return (
                      <div
                        key={u.username}
                        className="flex items-center justify-between bg-[var(--bg-void)] p-1.5 border border-[var(--bg-royal)] gap-2"
                      >
                        <button
                          type="button"
                          onClick={() => viewProfile(u.username)}
                          className="flex items-center gap-2 min-w-0 text-left cursor-pointer"
                        >
                          <AvatarBox user={u} sizeClass="w-7 h-7" />
                          <div className="min-w-0">
                            <div className="font-pixel-ui text-xs text-[var(--text-bright)] hover:underline truncate flex items-center gap-1 flex-wrap">
                              <span>{u.username}</span>
                              <BarutBadge username={u.username} role={u.role} rolesMap={rolesMap} compact />
                              {isMe && <span className="text-[var(--green-online)]">(YOU)</span>}
                            </div>
                            <div className="text-xs text-[var(--text-muted)] truncate">
                              {u.bio}
                            </div>
                          </div>
                        </button>
                        {!isMe && currentUser && (
                          <button
                            type="button"
                            onClick={() => handleOpenChatWith(u.username)}
                            className="win-btn px-1.5 py-0.5 text-[10px] shrink-0"
                          >
                            DM
                          </button>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </aside>

          {/* CENTER STAGE: Main Active Desktop Window */}
          <main className="lg:col-span-6">
            <div className="win-box">
              {/* Main Window Title Bar */}
              <div className="win-titlebar">
                <div className="flex items-center gap-2 min-w-0">
                  <span className="inline-block w-3 h-3 bg-[var(--accent-violet)] border border-[var(--text-bright)] shrink-0" />
                  <span className="font-pixel-ui text-xs sm:text-sm text-white tracking-wide truncate">
                    {currentMeta.title}
                  </span>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => setShowNotifications((prev) => !prev)}
                    className="win-btn px-2 py-0.5 text-[10px] flex items-center gap-1"
                    title="Notifications"
                  >
                    <span>BELL</span>
                    {unreadCount > 0 && (
                      <span className="bg-[var(--pink-love)] text-black px-1 font-bold tabular-nums">
                        {unreadCount}
                      </span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveView('landing')}
                    className="win-ctrl-btn"
                    title="Portal"
                  >
                    _
                  </button>
                </div>
              </div>

              {/* Address Bar */}
              <div className="bg-[var(--bg-void)] border-b-2 border-[var(--bg-royal)] px-2.5 py-1.5 flex items-center gap-2">
                <span className="font-pixel-ui text-[11px] text-[var(--text-muted)]">
                  ADDR://
                </span>
                <div className="win-inset px-2 py-0.5 flex-1 text-sm text-[var(--accent-lavender)] truncate font-mono">
                  {currentMeta.addr}
                </div>
                <button
                  type="button"
                  onClick={() => setActiveView(activeView)}
                  className="win-btn px-2 py-0.5 text-[10px]"
                >
                  RELOAD
                </button>
              </div>

              {/* Activity Notifications Drawer */}
              {showNotifications && (
                <div className="bg-[var(--bg-panel)] border-b-2 border-[var(--accent-violet)] p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-pixel-ui text-xs text-[var(--pink-love)]">
                      ★ ACTIVITY_LOG
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        setNotifications((prev) =>
                          prev.map((n) =>
                            !n.targetUser || n.targetUser === currentUser
                              ? { ...n, read: true }
                              : n
                          )
                        )
                      }
                      className="win-btn px-2 py-0.5 text-[10px]"
                    >
                      CLEAR UNREAD
                    </button>
                  </div>
                  <div className="flex flex-col gap-1.5 max-h-48 overflow-y-auto">
                    {relevantNotifications.length === 0 ? (
                      <div className="text-sm text-[var(--text-muted)] px-1">
                        No activity notifications yet.
                      </div>
                    ) : (
                      relevantNotifications.map((n) => (
                        <div
                          key={n.id}
                          className={`flex items-center justify-between px-2 py-1 text-sm border ${
                            n.read
                              ? 'border-[var(--bg-royal)] text-[var(--text-muted)]'
                              : 'border-[var(--accent-violet)] bg-[var(--bg-royal)] text-[var(--text-bright)]'
                          }`}
                        >
                          <span>
                            {n.read ? '○' : '●'} {n.text}
                          </span>
                          <span className="text-xs text-[var(--text-muted)] shrink-0 ml-2">
                            {n.time}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Dynamic View Content Container */}
              <div className="p-3 sm:p-5 min-h-[540px]">
                {siteState.settings.maintenanceMode &&
                !isAdminOrHigher &&
                activeView !== 'landing' ? (
                  <div className="win-inset p-6 text-center space-y-3 border-2 border-[#ff6bd6]">
                    <div className="font-pixel-title text-sm text-[#ff6bd6]">
                      MAINTENANCE MODE ACTIVE
                    </div>
                    <p className="text-base text-[#e6dcff]">
                      {siteState.settings.maintenanceMessage ||
                        'LOSTROOM.BXE is currently undergoing maintenance by Super Admin. Please check back shortly.'}
                    </p>
                    <button
                      type="button"
                      onClick={() => navigateTo('landing')}
                      className="win-btn win-btn-primary px-4 py-1.5 text-xs"
                    >
                      RETURN TO PORTAL GATE
                    </button>
                  </div>
                ) : (
                  <>
                    {activeView === 'landing' && (
                      <LandingPage
                        users={users}
                        currentUsername={currentUser}
                        portalTab={portalTab}
                        registrationEnabled={siteState.settings.registrationEnabled}
                        onChangePortalTab={setPortalTab}
                        onLogin={handleLogin}
                        onRegister={handleRegister}
                        onLogout={handleLogout}
                        onNavigate={navigateTo}
                        onToast={showToast}
                      />
                    )}

                    {activeView === 'feed' && (
                      <HomeFeedPage
                        posts={posts}
                        users={users}
                        currentUsername={currentUser}
                        rolesMap={rolesMap}
                        flagsMap={flagsMap}
                        postingEnabled={siteState.settings.postingEnabled}
                        commentsEnabled={siteState.settings.commentsEnabled}
                        confirmedFriends={confirmedFriends}
                        onToggleLike={handleToggleLike}
                        onAddComment={handleAddComment}
                        onDeletePost={handleDeletePost}
                        onOpenProfile={viewProfile}
                        onOpenChatWith={handleOpenChatWith}
                        onFilterByTag={(tag) => {
                          setExploreTagFilter(tag);
                          setActiveView('explore');
                        }}
                        onNavigate={navigateTo}
                      />
                    )}

                    {activeView === 'forum' && (
                      <ForumPage
                        categories={categories}
                        topics={topics}
                        users={users}
                        currentUsername={currentUser}
                        rolesMap={rolesMap}
                        postingEnabled={siteState.settings.postingEnabled}
                        commentsEnabled={siteState.settings.commentsEnabled}
                        selectedTopicId={selectedTopicId}
                        onSelectTopicId={handleSelectTopic}
                        onCreateCategory={handleCreateCategory}
                        onCreateTopic={handleCreateTopic}
                        onAddTopicReply={handleAddTopicReply}
                        onOpenProfile={viewProfile}
                      />
                    )}

                    {activeView === 'friends' && (
                      <FriendsPage
                        currentUsername={currentUser}
                        users={users}
                        rolesMap={rolesMap}
                        friendRequests={friendRequests}
                        onSendRequest={handleSendFriendRequest}
                        onRespondRequest={handleRespondFriendRequest}
                        onCancelRequest={handleCancelFriendRequest}
                        onRemoveFriend={handleRemoveFriend}
                        onOpenProfile={viewProfile}
                        onOpenChatWith={handleOpenChatWith}
                      />
                    )}

                    {activeView === 'explore' && (
                      <ExplorePage
                        users={users}
                        posts={posts}
                        currentUsername={currentUser}
                        rolesMap={rolesMap}
                        commentsEnabled={siteState.settings.commentsEnabled}
                        friendRequests={friendRequests}
                        searchQuery={exploreSearchQuery}
                        tagFilter={exploreTagFilter}
                        onChangeSearch={setExploreSearchQuery}
                        onChangeTagFilter={setExploreTagFilter}
                        onSendFriendRequest={handleSendFriendRequest}
                        onToggleLike={handleToggleLike}
                        onAddComment={handleAddComment}
                        onDeletePost={handleDeletePost}
                        onOpenProfile={viewProfile}
                        onOpenChatWith={handleOpenChatWith}
                      />
                    )}

                    {activeView === 'profile' && (
                      <ProfilePage
                        profileUsername={viewingProfileUsername || currentUser || ''}
                        users={users}
                        posts={posts}
                        currentUsername={currentUser}
                        rolesMap={rolesMap}
                        flagsMap={flagsMap}
                        commentsEnabled={siteState.settings.commentsEnabled}
                        friendRequests={friendRequests}
                        onSendFriendRequest={handleSendFriendRequest}
                        onRespondFriendRequest={handleRespondFriendRequest}
                        onRemoveFriend={handleRemoveFriend}
                        onNavigate={navigateTo}
                        onOpenProfile={viewProfile}
                        onOpenChatWith={handleOpenChatWith}
                        onOpenPublicUrl={openPublicUrl}
                        onSaveFlags={handleSaveFlags}
                        onToggleLike={handleToggleLike}
                        onAddComment={handleAddComment}
                        onDeletePost={handleDeletePost}
                        onFilterByTag={(tag) => {
                          setExploreTagFilter(tag);
                          setActiveView('explore');
                        }}
                      />
                    )}

                    {activeView === 'upload' && (
                      <UploadPage
                        postingEnabled={siteState.settings.postingEnabled}
                        onPublishPost={handleCreatePost}
                        onToast={showToast}
                      />
                    )}

                    {activeView === 'settings' && (
                      <SettingsPage
                        currentUser={currentUser ? users[currentUser] : null}
                        crtEnabled={crtEnabled}
                        strictPixelFont={strictPixelFont}
                        onToggleCrt={() => setCrtEnabled((prev) => !prev)}
                        onToggleStrictPixelFont={() => setStrictPixelFont((prev) => !prev)}
                        onSaveProfile={handleSaveProfile}
                        onOpenThemeEditor={() => navigateTo('theme')}
                        onWipeLocalData={handleWipeLocalData}
                        onToast={showToast}
                      />
                    )}

                    {activeView === 'theme' && (
                      <ThemeEditorPage
                        currentUsername={currentUser}
                        draftTheme={draftTheme}
                        onChangeDraftTheme={setDraftTheme}
                        onSaveToAccount={handleSaveThemeToAccount}
                        onResetDefault={handleResetThemeToDefault}
                      />
                    )}

                    {activeView === 'homepage' && (
                      <MyHomepagePage
                        currentUsername={currentUser}
                        onOpenPublicUrl={openPublicUrl}
                        onToast={showToast}
                      />
                    )}

                    {activeView === 'playlists' && (
                      <PlaylistsPage
                        currentUsername={currentUser}
                        onOpenPublicUrl={openPublicUrl}
                        onOpenProfile={viewProfile}
                        onOpenMyHomepage={() => navigateTo('homepage')}
                        onToast={showToast}
                      />
                    )}

                    {activeView === 'search' && (
                      <SearchPage
                        currentUsername={currentUser}
                        rolesMap={rolesMap}
                        onOpenProfile={(uname) => {
                          if (!currentUser) {
                            openPublicUrl(`/user/${uname}`);
                            return;
                          }
                          viewProfile(uname);
                        }}
                        onOpenPublicUrl={openPublicUrl}
                        onOpenForumTopic={(topicId) => {
                          if (!currentUser) {
                            showToast('Log in to open full forum thread view.');
                            return;
                          }
                          handleSelectTopic(topicId);
                          navigateTo('forum');
                        }}
                        onOpenBlogsFeed={() => navigateTo('feed')}
                        onOpenTagInExplore={(tag) => {
                          setExploreTagFilter(tag);
                          navigateTo('explore');
                        }}
                        onOpenChatWith={handleOpenChatWith}
                        onToast={showToast}
                      />
                    )}

                    {activeView === 'shorts' && (
                      <ShortsPage
                        currentUsername={currentUser}
                        users={users}
                        rolesMap={rolesMap}
                        postingEnabled={siteState.settings.postingEnabled}
                        commentsEnabled={siteState.settings.commentsEnabled}
                        onOpenPublicUrl={openPublicUrl}
                        onNavigateAuth={() => navigateTo('landing')}
                        onToast={showToast}
                      />
                    )}

                    {activeView === 'admin' &&
                      (isStaff ? (
                        <AdminDashboardPage
                          currentUsername={currentUser}
                          currentUserRole={currentUserRole}
                          onSiteStateChanged={refreshSiteState}
                          onOpenUserProfile={viewProfile}
                          onToast={showToast}
                        />
                      ) : (
                        <div className="win-inset p-6 text-center space-y-2 border border-[#ff6bd6]">
                          <div className="font-pixel-ui text-xs text-[#ff6bd6]">
                            403 // STAFF CLEARANCE REQUIRED
                          </div>
                          <p className="text-sm text-[var(--accent-lavender)]">
                            Only verified Super Admin, Admin, or Moderator accounts can open the Admin Console.
                          </p>
                        </div>
                      ))}
                  </>
                )}
              </div>

              {/* Window Status Footer */}
              <div className="bg-[var(--bg-void)] border-t-2 border-[var(--bg-royal)] px-3 py-1 flex flex-wrap items-center justify-between text-xs text-[var(--text-muted)]">
                <span>
                  ENGINE:{' '}
                  <strong className="text-[var(--green-online)]">
                    ZERO BOTS / REAL USERS ONLY
                  </strong>
                </span>
                <span>
                  STORAGE:{' '}
                  <strong className="text-[var(--accent-lavender)]">
                    LOCAL BROWSER PROTOTYPE
                  </strong>
                </span>
              </div>
            </div>
          </main>

          {/* RIGHT COLUMN: Real-User Private Chats Window */}
          <section
            className={`lg:col-span-3 ${showMobileChat ? 'block' : 'hidden lg:block'}`}
          >
            <PrivateChatPanel
              currentUsername={currentUser}
              users={users}
              rolesMap={rolesMap}
              chatEnabled={siteState.settings.chatEnabled}
              activePartner={activeChatPartner}
              onSelectPartner={setActiveChatPartner}
              messages={activeChatMessages}
              onSendMessage={handleSendChat}
              chatSeenStatus={chatSeenStatus}
              onToggleSeenStatus={() => {
                setChatSeenStatus((prev) => !prev);
                showToast(`Presence status: ${!chatSeenStatus ? 'SEEN' : 'DONT SEEN'}`);
              }}
              onMinimizeMobile={() => setShowMobileChat(false)}
            />
          </section>
        </div>
      </div>

      {/* BOTTOM RETRO TASKBAR */}
      <footer className="fixed bottom-0 left-0 right-0 z-40 h-11 bg-[var(--bg-panel)] border-t-2 border-[var(--bevel-light)] px-2 flex items-center justify-between select-none">
        <div className="flex items-center gap-2">
          <div className="relative">
            <button
              type="button"
              onClick={() => setShowStartMenu((prev) => !prev)}
              className="win-btn win-btn-primary px-3 py-1.5 flex items-center gap-2 font-pixel-ui text-xs"
            >
              <span className="inline-block w-3 h-3 bg-[var(--text-bright)] border border-black" />
              <span>BXE.MENU</span>
            </button>

            {showStartMenu && (
              <div className="absolute bottom-11 left-0 w-64 win-box z-50">
                <div
                  className="px-3 py-2 border-b border-[var(--bevel-light)]"
                  style={{
                    background:
                      'linear-gradient(90deg, var(--bg-royal) 0%, var(--accent-violet) 100%)',
                  }}
                >
                  <div className="font-pixel-title text-[10px] text-white">LOSTROOM.BXE</div>
                  <div className="text-xs text-[var(--text-bright)]">sometime, everytime...</div>
                </div>
                <div className="p-1.5 flex flex-col gap-1">
                  <button
                    type="button"
                    onClick={() => navigateTo('landing')}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    00. Portal Gate
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('feed')}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    01. Home Feed
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('forum')}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    02. Forum Boards
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('friends')}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    03. Friends &amp; Requests
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('explore')}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    04. Explore &amp; Search
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('upload')}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    05. Upload Photo/Video
                  </button>
                  <button
                    type="button"
                    onClick={openMyProfile}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    06. My Profile
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('settings')}
                    className="win-btn px-2.5 py-1.5 text-left"
                  >
                    07. Settings &amp; PFP
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('theme')}
                    className="win-btn px-2.5 py-1.5 text-left text-[var(--pink-love)]"
                  >
                    08. Color / Theme Editor
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('homepage')}
                    className="win-btn px-2.5 py-1.5 text-left text-[var(--green-online)]"
                  >
                    09. My Homepage Builder
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('playlists')}
                    className="win-btn px-2.5 py-1.5 text-left text-[var(--accent-lavender)]"
                  >
                    10. Music &amp; Playlists
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('shorts')}
                    className="win-btn px-2.5 py-1.5 text-left text-[#ff6bd6]"
                  >
                    11. SHORTyes Video Feed
                  </button>
                  <button
                    type="button"
                    onClick={() => navigateTo('search')}
                    className="win-btn px-2.5 py-1.5 text-left text-[#52ff94]"
                  >
                    12. Search Database
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowStartMenu(false);
                      setShowMyDesktop(true);
                    }}
                    className="win-btn px-2.5 py-1.5 text-left text-[#7dd3fc]"
                  >
                    13. My Desktop (Virtual OS)
                  </button>
                  {isStaff && (
                    <button
                      type="button"
                      onClick={() => navigateTo('admin')}
                      className="win-btn px-2.5 py-1.5 text-left text-[#ffd700]"
                    >
                      14. Admin Panel (God Mode)
                    </button>
                  )}
                  <hr className="border-[var(--bevel-mid)] my-1" />
                  <button
                    type="button"
                    onClick={handleLogout}
                    className="win-btn px-2.5 py-1.5 text-left text-[var(--accent-lavender)]"
                  >
                    Log Out / Switch Account
                  </button>
                </div>
              </div>
            )}
          </div>

          <div className="hidden sm:flex items-center gap-1.5 border-l border-[var(--bevel-mid)] pl-2">
            <button
              type="button"
              onClick={() => navigateTo('feed')}
              className="win-btn px-2.5 py-1 text-[11px] flex items-center gap-1.5"
            >
              <span className="w-2 h-2 bg-[var(--accent-violet)]" />
              <span>{currentMeta.short}</span>
            </button>
            <button
              type="button"
              onClick={() => setShowMobileChat((prev) => !prev)}
              className="win-btn px-2.5 py-1 text-[11px] flex items-center gap-1.5"
            >
              <span className="w-2 h-2 bg-[var(--pink-love)]" />
              <span>private chats</span>
            </button>
          </div>
        </div>

        <div className="win-inset px-2.5 py-1 flex items-center gap-3 text-xs">
          <button
            type="button"
            onClick={() => setCrtEnabled((prev) => !prev)}
            className="text-[var(--accent-lavender)] hover:text-white font-pixel-ui text-[10px] cursor-pointer"
            title="Toggle CRT Scanlines"
          >
            CRT:
            <span
              className={
                crtEnabled ? 'text-[var(--green-online)]' : 'text-[var(--pink-love)]'
              }
            >
              {crtEnabled ? 'ON' : 'OFF'}
            </span>
          </button>
          <span className="text-[var(--bevel-mid)]">|</span>
          <TaskbarClock />
        </div>
      </footer>

      {/* OPTIONAL VIRTUAL DESKTOP POPUP (ONLY OPENS ON USER CLICK) */}
      <MyDesktopModal
        isOpen={showMyDesktop}
        currentUsername={currentUser}
        users={users}
        rolesMap={rolesMap}
        onClose={() => setShowMyDesktop(false)}
        onNavigateAppPage={(page) => navigateTo(page)}
        onOpenPublicUrl={openPublicUrl}
        onOpenProfile={viewProfile}
        onToast={showToast}
      />
    </div>
  );
}
