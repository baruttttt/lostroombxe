export type ShortVisibility = 'public' | 'followers' | 'private';

export type ShortPlayerSkin =
  | 'y2k_lavender'
  | 'cyber_crt'
  | 'glitter_pink'
  | 'geocities_gold'
  | 'obsidian_minimal';

export type ShortCategory =
  | 'All'
  | 'Music'
  | 'Gaming'
  | 'Anime & Art'
  | 'Retro Tech'
  | 'Vlog & Daily'
  | 'Comedy'
  | 'Other';

export const SHORT_CATEGORIES: Exclude<ShortCategory, 'All'>[] = [
  'Music',
  'Gaming',
  'Anime & Art',
  'Retro Tech',
  'Vlog & Daily',
  'Comedy',
  'Other',
];

export const SHORT_PLAYER_SKINS: Record<
  ShortPlayerSkin,
  {
    label: string;
    frameBg: string;
    borderColor: string;
    accentColor: string;
    textColor: string;
    badgeBg: string;
  }
> = {
  y2k_lavender: {
    label: 'Y2K Lavender Bevel',
    frameBg: '#160d26',
    borderColor: '#c8b4f8',
    accentColor: '#52ff94',
    textColor: '#eee6ff',
    badgeBg: '#2a1746',
  },
  cyber_crt: {
    label: 'Dark Cyber CRT',
    frameBg: '#040912',
    borderColor: '#00f5d4',
    accentColor: '#00f5d4',
    textColor: '#e2e8f0',
    badgeBg: '#0f172a',
  },
  glitter_pink: {
    label: 'Glitter Pink 2000',
    frameBg: '#2e0820',
    borderColor: '#ff6bd6',
    accentColor: '#ff9ce3',
    textColor: '#ffe4f6',
    badgeBg: '#4a0d34',
  },
  geocities_gold: {
    label: 'Geocities Navy Gold',
    frameBg: '#000055',
    borderColor: '#ffff00',
    accentColor: '#00ffff',
    textColor: '#ffffff',
    badgeBg: '#000088',
  },
  obsidian_minimal: {
    label: 'Obsidian Terminal',
    frameBg: '#09060e',
    borderColor: '#7b42f6',
    accentColor: '#c8b4f8',
    textColor: '#eee6ff',
    badgeBg: '#1a1128',
  },
};

export interface ShortCommentReply {
  id: string;
  shortId: string;
  parentId: string | null;
  authorUsername: string;
  body: string;
  createdAt: string;
}

export interface ShortVideoRecord {
  id: string;
  authorUsername: string;
  authorBio: string;
  authorAvatarUrl: string;
  title: string;
  caption: string;
  category: Exclude<ShortCategory, 'All'>;
  hashtags: string[];
  videoUrl: string;
  mimeType: string;
  sizeBytes: number;
  thumbnailUrl: string;
  visibility: ShortVisibility;
  playerSkin: ShortPlayerSkin;
  views: number;
  likes: string[];
  savedBy: string[];
  commentCount: number;
  isHidden: boolean;
  isFollowingAuthor?: boolean;
  authorFollowerCount?: number;
  createdAt: string;
}

export interface ShortReportRecord {
  id: string;
  shortId: string;
  shortTitle: string;
  shortAuthor: string;
  reporterUsername: string;
  reason: string;
  details: string;
  status: 'open' | 'dismissed' | 'removed';
  createdAt: string;
}

export interface CreatorProfileSummary {
  username: string;
  bio: string;
  avatarUrl: string;
  followerCount: number;
  followingCount: number;
  isFollowing: boolean;
  isBlocked: boolean;
  videos: ShortVideoRecord[];
}
