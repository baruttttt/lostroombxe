export type PageId =
  | 'landing'
  | 'feed'
  | 'forum'
  | 'friends'
  | 'explore'
  | 'search'
  | 'shorts'
  | 'profile'
  | 'upload'
  | 'settings'
  | 'theme'
  | 'homepage'
  | 'playlists'
  | 'admin';

export type UserRole = 'super_admin' | 'admin' | 'moderator' | 'member';
export type UserAccountStatus = 'active' | 'suspended' | 'banned';

export type PixelAvatarKey =
  | 'cat_void'
  | 'blue_ghost'
  | 'lavender_skull'
  | 'cyber_angel';

export interface ThemeVariables {
  '--bg-pitch': string;
  '--bg-void': string;
  '--bg-panel': string;
  '--bg-royal': string;
  '--accent-violet': string;
  '--accent-lavender': string;
  '--text-bright': string;
  '--text-muted': string;
  '--bevel-light': string;
  '--bevel-mid': string;
  '--bevel-dark': string;
  '--green-online': string;
  '--pink-love': string;
}

export interface UserAccount {
  username: string;
  password: string;
  avatarType: 'preset' | 'custom';
  avatarValue: string; // PixelAvatarKey or base64 data URL
  bio: string;
  flags?: string[];
  joined: string;
  role?: UserRole;
  status?: UserAccountStatus;
  themeOverrides?: Partial<ThemeVariables>;
}

export interface PostComment {
  id: string;
  author: string;
  text: string;
  gifUrl?: string;
  likes?: string[];
  time: string;
}

export interface PostItem {
  id: string;
  author: string;
  timestamp: string;
  activityTag: string;
  mood: string;
  content: string;
  mediaType: 'none' | 'image' | 'video';
  mediaUrl: string;
  tags: string[];
  likes: string[];
  comments: PostComment[];
}

export interface ForumCategory {
  id: string;
  name: string;
  description: string;
  icon: 'chat' | 'help' | 'wave' | 'moon' | 'folder';
  createdBy: string;
  createdAt: string;
}

export interface ForumReply {
  id: string;
  author: string;
  body: string;
  createdAt: string;
}

export interface ForumTopic {
  id: string;
  categoryId: string;
  title: string;
  author: string;
  body: string;
  createdAt: string;
  views: number;
  replies: ForumReply[];
}

export interface FriendRequest {
  id: string;
  from: string;
  to: string;
  status: 'pending' | 'accepted' | 'declined';
  time: string;
}

export interface ChatMessage {
  id: string;
  sender: string;
  text: string;
  time: string;
}

export interface NotificationItem {
  id: string;
  targetUser: string | null;
  text: string;
  time: string;
  read: boolean;
}
