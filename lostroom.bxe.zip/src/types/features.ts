export type NotificationCategory =
  | 'private_message'
  | 'comment'
  | 'like'
  | 'follower'
  | 'friend_activity'
  | 'chatroom'
  | 'admin_announcement'
  | 'mention_reply';

export type BuiltinNotificationSoundId =
  | 'retro_ding'
  | 'icq_uhoh'
  | 'aim_door'
  | 'msn_chime'
  | 'win98_bell'
  | 'pixel_coin'
  | 'cyber_ping';

export interface CustomSoundAsset {
  id: string;
  name: string;
  url: string;
}

export interface NotificationCategoryConfig {
  enabled: boolean;
  soundEnabled: boolean;
  soundId: string; // BuiltinNotificationSoundId or `custom:${id}` or direct URL
}

export interface NotificationSettingsConfig {
  soundEnabled: boolean;
  masterMuted: boolean;
  volume: number; // 0 to 1
  browserNotificationsEnabled: boolean;
  customSounds: CustomSoundAsset[];
  categories: Record<NotificationCategory, NotificationCategoryConfig>;
}

export const NOTIFICATION_CATEGORY_LABELS: Record<
  NotificationCategory,
  { label: string; description: string }
> = {
  private_message: {
    label: 'New Private Messages',
    description: 'Direct whispers sent to your private inbox.',
  },
  comment: {
    label: 'New Comments',
    description: 'Comments or GIF replies added to your posts or photos.',
  },
  like: {
    label: 'New Likes',
    description: 'Hearts on your posts, comments, confessions, or album photos.',
  },
  follower: {
    label: 'New Followers',
    description: 'Users who start following your creator channel.',
  },
  friend_activity: {
    label: 'Friend Activity',
    description: 'Incoming friend requests and accepted friendships.',
  },
  chatroom: {
    label: 'Chatroom Messages',
    description: 'Live messages in active community chat windows.',
  },
  admin_announcement: {
    label: 'Admin Announcements',
    description: 'Pinned notices & broadcasts from BARUT Super Admin.',
  },
  mention_reply: {
    label: 'Mentions & Replies',
    description: '@mentions and direct thread replies.',
  },
};

export const BUILTIN_NOTIFICATION_SOUNDS: {
  id: BuiltinNotificationSoundId;
  label: string;
}[] = [
  { id: 'retro_ding', label: 'Retro Crystal Ding' },
  { id: 'icq_uhoh', label: 'Y2K Uh-Oh Classic' },
  { id: 'aim_door', label: 'Buddy Door Chime' },
  { id: 'msn_chime', label: 'Messenger Soft Ping' },
  { id: 'win98_bell', label: 'Win98 System Bell' },
  { id: 'pixel_coin', label: '8-Bit Pixel Spark' },
  { id: 'cyber_ping', label: 'Cyber Terminal Beep' },
];

export function createDefaultNotificationSettings(): NotificationSettingsConfig {
  return {
    soundEnabled: true,
    masterMuted: false,
    volume: 0.65,
    browserNotificationsEnabled: false,
    customSounds: [],
    categories: {
      private_message: { enabled: true, soundEnabled: true, soundId: 'msn_chime' },
      comment: { enabled: true, soundEnabled: true, soundId: 'retro_ding' },
      like: { enabled: true, soundEnabled: true, soundId: 'pixel_coin' },
      follower: { enabled: true, soundEnabled: true, soundId: 'aim_door' },
      friend_activity: { enabled: true, soundEnabled: true, soundId: 'win98_bell' },
      chatroom: { enabled: true, soundEnabled: true, soundId: 'icq_uhoh' },
      admin_announcement: { enabled: true, soundEnabled: true, soundId: 'cyber_ping' },
      mention_reply: { enabled: true, soundEnabled: true, soundId: 'retro_ding' },
    },
  };
}

// ============================================================================
// CUSTOM BADGES SYSTEM
// ============================================================================

export type BadgeRarity = 'common' | 'uncommon' | 'rare' | 'epic' | 'legendary';

export const BADGE_RARITY_META: Record<
  BadgeRarity,
  { label: string; color: string; bg: string }
> = {
  common: { label: 'COMMON', color: '#c8b4f8', bg: '#1a1128' },
  uncommon: { label: 'UNCOMMON', color: '#52ff94', bg: '#0c2418' },
  rare: { label: 'RARE', color: '#38bdf8', bg: '#0b1e33' },
  epic: { label: 'EPIC', color: '#ff6bd6', bg: '#2b0d26' },
  legendary: { label: 'LEGENDARY', color: '#ffd700', bg: '#2e1d04' },
};

export interface CustomBadge {
  id: string;
  creatorUsername: string;
  name: string;
  description: string;
  rarity: BadgeRarity;
  imageUrl: string;
  isOfficial: boolean;
  holdersCount: number;
  createdAt: string;
}

export interface UserBadgeAward {
  id: string;
  username: string;
  badgeId: string;
  awardedBy: string;
  isShowcased: boolean;
  createdAt: string;
  badge: CustomBadge;
}

// ============================================================================
// GIF LIBRARY & COMMENT REPORTS
// ============================================================================

export interface GifAsset {
  id: string;
  title: string;
  tags: string[];
  url: string;
  uploaderUsername: string;
  isBuiltin: boolean;
  createdAt: string;
}

export interface CommentReportRecord {
  id: string;
  targetType: string;
  postId: string;
  commentId: string;
  reporterUsername: string;
  reason: string;
  status: 'open' | 'dismissed' | 'removed';
  createdAt: string;
}

// ============================================================================
// ANONYMOUS CONFESSION BOARD
// ============================================================================

export const CONFESSION_CATEGORIES = [
  'All',
  'Love & Crush',
  'Late Night Thoughts',
  'Secrets',
  'Funny',
  'School & Work',
  'Advice',
] as const;

export type ConfessionCategory = (typeof CONFESSION_CATEGORIES)[number];

export interface ConfessionCommentItem {
  id: string;
  confessionId: string;
  anonAlias: string;
  body: string;
  createdAt: string;
}

export interface ConfessionItem {
  id: string;
  category: string;
  anonAlias: string;
  body: string;
  likesCount: number;
  likedByViewer: boolean;
  commentCount: number;
  createdAt: string;
  // Populated only for Admin moderation endpoints, never public endpoints
  adminAuthorUsername?: string;
}

export interface ConfessionReportItem {
  id: string;
  confessionId: string;
  confessionBody: string;
  confessionCategory: string;
  reporterUsername: string;
  reason: string;
  status: 'open' | 'dismissed' | 'removed';
  createdAt: string;
}

// ============================================================================
// POLL CONTESTS
// ============================================================================

export interface PollOption {
  id: string;
  text: string;
  imageUrl?: string;
  votes: number;
}

export interface PollContestItem {
  id: string;
  creatorUsername: string;
  title: string;
  description: string;
  imageUrl: string;
  allowMultiple: boolean;
  endsAt: string;
  isClosed: boolean;
  isEnded: boolean;
  totalVotes: number;
  viewerVotedOptionIds: string[];
  options: PollOption[];
  createdAt: string;
}

// ============================================================================
// PHOTO ALBUMS
// ============================================================================

export type AlbumPrivacy = 'public' | 'friends' | 'private';

export interface AlbumPhotoComment {
  id: string;
  photoId: string;
  authorUsername: string;
  body: string;
  createdAt: string;
}

export interface AlbumPhotoItem {
  id: string;
  albumId: string;
  ownerUsername: string;
  title: string;
  caption: string;
  imageUrl: string;
  likes: string[];
  commentCount: number;
  createdAt: string;
}

export interface PhotoAlbumItem {
  id: string;
  ownerUsername: string;
  title: string;
  description: string;
  privacy: AlbumPrivacy;
  coverUrl: string;
  photoCount: number;
  createdAt: string;
  updatedAt: string;
}
