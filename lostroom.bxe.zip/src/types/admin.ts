import { UserAccountStatus, UserRole } from './lostroom';

export type AnnouncementCategory = 'normal' | 'important' | 'maintenance' | 'event';

export interface SiteSettings {
  maintenanceMode: boolean;
  maintenanceMessage: string;
  registrationEnabled: boolean;
  postingEnabled: boolean;
  commentsEnabled: boolean;
  chatEnabled: boolean;
  globalBannerText: string;
  globalBannerEnabled: boolean;
  siteNotice: string;
}

export interface AnnouncementItem {
  id: string;
  title: string;
  body: string;
  category: AnnouncementCategory;
  isPinned: boolean;
  showBanner: boolean;
  sendToNotifications: boolean;
  scheduledAt: string | null;
  authorUsername: string;
  createdAt: string;
  updatedAt: string;
}

export interface SitePublicState {
  settings: SiteSettings;
  announcements: AnnouncementItem[];
  rolesByUsername: Record<string, UserRole>;
  flagsByUsername?: Record<string, string[]>;
}

export interface AdminUserRecord {
  username: string;
  bio: string;
  avatarUrl: string;
  role: UserRole;
  status: UserAccountStatus;
  isDeleted: boolean;
  createdAt: string;
  lastSeenAt: string;
  postCount: number;
  topicCount: number;
  shortCount: number;
}

export interface AdminPostRecord {
  id: string;
  kind: 'blog' | 'forum';
  author: string;
  title: string;
  content: string;
  createdAt: string;
  isDeleted: boolean;
  isPinned: boolean;
  deletedBy: string;
  deletedAt: string;
  comments: { id: string; author: string; text: string; time: string }[];
  likeCount: number;
}

export interface AdminAuditLogItem {
  id: string;
  actorUsername: string;
  actorRole: UserRole;
  action: string;
  targetType: string;
  targetId: string;
  details: string;
  result: string;
  createdAt: string;
}

export interface AdminOverviewData {
  stats: {
    totalUsers: number;
    totalPosts: number;
    onlineUsers: number;
    totalComments: number;
    newRegistrations7d: number;
    openReports: number;
    suspendedAccounts: number;
    bannedAccounts: number;
    deletedPosts: number;
  };
  administrators: AdminUserRecord[];
  recentLogs: AdminAuditLogItem[];
  recentReports: {
    id: string;
    shortId: string;
    shortTitle: string;
    shortAuthor: string;
    reporterUsername: string;
    reason: string;
    status: string;
    createdAt: string;
  }[];
}
