export type HomepageTemplateId =
  | 'geocities'
  | 'glitter_pink'
  | 'anime_fanpage'
  | 'dark_cyber'
  | 'pixel_art'
  | 'personal_blog'
  | 'minimal_retro'
  | 'y2k_aesthetic';

export type HomepageFontFamily =
  | 'vt323'
  | 'silkscreen'
  | 'courier'
  | 'georgia'
  | 'verdana'
  | 'comic';

export type HomepageBorderStyle =
  | 'solid'
  | 'dashed'
  | 'dotted'
  | 'double'
  | 'ridge'
  | 'outset';

export type GlitterEffectType =
  | 'none'
  | 'silver_twinkle'
  | 'pink_glitter'
  | 'lavender_stars'
  | 'cyber_grid';

export type StickerIconId =
  | 'sparkle_stars'
  | 'pixel_heart'
  | 'under_construction'
  | 'cyber_butterfly'
  | 'music_note'
  | 'retro_cd';

export type PlayerSkinId =
  | 'winamp_classic'
  | 'glitter_pop'
  | 'lavender_mini'
  | 'cyber_deck'
  | 'pixel_jukebox';

export type PlayerWidthOption = '280px' | '360px' | '100%';

export interface MusicPlayerStyleConfig {
  skin: PlayerSkinId;
  bgColor: string;
  borderColor: string;
  borderStyle: HomepageBorderStyle;
  buttonBg: string;
  buttonText: string;
  textColor: string;
  accentColor: string;
  width: PlayerWidthOption;
  glitterOverlay: boolean;
  pixelIcons: boolean;
}

export type HomepageBlockType =
  | 'heading'
  | 'text'
  | 'image'
  | 'button_link'
  | 'two_column'
  | 'sticker_divider'
  | 'music_player'
  | 'guestbook_counter';

export interface HomepageBlock {
  id: string;
  type: HomepageBlockType;
  title?: string;
  content?: string;
  align?: 'left' | 'center' | 'right';
  imageUrl?: string;
  imageWidth?: string;
  imageCaption?: string;
  linkUrl?: string;
  linkLabel?: string;
  buttonBg?: string;
  buttonText?: string;
  secondaryTitle?: string;
  secondaryContent?: string;
  stickerId?: StickerIconId;
  marqueeText?: string;
  playlistId?: string;
  playerConfig?: MusicPlayerStyleConfig;
  sectionBg?: string;
  sectionBorderColor?: string;
  sectionPadding?: number;
}

export interface HomepageThemeConfig {
  templateId: HomepageTemplateId;
  pageTitle: string;
  pageDescription: string;
  pageWidth: '680px' | '820px' | '980px' | '100%';
  containerPadding: number;
  sectionGap: number;
  bgColor: string;
  bgImageUrl: string;
  bgRepeat: 'repeat' | 'cover' | 'no-repeat';
  glitterEffect: GlitterEffectType;
  bannerImageUrl: string;
  bannerHeight: number;
  bannerFit: 'cover' | 'contain';
  textColor: string;
  headingColor: string;
  linkColor: string;
  fontFamily: HomepageFontFamily;
  borderStyle: HomepageBorderStyle;
  borderColor: string;
  borderWidth: number;
}

export interface HomepageDocument {
  theme: HomepageThemeConfig;
  blocks: HomepageBlock[];
}

export interface MediaAsset {
  id: string;
  ownerUsername: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  kind: 'image' | 'sticker' | 'banner' | 'background' | 'cover';
  url: string;
  createdAt: string;
}

export interface AudioTrack {
  id: string;
  ownerUsername: string;
  title: string;
  artist: string;
  description: string;
  coverUrl: string;
  filename: string;
  mimeType: string;
  sizeBytes: number;
  url: string;
  rightsConfirmed: boolean;
  createdAt: string;
}

export interface PlaylistRecord {
  id: string;
  ownerUsername: string;
  slug: string;
  name: string;
  description: string;
  coverUrl: string;
  isPublic: boolean;
  trackIds: string[];
  tracks?: AudioTrack[];
  likes: string[];
  savedBy: string[];
  createdAt: string;
  updatedAt: string;
}

export interface GuestbookEntry {
  id: string;
  homepageUsername: string;
  authorUsername: string;
  message: string;
  createdAt: string;
}

export interface HomepageRecord {
  username: string;
  isPublished: boolean;
  draft: HomepageDocument;
  published: HomepageDocument | null;
  visitorCount: number;
  updatedAt: string;
  publishedAt: string | null;
}
