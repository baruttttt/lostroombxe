export type DesktopThemePreset =
  | 'win98'
  | 'frutiger_aero'
  | 'gothic'
  | 'minimal'
  | 'custom';

export type DesktopAppId =
  | 'files'
  | 'music'
  | 'gallery'
  | 'notepad'
  | 'calculator'
  | 'calendar'
  | 'browser'
  | 'settings'
  | 'games'
  | 'profile';

export interface DesktopIconConfig {
  id: DesktopAppId;
  label: string;
  iconGlyph: string;
  x: number;
  y: number;
}

export interface DesktopNote {
  id: string;
  title: string;
  body: string;
  updatedAt: string;
}

export interface DesktopFileItem {
  id: string;
  name: string;
  type: 'folder' | 'text' | 'link';
  parentId: string | null;
  content: string;
  createdAt: string;
}

export interface DesktopCalendarEvent {
  id: string;
  date: string; // YYYY-MM-DD
  title: string;
}

export interface DesktopConfig {
  themePreset: DesktopThemePreset;
  wallpaperUrl: string;
  wallpaperBg: string;
  windowBg: string;
  windowTitleBg: string;
  windowBorder: string;
  textColor: string;
  taskbarBg: string;
  taskbarText: string;
  taskbarPosition: 'bottom' | 'top';
  clockFormat: '12h' | '24h';
  showDateInClock: boolean;
  icons: DesktopIconConfig[];
}

export interface DesktopWindowState {
  id: DesktopAppId;
  title: string;
  isOpen: boolean;
  isMinimized: boolean;
  isMaximized: boolean;
  x: number;
  y: number;
  width: number;
  height: number;
  zIndex: number;
}

export interface UserDesktopPayload {
  username: string;
  isPublic: boolean;
  isOwner: boolean;
  config: DesktopConfig;
  notes: DesktopNote[];
  files: DesktopFileItem[];
  calendarEvents: DesktopCalendarEvent[];
  updatedAt: string;
}

export const DESKTOP_THEME_PRESETS: Record<
  DesktopThemePreset,
  {
    label: string;
    wallpaperBg: string;
    windowBg: string;
    windowTitleBg: string;
    windowBorder: string;
    textColor: string;
    taskbarBg: string;
    taskbarText: string;
  }
> = {
  win98: {
    label: 'Windows 98',
    wallpaperBg: '#008080',
    windowBg: '#c0c0c0',
    windowTitleBg: '#000080',
    windowBorder: '#dfdfdf',
    textColor: '#111111',
    taskbarBg: '#c0c0c0',
    taskbarText: '#000000',
  },
  frutiger_aero: {
    label: 'Y2K / Frutiger Aero',
    wallpaperBg: 'linear-gradient(135deg, #0ea5e9 0%, #38bdf8 42%, #86efac 100%)',
    windowBg: '#e0f7ff',
    windowTitleBg: 'linear-gradient(90deg, #0284c7 0%, #22d3ee 100%)',
    windowBorder: '#7dd3fc',
    textColor: '#0c4a6e',
    taskbarBg: '#0369a1',
    taskbarText: '#f0f9ff',
  },
  gothic: {
    label: 'Gothic Velvet',
    wallpaperBg: 'radial-gradient(circle at top, #2d0a31 0%, #09030c 100%)',
    windowBg: '#160b1c',
    windowTitleBg: 'linear-gradient(90deg, #4a044e 0%, #9d174d 100%)',
    windowBorder: '#a855f7',
    textColor: '#f3e8ff',
    taskbarBg: '#110617',
    taskbarText: '#f5d0fe',
  },
  minimal: {
    label: 'Minimal Monochrome',
    wallpaperBg: '#18181b',
    windowBg: '#27272a',
    windowTitleBg: '#3f3f46',
    windowBorder: '#71717a',
    textColor: '#fafafa',
    taskbarBg: '#09090b',
    taskbarText: '#e4e4e7',
  },
  custom: {
    label: 'Custom Theme',
    wallpaperBg: 'linear-gradient(135deg, #1a1128 0%, #2a1746 100%)',
    windowBg: '#1a1128',
    windowTitleBg: 'linear-gradient(90deg, #2a1746 0%, #7b42f6 100%)',
    windowBorder: '#c8b4f8',
    textColor: '#eee6ff',
    taskbarBg: '#120c1c',
    taskbarText: '#eee6ff',
  },
};

export const DEFAULT_DESKTOP_ICONS: DesktopIconConfig[] = [
  { id: 'files', label: 'My Files', iconGlyph: '📁', x: 18, y: 18 },
  { id: 'music', label: 'Music Player', iconGlyph: '🎵', x: 18, y: 102 },
  { id: 'gallery', label: 'Gallery', iconGlyph: '🖼️', x: 18, y: 186 },
  { id: 'notepad', label: 'Notepad', iconGlyph: '📝', x: 18, y: 270 },
  { id: 'calculator', label: 'Calculator', iconGlyph: '🧮', x: 18, y: 354 },
  { id: 'calendar', label: 'Calendar', iconGlyph: '📅', x: 112, y: 18 },
  { id: 'browser', label: 'Browser', iconGlyph: '🌐', x: 112, y: 102 },
  { id: 'games', label: 'Games', iconGlyph: '🕹️', x: 112, y: 186 },
  { id: 'settings', label: 'Settings', iconGlyph: '⚙️', x: 112, y: 270 },
  { id: 'profile', label: 'My Profile', iconGlyph: '👤', x: 112, y: 354 },
];

export function createDefaultDesktopConfig(): DesktopConfig {
  const preset = DESKTOP_THEME_PRESETS.win98;
  return {
    themePreset: 'win98',
    wallpaperUrl: '',
    wallpaperBg: preset.wallpaperBg,
    windowBg: preset.windowBg,
    windowTitleBg: preset.windowTitleBg,
    windowBorder: preset.windowBorder,
    textColor: preset.textColor,
    taskbarBg: preset.taskbarBg,
    taskbarText: preset.taskbarText,
    taskbarPosition: 'bottom',
    clockFormat: '24h',
    showDateInClock: true,
    icons: DEFAULT_DESKTOP_ICONS.map((ic) => ({ ...ic })),
  };
}
