import { ForumCategory } from '../types/lostroom';

export const DEFAULT_FORUM_CATEGORIES: ForumCategory[] = [
  {
    id: 'cat-general',
    name: 'General Chat',
    description: 'Open discussion board for late-night thoughts, music, and random topics.',
    icon: 'chat',
    createdBy: 'system',
    createdAt: '2005-01-01',
  },
  {
    id: 'cat-help',
    name: 'Help',
    description: 'Questions about LOSTROOM.BXE accounts, CRT settings, uploads, and private chats.',
    icon: 'help',
    createdBy: 'system',
    createdAt: '2005-01-01',
  },
  {
    id: 'cat-intro',
    name: 'Introductions',
    description: 'Say hello to other registered users and share what brings you to LOSTROOM.BXE.',
    icon: 'wave',
    createdBy: 'system',
    createdAt: '2005-01-01',
  },
];
