import {
  HomepageDocument,
  HomepageTemplateId,
  MusicPlayerStyleConfig,
  PlayerSkinId,
} from '../types/homepage';

export const PLAYER_SKIN_PRESETS: Record<
  PlayerSkinId,
  { label: string; config: Omit<MusicPlayerStyleConfig, 'width' | 'glitterOverlay' | 'pixelIcons'> }
> = {
  winamp_classic: {
    label: 'Winamp Classic',
    config: {
      skin: 'winamp_classic',
      bgColor: '#1b1d26',
      borderColor: '#7a869a',
      borderStyle: 'ridge',
      buttonBg: '#363b4d',
      buttonText: '#e6edf7',
      textColor: '#39ff14',
      accentColor: '#60a5fa',
    },
  },
  glitter_pop: {
    label: 'Glitter Pink Pop',
    config: {
      skin: 'glitter_pop',
      bgColor: '#3b0c29',
      borderColor: '#ff85d8',
      borderStyle: 'double',
      buttonBg: '#ff4db8',
      buttonText: '#ffffff',
      textColor: '#ffe4f6',
      accentColor: '#f9a8d4',
    },
  },
  lavender_mini: {
    label: 'BXE Lavender Mini',
    config: {
      skin: 'lavender_mini',
      bgColor: '#1a1128',
      borderColor: '#c8b4f8',
      borderStyle: 'outset',
      buttonBg: '#7b42f6',
      buttonText: '#ffffff',
      textColor: '#eee6ff',
      accentColor: '#52ff94',
    },
  },
  cyber_deck: {
    label: 'Dark Cyber Deck',
    config: {
      skin: 'cyber_deck',
      bgColor: '#05080f',
      borderColor: '#00f5d4',
      borderStyle: 'solid',
      buttonBg: '#0f172a',
      buttonText: '#00f5d4',
      textColor: '#e2e8f0',
      accentColor: '#a855f7',
    },
  },
  pixel_jukebox: {
    label: 'Pixel 8-Bit Jukebox',
    config: {
      skin: 'pixel_jukebox',
      bgColor: '#221436',
      borderColor: '#facc15',
      borderStyle: 'dashed',
      buttonBg: '#4c1d95',
      buttonText: '#fef08a',
      textColor: '#fef9c3',
      accentColor: '#f472b6',
    },
  },
};

export function createDefaultPlayerConfig(skin: PlayerSkinId = 'lavender_mini'): MusicPlayerStyleConfig {
  const preset = PLAYER_SKIN_PRESETS[skin].config;
  return {
    ...preset,
    width: '360px',
    glitterOverlay: skin === 'glitter_pop',
    pixelIcons: true,
  };
}

export const HOMEPAGE_TEMPLATE_LIST: {
  id: HomepageTemplateId;
  name: string;
  tagline: string;
  previewAccent: string;
  previewBg: string;
}[] = [
  {
    id: 'geocities',
    name: 'Classic Geocities',
    tagline: 'Royal blue tables, yellow links, visitor counter & under-construction charm',
    previewAccent: '#ffff00',
    previewBg: '#000066',
  },
  {
    id: 'glitter_pink',
    name: 'Glitter Pink Website',
    tagline: 'Sparkling magenta overlays, heart stickers & cute Y2K buttons',
    previewAccent: '#ff66cc',
    previewBg: '#2e0821',
  },
  {
    id: 'anime_fanpage',
    name: 'Anime Fanpage',
    tagline: 'Twilight indigo shrine, two-column bio & character notes',
    previewAccent: '#a78bfa',
    previewBg: '#120e2b',
  },
  {
    id: 'dark_cyber',
    name: 'Dark Cyber Website',
    tagline: 'Obsidian matrix grid, neon violet/cyan borders & terminal player',
    previewAccent: '#00f5d4',
    previewBg: '#060913',
  },
  {
    id: 'pixel_art',
    name: 'Pixel-Art Homepage',
    tagline: 'Crisp bitmap headings, arcade stickers & retro jukebox',
    previewAccent: '#52ff94',
    previewBg: '#191029',
  },
  {
    id: 'personal_blog',
    name: 'Personal Blog',
    tagline: 'Cozy diary layout, dated journal blocks & guestbook corner',
    previewAccent: '#d8b4fe',
    previewBg: '#1a1625',
  },
  {
    id: 'minimal_retro',
    name: 'Minimal Retro Website',
    tagline: 'High-contrast monochrome & lavender hairline borders',
    previewAccent: '#c4b5fd',
    previewBg: '#0c0c10',
  },
  {
    id: 'y2k_aesthetic',
    name: 'Y2K Aesthetic Website',
    tagline: 'Lavender bevels, star dividers, music deck & sparkle vibes',
    previewAccent: '#ff6bd6',
    previewBg: '#1a0f2e',
  },
];

export function buildTemplateDocument(
  templateId: HomepageTemplateId,
  username: string
): HomepageDocument {
  const safeUser = username || 'visitor';

  switch (templateId) {
    case 'geocities':
      return {
        theme: {
          templateId: 'geocities',
          pageTitle: `~*~ ${safeUser}'s Geo-Zone ~*~`,
          pageDescription: `Welcome to ${safeUser}'s classic 2000s corner of the web!`,
          pageWidth: '820px',
          containerPadding: 20,
          sectionGap: 16,
          bgColor: '#000055',
          bgImageUrl: '',
          bgRepeat: 'repeat',
          glitterEffect: 'lavender_stars',
          bannerImageUrl: '',
          bannerHeight: 140,
          bannerFit: 'cover',
          textColor: '#ffffff',
          headingColor: '#ffff00',
          linkColor: '#00ffff',
          fontFamily: 'verdana',
          borderStyle: 'ridge',
          borderColor: '#c0c0c0',
          borderWidth: 4,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `WELCOME TO ${safeUser.toUpperCase()}'S HOMEPAGE!!`,
            content: 'Best viewed at 1024x768 · Sign my guestbook before leaving!',
            align: 'center',
            sectionBg: '#000088',
            sectionBorderColor: '#ffff00',
          },
          {
            id: 'blk-2',
            type: 'sticker_divider',
            stickerId: 'under_construction',
            marqueeText: `*** Welcome to ${safeUser}'s web shrine! New MP3s & links added weekly! ***`,
          },
          {
            id: 'blk-3',
            type: 'two_column',
            title: 'About Webmaster',
            content: `Hi! I'm ${safeUser}. I collect pixel art, burn midnight mixtapes, and build retro pages on LOSTROOM.BXE.`,
            secondaryTitle: 'Cool Webrings & Links',
            secondaryContent: 'Favorite spots: Midnight Forums, 8-Bit Archive, CRT Club.',
            sectionBg: '#000044',
            sectionBorderColor: '#00ffff',
          },
          {
            id: 'blk-4',
            type: 'music_player',
            title: 'My Geo-Jukebox',
            playerConfig: createDefaultPlayerConfig('winamp_classic'),
          },
          {
            id: 'blk-5',
            type: 'button_link',
            linkLabel: 'Visit Lostroom.BXE Feed',
            linkUrl: '/',
            buttonBg: '#ffff00',
            buttonText: '#000055',
            align: 'center',
          },
          {
            id: 'blk-6',
            type: 'guestbook_counter',
            title: 'Guestbook & Hit Counter',
          },
        ],
      };

    case 'glitter_pink':
      return {
        theme: {
          templateId: 'glitter_pink',
          pageTitle: `♡ ${safeUser}'s Glitter Palace ♡`,
          pageDescription: 'sparkles, pink pixels, and cute playlists',
          pageWidth: '820px',
          containerPadding: 22,
          sectionGap: 18,
          bgColor: '#2d0921',
          bgImageUrl: '',
          bgRepeat: 'repeat',
          glitterEffect: 'pink_glitter',
          bannerImageUrl: '',
          bannerHeight: 160,
          bannerFit: 'cover',
          textColor: '#ffe8f7',
          headingColor: '#ff85d8',
          linkColor: '#ffb8eb',
          fontFamily: 'comic',
          borderStyle: 'double',
          borderColor: '#ff66cc',
          borderWidth: 4,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `♡ ${safeUser}'s glitter world ♡`,
            content: 'thanks for visiting my cute homepage!!',
            align: 'center',
            sectionBg: '#450e33',
            sectionBorderColor: '#ff9ce3',
          },
          {
            id: 'blk-2',
            type: 'sticker_divider',
            stickerId: 'pixel_heart',
            marqueeText: '♡~ sparkle every day ~♡~ listen to my favorite tracks below ~♡',
          },
          {
            id: 'blk-3',
            type: 'text',
            title: 'About Me & My Likes',
            content: `Name: ${safeUser}\nMood: dreamy & sparkly\nLikes: pastel gifs, strawberry milk, late night music, and friends!`,
            align: 'left',
            sectionBg: '#3a0b2a',
            sectionBorderColor: '#ff66cc',
          },
          {
            id: 'blk-4',
            type: 'music_player',
            title: 'Glitter Playlist',
            playerConfig: createDefaultPlayerConfig('glitter_pop'),
          },
          {
            id: 'blk-5',
            type: 'guestbook_counter',
            title: 'Sign My Pink Guestbook ♡',
          },
        ],
      };

    case 'anime_fanpage':
      return {
        theme: {
          templateId: 'anime_fanpage',
          pageTitle: `${safeUser} // Twilight Anime Shrine`,
          pageDescription: '2000s anime fanpage, favorite OSTs, and character gallery',
          pageWidth: '980px',
          containerPadding: 20,
          sectionGap: 16,
          bgColor: '#100c26',
          bgImageUrl: '',
          bgRepeat: 'cover',
          glitterEffect: 'lavender_stars',
          bannerImageUrl: '',
          bannerHeight: 180,
          bannerFit: 'cover',
          textColor: '#e9e4ff',
          headingColor: '#c4b5fd',
          linkColor: '#f472b6',
          fontFamily: 'georgia',
          borderStyle: 'solid',
          borderColor: '#8b5cf6',
          borderWidth: 2,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `${safeUser}'s Midnight Shrine`,
            content: 'fanpage · ost archive · gallery · shrine links',
            align: 'center',
            sectionBg: '#1c1540',
            sectionBorderColor: '#a78bfa',
          },
          {
            id: 'blk-2',
            type: 'two_column',
            title: 'Shrine Dedication',
            content: 'Dedicated to classic 90s/2000s OVA aesthetics, rainy cityscapes, and late-night soundtrack CDs.',
            secondaryTitle: 'Top Episodes & Quotes',
            secondaryContent: '"No matter where you go, everyone is connected." — Favorite late-night rewatch.',
            sectionBg: '#161133',
            sectionBorderColor: '#7c3aed',
          },
          {
            id: 'blk-3',
            type: 'music_player',
            title: 'OST Listening Corner',
            playerConfig: createDefaultPlayerConfig('lavender_mini'),
          },
          {
            id: 'blk-4',
            type: 'guestbook_counter',
            title: 'Shrine Guestbook',
          },
        ],
      };

    case 'dark_cyber':
      return {
        theme: {
          templateId: 'dark_cyber',
          pageTitle: `${safeUser}.SYS // CYBER TERMINAL`,
          pageDescription: 'Encrypted personal node and midnight MP3 deck',
          pageWidth: '820px',
          containerPadding: 18,
          sectionGap: 14,
          bgColor: '#050812',
          bgImageUrl: '',
          bgRepeat: 'repeat',
          glitterEffect: 'cyber_grid',
          bannerImageUrl: '',
          bannerHeight: 140,
          bannerFit: 'cover',
          textColor: '#d1fae5',
          headingColor: '#00f5d4',
          linkColor: '#a855f7',
          fontFamily: 'courier',
          borderStyle: 'solid',
          borderColor: '#00f5d4',
          borderWidth: 2,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `NODE://${safeUser.toUpperCase()}`,
            content: 'ACCESS GRANTED · PERSONAL CYBER HOMEPAGE',
            align: 'left',
            sectionBg: '#0b1224',
            sectionBorderColor: '#00f5d4',
          },
          {
            id: 'blk-2',
            type: 'text',
            title: 'SYSTEM LOG',
            content: `Operator: ${safeUser}\nUplink: Active\nNotes: Uploading dark synth tracks, CRT captures, and custom links.`,
            align: 'left',
            sectionBg: '#090f1e',
            sectionBorderColor: '#7b42f6',
          },
          {
            id: 'blk-3',
            type: 'music_player',
            title: 'CYBER AUDIO DECK',
            playerConfig: createDefaultPlayerConfig('cyber_deck'),
          },
          {
            id: 'blk-4',
            type: 'guestbook_counter',
            title: 'TERMINAL GUESTBOOK',
          },
        ],
      };

    case 'pixel_art':
      return {
        theme: {
          templateId: 'pixel_art',
          pageTitle: `${safeUser}'s 8-Bit Pixel Home`,
          pageDescription: 'Pixel art stickers, chiptune MP3s, and retro frames',
          pageWidth: '820px',
          containerPadding: 20,
          sectionGap: 16,
          bgColor: '#160d24',
          bgImageUrl: '',
          bgRepeat: 'repeat',
          glitterEffect: 'silver_twinkle',
          bannerImageUrl: '',
          bannerHeight: 150,
          bannerFit: 'cover',
          textColor: '#f3e8ff',
          headingColor: '#52ff94',
          linkColor: '#facc15',
          fontFamily: 'silkscreen',
          borderStyle: 'dashed',
          borderColor: '#52ff94',
          borderWidth: 3,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `PIXEL HOME OF ${safeUser.toUpperCase()}`,
            content: '8-BIT GRAPHICS · CHIPTUNES · GUESTBOOK',
            align: 'center',
            sectionBg: '#231538',
            sectionBorderColor: '#facc15',
          },
          {
            id: 'blk-2',
            type: 'sticker_divider',
            stickerId: 'retro_cd',
            marqueeText: '★ INSERT COIN TO PLAY MY MIXTAPE ★ PIXEL ART ZONE ★',
          },
          {
            id: 'blk-3',
            type: 'music_player',
            title: '8-BIT JUKEBOX',
            playerConfig: createDefaultPlayerConfig('pixel_jukebox'),
          },
          {
            id: 'blk-4',
            type: 'guestbook_counter',
            title: 'ARCADE GUESTBOOK',
          },
        ],
      };

    case 'personal_blog':
      return {
        theme: {
          templateId: 'personal_blog',
          pageTitle: `${safeUser}'s Midnight Diary`,
          pageDescription: 'Personal web log, late-night entries, and listening journal',
          pageWidth: '680px',
          containerPadding: 24,
          sectionGap: 18,
          bgColor: '#15111f',
          bgImageUrl: '',
          bgRepeat: 'no-repeat',
          glitterEffect: 'none',
          bannerImageUrl: '',
          bannerHeight: 140,
          bannerFit: 'cover',
          textColor: '#ede9fe',
          headingColor: '#d8b4fe',
          linkColor: '#f472b6',
          fontFamily: 'georgia',
          borderStyle: 'solid',
          borderColor: '#6d28d9',
          borderWidth: 2,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `${safeUser}'s Web Diary`,
            content: 'quiet notes from after midnight',
            align: 'left',
            sectionBg: '#1e182d',
            sectionBorderColor: '#8b5cf6',
          },
          {
            id: 'blk-2',
            type: 'text',
            title: 'Entry #01 — Setting up my homepage',
            content: 'Just moved into my own space on LOSTROOM.BXE. Gonna post favorite songs, photos from walks, and random thoughts here.',
            align: 'left',
            sectionBg: '#1b1628',
            sectionBorderColor: '#4c1d95',
          },
          {
            id: 'blk-3',
            type: 'music_player',
            title: 'Currently Listening To',
            playerConfig: createDefaultPlayerConfig('lavender_mini'),
          },
          {
            id: 'blk-4',
            type: 'guestbook_counter',
            title: 'Leave a Note in My Guestbook',
          },
        ],
      };

    case 'minimal_retro':
      return {
        theme: {
          templateId: 'minimal_retro',
          pageTitle: `${safeUser} — minimal.htm`,
          pageDescription: 'Clean monochrome and lavender retro homepage',
          pageWidth: '680px',
          containerPadding: 24,
          sectionGap: 16,
          bgColor: '#0b0b0f',
          bgImageUrl: '',
          bgRepeat: 'no-repeat',
          glitterEffect: 'none',
          bannerImageUrl: '',
          bannerHeight: 120,
          bannerFit: 'cover',
          textColor: '#e4e4e7',
          headingColor: '#c4b5fd',
          linkColor: '#a78bfa',
          fontFamily: 'vt323',
          borderStyle: 'dotted',
          borderColor: '#71717a',
          borderWidth: 2,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `${safeUser}.htm`,
            content: 'simple · quiet · independent web',
            align: 'left',
            sectionBg: '#121218',
            sectionBorderColor: '#a78bfa',
          },
          {
            id: 'blk-2',
            type: 'text',
            title: 'Index',
            content: 'Welcome. Everything on this page is curated by hand. Scroll down to play my MP3 playlist or sign the guestbook.',
            align: 'left',
            sectionBg: '#121218',
            sectionBorderColor: '#52525b',
          },
          {
            id: 'blk-3',
            type: 'music_player',
            title: 'Audio',
            playerConfig: createDefaultPlayerConfig('lavender_mini'),
          },
          {
            id: 'blk-4',
            type: 'guestbook_counter',
            title: 'Guestbook',
          },
        ],
      };

    case 'y2k_aesthetic':
    default:
      return {
        theme: {
          templateId: 'y2k_aesthetic',
          pageTitle: `★ ${safeUser}'s Y2K Space ★`,
          pageDescription: 'Lavender chrome, custom MP3 player, stickers & guestbook',
          pageWidth: '820px',
          containerPadding: 20,
          sectionGap: 16,
          bgColor: '#140b24',
          bgImageUrl: '',
          bgRepeat: 'repeat',
          glitterEffect: 'silver_twinkle',
          bannerImageUrl: '',
          bannerHeight: 160,
          bannerFit: 'cover',
          textColor: '#f5efff',
          headingColor: '#ff6bd6',
          linkColor: '#52ff94',
          fontFamily: 'vt323',
          borderStyle: 'outset',
          borderColor: '#c8b4f8',
          borderWidth: 3,
        },
        blocks: [
          {
            id: 'blk-1',
            type: 'heading',
            title: `★ ${safeUser}'S LOSTROOM HOMEPAGE ★`,
            content: 'sometime, everytime... welcome to my personal cyber room!',
            align: 'center',
            sectionBg: '#22133b',
            sectionBorderColor: '#c8b4f8',
          },
          {
            id: 'blk-2',
            type: 'sticker_divider',
            stickerId: 'sparkle_stars',
            marqueeText: `★ ${safeUser} is online ★ check out my music playlist & drop a message in my guestbook! ★`,
          },
          {
            id: 'blk-3',
            type: 'two_column',
            title: 'Who I Am',
            content: `Handle: ${safeUser}\nVibe: 2000s lavender & CRT static.\nDrop a comment or check out my saved playlists!`,
            secondaryTitle: 'My Top Links',
            secondaryContent: 'Bookmark this URL: /user/' + safeUser + ' — always open to cool visitors.',
            sectionBg: '#1c1030',
            sectionBorderColor: '#7b42f6',
          },
          {
            id: 'blk-4',
            type: 'music_player',
            title: 'My Custom Y2K Player',
            playerConfig: createDefaultPlayerConfig('lavender_mini'),
          },
          {
            id: 'blk-5',
            type: 'guestbook_counter',
            title: 'Visitor Counter & Guestbook',
          },
        ],
      };
  }
}
