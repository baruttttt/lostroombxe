import React, { useEffect, useState } from 'react';
import { RetroMusicPlayer } from '../components/RetroMusicPlayer';
import { createDefaultPlayerConfig } from '../data/homepageTemplates';
import { PlaylistRecord } from '../types/homepage';
import {
  getPlaylistDetail,
  toggleLikePlaylist,
  toggleSavePlaylist,
} from '../utils/homepageApi';

interface PublicPlaylistPageProps {
  username: string;
  slug: string;
  currentViewerUsername: string | null;
  onReturnToLostroom: () => void;
  onOpenUserHomepage: (username: string) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const PublicPlaylistPage: React.FC<PublicPlaylistPageProps> = ({
  username,
  slug,
  currentViewerUsername,
  onReturnToLostroom,
  onOpenUserHomepage,
  onToast,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [playlist, setPlaylist] = useState<PlaylistRecord | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getPlaylistDetail(username, slug, currentViewerUsername);
      setPlaylist(res.playlist);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Playlist not found.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [username, slug]);

  const handleLike = async () => {
    if (!playlist) return;
    if (!currentViewerUsername) {
      onToast('Log in inside LOSTROOM.BXE to like playlists.', 'error');
      return;
    }
    try {
      const res = await toggleLikePlaylist(playlist.id, currentViewerUsername);
      setPlaylist(res.playlist);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to like playlist.', 'error');
    }
  };

  const handleSave = async () => {
    if (!playlist) return;
    if (!currentViewerUsername) {
      onToast('Log in inside LOSTROOM.BXE to save playlists.', 'error');
      return;
    }
    try {
      const res = await toggleSavePlaylist(playlist.id, currentViewerUsername);
      setPlaylist(res.playlist);
      onToast(
        res.playlist.savedBy.includes(currentViewerUsername)
          ? 'Saved playlist to your account!'
          : 'Removed from saved playlists.'
      );
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to save playlist.', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-[#09060e] text-[#eee6ff] flex flex-col">
      <div className="bg-[#120c1c] border-b-2 border-[#7b42f6] px-3 py-2 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onReturnToLostroom}
            className="win-btn win-btn-primary px-2.5 py-1 text-xs"
          >
            &lt;&lt; LOSTROOM.BXE
          </button>
          <span className="font-pixel-ui text-xs text-[#c8b4f8]">
            /playlist/{username}/{slug}
          </span>
        </div>
        <div className="flex gap-1.5">
          <button
            type="button"
            onClick={() => onOpenUserHomepage(username)}
            className="win-btn px-2.5 py-1 text-[10px] text-[#52ff94]"
          >
            VISIT {username.toUpperCase()}&apos;S HOMEPAGE
          </button>
          <button
            type="button"
            onClick={() => {
              navigator.clipboard?.writeText(window.location.href).catch(() => {});
              onToast('Copied playlist URL!');
            }}
            className="win-btn px-2.5 py-1 text-[10px]"
          >
            COPY LINK
          </button>
        </div>
      </div>

      <div className="max-w-2xl w-full mx-auto px-4 py-8 flex-1">
        {loading ? (
          <div className="win-box p-6 text-center font-pixel-ui text-xs text-[#c8b4f8]">
            LOADING PLAYLIST...
          </div>
        ) : error || !playlist ? (
          <div className="win-box p-6 text-center space-y-3">
            <div className="font-pixel-ui text-sm text-[#ff6bd6]">PLAYLIST UNAVAILABLE</div>
            <p className="text-[#c8b4f8]">{error}</p>
            <button
              type="button"
              onClick={onReturnToLostroom}
              className="win-btn win-btn-primary px-4 py-1.5 text-xs"
            >
              RETURN TO LOSTROOM.BXE
            </button>
          </div>
        ) : (
          <div className="win-box p-4 space-y-4">
            <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
              <div className="w-24 h-24 bg-[#120c1c] border-2 border-[#c8b4f8] shrink-0 overflow-hidden flex items-center justify-center">
                {playlist.coverUrl ? (
                  <img
                    src={playlist.coverUrl}
                    alt={playlist.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <span className="font-pixel-ui text-xs text-[#c8b4f8]">MIX</span>
                )}
              </div>
              <div className="flex-1 min-w-0 space-y-1">
                <h1 className="font-pixel-ui text-base sm:text-lg text-[#e6dcff] break-words">
                  {playlist.name}
                </h1>
                <div className="text-xs text-[#a690d6]">
                  CURATED BY{' '}
                  <button
                    type="button"
                    onClick={() => onOpenUserHomepage(playlist.ownerUsername)}
                    className="text-[#52ff94] hover:underline cursor-pointer"
                  >
                    {playlist.ownerUsername}
                  </button>{' '}
                  · {playlist.trackIds.length} TRACKS
                </div>
                {playlist.description && (
                  <p className="text-sm text-[#c8b4f8]">{playlist.description}</p>
                )}
                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleLike}
                    className="win-btn px-2.5 py-1 text-xs text-[#ff6bd6]"
                  >
                    ♥ LIKE ({playlist.likes.length})
                  </button>
                  <button
                    type="button"
                    onClick={handleSave}
                    className="win-btn px-2.5 py-1 text-xs text-[#52ff94]"
                  >
                    ★ SAVE ({playlist.savedBy.length})
                  </button>
                </div>
              </div>
            </div>

            <RetroMusicPlayer
              playlist={playlist}
              styleConfig={{
                ...createDefaultPlayerConfig('lavender_mini'),
                width: '100%',
              }}
            />
          </div>
        )}
      </div>
    </div>
  );
};
