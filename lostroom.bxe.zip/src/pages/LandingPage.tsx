import React, { useState } from 'react';
import { PIXEL_AVATAR_OPTIONS, PixelAvatarSVG } from '../components/RetroMedia';
import { PageId, PixelAvatarKey, UserAccount } from '../types/lostroom';
import { processImageFileToDataURL } from '../utils/media';

interface LandingPageProps {
  users: Record<string, UserAccount>;
  currentUsername: string | null;
  portalTab: 'login' | 'register';
  registrationEnabled?: boolean;
  onChangePortalTab: (tab: 'login' | 'register') => void;
  onLogin: (username: string, password: string) => Promise<string | null>;
  onRegister: (payload: {
    username: string;
    password: string;
    avatarType: 'preset' | 'custom';
    avatarValue: string;
    bio: string;
  }) => Promise<string | null>;
  onLogout: () => void;
  onNavigate: (page: PageId) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  users,
  currentUsername,
  portalTab,
  registrationEnabled = true,
  onChangePortalTab,
  onLogin,
  onRegister,
  onLogout,
  onNavigate,
  onToast,
}) => {
  const [loginUser, setLoginUser] = useState('');
  const [loginPass, setLoginPass] = useState('');

  const [regUser, setRegUser] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regAvatarPreset, setRegAvatarPreset] = useState<PixelAvatarKey>('cat_void');
  const [regCustomPfp, setRegCustomPfp] = useState<string>('');
  const [regBio, setRegBio] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const userCount = Object.keys(users).length;

  const handlePfpFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) {
      setRegCustomPfp('');
      return;
    }
    try {
      const dataUrl = await processImageFileToDataURL(file, 256, 0.85);
      setRegCustomPfp(dataUrl);
      onToast('Custom PFP loaded!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to load PFP', 'error');
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSubmitting(true);
    try {
      const err = await onLogin(loginUser, loginPass);
      if (err) {
        setFormError(err);
        onToast(err, 'error');
      } else {
        setLoginPass('');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!registrationEnabled) {
      const msg = 'New registrations are currently disabled by Super Admin.';
      setFormError(msg);
      onToast(msg, 'error');
      return;
    }
    setFormError(null);
    setSubmitting(true);
    try {
      const err = await onRegister({
        username: regUser,
        password: regPass,
        avatarType: regCustomPfp ? 'custom' : 'preset',
        avatarValue: regCustomPfp || regAvatarPreset,
        bio: regBio,
      });
      if (err) {
        setFormError(err);
        onToast(err, 'error');
      } else {
        setRegCustomPfp('');
        setRegPass('');
      }
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Hero Retro Terminal Banner */}
      <div className="win-inset p-4 sm:p-5 text-center">
        <div className="inline-block border border-[#7b42f6] bg-[#2a1746]/50 px-2.5 py-0.5 font-pixel-ui text-[10px] text-[#c8b4f8] mb-2">
          ZERO BOTS · {userCount} REGISTERED USER{userCount === 1 ? '' : 'S'}
        </div>

        <h1 className="font-pixel-title text-2xl sm:text-3xl text-[#e6dcff] tracking-wider mb-2 drop-shadow-[3px_3px_0px_#7b42f6]">
          LOSTROOM<span className="text-[#ff6bd6]">.BXE</span>
        </h1>

        <p className="text-xl sm:text-2xl text-[#c8b4f8] italic">
          &quot;sometime, everytime...&quot;
        </p>
        <p className="text-lg text-[#a690d6]">
          when you need privacy a bit...<span className="blink text-[#52ff94]">_</span>
        </p>
        <p className="text-sm sm:text-base text-[#ff6bd6] mt-1 font-pixel-ui">
          ♡ ı love you efsun · bxe means (efsun x barut) ♡
        </p>
      </div>

      {currentUsername ? (
        <div className="bg-[#120c1c] border border-[#52ff94] p-4 text-center space-y-3">
          <div className="font-pixel-ui text-xs text-[#52ff94]">
            CONNECTED AS {currentUsername.toUpperCase()}
          </div>
          <div className="flex flex-wrap justify-center gap-2.5">
            <button
              type="button"
              onClick={() => onNavigate('feed')}
              className="win-btn win-btn-primary px-4 py-2 text-xs"
            >
              OPEN PUBLIC FEED &gt;&gt;
            </button>
            <button
              type="button"
              onClick={() => onNavigate('forum')}
              className="win-btn px-4 py-2 text-xs"
            >
              OPEN FORUM BOARDS
            </button>
            <button
              type="button"
              onClick={() => onNavigate('upload')}
              className="win-btn px-4 py-2 text-xs"
            >
              + UPLOAD PHOTO / VIDEO
            </button>
            <button
              type="button"
              onClick={onLogout}
              className="win-btn px-4 py-2 text-xs text-[#ff6bd6]"
            >
              SWITCH / REGISTER ACCOUNT
            </button>
          </div>
        </div>
      ) : (
        /* Combined Login & Register Tabs right on the Portal Gate */
        <div className="win-box bg-[#120c1c]">
          <div className="flex border-b-2 border-[#4e2d82]">
            <button
              type="button"
              onClick={() => {
                setFormError(null);
                onChangePortalTab('login');
              }}
              className={`flex-1 py-2.5 font-pixel-ui text-xs cursor-pointer ${
                portalTab === 'login'
                  ? 'bg-[#2a1746] text-[#52ff94] border-b-2 border-[#52ff94]'
                  : 'bg-[#09060e] text-[#a690d6] hover:text-white'
              }`}
            >
              [ LOGIN TO ACCOUNT ]
            </button>
            <button
              type="button"
              onClick={() => {
                setFormError(null);
                onChangePortalTab('register');
              }}
              className={`flex-1 py-2.5 font-pixel-ui text-xs cursor-pointer ${
                portalTab === 'register'
                  ? 'bg-[#2a1746] text-[#ff6bd6] border-b-2 border-[#ff6bd6]'
                  : 'bg-[#09060e] text-[#a690d6] hover:text-white'
              }`}
            >
              [ CREATE NEW ACCOUNT ]
            </button>
          </div>

          <div className="p-4 sm:p-5">
            {formError && (
              <div
                role="alert"
                className="mb-3 bg-[#240a1a] border border-[#ff6bd6] px-3 py-2 text-sm text-[#ffd6f0]"
              >
                {formError}
              </div>
            )}

            {portalTab === 'login' ? (
              <form onSubmit={handleLoginSubmit} className="space-y-3.5 max-w-md mx-auto">
                <div>
                  <label
                    htmlFor="login-username"
                    className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1"
                  >
                    USERNAME:
                  </label>
                  <input
                    id="login-username"
                    type="text"
                    required
                    value={loginUser}
                    onChange={(e) => setLoginUser(e.target.value)}
                    placeholder="your username..."
                    className="win-inset w-full px-3 py-2 text-[#eee6ff] focus:outline-none"
                  />
                </div>
                <div>
                  <label
                    htmlFor="login-password"
                    className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1"
                  >
                    PASSWORD:
                  </label>
                  <input
                    id="login-password"
                    type="password"
                    required
                    value={loginPass}
                    onChange={(e) => setLoginPass(e.target.value)}
                    placeholder="••••••"
                    className="win-inset w-full px-3 py-2 text-[#eee6ff] focus:outline-none"
                  />
                </div>
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => onChangePortalTab('register')}
                    className="text-sm underline text-[#c8b4f8] hover:text-white cursor-pointer"
                  >
                    No account yet? Register here
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="win-btn win-btn-primary px-5 py-2 text-xs disabled:opacity-60"
                  >
                    {submitting ? 'CONNECTING...' : 'CONNECT >>'}
                  </button>
                </div>
              </form>
            ) : !registrationEnabled ? (
              <div className="win-inset p-4 text-center space-y-2 max-w-md mx-auto">
                <div className="font-pixel-ui text-xs text-[#ff6bd6]">
                  NEW REGISTRATIONS PAUSED
                </div>
                <p className="text-sm text-[#c8b4f8]">
                  Super Admin has temporarily paused new account registration via God Mode. Existing accounts can still log in.
                </p>
                <button
                  type="button"
                  onClick={() => onChangePortalTab('login')}
                  className="win-btn win-btn-primary px-4 py-1.5 text-xs"
                >
                  BACK TO LOGIN
                </button>
              </div>
            ) : (
              <form onSubmit={handleRegisterSubmit} className="space-y-3 max-w-md mx-auto">
                <div className="text-xs text-[#52ff94] bg-[#1a1128] border border-[#4e2d82] p-2">
                  ★ PRIVACY GUARANTEE: Username and password only. Zero email or phone number asked.
                </div>

                <div>
                  <label
                    htmlFor="reg-username"
                    className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1"
                  >
                    USERNAME:
                  </label>
                  <input
                    id="reg-username"
                    type="text"
                    required
                    maxLength={24}
                    value={regUser}
                    onChange={(e) => setRegUser(e.target.value)}
                    placeholder="pick a unique handle..."
                    className="win-inset w-full px-3 py-1.5 text-[#eee6ff]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="reg-password"
                    className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1"
                  >
                    PASSWORD:
                  </label>
                  <input
                    id="reg-password"
                    type="password"
                    required
                    value={regPass}
                    onChange={(e) => setRegPass(e.target.value)}
                    placeholder="••••••"
                    className="win-inset w-full px-3 py-1.5 text-[#eee6ff]"
                  />
                </div>

                {/* Custom PFP Upload + Pixel Fallback */}
                <div className="bg-[#1a1128] border border-[#4e2d82] p-2.5 space-y-2">
                  <span className="block font-pixel-ui text-xs text-[#e6dcff]">
                    PROFILE PICTURE (PFP):
                  </span>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 border border-[#c8b4f8] shrink-0 overflow-hidden bg-black">
                      {regCustomPfp ? (
                        <img
                          src={regCustomPfp}
                          alt="PFP preview"
                          className="w-12 h-12 object-cover"
                        />
                      ) : (
                        <PixelAvatarSVG preset={regAvatarPreset} />
                      )}
                    </div>
                    <div className="flex-1 space-y-1.5 min-w-0">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handlePfpFile}
                        className="text-xs text-[#c8b4f8] w-full"
                      />
                      <select
                        value={regAvatarPreset}
                        onChange={(e) => {
                          setRegAvatarPreset(e.target.value as PixelAvatarKey);
                          setRegCustomPfp('');
                        }}
                        className="win-inset w-full px-2 py-1 text-xs text-[#eee6ff]"
                      >
                        {PIXEL_AVATAR_OPTIONS.map((opt) => (
                          <option key={opt.key} value={opt.key}>
                            Fallback Pixel: {opt.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="reg-bio"
                    className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1"
                  >
                    BIOGRAPHY:
                  </label>
                  <textarea
                    id="reg-bio"
                    rows={2}
                    maxLength={160}
                    value={regBio}
                    onChange={(e) => setRegBio(e.target.value)}
                    placeholder="write a short bio..."
                    className="win-inset w-full px-3 py-1.5 text-[#eee6ff]"
                  />
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="win-btn win-btn-primary px-5 py-2 text-xs disabled:opacity-60"
                  >
                    {submitting ? 'CREATING...' : 'CREATE ACCOUNT >>'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
