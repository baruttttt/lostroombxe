import React from 'react';
import { ThemeVariables } from '../types/lostroom';

export const DEFAULT_THEME_VARIABLES: ThemeVariables = {
  '--bg-pitch': '#09060e',
  '--bg-void': '#120c1c',
  '--bg-panel': '#1a1128',
  '--bg-royal': '#2a1746',
  '--accent-violet': '#7b42f6',
  '--accent-lavender': '#c8b4f8',
  '--text-bright': '#eee6ff',
  '--text-muted': '#a690d6',
  '--bevel-light': '#a98ee8',
  '--bevel-mid': '#4e2d82',
  '--bevel-dark': '#07040b',
  '--green-online': '#52ff94',
  '--pink-love': '#ff6bd6',
};

const THEME_PRESETS: { name: string; vars: Partial<ThemeVariables> }[] = [
  {
    name: 'BXE Violet (Default)',
    vars: DEFAULT_THEME_VARIABLES,
  },
  {
    name: 'Cobalt Original',
    vars: {
      '--bg-pitch': '#050a14',
      '--bg-void': '#0a1428',
      '--bg-panel': '#0f1f3d',
      '--bg-royal': '#143166',
      '--accent-violet': '#1068d0',
      '--accent-lavender': '#93c5fd',
      '--text-bright': '#eff6ff',
      '--text-muted': '#93b4e0',
      '--bevel-light': '#7dd3fc',
      '--bevel-mid': '#1e40af',
      '--bevel-dark': '#02060d',
      '--green-online': '#4ade80',
      '--pink-love': '#f472b6',
    },
  },
  {
    name: 'Love Pink',
    vars: {
      '--bg-pitch': '#12050d',
      '--bg-void': '#1e0916',
      '--bg-panel': '#2a0e20',
      '--bg-royal': '#4a1536',
      '--accent-violet': '#db2777',
      '--accent-lavender': '#fbcfe8',
      '--text-bright': '#fff1f8',
      '--text-muted': '#e5a3c7',
      '--bevel-light': '#f9a8d4',
      '--bevel-mid': '#831843',
      '--bevel-dark': '#090206',
      '--green-online': '#86efac',
      '--pink-love': '#f472b6',
    },
  },
  {
    name: 'Phosphor CRT',
    vars: {
      '--bg-pitch': '#030a06',
      '--bg-void': '#07140c',
      '--bg-panel': '#0b1f13',
      '--bg-royal': '#123621',
      '--accent-violet': '#16a34a',
      '--accent-lavender': '#bbf7d0',
      '--text-bright': '#ecfdf5',
      '--text-muted': '#7bc497',
      '--bevel-light': '#86efac',
      '--bevel-mid': '#166534',
      '--bevel-dark': '#010503',
      '--green-online': '#52ff94',
      '--pink-love': '#c4b5fd',
    },
  },
  {
    name: 'Midnight Lilac',
    vars: {
      '--bg-pitch': '#08070d',
      '--bg-void': '#110f1c',
      '--bg-panel': '#191629',
      '--bg-royal': '#2d2647',
      '--accent-violet': '#6d28d9',
      '--accent-lavender': '#ddd6fe',
      '--text-bright': '#f5f3ff',
      '--text-muted': '#a79dc9',
      '--bevel-light': '#c4b5fd',
      '--bevel-mid': '#4c1d95',
      '--bevel-dark': '#040308',
      '--green-online': '#6ee7b7',
      '--pink-love': '#e879f9',
    },
  },
];

const VARIABLE_FIELDS: {
  key: keyof ThemeVariables;
  label: string;
  group: 'Accents' | 'Surfaces' | 'Borders & Text';
}[] = [
  { key: '--accent-violet', label: 'Primary Accent Color', group: 'Accents' },
  { key: '--accent-lavender', label: 'Secondary Lavender Accent', group: 'Accents' },
  { key: '--pink-love', label: 'Highlight / Alert Pink', group: 'Accents' },
  { key: '--green-online', label: 'Online / Success Accent', group: 'Accents' },
  { key: '--bg-pitch', label: 'Desktop Canvas Background', group: 'Surfaces' },
  { key: '--bg-void', label: 'Inset / Input Background', group: 'Surfaces' },
  { key: '--bg-panel', label: 'Window Panel Background', group: 'Surfaces' },
  { key: '--bg-royal', label: 'Titlebar / Button Base', group: 'Surfaces' },
  { key: '--bevel-light', label: 'Window Bevel Highlight', group: 'Borders & Text' },
  { key: '--bevel-mid', label: 'Window Bevel Midline', group: 'Borders & Text' },
  { key: '--text-bright', label: 'Primary Text Color', group: 'Borders & Text' },
  { key: '--text-muted', label: 'Muted Metadata Text', group: 'Borders & Text' },
];

interface ThemeEditorPageProps {
  currentUsername: string | null;
  draftTheme: ThemeVariables;
  onChangeDraftTheme: (next: ThemeVariables) => void;
  onSaveToAccount: (vars: ThemeVariables) => void;
  onResetDefault: () => void;
}

export const ThemeEditorPage: React.FC<ThemeEditorPageProps> = ({
  currentUsername,
  draftTheme,
  onChangeDraftTheme,
  onSaveToAccount,
  onResetDefault,
}) => {
  const handleVarChange = (key: keyof ThemeVariables, value: string) => {
    onChangeDraftTheme({
      ...draftTheme,
      [key]: value,
    });
  };

  const applyPreset = (vars: Partial<ThemeVariables>) => {
    onChangeDraftTheme({
      ...DEFAULT_THEME_VARIABLES,
      ...vars,
    });
  };

  const cssSnippet = `:root {\n${(Object.keys(draftTheme) as (keyof ThemeVariables)[])
    .map((k) => `  ${k}: ${draftTheme[k]};`)
    .join('\n')}\n}`;

  return (
    <div className="space-y-4">
      <div className="bg-[var(--bg-panel)] border border-[var(--accent-violet)] p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="font-pixel-ui text-xs text-[var(--text-bright)]">
            COLOR / THEME EDITOR // LIVE CSS VARIABLE OVERRIDES
          </div>
          <p className="text-sm text-[var(--accent-lavender)] mt-0.5">
            Customize CSS variables in real time and save them to{' '}
            <strong>{currentUsername || 'your local account'}</strong> settings.
          </p>
        </div>

        <div className="flex flex-wrap gap-2 shrink-0">
          <button
            type="button"
            onClick={onResetDefault}
            className="win-btn px-3 py-1.5 text-xs text-[var(--pink-love)]"
          >
            RESET DEFAULT
          </button>
          <button
            type="button"
            onClick={() => onSaveToAccount(draftTheme)}
            className="win-btn win-btn-primary px-4 py-1.5 text-xs"
          >
            SAVE TO ACCOUNT
          </button>
        </div>
      </div>

      {/* 1-Click Retro Theme Presets */}
      <div className="bg-[var(--bg-void)] border border-[var(--bevel-mid)] p-3 space-y-2">
        <div className="font-pixel-ui text-xs text-[var(--accent-lavender)]">
          RETRO PRESETS:
        </div>
        <div className="flex flex-wrap gap-2">
          {THEME_PRESETS.map((preset) => (
            <button
              key={preset.name}
              type="button"
              onClick={() => applyPreset(preset.vars)}
              className="win-btn px-3 py-1.5 text-[11px] flex items-center gap-2"
            >
              <span
                className="w-3 h-3 border border-white/60 inline-block shrink-0"
                style={{ backgroundColor: preset.vars['--accent-violet'] || '#7b42f6' }}
              />
              <span>{preset.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Live Preview Window */}
      <div className="win-box">
        <div className="win-titlebar">
          <span className="font-pixel-ui text-xs text-white">
            LIVE_PREVIEW.EXE — {currentUsername || 'GUEST'}
          </span>
          <span className="font-pixel-ui text-[10px] text-[var(--green-online)]">● ACTIVE</span>
        </div>
        <div className="p-3.5 space-y-3">
          <div className="win-inset p-3 flex flex-wrap items-center justify-between gap-3">
            <div>
              <div className="font-pixel-ui text-xs text-[var(--text-bright)]">
                Sample Window Content
              </div>
              <div className="text-sm text-[var(--text-muted)]">
                Muted subtitle · <span className="text-[var(--pink-love)]">Alert text</span> ·{' '}
                <span className="text-[var(--green-online)]">Online text</span>
              </div>
            </div>
            <div className="flex gap-2">
              <button type="button" className="win-btn px-3 py-1 text-xs">
                Secondary
              </button>
              <button type="button" className="win-btn win-btn-primary px-3 py-1 text-xs">
                Primary Action
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* CSS Variable Color Pickers */}
      {(['Accents', 'Surfaces', 'Borders & Text'] as const).map((groupName) => (
        <div
          key={groupName}
          className="bg-[var(--bg-void)] border border-[var(--bevel-mid)] p-3.5 space-y-2.5"
        >
          <div className="font-pixel-ui text-xs text-[var(--green-online)]">
            {groupName.toUpperCase()}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {VARIABLE_FIELDS.filter((f) => f.group === groupName).map((field) => {
              const currentVal = draftTheme[field.key];
              return (
                <div
                  key={field.key}
                  className="win-inset p-2.5 flex items-center justify-between gap-2.5"
                >
                  <div className="min-w-0">
                    <div className="text-sm text-[var(--text-bright)] truncate">
                      {field.label}
                    </div>
                    <div className="font-mono text-[11px] text-[var(--text-muted)]">
                      {field.key}
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <input
                      type="color"
                      aria-label={field.label}
                      value={/^#[0-9a-fA-F]{6}$/.test(currentVal) ? currentVal : '#7b42f6'}
                      onChange={(e) => handleVarChange(field.key, e.target.value)}
                      className="w-8 h-7 p-0 border border-[var(--bevel-light)] bg-transparent cursor-pointer"
                    />
                    <input
                      type="text"
                      aria-label={`${field.label} hex value`}
                      value={currentVal}
                      onChange={(e) => handleVarChange(field.key, e.target.value)}
                      className="win-inset w-20 px-1.5 py-1 text-xs font-mono text-[var(--text-bright)]"
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      {/* Generated CSS Variables Output */}
      <div className="bg-[var(--bg-void)] border border-[var(--bevel-mid)] p-3.5 space-y-2">
        <div className="font-pixel-ui text-xs text-[var(--accent-lavender)]">
          ACTIVE CSS OVERRIDES (:root)
        </div>
        <pre className="win-inset p-3 text-xs font-mono text-[var(--text-bright)] overflow-x-auto leading-relaxed">
          {cssSnippet}
        </pre>
      </div>
    </div>
  );
};
