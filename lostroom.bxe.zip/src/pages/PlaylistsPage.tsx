import React, { useEffect, useMemo, useState } from 'react';
import { RetroMusicPlayer } from '../components/RetroMusicPlayer';
import { createDefaultPlayerConfig } from '../data/homepageTemplates';
import { AudioTrack, PlaylistRecord } from '../types/homepage';
import {
  createPlaylist,
  deleteAudioTrack,
  deletePlaylist,
  formatBytes,
  listAudioTracks,
  listPublicPlaylists,
  listUserPlaylists,
  toggleLikePlaylist,
  toggleSavePlaylist,
  updatePlaylist,
  uploadAudioTrack,
  uploadImageAsset,
} from '../utils/homepageApi';

interface PlaylistsPageProps {
  currentUsername: string | null;
  onOpenPublicUrl: (path: string) => void;
  onOpenProfile: (username: string) => void;
  onOpenMyHomepage: () => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

type PlaylistBrowserTab = 'public' | 'mine' | 'saved';

export const PlaylistsPage: React.FC<PlaylistsPageProps> = ({
  currentUsername,
  onOpenPublicUrl,
  onOpenProfile,
  onOpenMyHomepage,
  onToast,
}) => {
  const [tab, setTab] = useState<PlaylistBrowserTab>('public');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [publicPlaylists, setPublicPlaylists] = useState<PlaylistRecord[]>([]);
  const [myPlaylists, setMyPlaylists] = useState<PlaylistRecord[]>([]);
  const [savedPlaylists, setSavedPlaylists] = useState<PlaylistRecord[]>([]);
  const [audioTracks, setAudioTracks] = useState<AudioTrack[]>([]);
  const [audioBytes, setAudioBytes] = useState(0);
  const [audioQuota, setAudioQuota] = useState(80 * 1024 * 1024);

  const [playingPlaylistId, setPlayingPlaylistId] = useState<string | null>(null);
  const [showStudio, setShowStudio] = useState(false);
  const [editingPlaylistId, setEditingPlaylistId] = useState<string | null>(null);

  // Create Playlist Form
  const [newPlName, setNewPlName] = useState('');
  const [newPlDesc, setNewPlDesc] = useState('');
  const [newPlCover, setNewPlCover] = useState('');
  const [newPlPublic, setNewPlPublic] = useState(true);
  const [newPlTrackIds, setNewPlTrackIds] = useState<string[]>([]);
  const [creatingPl, setCreatingPl] = useState(false);

  // Upload Song Form
  const [songTitle, setSongTitle] = useState('');
  const [songArtist, setSongArtist] = useState('');
  const [songCover, setSongCover] = useState('');
  const [rightsConfirmed, setRightsConfirmed] = useState(true);
  const [uploadTargetPlaylistId, setUploadTargetPlaylistId] = useState<string>('');
  const [uploadingAudio, setUploadingAudio] = useState(false);

  // Edit Playlist Meta State
  const [editPlName, setEditPlName] = useState('');
  const [editPlDesc, setEditPlDesc] = useState('');
  const [savingEdit, setSavingEdit] = useState(false);

  const loadPlaylists = async () => {
    setLoading(true);
    try {
      const pubRes = await listPublicPlaylists();
      setPublicPlaylists(pubRes.playlists);
      if (currentUsername) {
        const [userRes, audioRes] = await Promise.all([
          listUserPlaylists(currentUsername, currentUsername),
          listAudioTracks(currentUsername),
        ]);
        setMyPlaylists(userRes.playlists);
        setSavedPlaylists(userRes.savedPlaylists);
        setAudioTracks(audioRes.tracks);
        setAudioBytes(audioRes.totalBytes);
        setAudioQuota(audioRes.quotaBytes);
      } else {
        setMyPlaylists([]);
        setSavedPlaylists([]);
        setAudioTracks([]);
      }
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to load playlists.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPlaylists();
  }, [currentUsername]);

  const activeList = useMemo(() => {
    const source =
      tab === 'mine' ? myPlaylists : tab === 'saved' ? savedPlaylists : publicPlaylists;
    const q = searchQuery.trim().toLowerCase();
    if (!q) return source;
    return source.filter(
      (pl) =>
        pl.name.toLowerCase().includes(q) ||
        pl.ownerUsername.toLowerCase().includes(q) ||
        pl.description.toLowerCase().includes(q) ||
        (pl.tracks || []).some(
          (t) =>
            t.title.toLowerCase().includes(q) || t.artist.toLowerCase().includes(q)
        )
    );
  }, [tab, publicPlaylists, myPlaylists, savedPlaylists, searchQuery]);

  const activePlayingPlaylist = useMemo(() => {
    const all = [...publicPlaylists, ...myPlaylists, ...savedPlaylists];
    return all.find((p) => p.id === playingPlaylistId) || null;
  }, [publicPlaylists, myPlaylists, savedPlaylists, playingPlaylistId]);

  const editingPlaylist = useMemo(() => {
    if (!editingPlaylistId) return null;
    return myPlaylists.find((p) => p.id === editingPlaylistId) || null;
  }, [myPlaylists, editingPlaylistId]);

  useEffect(() => {
    if (editingPlaylist) {
      setEditPlName(editingPlaylist.name);
      setEditPlDesc(editingPlaylist.description || '');
    }
  }, [editingPlaylist?.id]);

  const openEditorForPlaylist = (pl: PlaylistRecord) => {
    setEditingPlaylistId(pl.id);
    setEditPlName(pl.name);
    setEditPlDesc(pl.description || '');
    setUploadTargetPlaylistId(pl.id);
  };

  const handleToggleStudio = () => {
    if (!currentUsername) {
      onToast('Please log in to create playlists or upload songs.', 'error');
      return;
    }
    setShowStudio((prev) => !prev);
  };

  const handleUploadCoverImage = async (files: FileList | null, target: 'playlist' | 'song') => {
    if (!currentUsername || !files || files.length === 0) return;
    try {
      const res = await uploadImageAsset(files[0], currentUsername, 'cover');
      if (target === 'playlist') {
        setNewPlCover(res.asset.url);
      } else {
        setSongCover(res.asset.url);
      }
      onToast('Cover image uploaded!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Cover upload failed.', 'error');
    }
  };

  const handleUploadSongs = async (
    files: FileList | null,
    explicitTargetPlaylistId?: string
  ) => {
    if (!currentUsername) {
      onToast('Log in to upload songs.', 'error');
      return;
    }
    if (!files || files.length === 0) return;
    if (!rightsConfirmed) {
      onToast('Please check the audio sharing permission box before uploading.', 'error');
      return;
    }

    setUploadingAudio(true);
    try {
      const fileArr = Array.from(files);
      const uploadedIds: string[] = [];
      for (let i = 0; i < fileArr.length; i += 1) {
        const file = fileArr[i];
        const fallbackTitle = file.name.replace(/\.(mp3|wav|ogg|m4a|aac|webm)$/i, '');
        const res = await uploadAudioTrack(file, {
          username: currentUsername,
          title: fileArr.length === 1 && songTitle.trim() ? songTitle.trim() : fallbackTitle,
          artist: songArtist.trim() || currentUsername,
          description: '',
          coverUrl: songCover.trim(),
          rightsConfirmed: true,
        });
        uploadedIds.push(res.track.id);
      }

      const targetId =
        explicitTargetPlaylistId !== undefined ? explicitTargetPlaylistId : uploadTargetPlaylistId;
      if (targetId && uploadedIds.length > 0) {
        const targetPl = myPlaylists.find((p) => p.id === targetId);
        if (targetPl) {
          const mergedIds = Array.from(new Set([...targetPl.trackIds, ...uploadedIds]));
          await updatePlaylist(targetPl.id, { trackIds: mergedIds });
          onToast(
            `Uploaded ${uploadedIds.length} song(s) and added to "${targetPl.name}"!`
          );
        } else {
          onToast(`Uploaded ${uploadedIds.length} song(s) to your Music Library!`);
        }
      } else {
        onToast(`Uploaded ${uploadedIds.length} song(s) to your Music Library!`);
      }

      setSongTitle('');
      setNewPlTrackIds((prev) => Array.from(new Set([...prev, ...uploadedIds])));
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Song upload failed.', 'error');
    } finally {
      setUploadingAudio(false);
    }
  };

  const handleDeleteSong = async (trackId: string) => {
    try {
      await deleteAudioTrack(trackId);
      onToast('Song deleted from your library.');
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to delete song.', 'error');
    }
  };

  const handleCreatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUsername) {
      onToast('Log in to create a playlist.', 'error');
      return;
    }
    if (!newPlName.trim()) {
      onToast('Enter a playlist name.', 'error');
      return;
    }
    setCreatingPl(true);
    try {
      const res = await createPlaylist({
        ownerUsername: currentUsername,
        name: newPlName.trim(),
        description: newPlDesc.trim(),
        coverUrl: newPlCover.trim(),
        isPublic: newPlPublic,
        trackIds: newPlTrackIds,
      });
      setNewPlName('');
      setNewPlDesc('');
      setNewPlCover('');
      setNewPlTrackIds([]);
      setTab('mine');
      await loadPlaylists();
      setEditingPlaylistId(res.playlist.id);
      setUploadTargetPlaylistId(res.playlist.id);
      onToast(
        newPlTrackIds.length > 0
          ? `Playlist "${res.playlist.name}" created with ${newPlTrackIds.length} song(s)!`
          : `Playlist "${res.playlist.name}" created! Now add or upload songs below.`
      );
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Could not create playlist.', 'error');
    } finally {
      setCreatingPl(false);
    }
  };

  const handleAddTrackToPlaylist = async (pl: PlaylistRecord, trackId: string) => {
    if (!trackId) return;
    if (pl.trackIds.includes(trackId)) {
      onToast('That song is already in this playlist.');
      return;
    }
    try {
      await updatePlaylist(pl.id, { trackIds: [...pl.trackIds, trackId] });
      onToast(`Added song to "${pl.name}"!`);
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Could not add song.', 'error');
    }
  };

  const handleRemoveTrackFromPlaylist = async (pl: PlaylistRecord, idx: number) => {
    try {
      const next = pl.trackIds.filter((_, i) => i !== idx);
      await updatePlaylist(pl.id, { trackIds: next });
      onToast('Removed song from playlist.');
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Could not remove song.', 'error');
    }
  };

  const handleMoveTrackInPlaylist = async (
    pl: PlaylistRecord,
    idx: number,
    dir: -1 | 1
  ) => {
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= pl.trackIds.length) return;
    const next = [...pl.trackIds];
    const [moved] = next.splice(idx, 1);
    next.splice(targetIdx, 0, moved);
    try {
      await updatePlaylist(pl.id, { trackIds: next });
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Reorder failed.', 'error');
    }
  };

  const handleSavePlaylistMeta = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPlaylist) return;
    if (!editPlName.trim()) {
      onToast('Playlist name cannot be empty.', 'error');
      return;
    }
    setSavingEdit(true);
    try {
      await updatePlaylist(editingPlaylist.id, {
        name: editPlName.trim(),
        description: editPlDesc.trim(),
      });
      onToast('Playlist details updated!');
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Update failed.', 'error');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleTogglePlaylistPublic = async (pl: PlaylistRecord) => {
    try {
      await updatePlaylist(pl.id, { isPublic: !pl.isPublic });
      onToast(pl.isPublic ? 'Playlist set to PRIVATE.' : 'Playlist is now PUBLIC!');
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to update visibility.', 'error');
    }
  };

  const handleDeletePlaylist = async (pl: PlaylistRecord) => {
    try {
      await deletePlaylist(pl.id);
      if (editingPlaylistId === pl.id) setEditingPlaylistId(null);
      if (playingPlaylistId === pl.id) setPlayingPlaylistId(null);
      onToast(`Deleted playlist "${pl.name}".`);
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to delete playlist.', 'error');
    }
  };

  const handleLike = async (plId: string) => {
    if (!currentUsername) {
      onToast('Log in to like playlists.', 'error');
      return;
    }
    try {
      await toggleLikePlaylist(plId, currentUsername);
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Could not like playlist.', 'error');
    }
  };

  const handleSave = async (plId: string) => {
    if (!currentUsername) {
      onToast('Log in to save playlists.', 'error');
      return;
    }
    try {
      const res = await toggleSavePlaylist(plId, currentUsername);
      const saved = res.playlist.savedBy.includes(currentUsername);
      onToast(saved ? 'Saved playlist to your collection!' : 'Removed from saved playlists.');
      await loadPlaylists();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Could not save playlist.', 'error');
    }
  };

  const copyPlaylistLink = (pl: PlaylistRecord) => {
    const path = `/playlist/${pl.ownerUsername}/${pl.slug}`;
    navigator.clipboard?.writeText(`${window.location.origin}${path}`).catch(() => {});
    onToast(`Copied playlist link: ${path}`);
  };

  return (
    <div className="space-y-4">
      {/* Header & Tabs */}
      <div className="win-inset p-3 space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-pixel-ui text-sm text-[#e6dcff]">
              PLAYLIST ARCHIVE &amp; COMMUNITY MIXTAPES
            </h2>
            <p className="text-xs text-[#a690d6]">
              Create mixtapes, upload MP3/WAV/OGG/M4A songs, add tracks right here, or browse community playlists.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={handleToggleStudio}
              className={`win-btn px-3 py-1.5 text-xs ${
                showStudio ? 'text-[#52ff94] border-[#52ff94]' : 'win-btn-primary'
              }`}
            >
              {showStudio ? '− CLOSE PLAYLIST STUDIO' : '+ CREATE / UPLOAD SONGS'}
            </button>
            {currentUsername && (
              <button
                type="button"
                onClick={onOpenMyHomepage}
                className="win-btn px-2.5 py-1.5 text-[11px] text-[#c8b4f8]"
                title="Open My Homepage Builder to embed a music player widget"
              >
                MY HOMEPAGE
              </button>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          <div className="flex flex-wrap gap-1.5">
            <button
              type="button"
              onClick={() => setTab('public')}
              className={`win-btn px-2.5 py-1 text-xs ${tab === 'public' ? 'win-btn-primary' : ''}`}
            >
              PUBLIC ({publicPlaylists.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('mine')}
              className={`win-btn px-2.5 py-1 text-xs ${tab === 'mine' ? 'win-btn-primary' : ''}`}
            >
              MY PLAYLISTS ({myPlaylists.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('saved')}
              className={`win-btn px-2.5 py-1 text-xs ${tab === 'saved' ? 'win-btn-primary' : ''}`}
            >
              SAVED ({savedPlaylists.length})
            </button>
          </div>

          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search playlist, user, or song..."
            className="win-inset px-2.5 py-1 text-sm text-white w-full sm:w-64"
          />
        </div>
      </div>

      {/* Inline Create Playlist + Upload Songs Studio */}
      {showStudio && currentUsername && (
        <div className="win-box p-3 space-y-3 border-2 border-[#7b42f6]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a1746] pb-2">
            <span className="font-pixel-ui text-xs text-[#52ff94]">
              PLAYLIST &amp; SONG STUDIO — {currentUsername.toUpperCase()}
            </span>
            <span className="text-[11px] text-[#a690d6]">
              AUDIO STORAGE: {formatBytes(audioBytes)} / {formatBytes(audioQuota)} ({audioTracks.length} tracks)
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            {/* Step 1: Upload Songs */}
            <div className="win-inset p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#e6dcff]">
                1. UPLOAD SONGS (MP3, WAV, OGG, M4A, WEBM)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <input
                  type="text"
                  value={songTitle}
                  onChange={(e) => setSongTitle(e.target.value)}
                  placeholder="Song title (optional for multi-upload)"
                  className="win-inset px-2 py-1.5 text-white"
                />
                <input
                  type="text"
                  value={songArtist}
                  onChange={(e) => setSongArtist(e.target.value)}
                  placeholder={`Artist (default: ${currentUsername})`}
                  className="win-inset px-2 py-1.5 text-white"
                />
                <div className="sm:col-span-2 flex gap-1.5 items-center">
                  <input
                    type="text"
                    value={songCover}
                    onChange={(e) => setSongCover(e.target.value)}
                    placeholder="Optional cover URL"
                    className="flex-1 win-inset px-2 py-1.5 text-white"
                  />
                  <label className="win-btn px-2 py-1 text-[10px] cursor-pointer shrink-0">
                    + COVER
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/gif,image/webp"
                      className="hidden"
                      onChange={(e) => handleUploadCoverImage(e.target.files, 'song')}
                    />
                  </label>
                </div>
              </div>

              {myPlaylists.length > 0 && (
                <div>
                  <label className="text-[11px] text-[#c8b4f8] block mb-1">
                    Auto-add uploaded song(s) to playlist:
                  </label>
                  <select
                    value={uploadTargetPlaylistId}
                    onChange={(e) => setUploadTargetPlaylistId(e.target.value)}
                    className="w-full win-inset px-2 py-1.5 text-xs text-white"
                  >
                    <option value="">-- Save to My Music Library only --</option>
                    {myPlaylists.map((pl) => (
                      <option key={pl.id} value={pl.id}>
                        {pl.name} ({pl.trackIds.length} tracks)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <label className="flex items-start gap-2 text-[11px] text-[#c8b4f8] bg-[#120c1c] p-2 border border-[#2a1746] cursor-pointer">
                <input
                  type="checkbox"
                  checked={rightsConfirmed}
                  onChange={(e) => setRightsConfirmed(e.target.checked)}
                  className="mt-0.5"
                />
                <span>
                  I confirm I own or have permission to upload &amp; share these audio files on LOSTROOM.BXE.
                </span>
              </label>

              <label className="win-btn win-btn-primary px-3 py-1.5 text-xs inline-block cursor-pointer">
                {uploadingAudio ? 'UPLOADING SONG(S)...' : '+ SELECT AUDIO FILE(S) TO UPLOAD'}
                <input
                  type="file"
                  multiple
                  accept=".mp3,.wav,.ogg,.m4a,.aac,.webm,audio/*"
                  disabled={uploadingAudio}
                  className="hidden"
                  onChange={(e) => {
                    handleUploadSongs(e.target.files);
                    e.target.value = '';
                  }}
                />
              </label>
            </div>

            {/* Step 2: Create Playlist */}
            <form onSubmit={handleCreatePlaylist} className="win-inset p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#e6dcff]">
                2. CREATE NEW PLAYLIST
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <input
                  type="text"
                  value={newPlName}
                  onChange={(e) => setNewPlName(e.target.value)}
                  placeholder="Playlist name (e.g. Late Night Mix)"
                  className="win-inset px-2 py-1.5 text-white"
                />
                <input
                  type="text"
                  value={newPlDesc}
                  onChange={(e) => setNewPlDesc(e.target.value)}
                  placeholder="Short description"
                  className="win-inset px-2 py-1.5 text-white"
                />
                <div className="sm:col-span-2 flex gap-1.5 items-center">
                  <input
                    type="text"
                    value={newPlCover}
                    onChange={(e) => setNewPlCover(e.target.value)}
                    placeholder="Optional cover image URL"
                    className="flex-1 win-inset px-2 py-1.5 text-white"
                  />
                  <label className="win-btn px-2 py-1 text-[10px] cursor-pointer shrink-0">
                    + COVER
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/gif,image/webp"
                      className="hidden"
                      onChange={(e) => handleUploadCoverImage(e.target.files, 'playlist')}
                    />
                  </label>
                </div>
              </div>

              {audioTracks.length > 0 && (
                <div className="space-y-1">
                  <div className="text-[11px] text-[#c8b4f8]">
                    Select songs to include ({newPlTrackIds.length} selected):
                  </div>
                  <div className="max-h-28 overflow-y-auto bg-[#0c0713] border border-[#2a1746] p-1.5 space-y-1">
                    {audioTracks.map((trk) => {
                      const checked = newPlTrackIds.includes(trk.id);
                      return (
                        <label
                          key={trk.id}
                          className="flex items-center gap-2 text-xs text-[#e6dcff] cursor-pointer hover:bg-[#1a102b] px-1 py-0.5"
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() =>
                              setNewPlTrackIds((prev) =>
                                checked
                                  ? prev.filter((id) => id !== trk.id)
                                  : [...prev, trk.id]
                              )
                            }
                          />
                          <span className="truncate">
                            {trk.title} — <span className="text-[#a690d6]">{trk.artist}</span>
                          </span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              )}

              <label className="flex items-center gap-2 text-xs text-[#c8b4f8] cursor-pointer">
                <input
                  type="checkbox"
                  checked={newPlPublic}
                  onChange={(e) => setNewPlPublic(e.target.checked)}
                />
                <span>Public playlist (visible in PUBLIC &amp; shareable via /playlist/...)</span>
              </label>

              <button
                type="submit"
                disabled={creatingPl}
                className="win-btn win-btn-primary px-3 py-1.5 text-xs"
              >
                {creatingPl ? 'CREATING...' : '+ CREATE PLAYLIST'}
              </button>
            </form>
          </div>

          {/* My Uploaded Songs Library */}
          <div className="win-inset p-3 space-y-2">
            <div className="font-pixel-ui text-xs text-[#e6dcff]">
              MY UPLOADED SONGS ({audioTracks.length})
            </div>
            {audioTracks.length === 0 ? (
              <div className="text-xs text-[#a690d6]">
                No songs uploaded yet. Upload an MP3/WAV/OGG/M4A file in step 1 above!
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-h-64 overflow-y-auto pr-1">
                {audioTracks.map((trk) => (
                  <div
                    key={trk.id}
                    className="bg-[#120c1c] border border-[#2a1746] p-2 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="text-xs text-[#e6dcff] font-bold truncate">
                          {trk.title}
                        </div>
                        <div className="text-[11px] text-[#a690d6] truncate">
                          {trk.artist} · {formatBytes(trk.sizeBytes)}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleDeleteSong(trk.id)}
                        className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6] shrink-0"
                      >
                        DEL
                      </button>
                    </div>
                    <audio controls src={trk.url} className="w-full h-7" preload="none" />
                    {editingPlaylist && !editingPlaylist.trackIds.includes(trk.id) && (
                      <button
                        type="button"
                        onClick={() => handleAddTrackToPlaylist(editingPlaylist, trk.id)}
                        className="win-btn win-btn-primary w-full py-1 text-[10px]"
                      >
                        + ADD TO &quot;{editingPlaylist.name}&quot;
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Inline Playlist Song Manager */}
      {editingPlaylist && currentUsername && (
        <div className="win-box p-3 space-y-3 border-2 border-[#52ff94]">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a1746] pb-2">
            <div>
              <span className="font-pixel-ui text-xs text-[#52ff94]">
                MANAGING SONGS: {editingPlaylist.name}
              </span>
              <span className="ml-2 text-[10px] px-1.5 py-0.5 bg-[#120c1c] border border-[#7b42f6] text-[#c8b4f8]">
                {editingPlaylist.isPublic ? 'PUBLIC' : 'PRIVATE'}
              </span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => handleTogglePlaylistPublic(editingPlaylist)}
                className="win-btn px-2 py-0.5 text-[10px]"
              >
                MAKE {editingPlaylist.isPublic ? 'PRIVATE' : 'PUBLIC'}
              </button>
              <button
                type="button"
                onClick={() => handleDeletePlaylist(editingPlaylist)}
                className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
              >
                DELETE PLAYLIST
              </button>
              <button
                type="button"
                onClick={() => setEditingPlaylistId(null)}
                className="win-btn px-2 py-0.5 text-[10px]"
              >
                CLOSE EDITOR
              </button>
            </div>
          </div>

          <form onSubmit={handleSavePlaylistMeta} className="grid grid-cols-1 sm:grid-cols-12 gap-2 text-xs">
            <input
              type="text"
              value={editPlName}
              onChange={(e) => setEditPlName(e.target.value)}
              placeholder="Playlist name"
              className="sm:col-span-4 win-inset px-2 py-1 text-white"
            />
            <input
              type="text"
              value={editPlDesc}
              onChange={(e) => setEditPlDesc(e.target.value)}
              placeholder="Description"
              className="sm:col-span-6 win-inset px-2 py-1 text-white"
            />
            <button
              type="submit"
              disabled={savingEdit}
              className="sm:col-span-2 win-btn px-2 py-1 text-[10px]"
            >
              {savingEdit ? 'SAVING...' : 'SAVE INFO'}
            </button>
          </form>

          {/* Add Songs Controls */}
          <div className="win-inset p-2.5 space-y-2">
            <div className="font-pixel-ui text-[10px] text-[#c8b4f8]">
              ADD SONGS TO &quot;{editingPlaylist.name}&quot;
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value=""
                onChange={(e) => {
                  const id = e.target.value;
                  if (id) handleAddTrackToPlaylist(editingPlaylist, id);
                }}
                className="flex-1 min-w-[200px] win-inset px-2 py-1.5 text-xs text-white"
              >
                <option value="">
                  {audioTracks.length === 0
                    ? '-- No uploaded songs yet (upload on the right!) --'
                    : '-- Pick a song from your Music Library to add --'}
                </option>
                {audioTracks
                  .filter((t) => !editingPlaylist.trackIds.includes(t.id))
                  .map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.title} — {t.artist}
                    </option>
                  ))}
              </select>

              <label className="win-btn win-btn-primary px-3 py-1.5 text-[11px] cursor-pointer shrink-0">
                {uploadingAudio ? 'UPLOADING...' : '+ UPLOAD NEW SONG & ADD'}
                <input
                  type="file"
                  multiple
                  accept=".mp3,.wav,.ogg,.m4a,.aac,.webm,audio/*"
                  disabled={uploadingAudio}
                  className="hidden"
                  onChange={(e) => {
                    handleUploadSongs(e.target.files, editingPlaylist.id);
                    e.target.value = '';
                  }}
                />
              </label>
            </div>

            {audioTracks.some((t) => !editingPlaylist.trackIds.includes(t.id)) && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {audioTracks
                  .filter((t) => !editingPlaylist.trackIds.includes(t.id))
                  .slice(0, 8)
                  .map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => handleAddTrackToPlaylist(editingPlaylist, t.id)}
                      className="win-btn px-2 py-0.5 text-[10px] text-[#52ff94]"
                    >
                      + {t.title}
                    </button>
                  ))}
              </div>
            )}
          </div>

          {/* Current Ordered Playlist Tracks */}
          <div className="space-y-1.5">
            <div className="font-pixel-ui text-[10px] text-[#c8b4f8]">
              TRACKS IN PLAYLIST ({editingPlaylist.tracks?.length || 0})
            </div>
            {!editingPlaylist.tracks || editingPlaylist.tracks.length === 0 ? (
              <div className="win-inset p-3 text-xs text-[#a690d6]">
                This playlist has no songs yet. Upload a song or pick one from the dropdown above!
              </div>
            ) : (
              editingPlaylist.tracks.map((trk, idx) => (
                <div
                  key={`${trk.id}-${idx}`}
                  className="win-inset px-2.5 py-1.5 flex items-center justify-between gap-2 text-xs"
                >
                  <span className="truncate text-[#e6dcff]">
                    {idx + 1}. {trk.title} —{' '}
                    <span className="text-[#a690d6]">{trk.artist}</span>
                  </span>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => handleMoveTrackInPlaylist(editingPlaylist, idx, -1)}
                      className="win-btn px-1.5 py-0.5 text-[9px] disabled:opacity-40"
                    >
                      UP
                    </button>
                    <button
                      type="button"
                      disabled={idx === editingPlaylist.trackIds.length - 1}
                      onClick={() => handleMoveTrackInPlaylist(editingPlaylist, idx, 1)}
                      className="win-btn px-1.5 py-0.5 text-[9px] disabled:opacity-40"
                    >
                      DN
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveTrackFromPlaylist(editingPlaylist, idx)}
                      className="win-btn px-1.5 py-0.5 text-[9px] text-[#ff6bd6]"
                    >
                      REMOVE
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Inline Active Audio Player */}
      {activePlayingPlaylist && (
        <div className="win-box p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-pixel-ui text-xs text-[#52ff94]">
              NOW LISTENING: {activePlayingPlaylist.name} (by {activePlayingPlaylist.ownerUsername})
            </span>
            <button
              type="button"
              onClick={() => setPlayingPlaylistId(null)}
              className="win-btn px-2 py-0.5 text-[10px]"
            >
              CLOSE DECK
            </button>
          </div>
          <RetroMusicPlayer
            playlist={activePlayingPlaylist}
            styleConfig={{
              ...createDefaultPlayerConfig('lavender_mini'),
              width: '100%',
            }}
          />
        </div>
      )}

      {/* Playlist Grid */}
      {loading ? (
        <div className="win-inset p-6 text-center text-xs font-pixel-ui text-[#c8b4f8]">
          LOADING PLAYLISTS...
        </div>
      ) : activeList.length === 0 ? (
        <div className="win-inset p-6 text-center space-y-2.5 text-[#a690d6]">
          <div>
            {tab === 'mine'
              ? 'You have not created any playlists yet.'
              : tab === 'saved'
                ? 'You have not saved any community playlists yet.'
                : 'No public playlists found yet.'}
          </div>
          {currentUsername && tab !== 'saved' && (
            <button
              type="button"
              onClick={() => setShowStudio(true)}
              className="win-btn win-btn-primary px-3 py-1.5 text-xs"
            >
              + CREATE PLAYLIST &amp; UPLOAD SONGS
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {activeList.map((pl) => {
            const isOwner = !!currentUsername && pl.ownerUsername === currentUsername;
            const isLiked = !!currentUsername && pl.likes.includes(currentUsername);
            const isSaved = !!currentUsername && pl.savedBy.includes(currentUsername);
            return (
              <div key={pl.id} className="win-box p-3 flex flex-col justify-between gap-2.5">
                <div className="flex gap-3">
                  <div className="w-16 h-16 bg-[#09060e] border-2 border-[#7b42f6] shrink-0 overflow-hidden flex items-center justify-center">
                    {pl.coverUrl ? (
                      <img
                        src={pl.coverUrl}
                        alt={pl.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="font-pixel-ui text-[10px] text-[#c8b4f8]">MIX</span>
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <span className="font-pixel-ui text-xs text-[#e6dcff] truncate">
                        {pl.name}
                      </span>
                      {!pl.isPublic && (
                        <span className="text-[9px] px-1 py-0.5 bg-[#120c1c] border border-[#7b42f6] text-[#c8b4f8] shrink-0">
                          PRIVATE
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-[#a690d6] mt-0.5">
                      by{' '}
                      <button
                        type="button"
                        onClick={() => onOpenProfile(pl.ownerUsername)}
                        className="text-[#52ff94] hover:underline cursor-pointer"
                      >
                        {pl.ownerUsername}
                      </button>{' '}
                      · {pl.trackIds.length} tracks
                    </div>
                    {pl.description && (
                      <p className="text-xs text-[#c8b4f8] mt-1 line-clamp-2">
                        {pl.description}
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex flex-wrap gap-1.5 pt-1 border-t border-[#2a1746]">
                  <button
                    type="button"
                    onClick={() => setPlayingPlaylistId(pl.id)}
                    className="win-btn win-btn-primary px-2.5 py-1 text-[10px]"
                  >
                    ▶ PLAY
                  </button>
                  {isOwner && (
                    <button
                      type="button"
                      onClick={() => openEditorForPlaylist(pl)}
                      className="win-btn px-2.5 py-1 text-[10px] text-[#52ff94]"
                    >
                      EDIT / ADD SONGS
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => handleLike(pl.id)}
                    className={`win-btn px-2 py-1 text-[10px] ${
                      isLiked ? 'text-[#ff6bd6]' : ''
                    }`}
                  >
                    ♥ {pl.likes.length}
                  </button>
                  {!isOwner && (
                    <button
                      type="button"
                      onClick={() => handleSave(pl.id)}
                      className={`win-btn px-2 py-1 text-[10px] ${
                        isSaved ? 'text-[#52ff94]' : ''
                      }`}
                    >
                      {isSaved ? '★ SAVED' : '+ SAVE'}
                    </button>
                  )}
                  {pl.isPublic && (
                    <>
                      <button
                        type="button"
                        onClick={() => onOpenPublicUrl(`/playlist/${pl.ownerUsername}/${pl.slug}`)}
                        className="win-btn px-2 py-1 text-[10px]"
                      >
                        OPEN PAGE
                      </button>
                      <button
                        type="button"
                        onClick={() => copyPlaylistLink(pl)}
                        className="win-btn px-2 py-1 text-[10px]"
                      >
                        SHARE LINK
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
