import React, { useCallback, useEffect, useState } from 'react';
import { BarutBadge } from '../components/BarutBadge';
import {
  AdminAuditLogItem,
  AdminOverviewData,
  AdminPostRecord,
  AdminUserRecord,
  AnnouncementCategory,
  AnnouncementItem,
  SiteSettings,
} from '../types/admin';
import { UserAccountStatus, UserRole } from '../types/lostroom';
import {
  adminCreateAnnouncement,
  adminDeleteAnnouncement,
  adminDeleteComment,
  adminDeletePost,
  adminDeleteUser,
  adminEditUser,
  adminGetGodMode,
  adminListAnnouncements,
  adminListLogs,
  adminRenameUser,
  adminRestoreAllFeatures,
  adminRestorePost,
  adminRotateAllTokens,
  adminSetUserRole,
  adminSetUserStatus,
  adminUpdateAnnouncement,
  adminUpdateGodMode,
  adminUpdatePost,
  fetchAdminOverview,
  fetchAdminPosts,
  fetchAdminUsers,
} from '../utils/adminApi';
import { resolveShortReport } from '../utils/shortsApi';

type AdminTab =
  | 'overview'
  | 'users'
  | 'posts'
  | 'roles'
  | 'god_mode'
  | 'announcements'
  | 'logs'
  | 'security';

interface AdminDashboardPageProps {
  currentUsername: string | null;
  currentUserRole: UserRole;
  onSiteStateChanged: () => void;
  onOpenUserProfile: (username: string) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({
  currentUsername,
  currentUserRole,
  onSiteStateChanged,
  onOpenUserProfile,
  onToast,
}) => {
  const isSuperAdmin = currentUserRole === 'super_admin';
  const isAdminOrHigher = currentUserRole === 'super_admin' || currentUserRole === 'admin';
  const isStaff =
    currentUserRole === 'super_admin' ||
    currentUserRole === 'admin' ||
    currentUserRole === 'moderator';

  const [tab, setTab] = useState<AdminTab>('overview');
  const [loading, setLoading] = useState(false);

  const [overview, setOverview] = useState<AdminOverviewData | null>(null);
  const [adminUsers, setAdminUsers] = useState<AdminUserRecord[]>([]);
  const [userSearch, setUserSearch] = useState('');
  const [editingBioUser, setEditingBioUser] = useState<string | null>(null);
  const [bioDraft, setBioDraft] = useState('');
  const [renamingUser, setRenamingUser] = useState<string | null>(null);
  const [renameDraft, setRenameDraft] = useState('');

  const [adminPosts, setAdminPosts] = useState<AdminPostRecord[]>([]);
  const [postSearch, setPostSearch] = useState('');
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [postTitleDraft, setPostTitleDraft] = useState('');
  const [postBodyDraft, setPostBodyDraft] = useState('');

  const [godSettings, setGodSettings] = useState<SiteSettings | null>(null);
  const [announcements, setAnnouncements] = useState<AnnouncementItem[]>([]);
  const [annTitle, setAnnTitle] = useState('');
  const [annBody, setAnnBody] = useState('');
  const [annCategory, setAnnCategory] = useState<AnnouncementCategory>('normal');
  const [annPinned, setAnnPinned] = useState(false);
  const [annShowBanner, setAnnShowBanner] = useState(true);
  const [annNotify, setAnnNotify] = useState(true);
  const [annSchedule, setAnnSchedule] = useState('');
  const [editingAnnId, setEditingAnnId] = useState<string | null>(null);

  const [logs, setLogs] = useState<AdminAuditLogItem[]>([]);
  const [logSearch, setLogSearch] = useState('');
  const [logActionFilter, setLogActionFilter] = useState('all');

  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    onConfirm: () => Promise<void>;
  } | null>(null);

  const loadTab = useCallback(
    async (activeTab: AdminTab) => {
      if (!isStaff) return;
      setLoading(true);
      try {
        if (activeTab === 'overview') {
          const data = await fetchAdminOverview();
          setOverview(data);
        } else if (activeTab === 'users' || activeTab === 'roles') {
          const res = await fetchAdminUsers(userSearch);
          setAdminUsers(res.users);
        } else if (activeTab === 'posts') {
          const res = await fetchAdminPosts(postSearch);
          setAdminPosts(res.posts);
        } else if (activeTab === 'god_mode' && isSuperAdmin) {
          const res = await adminGetGodMode();
          setGodSettings(res.settings);
        } else if (activeTab === 'announcements') {
          const res = await adminListAnnouncements();
          setAnnouncements(res.announcements);
        } else if (activeTab === 'logs') {
          const res = await adminListLogs({ q: logSearch, action: logActionFilter });
          setLogs(res.logs);
        }
      } catch (err) {
        onToast(err instanceof Error ? err.message : 'Failed to load admin data.', 'error');
      } finally {
        setLoading(false);
      }
    },
    [isStaff, isSuperAdmin, userSearch, postSearch, logSearch, logActionFilter, onToast]
  );

  useEffect(() => {
    loadTab(tab);
  }, [tab, loadTab]);

  if (!currentUsername || !isStaff) {
    return (
      <div className="win-box p-6 text-center space-y-2 border-2 border-[#ff6bd6]">
        <div className="font-pixel-title text-sm text-[#ff6bd6]">403 // ACCESS DENIED</div>
        <p className="text-sm text-[var(--accent-lavender)]">
          This Private Admin Dashboard requires server-verified administrative privileges.
        </p>
      </div>
    );
  }

  const sidebarItems: { id: AdminTab; label: string; superOnly?: boolean }[] = [
    { id: 'overview', label: 'Dashboard Overview' },
    { id: 'users', label: 'User Management' },
    { id: 'posts', label: 'Post & Content' },
    { id: 'roles', label: 'Role Management', superOnly: true },
    { id: 'god_mode', label: '★ GOD MODE', superOnly: true },
    { id: 'announcements', label: 'Announcements' },
    { id: 'logs', label: 'Site Logs & Audit' },
    { id: 'security', label: 'Security Settings', superOnly: true },
  ];

  return (
    <div className="space-y-3">
      {/* Confirmation Modal for Destructive Actions */}
      {confirmDialog && (
        <div className="fixed inset-0 z-50 bg-black/75 flex items-center justify-center p-4">
          <div className="win-box max-w-md w-full p-4 space-y-3 border-2 border-[#ff6bd6]">
            <div className="font-pixel-ui text-xs text-[#ff6bd6]">
              CONFIRM DESTRUCTIVE ACTION // {confirmDialog.title}
            </div>
            <p className="text-sm text-white">{confirmDialog.message}</p>
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setConfirmDialog(null)}
                className="win-btn px-3 py-1.5 text-xs"
              >
                CANCEL
              </button>
              <button
                type="button"
                onClick={async () => {
                  const fn = confirmDialog.onConfirm;
                  setConfirmDialog(null);
                  await fn();
                }}
                className="win-btn win-btn-primary px-3 py-1.5 text-xs text-[#ff6bd6]"
              >
                CONFIRM ACTION
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Top Admin Header */}
      <div
        className="win-box p-3 flex flex-wrap items-center justify-between gap-2 border-2"
        style={{
          borderColor: isSuperAdmin ? '#ffd700' : 'var(--accent-violet)',
          background: isSuperAdmin
            ? 'linear-gradient(90deg, #1f0a38 0%, #3b0764 50%, #1a1128 100%)'
            : undefined,
        }}
      >
        <div className="flex items-center gap-2 flex-wrap">
          <span className="font-pixel-title text-xs sm:text-sm text-[#ffd700]">
            {isSuperAdmin ? '★ BARUT SUPER ADMIN PANEL' : 'STAFF ADMIN PANEL'}
          </span>
          <BarutBadge username={currentUsername} role={currentUserRole} />
        </div>
        <div className="text-xs font-pixel-ui text-[#52ff94]">
          ROLE: {currentUserRole.toUpperCase()} · SERVER-VERIFIED
        </div>
      </div>

      {/* Layout: Sidebar + Main Panel */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-start">
        <aside className="md:col-span-4 lg:col-span-3 win-box p-2 space-y-1">
          {sidebarItems
            .filter((item) => !item.superOnly || isSuperAdmin)
            .map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`w-full win-btn px-2.5 py-2 text-left text-xs ${
                  tab === item.id
                    ? 'win-btn-primary'
                    : item.id === 'god_mode'
                      ? 'text-[#ffd700] border-[#ffd700]'
                      : ''
                }`}
              >
                {item.label}
              </button>
            ))}
        </aside>

        <section className="md:col-span-8 lg:col-span-9 win-box p-3 space-y-3 min-h-[420px]">
          {loading && (
            <div className="text-xs font-pixel-ui text-[#52ff94]">
              Syncing with server database...
            </div>
          )}

          {/* 1. OVERVIEW */}
          {tab === 'overview' && overview && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { label: 'Total Users', val: overview.stats.totalUsers, color: 'text-white' },
                  { label: 'Total Posts', val: overview.stats.totalPosts, color: 'text-[#52ff94]' },
                  {
                    label: 'Online Users (5m)',
                    val: overview.stats.onlineUsers,
                    color: 'text-[#52ff94]',
                  },
                  {
                    label: 'Total Comments',
                    val: overview.stats.totalComments,
                    color: 'text-[var(--accent-lavender)]',
                  },
                  {
                    label: 'New Regs (7d)',
                    val: overview.stats.newRegistrations7d,
                    color: 'text-[#ffd700]',
                  },
                  {
                    label: 'Open Reports',
                    val: overview.stats.openReports,
                    color: 'text-[#ff6bd6]',
                  },
                  {
                    label: 'Suspended',
                    val: overview.stats.suspendedAccounts,
                    color: 'text-[#ff6bd6]',
                  },
                  {
                    label: 'Banned',
                    val: overview.stats.bannedAccounts,
                    color: 'text-[#ff6bd6]',
                  },
                  {
                    label: 'Deleted Posts',
                    val: overview.stats.deletedPosts,
                    color: 'text-[var(--text-muted)]',
                  },
                ].map((stat) => (
                  <div key={stat.label} className="win-inset p-2.5">
                    <div className="text-[10px] font-pixel-ui text-[var(--text-muted)]">
                      {stat.label}
                    </div>
                    <div className={`text-xl font-pixel-title mt-1 ${stat.color}`}>{stat.val}</div>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
                <div className="win-inset p-2.5 space-y-2">
                  <div className="font-pixel-ui text-xs text-[#ffd700]">
                    ADMINISTRATOR ROSTER ({overview.administrators.length})
                  </div>
                  {overview.administrators.map((adm) => (
                    <div
                      key={adm.username}
                      className="flex items-center justify-between text-xs border-b border-[var(--bg-royal)] pb-1"
                    >
                      <span className="flex items-center gap-1.5 font-bold text-white">
                        {adm.username}
                        <BarutBadge username={adm.username} role={adm.role} compact />
                      </span>
                      <span className="text-[10px] font-pixel-ui text-[#52ff94]">
                        {adm.role.toUpperCase()}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="win-inset p-2.5 space-y-2">
                  <div className="font-pixel-ui text-xs text-[#ff6bd6]">
                    RECENT REPORTS ({overview.recentReports.length})
                  </div>
                  {overview.recentReports.length === 0 ? (
                    <div className="text-xs text-[var(--text-muted)]">No reports filed.</div>
                  ) : (
                    overview.recentReports.map((r) => (
                      <div
                        key={r.id}
                        className="flex items-center justify-between gap-2 text-xs border-b border-[var(--bg-royal)] pb-1"
                      >
                        <div className="truncate">
                          <strong className="text-white">{r.shortTitle}</strong> · {r.reason}
                        </div>
                        {r.status === 'open' ? (
                          <button
                            type="button"
                            onClick={async () => {
                              await resolveShortReport(r.id, 'remove');
                              onToast('Reported short removed.');
                              loadTab('overview');
                            }}
                            className="win-btn px-1.5 py-0.5 text-[10px] text-[#ff6bd6]"
                          >
                            HIDE
                          </button>
                        ) : (
                          <span className="text-[10px] text-[var(--text-muted)]">{r.status}</span>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div className="win-inset p-2.5 space-y-1.5">
                <div className="font-pixel-ui text-xs text-[var(--accent-lavender)]">
                  RECENT ADMINISTRATIVE ACTIVITY
                </div>
                {overview.recentLogs.length === 0 ? (
                  <div className="text-xs text-[var(--text-muted)]">No audit events recorded yet.</div>
                ) : (
                  overview.recentLogs.map((l) => (
                    <div key={l.id} className="text-xs flex flex-wrap justify-between gap-2">
                      <span>
                        <strong className="text-[#52ff94]">{l.actorUsername}</strong> →{' '}
                        <span className="text-[#ffd700]">{l.action}</span> on{' '}
                        <span className="text-white">{l.targetId}</span>
                      </span>
                      <span className="text-[10px] text-[var(--text-muted)]">
                        {l.createdAt.slice(0, 19).replace('T', ' ')}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* 2. USER MANAGEMENT */}
          {tab === 'users' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="Search registered users by username..."
                  className="flex-1 win-inset px-2.5 py-1.5 text-sm text-white"
                />
                <button
                  type="button"
                  onClick={() => loadTab('users')}
                  className="win-btn win-btn-primary px-3 py-1.5 text-xs"
                >
                  SEARCH
                </button>
              </div>

              <div className="space-y-2 max-h-[520px] overflow-y-auto">
                {adminUsers.map((u) => {
                  const targetIsSuper = u.role === 'super_admin' || u.username === 'barut';
                  return (
                    <div
                      key={u.username}
                      className="win-inset p-2.5 space-y-2 text-xs"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-1.5 font-pixel-ui text-white">
                            <button
                              type="button"
                              onClick={() => onOpenUserProfile(u.username)}
                              className="hover:underline cursor-pointer"
                            >
                              {u.username}
                            </button>
                            <BarutBadge username={u.username} role={u.role} compact />
                            <span className="text-[10px] px-1 border border-[var(--accent-violet)] text-[#52ff94]">
                              {u.role.toUpperCase()}
                            </span>
                            <span
                              className={`text-[10px] px-1 border ${
                                u.status === 'active'
                                  ? 'border-[#52ff94] text-[#52ff94]'
                                  : 'border-[#ff6bd6] text-[#ff6bd6]'
                              }`}
                            >
                              {u.isDeleted ? 'DELETED' : u.status.toUpperCase()}
                            </span>
                          </div>
                          <div className="text-[11px] text-[var(--text-muted)] mt-0.5">
                            Joined: {u.createdAt.slice(0, 10) || 'unknown'} · Posts: {u.postCount} ·
                            Topics: {u.topicCount} · Shorts: {u.shortCount}
                          </div>
                          <div className="text-[var(--accent-lavender)] mt-0.5">{u.bio}</div>
                        </div>

                        {!targetIsSuper && (
                          <div className="flex flex-wrap gap-1">
                            {isAdminOrHigher && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setEditingBioUser(u.username);
                                    setBioDraft(u.bio);
                                  }}
                                  className="win-btn px-2 py-1 text-[10px]"
                                >
                                  EDIT BIO
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setRenamingUser(u.username);
                                    setRenameDraft(u.username);
                                  }}
                                  className="win-btn px-2 py-1 text-[10px]"
                                >
                                  RENAME
                                </button>
                              </>
                            )}
                            {u.status !== 'active' ? (
                              <button
                                type="button"
                                onClick={async () => {
                                  await adminSetUserStatus(u.username, 'active');
                                  onToast(`Restored ${u.username}.`);
                                  loadTab('users');
                                }}
                                className="win-btn px-2 py-1 text-[10px] text-[#52ff94]"
                              >
                                RESTORE
                              </button>
                            ) : (
                              <>
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await adminSetUserStatus(u.username, 'suspended');
                                    onToast(`Suspended ${u.username}.`);
                                    loadTab('users');
                                  }}
                                  className="win-btn px-2 py-1 text-[10px] text-[#ffd700]"
                                >
                                  SUSPEND
                                </button>
                                <button
                                  type="button"
                                  onClick={() =>
                                    setConfirmDialog({
                                      title: `BAN ${u.username}`,
                                      message: `Ban ${u.username} from logging in?`,
                                      onConfirm: async () => {
                                        await adminSetUserStatus(u.username, 'banned');
                                        onToast(`Banned ${u.username}.`);
                                        loadTab('users');
                                      },
                                    })
                                  }
                                  className="win-btn px-2 py-1 text-[10px] text-[#ff6bd6]"
                                >
                                  BAN
                                </button>
                              </>
                            )}
                            {isAdminOrHigher && !u.isDeleted && (
                              <button
                                type="button"
                                onClick={() =>
                                  setConfirmDialog({
                                    title: `DELETE ${u.username}`,
                                    message: `Soft-delete account "${u.username}" and revoke all sessions?`,
                                    onConfirm: async () => {
                                      await adminDeleteUser(u.username);
                                      onToast(`Deleted ${u.username}.`);
                                      loadTab('users');
                                    },
                                  })
                                }
                                className="win-btn px-2 py-1 text-[10px] text-[#ff6bd6]"
                              >
                                DELETE
                              </button>
                            )}
                          </div>
                        )}
                      </div>

                      {editingBioUser === u.username && (
                        <div className="flex gap-1.5 pt-1">
                          <input
                            type="text"
                            value={bioDraft}
                            onChange={(e) => setBioDraft(e.target.value)}
                            className="flex-1 win-inset px-2 py-1 text-white"
                          />
                          <button
                            type="button"
                            onClick={async () => {
                              await adminEditUser(u.username, { bio: bioDraft });
                              setEditingBioUser(null);
                              onToast('Profile updated.');
                              loadTab('users');
                            }}
                            className="win-btn win-btn-primary px-2 py-1 text-[10px]"
                          >
                            SAVE BIO
                          </button>
                        </div>
                      )}

                      {renamingUser === u.username && (
                        <div className="flex gap-1.5 pt-1">
                          <input
                            type="text"
                            value={renameDraft}
                            onChange={(e) => setRenameDraft(e.target.value)}
                            className="flex-1 win-inset px-2 py-1 text-white"
                          />
                          <button
                            type="button"
                            onClick={async () => {
                              try {
                                await adminRenameUser(u.username, renameDraft);
                                setRenamingUser(null);
                                onToast('Username changed.');
                                loadTab('users');
                              } catch (err) {
                                onToast(
                                  err instanceof Error ? err.message : 'Rename failed',
                                  'error'
                                );
                              }
                            }}
                            className="win-btn win-btn-primary px-2 py-1 text-[10px]"
                          >
                            CONFIRM RENAME
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* 3. POST & CONTENT MANAGEMENT */}
          {tab === 'posts' && (
            <div className="space-y-3">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={postSearch}
                  onChange={(e) => setPostSearch(e.target.value)}
                  placeholder="Search blog posts or forum topics..."
                  className="flex-1 win-inset px-2.5 py-1.5 text-sm text-white"
                />
                <button
                  type="button"
                  onClick={() => loadTab('posts')}
                  className="win-btn win-btn-primary px-3 py-1.5 text-xs"
                >
                  SEARCH
                </button>
              </div>

              <div className="space-y-2 max-h-[520px] overflow-y-auto">
                {adminPosts.length === 0 ? (
                  <div className="win-inset p-4 text-xs text-[var(--text-muted)]">
                    No synced blog posts or forum topics found yet.
                  </div>
                ) : (
                  adminPosts.map((p) => (
                    <div key={`${p.kind}-${p.id}`} className="win-inset p-2.5 space-y-2 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <div>
                          <span className="px-1 bg-[var(--bg-royal)] text-[#52ff94] font-pixel-ui text-[10px] mr-1.5">
                            {p.kind.toUpperCase()}
                          </span>
                          {p.isPinned && (
                            <span className="px-1 bg-[#ffd700] text-black font-pixel-ui text-[10px] mr-1.5">
                              PINNED
                            </span>
                          )}
                          {p.isDeleted && (
                            <span className="px-1 bg-[#ff6bd6] text-black font-pixel-ui text-[10px] mr-1.5">
                              DELETED
                            </span>
                          )}
                          <strong className="text-white">{p.title}</strong>{' '}
                          <span className="text-[var(--text-muted)]">by @{p.author}</span>
                        </div>

                        <div className="flex flex-wrap gap-1">
                          <button
                            type="button"
                            onClick={async () => {
                              await adminUpdatePost(p.id, p.kind, { isPinned: !p.isPinned });
                              onToast(p.isPinned ? 'Unpinned post.' : 'Pinned post.');
                              loadTab('posts');
                            }}
                            className="win-btn px-2 py-0.5 text-[10px]"
                          >
                            {p.isPinned ? 'UNPIN' : 'PIN'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              setEditingPostId(p.id);
                              setPostTitleDraft(p.title);
                              setPostBodyDraft(p.content);
                            }}
                            className="win-btn px-2 py-0.5 text-[10px]"
                          >
                            EDIT
                          </button>
                          {p.isDeleted ? (
                            <button
                              type="button"
                              onClick={async () => {
                                await adminRestorePost(p.id, p.kind);
                                onToast('Post restored from backup!');
                                loadTab('posts');
                              }}
                              className="win-btn px-2 py-0.5 text-[10px] text-[#52ff94]"
                            >
                              RESTORE
                            </button>
                          ) : (
                            <button
                              type="button"
                              onClick={() =>
                                setConfirmDialog({
                                  title: 'DELETE POST',
                                  message: `Move "${p.title}" by @${p.author} to deleted backup?`,
                                  onConfirm: async () => {
                                    await adminDeletePost(p.id, p.kind);
                                    onToast('Post soft-deleted.');
                                    loadTab('posts');
                                  },
                                })
                              }
                              className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
                            >
                              DELETE
                            </button>
                          )}
                        </div>
                      </div>

                      <p className="text-[var(--accent-lavender)] break-words">{p.content}</p>

                      {editingPostId === p.id && (
                        <div className="space-y-1.5 pt-1 border-t border-[var(--bg-royal)]">
                          {p.kind === 'forum' && (
                            <input
                              type="text"
                              value={postTitleDraft}
                              onChange={(e) => setPostTitleDraft(e.target.value)}
                              className="w-full win-inset px-2 py-1 text-white"
                            />
                          )}
                          <textarea
                            value={postBodyDraft}
                            onChange={(e) => setPostBodyDraft(e.target.value)}
                            rows={2}
                            className="w-full win-inset px-2 py-1 text-white"
                          />
                          <div className="flex gap-1.5">
                            <button
                              type="button"
                              onClick={async () => {
                                await adminUpdatePost(p.id, p.kind, {
                                  title: p.kind === 'forum' ? postTitleDraft : undefined,
                                  content: postBodyDraft,
                                });
                                setEditingPostId(null);
                                onToast('Post updated.');
                                loadTab('posts');
                              }}
                              className="win-btn win-btn-primary px-2 py-1 text-[10px]"
                            >
                              SAVE
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingPostId(null)}
                              className="win-btn px-2 py-1 text-[10px]"
                            >
                              CANCEL
                            </button>
                          </div>
                        </div>
                      )}

                      {p.comments.length > 0 && (
                        <div className="pl-2 border-l-2 border-[var(--accent-violet)] space-y-1">
                          {p.comments.map((c) => (
                            <div key={c.id} className="flex items-center justify-between gap-2">
                              <span>
                                <strong className="text-[#52ff94]">@{c.author}:</strong> {c.text}
                              </span>
                              <button
                                type="button"
                                onClick={async () => {
                                  await adminDeleteComment(p.id, c.id, p.kind);
                                  onToast('Comment removed.');
                                  loadTab('posts');
                                }}
                                className="text-[10px] text-[#ff6bd6] underline cursor-pointer"
                              >
                                delete comment
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {/* 4. ROLE MANAGEMENT (SUPER ADMIN ONLY) */}
          {tab === 'roles' && isSuperAdmin && (
            <div className="space-y-3">
              <div className="win-inset p-2.5 text-xs text-[#ffd700]">
                Hierarchy: 1. Super Admin (barut exclusive) &gt; 2. Administrator &gt; 3.
                Moderator &gt; 4. Member. Ordinary admins cannot promote themselves or modify
                Super Admin.
              </div>
              <div className="space-y-2 max-h-[480px] overflow-y-auto">
                {adminUsers.map((u) => (
                  <div
                    key={u.username}
                    className="win-inset p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <div className="flex items-center gap-1.5 font-pixel-ui text-white">
                      <span>{u.username}</span>
                      <BarutBadge username={u.username} role={u.role} compact />
                    </div>
                    {u.username === 'barut' ? (
                      <span className="font-pixel-ui text-[10px] text-[#ffd700]">
                        IMMUTABLE SUPER ADMIN
                      </span>
                    ) : (
                      <select
                        value={u.role}
                        onChange={async (e) => {
                          const nextRole = e.target.value as 'admin' | 'moderator' | 'member';
                          await adminSetUserRole(u.username, nextRole);
                          onToast(`Assigned ${nextRole.toUpperCase()} to ${u.username}`);
                          onSiteStateChanged();
                          loadTab('roles');
                        }}
                        className="win-inset px-2 py-1 text-white text-xs"
                      >
                        <option value="member">Member</option>
                        <option value="moderator">Moderator</option>
                        <option value="admin">Administrator</option>
                      </select>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. GOD MODE (SUPER ADMIN ONLY) */}
          {tab === 'god_mode' && isSuperAdmin && godSettings && (
            <div className="space-y-4 text-xs">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#ffd700]/40 pb-2">
                <div className="font-pixel-title text-xs text-[#ffd700]">
                  ★ GOD MODE // GLOBAL WEBSITE CONTROLS
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    const res = await adminRestoreAllFeatures();
                    setGodSettings(res.settings);
                    onSiteStateChanged();
                    onToast('All website features restored to ONLINE!');
                  }}
                  className="win-btn win-btn-primary px-3 py-1.5 text-[10px] text-[#52ff94]"
                >
                  RESTORE ALL FEATURES IN 1 CLICK
                </button>
              </div>

              {/* Maintenance Mode */}
              <div className="win-inset p-3 space-y-2 border border-[#ff6bd6]/60">
                <div className="flex items-center justify-between">
                  <span className="font-pixel-ui text-[#ff6bd6]">MAINTENANCE MODE</span>
                  <button
                    type="button"
                    onClick={async () => {
                      const res = await adminUpdateGodMode({
                        maintenanceMode: !godSettings.maintenanceMode,
                      });
                      setGodSettings(res.settings);
                      onSiteStateChanged();
                      onToast(
                        res.settings.maintenanceMode
                          ? 'Maintenance Mode ENABLED.'
                          : 'Maintenance Mode DISABLED.'
                      );
                    }}
                    className={`win-btn px-3 py-1 text-[10px] ${
                      godSettings.maintenanceMode ? 'win-btn-primary text-[#ff6bd6]' : ''
                    }`}
                  >
                    {godSettings.maintenanceMode ? 'ENABLED (CLICK TO DISABLE)' : 'DISABLED'}
                  </button>
                </div>
                <input
                  type="text"
                  value={godSettings.maintenanceMessage}
                  onChange={(e) =>
                    setGodSettings({ ...godSettings, maintenanceMessage: e.target.value })
                  }
                  className="w-full win-inset px-2.5 py-1.5 text-white"
                  placeholder="Custom maintenance message..."
                />
              </div>

              {/* Feature Toggles */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {(
                  [
                    { key: 'registrationEnabled', label: 'New Account Registration' },
                    { key: 'postingEnabled', label: 'New Posts / Topics / Shorts' },
                    { key: 'commentsEnabled', label: 'Comments & Replies' },
                    { key: 'chatEnabled', label: 'Private & Public Chatrooms' },
                  ] as { key: keyof SiteSettings; label: string }[]
                ).map((ctrl) => {
                  const enabled = Boolean(godSettings[ctrl.key]);
                  return (
                    <div
                      key={ctrl.key}
                      className="win-inset p-2.5 flex items-center justify-between gap-2"
                    >
                      <span className="text-white">{ctrl.label}</span>
                      <button
                        type="button"
                        onClick={async () => {
                          const res = await adminUpdateGodMode({ [ctrl.key]: !enabled });
                          setGodSettings(res.settings);
                          onSiteStateChanged();
                          onToast(`${ctrl.label}: ${!enabled ? 'ENABLED' : 'DISABLED'}`);
                        }}
                        className={`win-btn px-2.5 py-1 text-[10px] ${
                          enabled ? 'text-[#52ff94]' : 'text-[#ff6bd6]'
                        }`}
                      >
                        {enabled ? 'ON' : 'OFF'}
                      </button>
                    </div>
                  );
                })}
              </div>

              {/* Global Banner & Site Notice */}
              <div className="win-inset p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-pixel-ui text-[var(--accent-lavender)]">
                    GLOBAL WEBSITE BANNER &amp; NOTICE
                  </span>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={godSettings.globalBannerEnabled}
                      onChange={(e) =>
                        setGodSettings({ ...godSettings, globalBannerEnabled: e.target.checked })
                      }
                    />
                    <span>Show Global Banner</span>
                  </label>
                </div>
                <input
                  type="text"
                  value={godSettings.globalBannerText}
                  onChange={(e) =>
                    setGodSettings({ ...godSettings, globalBannerText: e.target.value })
                  }
                  placeholder="Global announcement banner text..."
                  className="w-full win-inset px-2.5 py-1.5 text-white"
                />
                <input
                  type="text"
                  value={godSettings.siteNotice}
                  onChange={(e) => setGodSettings({ ...godSettings, siteNotice: e.target.value })}
                  placeholder="Site-wide footer or notice message..."
                  className="w-full win-inset px-2.5 py-1.5 text-white"
                />
                <button
                  type="button"
                  onClick={async () => {
                    const res = await adminUpdateGodMode(godSettings);
                    setGodSettings(res.settings);
                    onSiteStateChanged();
                    onToast('Global God Mode settings saved!');
                  }}
                  className="win-btn win-btn-primary px-4 py-1.5 text-xs"
                >
                  SAVE GLOBAL SETTINGS
                </button>
              </div>
            </div>
          )}

          {/* 6. ANNOUNCEMENTS */}
          {tab === 'announcements' && (
            <div className="space-y-3 text-xs">
              {isSuperAdmin && (
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    if (editingAnnId) {
                      await adminUpdateAnnouncement(editingAnnId, {
                        title: annTitle,
                        body: annBody,
                        category: annCategory,
                        isPinned: annPinned,
                        showBanner: annShowBanner,
                        sendToNotifications: annNotify,
                        scheduledAt: annSchedule || null,
                      });
                      setEditingAnnId(null);
                      onToast('Announcement updated!');
                    } else {
                      await adminCreateAnnouncement({
                        title: annTitle,
                        body: annBody,
                        category: annCategory,
                        isPinned: annPinned,
                        showBanner: annShowBanner,
                        sendToNotifications: annNotify,
                        scheduledAt: annSchedule || null,
                      });
                      onToast('Announcement published!');
                    }
                    setAnnTitle('');
                    setAnnBody('');
                    setAnnSchedule('');
                    onSiteStateChanged();
                    loadTab('announcements');
                  }}
                  className="win-inset p-3 space-y-2"
                >
                  <div className="font-pixel-ui text-[#ffd700]">
                    {editingAnnId ? 'EDIT ANNOUNCEMENT' : '+ PUBLISH GLOBAL ANNOUNCEMENT'}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      required
                      value={annTitle}
                      onChange={(e) => setAnnTitle(e.target.value)}
                      placeholder="Announcement title..."
                      className="win-inset px-2 py-1.5 text-white"
                    />
                    <select
                      value={annCategory}
                      onChange={(e) => setAnnCategory(e.target.value as AnnouncementCategory)}
                      className="win-inset px-2 py-1.5 text-white"
                    >
                      <option value="normal">Normal Announcement</option>
                      <option value="important">Important Announcement</option>
                      <option value="maintenance">Maintenance Announcement</option>
                      <option value="event">Event Announcement</option>
                    </select>
                  </div>
                  <textarea
                    required
                    rows={2}
                    value={annBody}
                    onChange={(e) => setAnnBody(e.target.value)}
                    placeholder="Announcement details..."
                    className="w-full win-inset px-2 py-1.5 text-white"
                  />
                  <div className="flex flex-wrap items-center gap-3">
                    <label className="flex items-center gap-1">
                      <input
                        type="checkbox"
                        checked={annPinned}
                        onChange={(e) => setAnnPinned(e.target.checked)}
                      />
                      Pin Important
                    </label>
                    <label className="flex items-center gap-1">
                      <input
                        type="checkbox"
                        checked={annShowBanner}
                        onChange={(e) => setAnnShowBanner(e.target.checked)}
                      />
                      Show Banner
                    </label>
                    <label className="flex items-center gap-1">
                      <input
                        type="checkbox"
                        checked={annNotify}
                        onChange={(e) => setAnnNotify(e.target.checked)}
                      />
                      Push Notification
                    </label>
                    <input
                      type="datetime-local"
                      value={annSchedule}
                      onChange={(e) => setAnnSchedule(e.target.value)}
                      className="win-inset px-1.5 py-0.5 text-white"
                      title="Optional schedule date/time"
                    />
                  </div>
                  <button type="submit" className="win-btn win-btn-primary px-3 py-1.5 text-xs">
                    {editingAnnId ? 'UPDATE ANNOUNCEMENT' : 'PUBLISH ANNOUNCEMENT'}
                  </button>
                </form>
              )}

              <div className="space-y-2 max-h-72 overflow-y-auto">
                {announcements.map((a) => (
                  <div key={a.id} className="win-inset p-2.5 space-y-1">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="px-1 bg-[var(--bg-royal)] text-[#ffd700] font-pixel-ui text-[10px] mr-1.5">
                          {a.category.toUpperCase()}
                        </span>
                        {a.isPinned && (
                          <span className="px-1 bg-[#ff6bd6] text-black font-pixel-ui text-[10px] mr-1.5">
                            PINNED
                          </span>
                        )}
                        <strong className="text-white">{a.title}</strong>
                      </div>
                      {isSuperAdmin && (
                        <div className="flex gap-1">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingAnnId(a.id);
                              setAnnTitle(a.title);
                              setAnnBody(a.body);
                              setAnnCategory(a.category);
                              setAnnPinned(a.isPinned);
                              setAnnShowBanner(a.showBanner);
                              setAnnNotify(a.sendToNotifications);
                            }}
                            className="win-btn px-2 py-0.5 text-[10px]"
                          >
                            EDIT
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setConfirmDialog({
                                title: 'DELETE ANNOUNCEMENT',
                                message: `Delete announcement "${a.title}"?`,
                                onConfirm: async () => {
                                  await adminDeleteAnnouncement(a.id);
                                  onSiteStateChanged();
                                  loadTab('announcements');
                                },
                              })
                            }
                            className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
                          >
                            DELETE
                          </button>
                        </div>
                      )}
                    </div>
                    <p className="text-[var(--accent-lavender)]">{a.body}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7. IMMUTABLE SITE LOGS & AUDIT HISTORY */}
          {tab === 'logs' && (
            <div className="space-y-3 text-xs">
              <div className="flex flex-wrap gap-2">
                <input
                  type="text"
                  value={logSearch}
                  onChange={(e) => setLogSearch(e.target.value)}
                  placeholder="Search actor, target, or details..."
                  className="flex-1 win-inset px-2 py-1 text-white"
                />
                <select
                  value={logActionFilter}
                  onChange={(e) => setLogActionFilter(e.target.value)}
                  className="win-inset px-2 py-1 text-white"
                >
                  <option value="all">All Actions</option>
                  <option value="delete">Deletions</option>
                  <option value="status">Bans / Suspensions</option>
                  <option value="role">Role Changes</option>
                  <option value="god_mode">God Mode</option>
                  <option value="announcement">Announcements</option>
                </select>
                <button
                  type="button"
                  onClick={() => loadTab('logs')}
                  className="win-btn win-btn-primary px-3 py-1 text-xs"
                >
                  FILTER
                </button>
              </div>

              <div className="win-inset p-2 text-[11px] text-[#52ff94]">
                Audit logs are append-only on the server and cannot be edited or deleted.
              </div>

              <div className="space-y-1.5 max-h-[420px] overflow-y-auto">
                {logs.map((l) => (
                  <div
                    key={l.id}
                    className="win-inset p-2 flex flex-wrap items-center justify-between gap-2"
                  >
                    <div>
                      <span className="font-pixel-ui text-[#52ff94]">{l.actorUsername}</span>{' '}
                      <span className="text-[10px] text-[var(--text-muted)]">
                        ({l.actorRole})
                      </span>{' '}
                      → <strong className="text-[#ffd700]">{l.action}</strong> [{l.targetType}:{' '}
                      <span className="text-white">{l.targetId}</span>]{' '}
                      {l.details && (
                        <span className="text-[var(--accent-lavender)]">— {l.details}</span>
                      )}
                    </div>
                    <div className="text-[10px] text-[var(--text-muted)]">
                      {l.result} · {l.createdAt.slice(0, 19).replace('T', ' ')}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 8. SECURITY SETTINGS (SUPER ADMIN ONLY) */}
          {tab === 'security' && isSuperAdmin && (
            <div className="space-y-3 text-xs">
              <div className="win-inset p-3 space-y-2">
                <div className="font-pixel-ui text-[#52ff94]">
                  BARUT SUPER ADMIN SECURITY ARCHITECTURE
                </div>
                <ul className="list-disc pl-5 space-y-1 text-[var(--accent-lavender)]">
                  <li>
                    Credentials hashed server-side using salted <code>crypto.scryptSync</code> +
                    constant-time <code>crypto.timingSafeEqual</code>.
                  </li>
                  <li>
                    Session tokens signed with HMAC-SHA256 and verified against SQLite account
                    status &amp; <code>token_version</code> on every request.
                  </li>
                  <li>
                    Super Admin (<code>barut</code>) cannot be deleted, banned, suspended, renamed,
                    or demoted by ordinary administrators.
                  </li>
                  <li>
                    Private messages &amp; passwords are never exposed in Admin Dashboard queries.
                  </li>
                </ul>
              </div>

              <button
                type="button"
                onClick={() =>
                  setConfirmDialog({
                    title: 'ROTATE ALL SESSION TOKENS',
                    message:
                      'Force logout all non-Super Admin users and invalidate all existing session tokens?',
                    onConfirm: async () => {
                      const res = await adminRotateAllTokens();
                      onToast(res.message);
                    },
                  })
                }
                className="win-btn px-4 py-2 text-xs text-[#ff6bd6]"
              >
                FORCE LOGOUT ALL ORDINARY USERS (ROTATE SESSION TOKENS)
              </button>
            </div>
          )}
        </section>
      </div>
    </div>
  );
};
