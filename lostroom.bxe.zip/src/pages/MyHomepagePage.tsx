import React, { useEffect, useMemo, useState } from 'react';
import { HomepageRenderer } from '../components/HomepageRenderer';
import {
  buildTemplateDocument,
  createDefaultPlayerConfig,
  HOMEPAGE_TEMPLATE_LIST,
  PLAYER_SKIN_PRESETS,
} from '../data/homepageTemplates';
import {
  AudioTrack,
  GuestbookEntry,
  HomepageBlock,
  HomepageBlockType,
  HomepageBorderStyle,
  HomepageDocument,
  HomepageFontFamily,
  HomepageRecord,
  HomepageTemplateId,
  MediaAsset,
  PlayerSkinId,
  PlaylistRecord,
  StickerIconId,
} from '../types/homepage';
import {
  createPlaylist,
  deleteAudioTrack,
  deleteMediaAsset,
  deletePlaylist,
  formatBytes,
  getEditorHomepage,
  getPublishedDirectory,
  listAudioTracks,
  listMediaAssets,
  listUserPlaylists,
  PublishedDirectoryItem,
  publishHomepage,
  saveHomepageDraft,
  syncAccount,
  unpublishHomepage,
  updateAudioTrack,
  updatePlaylist,
  uploadAudioTrack,
  uploadImageAsset,
} from '../utils/homepageApi';

interface MyHomepagePageProps {
  currentUsername: string | null;
  onOpenPublicUrl: (path: string) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

type StudioTab = 'editor' | 'templates' | 'media' | 'music' | 'playlists';
type InspectorTab = 'page' | 'block';

export const MyHomepagePage: React.FC<MyHomepagePageProps> = ({
  currentUsername,
  onOpenPublicUrl,
  onToast,
}) => {
  const [studioTab, setStudioTab] = useState<StudioTab>('editor');
  const [inspectorTab, setInspectorTab] = useState<InspectorTab>('page');
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [showDirectory, setShowDirectory] = useState(false);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [homepageRec, setHomepageRec] = useState<HomepageRecord | null>(null);
  const [draftDoc, setDraftDoc] = useState<HomepageDocument | null>(null);
  const [guestbook, setGuestbook] = useState<GuestbookEntry[]>([]);
  const [selectedBlockId, setSelectedBlockId] = useState<string | null>(null);
  const [draggedBlockId, setDraggedBlockId] = useState<string | null>(null);

  const [mediaAssets, setMediaAssets] = useState<MediaAsset[]>([]);
  const [mediaBytes, setMediaBytes] = useState(0);
  const [mediaQuota, setMediaQuota] = useState(60 * 1024 * 1024);
  const [uploadMediaKind, setUploadMediaKind] = useState<MediaAsset['kind']>('image');
  const [uploadingImage, setUploadingImage] = useState(false);

  const [audioTracks, setAudioTracks] = useState<AudioTrack[]>([]);
  const [audioBytes, setAudioBytes] = useState(0);
  const [audioQuota, setAudioQuota] = useState(80 * 1024 * 1024);
  const [mp3RightsChecked, setMp3RightsChecked] = useState(true);
  const [mp3TitleInput, setMp3TitleInput] = useState('');
  const [mp3ArtistInput, setMp3ArtistInput] = useState('');
  const [mp3DescInput, setMp3DescInput] = useState('');
  const [mp3CoverInput, setMp3CoverInput] = useState('');
  const [uploadingAudio, setUploadingAudio] = useState(false);
  const [editingTrackId, setEditingTrackId] = useState<string | null>(null);
  const [trackEditForm, setTrackEditForm] = useState({
    title: '',
    artist: '',
    description: '',
    coverUrl: '',
  });

  const [playlists, setPlaylists] = useState<PlaylistRecord[]>([]);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [newPlName, setNewPlName] = useState('');
  const [newPlDesc, setNewPlDesc] = useState('');
  const [newPlCover, setNewPlCover] = useState('');
  const [newPlPublic, setNewPlPublic] = useState(true);
  const [newPlTrackIds, setNewPlTrackIds] = useState<string[]>([]);
  const [creatingPl, setCreatingPl] = useState(false);

  const [directory, setDirectory] = useState<PublishedDirectoryItem[]>([]);

  const loadAllStudioData = async (username: string) => {
    setLoading(true);
    try {
      await syncAccount({ username });
      const [editorRes, mediaRes, audioRes, plRes, dirRes] = await Promise.all([
        getEditorHomepage(username),
        listMediaAssets(username),
        listAudioTracks(username),
        listUserPlaylists(username, username),
        getPublishedDirectory(),
      ]);
      setHomepageRec(editorRes.homepage);
      setDraftDoc(editorRes.homepage.draft);
      setGuestbook(editorRes.guestbook);
      setSelectedBlockId(editorRes.homepage.draft.blocks[0]?.id || null);

      setMediaAssets(mediaRes.assets);
      setMediaBytes(mediaRes.totalBytes);
      setMediaQuota(mediaRes.quotaBytes);

      setAudioTracks(audioRes.tracks);
      setAudioBytes(audioRes.totalBytes);
      setAudioQuota(audioRes.quotaBytes);

      setPlaylists(plRes.playlists);
      if (plRes.playlists.length > 0 && !selectedPlaylistId) {
        setSelectedPlaylistId(plRes.playlists[0].id);
      }

      setDirectory(dirRes.homepages);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to load homepage studio.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentUsername) {
      loadAllStudioData(currentUsername);
    }
  }, [currentUsername]);

  const playlistsById = useMemo(() => {
    const map: Record<string, PlaylistRecord> = {};
    playlists.forEach((pl) => {
      map[pl.id] = pl;
    });
    return map;
  }, [playlists]);

  const selectedBlock = useMemo(
    () => draftDoc?.blocks.find((b) => b.id === selectedBlockId) || null,
    [draftDoc, selectedBlockId]
  );

  const activeEditPlaylist = useMemo(
    () => playlists.find((p) => p.id === selectedPlaylistId) || playlists[0] || null,
    [playlists, selectedPlaylistId]
  );

  if (!currentUsername) {
    return (
      <div className="win-inset p-6 text-center space-y-3">
        <div className="font-pixel-ui text-sm text-[#ff6bd6]">LOGIN REQUIRED</div>
        <p className="text-base text-[#c8b4f8]">
          Please log in or register in Portal Gate to build, save, and publish your personal MY HOMEPAGE website.
        </p>
      </div>
    );
  }

  if (loading && !draftDoc) {
    return (
      <div className="win-inset p-8 text-center font-pixel-ui text-xs text-[#c8b4f8]">
        LOADING MY_HOMEPAGE STUDIO &amp; PERSISTENT LIBRARIES...
      </div>
    );
  }

  const updateTheme = (patch: Partial<HomepageDocument['theme']>) => {
    setDraftDoc((prev) =>
      prev ? { ...prev, theme: { ...prev.theme, ...patch } } : prev
    );
  };

  const updateBlock = (blockId: string, patch: Partial<HomepageBlock>) => {
    setDraftDoc((prev) =>
      prev
        ? {
            ...prev,
            blocks: prev.blocks.map((b) => (b.id === blockId ? { ...b, ...patch } : b)),
          }
        : prev
    );
  };

  const addBlock = (type: HomepageBlockType) => {
    if (!draftDoc) return;
    const id = `blk-${Date.now()}-${Math.random().toString(16).slice(2, 5)}`;
    let newBlock: HomepageBlock = { id, type };
    if (type === 'heading') {
      newBlock = {
        id,
        type,
        title: 'NEW SECTION HEADING',
        content: 'Optional subtitle here...',
        align: 'center',
      };
    } else if (type === 'text') {
      newBlock = {
        id,
        type,
        title: 'About / Journal Entry',
        content: 'Write whatever you want on your retro 2000s homepage!',
        align: 'left',
      };
    } else if (type === 'image') {
      newBlock = {
        id,
        type,
        imageUrl: mediaAssets[0]?.url || '',
        imageWidth: '100%',
        imageCaption: 'Uploaded graphic',
        align: 'center',
      };
    } else if (type === 'button_link') {
      newBlock = {
        id,
        type,
        linkLabel: '★ CLICK MY LINK ★',
        linkUrl: '/',
        buttonBg: draftDoc.theme.headingColor,
        buttonText: '#09060e',
        align: 'center',
      };
    } else if (type === 'two_column') {
      newBlock = {
        id,
        type,
        title: 'Left Column',
        content: 'Interests, status, or mood notes...',
        secondaryTitle: 'Right Column',
        secondaryContent: 'Favorite links, stamps, or credits...',
      };
    } else if (type === 'sticker_divider') {
      newBlock = {
        id,
        type,
        stickerId: 'sparkle_stars',
        marqueeText: `★ ${currentUsername}'s 2000s webpage — thanks for stopping by! ★`,
      };
    } else if (type === 'music_player') {
      newBlock = {
        id,
        type,
        title: 'My Custom MP3 Player',
        playlistId: playlists[0]?.id || '',
        playerConfig: createDefaultPlayerConfig('lavender_mini'),
      };
    } else if (type === 'guestbook_counter') {
      newBlock = {
        id,
        type,
        title: 'Visitor Counter & Guestbook',
      };
    }

    setDraftDoc({ ...draftDoc, blocks: [...draftDoc.blocks, newBlock] });
    setSelectedBlockId(id);
    setInspectorTab('block');
    onToast(`Added ${type.replace('_', ' ')} block.`);
  };

  const handleMoveBlock = (blockId: string, dir: 'up' | 'down') => {
    if (!draftDoc) return;
    const idx = draftDoc.blocks.findIndex((b) => b.id === blockId);
    if (idx === -1) return;
    const targetIdx = dir === 'up' ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= draftDoc.blocks.length) return;
    const next = [...draftDoc.blocks];
    const [moved] = next.splice(idx, 1);
    next.splice(targetIdx, 0, moved);
    setDraftDoc({ ...draftDoc, blocks: next });
  };

  const handleDropOnBlock = (targetId: string) => {
    if (!draftDoc || !draggedBlockId || draggedBlockId === targetId) return;
    const fromIdx = draftDoc.blocks.findIndex((b) => b.id === draggedBlockId);
    const toIdx = draftDoc.blocks.findIndex((b) => b.id === targetId);
    if (fromIdx === -1 || toIdx === -1) return;
    const next = [...draftDoc.blocks];
    const [moved] = next.splice(fromIdx, 1);
    next.splice(toIdx, 0, moved);
    setDraftDoc({ ...draftDoc, blocks: next });
    setDraggedBlockId(null);
  };

  const handleDeleteBlock = (blockId: string) => {
    if (!draftDoc) return;
    const filtered = draftDoc.blocks.filter((b) => b.id !== blockId);
    setDraftDoc({ ...draftDoc, blocks: filtered });
    if (selectedBlockId === blockId) {
      setSelectedBlockId(filtered[0]?.id || null);
    }
  };

  const handleSaveDraft = async () => {
    if (!draftDoc) return;
    setSaving(true);
    try {
      const res = await saveHomepageDraft(currentUsername, draftDoc);
      setHomepageRec(res.homepage);
      onToast('Homepage draft saved persistently!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Save draft failed.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handlePublish = async () => {
    if (!draftDoc) return;
    setSaving(true);
    try {
      const res = await publishHomepage(currentUsername, draftDoc);
      setHomepageRec(res.homepage);
      const dirRes = await getPublishedDirectory();
      setDirectory(dirRes.homepages);
      onToast(`Published! Live at /user/${currentUsername}`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Publish failed.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleUnpublish = async () => {
    setSaving(true);
    try {
      const res = await unpublishHomepage(currentUsername);
      setHomepageRec(res.homepage);
      const dirRes = await getPublishedDirectory();
      setDirectory(dirRes.homepages);
      onToast('Homepage unpublished. Your draft is still safely saved.');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Unpublish failed.', 'error');
    } finally {
      setSaving(false);
    }
  };

  const handleApplyTemplate = (templateId: HomepageTemplateId) => {
    const freshDoc = buildTemplateDocument(templateId, currentUsername);
    // Preserve assigned playlist if user already created one
    if (playlists[0]) {
      freshDoc.blocks = freshDoc.blocks.map((b) =>
        b.type === 'music_player' && !b.playlistId
          ? { ...b, playlistId: playlists[0].id }
          : b
      );
    }
    setDraftDoc(freshDoc);
    setSelectedBlockId(freshDoc.blocks[0]?.id || null);
    setStudioTab('editor');
    onToast(`Applied "${templateId.replace('_', ' ')}" template to your draft!`);
  };

  const handleUploadImages = async (
    files: FileList | null,
    kindOverride?: MediaAsset['kind'],
    applyTo?: 'banner' | 'background' | 'block' | 'track_cover' | 'playlist_cover'
  ) => {
    if (!files || files.length === 0) return;
    setUploadingImage(true);
    try {
      let lastAsset: MediaAsset | null = null;
      for (const file of Array.from(files)) {
        const res = await uploadImageAsset(file, currentUsername, kindOverride || uploadMediaKind);
        lastAsset = res.asset;
      }
      const mediaRes = await listMediaAssets(currentUsername);
      setMediaAssets(mediaRes.assets);
      setMediaBytes(mediaRes.totalBytes);
      setMediaQuota(mediaRes.quotaBytes);

      if (lastAsset) {
        if (applyTo === 'banner') updateTheme({ bannerImageUrl: lastAsset.url });
        if (applyTo === 'background') updateTheme({ bgImageUrl: lastAsset.url });
        if (applyTo === 'block' && selectedBlock) {
          updateBlock(selectedBlock.id, { imageUrl: lastAsset.url });
        }
        if (applyTo === 'track_cover') setMp3CoverInput(lastAsset.url);
        if (applyTo === 'playlist_cover') setNewPlCover(lastAsset.url);
      }
      onToast(`Uploaded ${files.length} image(s) to Media Library!`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Image upload failed.', 'error');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleDeleteImage = async (id: string) => {
    try {
      await deleteMediaAsset(id);
      const mediaRes = await listMediaAssets(currentUsername);
      setMediaAssets(mediaRes.assets);
      setMediaBytes(mediaRes.totalBytes);
      onToast('Deleted media file.');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Delete failed.', 'error');
    }
  };

  const handleUploadMp3Files = async (
    files: FileList | null,
    targetPlaylistId?: string
  ) => {
    if (!files || files.length === 0) return;
    if (!mp3RightsChecked) {
      onToast('Please confirm audio sharing permission checkbox before uploading songs.', 'error');
      return;
    }
    setUploadingAudio(true);
    try {
      const fileArr = Array.from(files);
      const uploadedIds: string[] = [];
      for (let i = 0; i < fileArr.length; i += 1) {
        const file = fileArr[i];
        const fallbackTitle = file.name.replace(/\.(mp3|wav|ogg|m4a|aac|webm)$/i, '');
        const res = await uploadAudioTrack(file, {
          username: currentUsername,
          title: fileArr.length === 1 && mp3TitleInput.trim() ? mp3TitleInput.trim() : fallbackTitle,
          artist: mp3ArtistInput.trim() || currentUsername,
          description: mp3DescInput.trim(),
          coverUrl: mp3CoverInput.trim(),
          rightsConfirmed: true,
        });
        uploadedIds.push(res.track.id);
      }
      if (targetPlaylistId && uploadedIds.length > 0) {
        const targetPl = playlists.find((p) => p.id === targetPlaylistId);
        if (targetPl) {
          await updatePlaylist(targetPl.id, {
            trackIds: Array.from(new Set([...targetPl.trackIds, ...uploadedIds])),
          });
        }
      }
      const [audioRes, plRes] = await Promise.all([
        listAudioTracks(currentUsername),
        listUserPlaylists(currentUsername, currentUsername),
      ]);
      setAudioTracks(audioRes.tracks);
      setAudioBytes(audioRes.totalBytes);
      setAudioQuota(audioRes.quotaBytes);
      setPlaylists(plRes.playlists);
      setMp3TitleInput('');
      setMp3DescInput('');
      onToast(
        targetPlaylistId
          ? `Uploaded ${fileArr.length} song(s) and added to playlist!`
          : `Uploaded ${fileArr.length} song(s) persistently!`
      );
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Audio upload failed.', 'error');
    } finally {
      setUploadingAudio(false);
    }
  };

  const handleSaveTrackEdit = async (trackId: string) => {
    try {
      await updateAudioTrack(trackId, trackEditForm);
      const [audioRes, plRes] = await Promise.all([
        listAudioTracks(currentUsername),
        listUserPlaylists(currentUsername, currentUsername),
      ]);
      setAudioTracks(audioRes.tracks);
      setPlaylists(plRes.playlists);
      setEditingTrackId(null);
      onToast('Track metadata updated!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Track update failed.', 'error');
    }
  };

  const handleDeleteTrack = async (trackId: string) => {
    try {
      await deleteAudioTrack(trackId);
      const [audioRes, plRes] = await Promise.all([
        listAudioTracks(currentUsername),
        listUserPlaylists(currentUsername, currentUsername),
      ]);
      setAudioTracks(audioRes.tracks);
      setAudioBytes(audioRes.totalBytes);
      setPlaylists(plRes.playlists);
      onToast('MP3 track deleted.');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Delete failed.', 'error');
    }
  };

  const handleCreatePlaylist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPlName.trim()) {
      onToast('Enter a playlist name.', 'error');
      return;
    }
    setCreatingPl(true);
    try {
      const res = await createPlaylist({
        ownerUsername: currentUsername,
        name: newPlName.trim(),
        description: newPlDesc.trim(),
        coverUrl: newPlCover.trim(),
        isPublic: newPlPublic,
        trackIds: newPlTrackIds,
      });
      const plRes = await listUserPlaylists(currentUsername, currentUsername);
      setPlaylists(plRes.playlists);
      setSelectedPlaylistId(res.playlist.id);
      setNewPlName('');
      setNewPlDesc('');
      setNewPlCover('');
      setNewPlTrackIds([]);
      onToast(`Playlist "${res.playlist.name}" created!`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Playlist creation failed.', 'error');
    } finally {
      setCreatingPl(false);
    }
  };

  const handlePatchPlaylist = async (
    plId: string,
    patch: {
      name?: string;
      description?: string;
      coverUrl?: string;
      isPublic?: boolean;
      trackIds?: string[];
    }
  ) => {
    try {
      await updatePlaylist(plId, patch);
      const plRes = await listUserPlaylists(currentUsername, currentUsername);
      setPlaylists(plRes.playlists);
      onToast('Playlist updated!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to update playlist.', 'error');
    }
  };

  const handleDeletePlaylist = async (plId: string) => {
    try {
      await deletePlaylist(plId);
      const plRes = await listUserPlaylists(currentUsername, currentUsername);
      setPlaylists(plRes.playlists);
      if (selectedPlaylistId === plId) {
        setSelectedPlaylistId(plRes.playlists[0]?.id || null);
      }
      onToast('Playlist removed.');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Delete playlist failed.', 'error');
    }
  };

  const assignPlaylistToHomepage = (plId: string) => {
    if (!draftDoc) return;
    const existingPlayer = draftDoc.blocks.find((b) => b.type === 'music_player');
    if (existingPlayer) {
      updateBlock(existingPlayer.id, { playlistId: plId });
      setSelectedBlockId(existingPlayer.id);
    } else {
      const id = `blk-${Date.now()}`;
      setDraftDoc({
        ...draftDoc,
        blocks: [
          ...draftDoc.blocks,
          {
            id,
            type: 'music_player',
            title: playlistsById[plId]?.name || 'My Music Player',
            playlistId: plId,
            playerConfig: createDefaultPlayerConfig('lavender_mini'),
          },
        ],
      });
      setSelectedBlockId(id);
    }
    setStudioTab('editor');
    setInspectorTab('block');
    onToast('Assigned playlist to your homepage music player!');
  };

  const copyShareUrl = (path: string) => {
    const full = `${window.location.origin}${path}`;
    navigator.clipboard?.writeText(full).catch(() => {});
    onToast(`Copied URL: ${path}`);
  };

  const publicUrlPath = `/user/${currentUsername}`;

  return (
    <div className="space-y-3">
      {/* MY HOMEPAGE Top Control & Publish Bar */}
      <div className="win-inset p-3 space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-pixel-ui text-xs sm:text-sm text-[#e6dcff]">
                MY HOMEPAGE BUILDER
              </span>
              <span
                className={`px-2 py-0.5 font-pixel-ui text-[10px] border ${
                  homepageRec?.isPublished
                    ? 'border-[#52ff94] text-[#52ff94] bg-[#0c2918]'
                    : 'border-[#c8b4f8] text-[#c8b4f8] bg-[#1a1128]'
                }`}
              >
                {homepageRec?.isPublished ? 'LIVE / PUBLISHED' : 'UNPUBLISHED DRAFT'}
              </span>
              <span className="text-xs text-[#a690d6]">
                VISITORS: {homepageRec?.visitorCount ?? 0}
              </span>
            </div>
            <div className="text-xs text-[#a690d6] mt-1 flex flex-wrap items-center gap-2">
              <span>PUBLIC URL:</span>
              <code className="bg-[#120c1c] border border-[#2a1746] px-1.5 py-0.5 text-[#52ff94]">
                {publicUrlPath}
              </code>
              <button
                type="button"
                onClick={() => copyShareUrl(publicUrlPath)}
                className="win-btn px-2 py-0.5 text-[10px]"
              >
                COPY URL
              </button>
              {homepageRec?.isPublished && (
                <button
                  type="button"
                  onClick={() => onOpenPublicUrl(publicUrlPath)}
                  className="win-btn px-2 py-0.5 text-[10px] text-[#52ff94]"
                >
                  OPEN LIVE SITE &gt;&gt;
                </button>
              )}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setIsPreviewMode((p) => !p)}
              className={`win-btn px-2.5 py-1 text-[11px] ${isPreviewMode ? 'active-tab' : ''}`}
            >
              {isPreviewMode ? 'EDIT MODE' : 'PREVIEW'}
            </button>
            <button
              type="button"
              onClick={handleSaveDraft}
              disabled={saving}
              className="win-btn px-2.5 py-1 text-[11px]"
            >
              {saving ? 'SAVING...' : 'SAVE DRAFT'}
            </button>
            <button
              type="button"
              onClick={handlePublish}
              disabled={saving}
              className="win-btn win-btn-primary px-3 py-1 text-[11px]"
            >
              {homepageRec?.isPublished ? 'UPDATE PUBLISHED' : 'PUBLISH SITE'}
            </button>
            {homepageRec?.isPublished && (
              <button
                type="button"
                onClick={handleUnpublish}
                disabled={saving}
                className="win-btn px-2.5 py-1 text-[11px] text-[#ff6bd6]"
              >
                UNPUBLISH
              </button>
            )}
            <button
              type="button"
              onClick={() => setShowDirectory((p) => !p)}
              className="win-btn px-2.5 py-1 text-[11px]"
            >
              SITES ({directory.length})
            </button>
          </div>
        </div>

        {/* Published Community Homepages Directory Drawer */}
        {showDirectory && (
          <div className="bg-[#120c1c] border border-[#7b42f6] p-2.5 space-y-2">
            <div className="font-pixel-ui text-[10px] text-[#c8b4f8]">
              PUBLISHED MEMBER HOMEPAGES ({directory.length})
            </div>
            {directory.length === 0 ? (
              <div className="text-xs text-[#a690d6]">
                No published member homepages yet. Publish yours to appear here!
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                {directory.map((item) => (
                  <button
                    key={item.username}
                    type="button"
                    onClick={() => onOpenPublicUrl(`/user/${item.username}`)}
                    className="win-btn p-2 text-left flex items-center justify-between gap-2"
                  >
                    <div className="min-w-0">
                      <div className="text-xs text-[#e6dcff] truncate">{item.pageTitle}</div>
                      <div className="text-[10px] text-[#52ff94]">/user/{item.username}</div>
                    </div>
                    <span className="text-[10px] text-[#c8b4f8] shrink-0">
                      {item.visitorCount} VISITS
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Studio Navigation Tabs */}
        <div className="flex flex-wrap gap-1.5 pt-1 border-t border-[#2a1746]">
          {[
            { id: 'editor' as StudioTab, label: '1. VISUAL EDITOR' },
            { id: 'templates' as StudioTab, label: '2. TEMPLATES (8)' },
            { id: 'media' as StudioTab, label: `3. MEDIA LIBRARY (${mediaAssets.length})` },
            { id: 'music' as StudioTab, label: `4. MUSIC / MP3 (${audioTracks.length})` },
            { id: 'playlists' as StudioTab, label: `5. PLAYLISTS (${playlists.length})` },
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setStudioTab(tab.id)}
              className={`win-btn px-2.5 py-1 text-[11px] ${
                studioTab === tab.id ? 'win-btn-primary' : ''
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* TAB 1: VISUAL DRAG-AND-DROP WEBSITE EDITOR */}
      {studioTab === 'editor' && draftDoc && (
        <div className="space-y-3">
          {/* Block Palette */}
          {!isPreviewMode && (
            <div className="win-inset p-2.5">
              <div className="font-pixel-ui text-[10px] text-[#c8b4f8] mb-2">
                + ADD SECTION / WIDGET (DRAG BLOCKS BELOW TO REORDER):
              </div>
              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    ['heading', '+ HEADING'],
                    ['text', '+ TEXT BLOCK'],
                    ['image', '+ IMAGE / GIF'],
                    ['button_link', '+ BUTTON / LINK'],
                    ['two_column', '+ 2 COLUMNS'],
                    ['sticker_divider', '+ STICKER & MARQUEE'],
                    ['music_player', '+ MUSIC PLAYER'],
                    ['guestbook_counter', '+ GUESTBOOK / COUNTER'],
                  ] as [HomepageBlockType, string][]
                ).map(([type, label]) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => addBlock(type)}
                    className="win-btn px-2 py-1 text-[10px]"
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Customization Panel (Collapsible tabs: Page Style vs Selected Block) */}
          {!isPreviewMode && (
            <div className="win-box p-3 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a1746] pb-2">
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => setInspectorTab('page')}
                    className={`win-btn px-2.5 py-1 text-[10px] ${
                      inspectorTab === 'page' ? 'win-btn-primary' : ''
                    }`}
                  >
                    PAGE CUSTOMIZATION
                  </button>
                  <button
                    type="button"
                    onClick={() => setInspectorTab('block')}
                    className={`win-btn px-2.5 py-1 text-[10px] ${
                      inspectorTab === 'block' ? 'win-btn-primary' : ''
                    }`}
                  >
                    BLOCK INSPECTOR {selectedBlock ? `[${selectedBlock.type}]` : ''}
                  </button>
                </div>
                <span className="text-xs text-[#a690d6]">
                  Live preview updates automatically below
                </span>
              </div>

              {inspectorTab === 'page' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
                  <div>
                    <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                      PAGE TITLE
                    </label>
                    <input
                      type="text"
                      value={draftDoc.theme.pageTitle}
                      onChange={(e) => updateTheme({ pageTitle: e.target.value })}
                      className="w-full win-inset px-2 py-1 text-white"
                    />
                  </div>
                  <div>
                    <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                      PAGE DESCRIPTION
                    </label>
                    <input
                      type="text"
                      value={draftDoc.theme.pageDescription}
                      onChange={(e) => updateTheme({ pageDescription: e.target.value })}
                      className="w-full win-inset px-2 py-1 text-white"
                    />
                  </div>

                  <div>
                    <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                      FONT FAMILY
                    </label>
                    <select
                      value={draftDoc.theme.fontFamily}
                      onChange={(e) =>
                        updateTheme({ fontFamily: e.target.value as HomepageFontFamily })
                      }
                      className="w-full win-inset px-2 py-1 text-white"
                    >
                      <option value="vt323">VT323 (Retro Terminal)</option>
                      <option value="silkscreen">Silkscreen (Pixel Art)</option>
                      <option value="courier">Courier New (Classic Mono)</option>
                      <option value="verdana">Verdana (2000s Web)</option>
                      <option value="georgia">Georgia (Editorial Diary)</option>
                      <option value="comic">Comic Sans (Geocities Cute)</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                      GLITTER &amp; SPARKLE EFFECT
                    </label>
                    <select
                      value={draftDoc.theme.glitterEffect}
                      onChange={(e) =>
                        updateTheme({
                          glitterEffect: e.target.value as HomepageDocument['theme']['glitterEffect'],
                        })
                      }
                      className="w-full win-inset px-2 py-1 text-white"
                    >
                      <option value="none">None</option>
                      <option value="silver_twinkle">Silver Twinkle Stars</option>
                      <option value="pink_glitter">Glitter Pink Sparkle</option>
                      <option value="lavender_stars">Lavender &amp; Mint Stars</option>
                      <option value="cyber_grid">Cyber Matrix Grid</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                        PAGE WIDTH
                      </label>
                      <select
                        value={draftDoc.theme.pageWidth}
                        onChange={(e) =>
                          updateTheme({
                            pageWidth: e.target.value as HomepageDocument['theme']['pageWidth'],
                          })
                        }
                        className="w-full win-inset px-2 py-1 text-white"
                      >
                        <option value="680px">680px (Diary)</option>
                        <option value="820px">820px (Classic)</option>
                        <option value="980px">980px (Wide)</option>
                        <option value="100%">100% (Full)</option>
                      </select>
                    </div>
                    <div>
                      <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                        BORDER STYLE
                      </label>
                      <select
                        value={draftDoc.theme.borderStyle}
                        onChange={(e) =>
                          updateTheme({ borderStyle: e.target.value as HomepageBorderStyle })
                        }
                        className="w-full win-inset px-2 py-1 text-white"
                      >
                        <option value="solid">Solid</option>
                        <option value="dashed">Dashed</option>
                        <option value="dotted">Dotted</option>
                        <option value="double">Double</option>
                        <option value="ridge">Ridge (3D)</option>
                        <option value="outset">Outset (Win98)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-5 gap-2">
                    <div>
                      <label className="text-[10px] block text-[#c8b4f8]">BG</label>
                      <input
                        type="color"
                        value={draftDoc.theme.bgColor}
                        onChange={(e) => updateTheme({ bgColor: e.target.value })}
                        className="w-full h-8 cursor-pointer bg-transparent"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] block text-[#c8b4f8]">HEAD</label>
                      <input
                        type="color"
                        value={draftDoc.theme.headingColor}
                        onChange={(e) => updateTheme({ headingColor: e.target.value })}
                        className="w-full h-8 cursor-pointer bg-transparent"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] block text-[#c8b4f8]">TEXT</label>
                      <input
                        type="color"
                        value={draftDoc.theme.textColor}
                        onChange={(e) => updateTheme({ textColor: e.target.value })}
                        className="w-full h-8 cursor-pointer bg-transparent"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] block text-[#c8b4f8]">LINK</label>
                      <input
                        type="color"
                        value={draftDoc.theme.linkColor}
                        onChange={(e) => updateTheme({ linkColor: e.target.value })}
                        className="w-full h-8 cursor-pointer bg-transparent"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] block text-[#c8b4f8]">BORDER</label>
                      <input
                        type="color"
                        value={draftDoc.theme.borderColor}
                        onChange={(e) => updateTheme({ borderColor: e.target.value })}
                        className="w-full h-8 cursor-pointer bg-transparent"
                      />
                    </div>
                  </div>

                  {/* Background Image Picker / Uploader */}
                  <div className="space-y-1">
                    <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block">
                      BACKGROUND IMAGE (PNG/JPG/GIF/WEBP)
                    </label>
                    <div className="flex gap-1.5">
                      <select
                        value={draftDoc.theme.bgImageUrl}
                        onChange={(e) => updateTheme({ bgImageUrl: e.target.value })}
                        className="flex-1 win-inset px-2 py-1 text-white text-xs"
                      >
                        <option value="">-- No Background Image --</option>
                        {mediaAssets.map((a) => (
                          <option key={a.id} value={a.url}>
                            {a.filename}
                          </option>
                        ))}
                      </select>
                      <select
                        value={draftDoc.theme.bgRepeat}
                        onChange={(e) =>
                          updateTheme({
                            bgRepeat: e.target.value as HomepageDocument['theme']['bgRepeat'],
                          })
                        }
                        className="win-inset px-2 py-1 text-white text-xs"
                      >
                        <option value="repeat">Tile</option>
                        <option value="cover">Cover</option>
                        <option value="no-repeat">Center</option>
                      </select>
                    </div>
                    <label className="win-btn px-2 py-0.5 text-[10px] inline-block cursor-pointer">
                      UPLOAD BG IMAGE
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/gif,image/webp"
                        className="hidden"
                        onChange={(e) => handleUploadImages(e.target.files, 'background', 'background')}
                      />
                    </label>
                  </div>

                  {/* Banner Image Picker / Uploader + Dimensions */}
                  <div className="space-y-1">
                    <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block">
                      BANNER IMAGE &amp; HEIGHT ({draftDoc.theme.bannerHeight}px)
                    </label>
                    <div className="flex gap-1.5">
                      <select
                        value={draftDoc.theme.bannerImageUrl}
                        onChange={(e) => updateTheme({ bannerImageUrl: e.target.value })}
                        className="flex-1 win-inset px-2 py-1 text-white text-xs"
                      >
                        <option value="">-- No Banner --</option>
                        {mediaAssets.map((a) => (
                          <option key={a.id} value={a.url}>
                            {a.filename}
                          </option>
                        ))}
                      </select>
                      <select
                        value={draftDoc.theme.bannerFit}
                        onChange={(e) =>
                          updateTheme({
                            bannerFit: e.target.value as HomepageDocument['theme']['bannerFit'],
                          })
                        }
                        className="win-inset px-2 py-1 text-white text-xs"
                      >
                        <option value="cover">Cover</option>
                        <option value="contain">Contain</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-2">
                      <label className="win-btn px-2 py-0.5 text-[10px] inline-block cursor-pointer shrink-0">
                        UPLOAD BANNER
                        <input
                          type="file"
                          accept="image/png,image/jpeg,image/gif,image/webp"
                          className="hidden"
                          onChange={(e) => handleUploadImages(e.target.files, 'banner', 'banner')}
                        />
                      </label>
                      <input
                        type="range"
                        min={70}
                        max={320}
                        value={draftDoc.theme.bannerHeight}
                        onChange={(e) => updateTheme({ bannerHeight: Number(e.target.value) })}
                        className="flex-1"
                      />
                    </div>
                  </div>

                  {/* Margins & Spacing Sliders */}
                  <div className="sm:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                    <div>
                      <label className="text-xs text-[#c8b4f8] block">
                        PAGE MARGIN/PADDING: {draftDoc.theme.containerPadding}px
                      </label>
                      <input
                        type="range"
                        min={8}
                        max={44}
                        value={draftDoc.theme.containerPadding}
                        onChange={(e) =>
                          updateTheme({ containerPadding: Number(e.target.value) })
                        }
                        className="w-full"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-[#c8b4f8] block">
                        SECTION SPACING: {draftDoc.theme.sectionGap}px
                      </label>
                      <input
                        type="range"
                        min={6}
                        max={36}
                        value={draftDoc.theme.sectionGap}
                        onChange={(e) => updateTheme({ sectionGap: Number(e.target.value) })}
                        className="w-full"
                      />
                    </div>
                    <div>
                      <label className="text-xs text-[#c8b4f8] block">
                        BORDER WIDTH: {draftDoc.theme.borderWidth}px
                      </label>
                      <input
                        type="range"
                        min={1}
                        max={8}
                        value={draftDoc.theme.borderWidth}
                        onChange={(e) => updateTheme({ borderWidth: Number(e.target.value) })}
                        className="w-full"
                      />
                    </div>
                  </div>
                </div>
              ) : !selectedBlock ? (
                <div className="text-sm text-[#a690d6]">
                  Click any block in the live preview canvas below to edit its content or style.
                </div>
              ) : (
                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="font-pixel-ui text-xs text-[#52ff94]">
                      EDITING BLOCK: {selectedBlock.type.toUpperCase()}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDeleteBlock(selectedBlock.id)}
                      className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
                    >
                      REMOVE BLOCK
                    </button>
                  </div>

                  {(selectedBlock.type === 'heading' ||
                    selectedBlock.type === 'text' ||
                    selectedBlock.type === 'two_column' ||
                    selectedBlock.type === 'guestbook_counter' ||
                    selectedBlock.type === 'music_player') && (
                    <div>
                      <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                        TITLE / HEADING
                      </label>
                      <input
                        type="text"
                        value={selectedBlock.title || ''}
                        onChange={(e) =>
                          updateBlock(selectedBlock.id, { title: e.target.value })
                        }
                        className="w-full win-inset px-2 py-1 text-white"
                      />
                    </div>
                  )}

                  {(selectedBlock.type === 'heading' ||
                    selectedBlock.type === 'text' ||
                    selectedBlock.type === 'two_column') && (
                    <div>
                      <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                        CONTENT TEXT
                      </label>
                      <textarea
                        rows={3}
                        value={selectedBlock.content || ''}
                        onChange={(e) =>
                          updateBlock(selectedBlock.id, { content: e.target.value })
                        }
                        className="w-full win-inset px-2 py-1 text-white"
                      />
                    </div>
                  )}

                  {selectedBlock.type === 'two_column' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                          RIGHT COLUMN TITLE
                        </label>
                        <input
                          type="text"
                          value={selectedBlock.secondaryTitle || ''}
                          onChange={(e) =>
                            updateBlock(selectedBlock.id, { secondaryTitle: e.target.value })
                          }
                          className="w-full win-inset px-2 py-1 text-white"
                        />
                      </div>
                      <div>
                        <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                          RIGHT COLUMN CONTENT
                        </label>
                        <textarea
                          rows={2}
                          value={selectedBlock.secondaryContent || ''}
                          onChange={(e) =>
                            updateBlock(selectedBlock.id, { secondaryContent: e.target.value })
                          }
                          className="w-full win-inset px-2 py-1 text-white"
                        />
                      </div>
                    </div>
                  )}

                  {selectedBlock.type === 'image' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                          PICK IMAGE FROM MEDIA LIBRARY
                        </label>
                        <select
                          value={selectedBlock.imageUrl || ''}
                          onChange={(e) =>
                            updateBlock(selectedBlock.id, { imageUrl: e.target.value })
                          }
                          className="w-full win-inset px-2 py-1 text-white text-xs"
                        >
                          <option value="">-- Select uploaded image --</option>
                          {mediaAssets.map((a) => (
                            <option key={a.id} value={a.url}>
                              {a.filename}
                            </option>
                          ))}
                        </select>
                        <label className="win-btn px-2 py-0.5 text-[10px] mt-1 inline-block cursor-pointer">
                          UPLOAD PNG/JPG/GIF/WEBP
                          <input
                            type="file"
                            accept="image/png,image/jpeg,image/gif,image/webp"
                            className="hidden"
                            onChange={(e) => handleUploadImages(e.target.files, 'image', 'block')}
                          />
                        </label>
                      </div>
                      <div className="space-y-1.5">
                        <div>
                          <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block">
                            WIDTH (e.g. 100%, 320px)
                          </label>
                          <input
                            type="text"
                            value={selectedBlock.imageWidth || '100%'}
                            onChange={(e) =>
                              updateBlock(selectedBlock.id, { imageWidth: e.target.value })
                            }
                            className="w-full win-inset px-2 py-1 text-white"
                          />
                        </div>
                        <div>
                          <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block">
                            CAPTION
                          </label>
                          <input
                            type="text"
                            value={selectedBlock.imageCaption || ''}
                            onChange={(e) =>
                              updateBlock(selectedBlock.id, { imageCaption: e.target.value })
                            }
                            className="w-full win-inset px-2 py-1 text-white"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedBlock.type === 'button_link' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block">
                          BUTTON LABEL
                        </label>
                        <input
                          type="text"
                          value={selectedBlock.linkLabel || ''}
                          onChange={(e) =>
                            updateBlock(selectedBlock.id, { linkLabel: e.target.value })
                          }
                          className="w-full win-inset px-2 py-1 text-white"
                        />
                      </div>
                      <div>
                        <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block">
                          LINK URL (/user/name or https://...)
                        </label>
                        <input
                          type="text"
                          value={selectedBlock.linkUrl || ''}
                          onChange={(e) =>
                            updateBlock(selectedBlock.id, { linkUrl: e.target.value })
                          }
                          className="w-full win-inset px-2 py-1 text-white"
                        />
                      </div>
                      <div className="flex gap-3">
                        <div>
                          <label className="text-[10px] block text-[#c8b4f8]">BTN BG</label>
                          <input
                            type="color"
                            value={selectedBlock.buttonBg || '#7b42f6'}
                            onChange={(e) =>
                              updateBlock(selectedBlock.id, { buttonBg: e.target.value })
                            }
                          />
                        </div>
                        <div>
                          <label className="text-[10px] block text-[#c8b4f8]">BTN TEXT</label>
                          <input
                            type="color"
                            value={selectedBlock.buttonText || '#ffffff'}
                            onChange={(e) =>
                              updateBlock(selectedBlock.id, { buttonText: e.target.value })
                            }
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {selectedBlock.type === 'sticker_divider' && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div>
                        <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                          DECORATIVE PIXEL STICKER
                        </label>
                        <select
                          value={selectedBlock.stickerId || 'sparkle_stars'}
                          onChange={(e) =>
                            updateBlock(selectedBlock.id, {
                              stickerId: e.target.value as StickerIconId,
                            })
                          }
                          className="w-full win-inset px-2 py-1 text-white"
                        >
                          <option value="sparkle_stars">Sparkle Stars</option>
                          <option value="pixel_heart">Pixel Heart</option>
                          <option value="under_construction">Under Construction</option>
                          <option value="cyber_butterfly">Cyber Butterfly</option>
                          <option value="music_note">Music Note</option>
                          <option value="retro_cd">Retro Compact Disc</option>
                        </select>
                      </div>
                      <div>
                        <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                          SCROLLING MARQUEE TEXT
                        </label>
                        <input
                          type="text"
                          value={selectedBlock.marqueeText || ''}
                          onChange={(e) =>
                            updateBlock(selectedBlock.id, { marqueeText: e.target.value })
                          }
                          className="w-full win-inset px-2 py-1 text-white"
                        />
                      </div>
                    </div>
                  )}

                  {selectedBlock.type === 'music_player' && (() => {
                    const pCfg =
                      selectedBlock.playerConfig || createDefaultPlayerConfig('lavender_mini');
                    const patchPlayer = (patch: Partial<typeof pCfg>) =>
                      updateBlock(selectedBlock.id, {
                        playerConfig: { ...pCfg, ...patch },
                      });
                    return (
                      <div className="space-y-2.5 bg-[#120c1c] p-2.5 border border-[#7b42f6]">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <div>
                            <label className="font-pixel-ui text-[10px] text-[#52ff94] block mb-1">
                              ASSIGN PLAYLIST
                            </label>
                            <select
                              value={selectedBlock.playlistId || ''}
                              onChange={(e) =>
                                updateBlock(selectedBlock.id, { playlistId: e.target.value })
                              }
                              className="w-full win-inset px-2 py-1 text-white"
                            >
                              <option value="">-- Select a Playlist --</option>
                              {playlists.map((pl) => (
                                <option key={pl.id} value={pl.id}>
                                  {pl.name} ({pl.trackIds.length} tracks)
                                </option>
                              ))}
                            </select>
                          </div>
                          <div>
                            <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block mb-1">
                              PLAYER SKIN PRESET
                            </label>
                            <select
                              value={pCfg.skin}
                              onChange={(e) => {
                                const skin = e.target.value as PlayerSkinId;
                                const preset = PLAYER_SKIN_PRESETS[skin].config;
                                updateBlock(selectedBlock.id, {
                                  playerConfig: { ...pCfg, ...preset },
                                });
                              }}
                              className="w-full win-inset px-2 py-1 text-white"
                            >
                              {Object.entries(PLAYER_SKIN_PRESETS).map(([k, v]) => (
                                <option key={k} value={k}>
                                  {v.label}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 items-end">
                          <div>
                            <label className="text-[10px] block text-[#c8b4f8]">BG</label>
                            <input
                              type="color"
                              value={pCfg.bgColor}
                              onChange={(e) => patchPlayer({ bgColor: e.target.value })}
                              className="w-full h-7"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] block text-[#c8b4f8]">BORDER</label>
                            <input
                              type="color"
                              value={pCfg.borderColor}
                              onChange={(e) => patchPlayer({ borderColor: e.target.value })}
                              className="w-full h-7"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] block text-[#c8b4f8]">BTN BG</label>
                            <input
                              type="color"
                              value={pCfg.buttonBg}
                              onChange={(e) => patchPlayer({ buttonBg: e.target.value })}
                              className="w-full h-7"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] block text-[#c8b4f8]">TEXT</label>
                            <input
                              type="color"
                              value={pCfg.textColor}
                              onChange={(e) => patchPlayer({ textColor: e.target.value })}
                              className="w-full h-7"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] block text-[#c8b4f8]">ACCENT</label>
                            <input
                              type="color"
                              value={pCfg.accentColor}
                              onChange={(e) => patchPlayer({ accentColor: e.target.value })}
                              className="w-full h-7"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] block text-[#c8b4f8]">WIDTH</label>
                            <select
                              value={pCfg.width}
                              onChange={(e) =>
                                patchPlayer({
                                  width: e.target.value as typeof pCfg.width,
                                })
                              }
                              className="w-full win-inset px-1 py-1 text-xs text-white"
                            >
                              <option value="280px">280px</option>
                              <option value="360px">360px</option>
                              <option value="100%">100%</option>
                            </select>
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-4 text-xs">
                          <label className="flex items-center gap-1.5 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={pCfg.glitterOverlay}
                              onChange={(e) =>
                                patchPlayer({ glitterOverlay: e.target.checked })
                              }
                            />
                            <span>Glitter Overlay</span>
                          </label>
                          <label className="flex items-center gap-1.5 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={pCfg.pixelIcons}
                              onChange={(e) => patchPlayer({ pixelIcons: e.target.checked })}
                            />
                            <span>Pixel-Art Theme Icons</span>
                          </label>
                        </div>
                      </div>
                    );
                  })()}
                </div>
              )}
            </div>
          )}

          {/* LIVE DRAG-AND-DROP CANVAS */}
          <div className="win-box overflow-hidden">
            <div className="win-titlebar">
              <span className="font-pixel-ui text-xs text-white">
                {isPreviewMode ? 'LIVE PREVIEW' : 'DRAG-AND-DROP HOMEPAGE CANVAS'}
              </span>
              <span className="font-pixel-ui text-[10px] text-[#c8b4f8]">
                {draftDoc.blocks.length} BLOCKS
              </span>
            </div>
            <HomepageRenderer
              document={draftDoc}
              username={currentUsername}
              playlistsById={playlistsById}
              visitorCount={homepageRec?.visitorCount ?? 0}
              guestbook={guestbook}
              currentViewerUsername={currentUsername}
              editMode={!isPreviewMode}
              selectedBlockId={selectedBlockId}
              onSelectBlock={(id) => {
                setSelectedBlockId(id);
                setInspectorTab('block');
              }}
              onDragStartBlock={setDraggedBlockId}
              onDropOnBlock={handleDropOnBlock}
              onMoveBlock={handleMoveBlock}
              onDeleteBlock={handleDeleteBlock}
            />
          </div>
        </div>
      )}

      {/* TAB 2: 8 EDITABLE TEMPLATES */}
      {studioTab === 'templates' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {HOMEPAGE_TEMPLATE_LIST.map((tpl) => (
            <div key={tpl.id} className="win-box p-3 flex flex-col justify-between gap-2.5">
              <div>
                <div
                  className="h-14 border-2 mb-2 p-2 flex items-center justify-between"
                  style={{
                    backgroundColor: tpl.previewBg,
                    borderColor: tpl.previewAccent,
                  }}
                >
                  <span
                    className="font-pixel-ui text-xs font-bold"
                    style={{ color: tpl.previewAccent }}
                  >
                    {tpl.name}
                  </span>
                  <span
                    className="w-4 h-4 inline-block border border-white"
                    style={{ backgroundColor: tpl.previewAccent }}
                  />
                </div>
                <p className="text-sm text-[#c8b4f8]">{tpl.tagline}</p>
              </div>
              <button
                type="button"
                onClick={() => handleApplyTemplate(tpl.id)}
                className="win-btn win-btn-primary py-1.5 text-xs"
              >
                APPLY &amp; CUSTOMIZE TEMPLATE
              </button>
            </div>
          ))}
        </div>
      )}

      {/* TAB 3: PERSONAL MEDIA LIBRARY */}
      {studioTab === 'media' && (
        <div className="space-y-3">
          <div className="win-box p-3 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="font-pixel-ui text-xs text-[#e6dcff]">
                UPLOAD PNG / JPG / GIF / WEBP TO MEDIA LIBRARY
              </div>
              <div className="text-xs text-[#52ff94] tabular-nums">
                STORAGE: {formatBytes(mediaBytes)} / {formatBytes(mediaQuota)}
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <select
                value={uploadMediaKind}
                onChange={(e) => setUploadMediaKind(e.target.value as MediaAsset['kind'])}
                className="win-inset px-2 py-1 text-xs text-white"
              >
                <option value="image">General Image / GIF</option>
                <option value="banner">Banner Graphic</option>
                <option value="background">Background Texture</option>
                <option value="sticker">Sticker / Pixel Art</option>
                <option value="cover">Album / Playlist Cover</option>
              </select>
              <label className="win-btn win-btn-primary px-3 py-1.5 text-xs cursor-pointer">
                {uploadingImage ? 'UPLOADING...' : '+ CHOOSE FILES (PNG/JPG/GIF/WEBP)'}
                <input
                  type="file"
                  multiple
                  accept="image/png,image/jpeg,image/gif,image/webp"
                  disabled={uploadingImage}
                  className="hidden"
                  onChange={(e) => handleUploadImages(e.target.files)}
                />
              </label>
            </div>
          </div>

          {mediaAssets.length === 0 ? (
            <div className="win-inset p-6 text-center text-[#a690d6]">
              No uploaded graphics yet. Upload PNGs, JPGs, animated GIFs, or WEBPs to reuse across your homepage, banners, backgrounds, and album covers!
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              {mediaAssets.map((asset) => (
                <div key={asset.id} className="win-box p-2 flex flex-col gap-2">
                  <div className="h-28 bg-[#09060e] border border-[#2a1746] flex items-center justify-center overflow-hidden">
                    <img
                      src={asset.url}
                      alt={asset.filename}
                      className="max-h-full max-w-full object-contain"
                    />
                  </div>
                  <div className="text-xs truncate text-[#e6dcff]" title={asset.filename}>
                    {asset.filename}
                  </div>
                  <div className="text-[10px] text-[#a690d6]">
                    {asset.kind.toUpperCase()} · {formatBytes(asset.sizeBytes)}
                  </div>
                  <div className="flex flex-wrap gap-1">
                    <button
                      type="button"
                      onClick={() => {
                        updateTheme({ bannerImageUrl: asset.url });
                        onToast('Applied as Homepage Banner!');
                      }}
                      className="win-btn px-1.5 py-0.5 text-[9px]"
                    >
                      BANNER
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateTheme({ bgImageUrl: asset.url });
                        onToast('Applied as Homepage Background!');
                      }}
                      className="win-btn px-1.5 py-0.5 text-[9px]"
                    >
                      BG
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        if (!draftDoc) return;
                        const id = `blk-${Date.now()}`;
                        setDraftDoc({
                          ...draftDoc,
                          blocks: [
                            ...draftDoc.blocks,
                            {
                              id,
                              type: 'image',
                              imageUrl: asset.url,
                              imageWidth: '100%',
                              imageCaption: asset.filename,
                              align: 'center',
                            },
                          ],
                        });
                        setStudioTab('editor');
                        onToast('Inserted image block into homepage!');
                      }}
                      className="win-btn px-1.5 py-0.5 text-[9px] text-[#52ff94]"
                    >
                      +BLOCK
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteImage(asset.id)}
                      className="win-btn px-1.5 py-0.5 text-[9px] text-[#ff6bd6]"
                    >
                      DEL
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: PERSONAL MUSIC LIBRARY & MP3 UPLOAD */}
      {studioTab === 'music' && (
        <div className="space-y-3">
          <div className="win-box p-3 space-y-2.5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="font-pixel-ui text-xs text-[#e6dcff]">
                UPLOAD MP3 AUDIO TRACKS (PERSISTENT STORAGE)
              </div>
              <div className="text-xs text-[#52ff94] tabular-nums">
                AUDIO QUOTA: {formatBytes(audioBytes)} / {formatBytes(audioQuota)}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
              <input
                type="text"
                value={mp3TitleInput}
                onChange={(e) => setMp3TitleInput(e.target.value)}
                placeholder="Song title (single file, else uses filename)"
                className="win-inset px-2 py-1 text-white"
              />
              <input
                type="text"
                value={mp3ArtistInput}
                onChange={(e) => setMp3ArtistInput(e.target.value)}
                placeholder={`Artist name (default: ${currentUsername})`}
                className="win-inset px-2 py-1 text-white"
              />
              <input
                type="text"
                value={mp3DescInput}
                onChange={(e) => setMp3DescInput(e.target.value)}
                placeholder="Track description / liner notes (optional)"
                className="win-inset px-2 py-1 text-white"
              />
              <div className="flex gap-1.5">
                <select
                  value={mp3CoverInput}
                  onChange={(e) => setMp3CoverInput(e.target.value)}
                  className="flex-1 win-inset px-2 py-1 text-white text-xs"
                >
                  <option value="">-- Optional Album Cover --</option>
                  {mediaAssets.map((a) => (
                    <option key={a.id} value={a.url}>
                      {a.filename}
                    </option>
                  ))}
                </select>
                <label className="win-btn px-2 py-1 text-[10px] cursor-pointer shrink-0">
                  +COVER
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/gif,image/webp"
                    className="hidden"
                    onChange={(e) => handleUploadImages(e.target.files, 'cover', 'track_cover')}
                  />
                </label>
              </div>
            </div>

            <label className="flex items-start gap-2 text-xs text-[#c8b4f8] bg-[#120c1c] p-2 border border-[#2a1746] cursor-pointer">
              <input
                type="checkbox"
                checked={mp3RightsChecked}
                onChange={(e) => setMp3RightsChecked(e.target.checked)}
                className="mt-0.5"
              />
              <span>
                I confirm that I own or have permission to upload and share these MP3 audio files on my LOSTROOM.BXE personal homepage and playlists.
              </span>
            </label>

            <label className="win-btn win-btn-primary px-3 py-1.5 text-xs inline-block cursor-pointer">
              {uploadingAudio ? 'UPLOADING AUDIO...' : '+ SELECT AUDIO FILE(S) TO UPLOAD'}
              <input
                type="file"
                multiple
                accept=".mp3,.wav,.ogg,.m4a,.aac,.webm,audio/*"
                disabled={uploadingAudio}
                className="hidden"
                onChange={(e) => {
                  handleUploadMp3Files(e.target.files);
                  e.target.value = '';
                }}
              />
            </label>
          </div>

          {/* Track List */}
          {audioTracks.length === 0 ? (
            <div className="win-inset p-6 text-center text-[#a690d6]">
              Your MP3 library is empty. Upload MP3 files above to build playlists and play music on your homepage!
            </div>
          ) : (
            <div className="space-y-2.5">
              {audioTracks.map((trk) => {
                const isEditing = editingTrackId === trk.id;
                return (
                  <div key={trk.id} className="win-box p-3 space-y-2">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-12 h-12 bg-[#09060e] border border-[#7b42f6] shrink-0 overflow-hidden flex items-center justify-center">
                          {trk.coverUrl ? (
                            <img
                              src={trk.coverUrl}
                              alt={trk.title}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <span className="font-pixel-ui text-[10px] text-[#52ff94]">MP3</span>
                          )}
                        </div>
                        <div className="min-w-0">
                          <div className="font-pixel-ui text-xs text-[#e6dcff] truncate">
                            {trk.title}
                          </div>
                          <div className="text-sm text-[#c8b4f8] truncate">
                            {trk.artist} · {formatBytes(trk.sizeBytes)}
                          </div>
                          {trk.description && (
                            <div className="text-xs text-[#a690d6] truncate">
                              {trk.description}
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            if (isEditing) {
                              setEditingTrackId(null);
                            } else {
                              setEditingTrackId(trk.id);
                              setTrackEditForm({
                                title: trk.title,
                                artist: trk.artist,
                                description: trk.description,
                                coverUrl: trk.coverUrl,
                              });
                            }
                          }}
                          className="win-btn px-2 py-1 text-[10px]"
                        >
                          {isEditing ? 'CANCEL' : 'EDIT INFO'}
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteTrack(trk.id)}
                          className="win-btn px-2 py-1 text-[10px] text-[#ff6bd6]"
                        >
                          DELETE
                        </button>
                      </div>
                    </div>

                    <audio controls src={trk.url} className="w-full h-8" preload="none" />

                    {isEditing && (
                      <div className="bg-[#120c1c] p-2.5 border border-[#7b42f6] space-y-2 text-sm">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          <input
                            type="text"
                            value={trackEditForm.title}
                            onChange={(e) =>
                              setTrackEditForm((f) => ({ ...f, title: e.target.value }))
                            }
                            placeholder="Title"
                            className="win-inset px-2 py-1 text-white"
                          />
                          <input
                            type="text"
                            value={trackEditForm.artist}
                            onChange={(e) =>
                              setTrackEditForm((f) => ({ ...f, artist: e.target.value }))
                            }
                            placeholder="Artist"
                            className="win-inset px-2 py-1 text-white"
                          />
                          <input
                            type="text"
                            value={trackEditForm.description}
                            onChange={(e) =>
                              setTrackEditForm((f) => ({ ...f, description: e.target.value }))
                            }
                            placeholder="Description"
                            className="win-inset px-2 py-1 text-white"
                          />
                          <select
                            value={trackEditForm.coverUrl}
                            onChange={(e) =>
                              setTrackEditForm((f) => ({ ...f, coverUrl: e.target.value }))
                            }
                            className="win-inset px-2 py-1 text-white text-xs"
                          >
                            <option value="">-- No Cover Image --</option>
                            {mediaAssets.map((a) => (
                              <option key={a.id} value={a.url}>
                                {a.filename}
                              </option>
                            ))}
                          </select>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleSaveTrackEdit(trk.id)}
                          className="win-btn win-btn-primary px-3 py-1 text-xs"
                        >
                          SAVE TRACK DETAILS
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 5: PLAYLIST CREATOR */}
      {studioTab === 'playlists' && (
        <div className="space-y-3">
          <form onSubmit={handleCreatePlaylist} className="win-box p-3 space-y-2.5">
            <div className="font-pixel-ui text-xs text-[#e6dcff]">
              CREATE NEW PLAYLIST
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
              <input
                type="text"
                value={newPlName}
                onChange={(e) => setNewPlName(e.target.value)}
                placeholder="Playlist name (e.g. Midnight Cyber Mix)"
                className="win-inset px-2 py-1 text-white"
              />
              <input
                type="text"
                value={newPlDesc}
                onChange={(e) => setNewPlDesc(e.target.value)}
                placeholder="Short description"
                className="win-inset px-2 py-1 text-white"
              />
              <div className="flex gap-1.5">
                <select
                  value={newPlCover}
                  onChange={(e) => setNewPlCover(e.target.value)}
                  className="flex-1 win-inset px-2 py-1 text-white text-xs"
                >
                  <option value="">-- Optional Playlist Cover --</option>
                  {mediaAssets.map((a) => (
                    <option key={a.id} value={a.url}>
                      {a.filename}
                    </option>
                  ))}
                </select>
                <label className="win-btn px-2 py-1 text-[10px] cursor-pointer shrink-0">
                  +COVER
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/gif,image/webp"
                    className="hidden"
                    onChange={(e) =>
                      handleUploadImages(e.target.files, 'cover', 'playlist_cover')
                    }
                  />
                </label>
              </div>
              <label className="flex items-center gap-2 text-xs text-[#c8b4f8] px-1 cursor-pointer">
                <input
                  type="checkbox"
                  checked={newPlPublic}
                  onChange={(e) => setNewPlPublic(e.target.checked)}
                />
                <span>Public playlist (discoverable &amp; shareable at /playlist/...)</span>
              </label>
            </div>
            {audioTracks.length > 0 && (
              <div className="bg-[#120c1c] border border-[#2a1746] p-2 space-y-1">
                <div className="text-[11px] text-[#c8b4f8]">
                  Include songs ({newPlTrackIds.length} selected):
                </div>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
                  {audioTracks.map((trk) => {
                    const checked = newPlTrackIds.includes(trk.id);
                    return (
                      <label
                        key={trk.id}
                        className="flex items-center gap-1.5 text-xs text-[#e6dcff] bg-[#1a102b] border border-[#4e2d82] px-2 py-0.5 cursor-pointer"
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() =>
                            setNewPlTrackIds((prev) =>
                              checked
                                ? prev.filter((id) => id !== trk.id)
                                : [...prev, trk.id]
                            )
                          }
                        />
                        <span>{trk.title}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            )}
            <button
              type="submit"
              disabled={creatingPl}
              className="win-btn win-btn-primary px-3 py-1.5 text-xs"
            >
              {creatingPl ? 'CREATING...' : '+ CREATE PLAYLIST'}
            </button>
          </form>

          {playlists.length === 0 ? (
            <div className="win-inset p-6 text-center text-[#a690d6]">
              No playlists created yet. Create a playlist above, add your MP3s, and place it on your homepage!
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
              {/* Playlists List */}
              <div className="md:col-span-5 space-y-2">
                {playlists.map((pl) => (
                  <div
                    key={pl.id}
                    className={`win-box p-2.5 cursor-pointer ${
                      activeEditPlaylist?.id === pl.id ? 'ring-2 ring-[#52ff94]' : ''
                    }`}
                    onClick={() => setSelectedPlaylistId(pl.id)}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-pixel-ui text-xs text-[#e6dcff] truncate">
                        {pl.name}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 bg-[#120c1c] border border-[#7b42f6] text-[#c8b4f8]">
                        {pl.isPublic ? 'PUBLIC' : 'PRIVATE'}
                      </span>
                    </div>
                    <div className="text-xs text-[#a690d6] mt-0.5">
                      {pl.trackIds.length} track(s) · {pl.likes.length} likes
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          assignPlaylistToHomepage(pl.id);
                        }}
                        className="win-btn win-btn-primary px-2 py-0.5 text-[10px]"
                      >
                        SET ON HOMEPAGE
                      </button>
                      {pl.isPublic && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            copyShareUrl(`/playlist/${pl.ownerUsername}/${pl.slug}`);
                          }}
                          className="win-btn px-2 py-0.5 text-[10px]"
                        >
                          COPY LINK
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeletePlaylist(pl.id);
                        }}
                        className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
                      >
                        DEL
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Active Playlist Track Manager */}
              {activeEditPlaylist && (
                <div className="md:col-span-7 win-box p-3 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a1746] pb-2">
                    <span className="font-pixel-ui text-xs text-[#52ff94]">
                      EDITING: {activeEditPlaylist.name}
                    </span>
                    <button
                      type="button"
                      onClick={() =>
                        handlePatchPlaylist(activeEditPlaylist.id, {
                          isPublic: !activeEditPlaylist.isPublic,
                        })
                      }
                      className="win-btn px-2 py-0.5 text-[10px]"
                    >
                      SWITCH TO {activeEditPlaylist.isPublic ? 'PRIVATE' : 'PUBLIC'}
                    </button>
                  </div>

                  {activeEditPlaylist.isPublic && (
                    <div className="text-xs text-[#a690d6] flex items-center justify-between gap-2 bg-[#120c1c] p-2 border border-[#2a1746]">
                      <span className="truncate">
                        SHARE URL: /playlist/{activeEditPlaylist.ownerUsername}/
                        {activeEditPlaylist.slug}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          onOpenPublicUrl(
                            `/playlist/${activeEditPlaylist.ownerUsername}/${activeEditPlaylist.slug}`
                          )
                        }
                        className="win-btn px-2 py-0.5 text-[10px] shrink-0 text-[#52ff94]"
                      >
                        OPEN
                      </button>
                    </div>
                  )}

                  {/* Add Track to Playlist */}
                  <div className="space-y-2">
                    <label className="font-pixel-ui text-[10px] text-[#c8b4f8] block">
                      ADD SONG TO PLAYLIST
                    </label>
                    <div className="flex flex-wrap gap-1.5">
                      <select
                        id="add-track-select"
                        defaultValue=""
                        onChange={(e) => {
                          const id = e.target.value;
                          if (!id) return;
                          if (!activeEditPlaylist.trackIds.includes(id)) {
                            handlePatchPlaylist(activeEditPlaylist.id, {
                              trackIds: [...activeEditPlaylist.trackIds, id],
                            });
                          }
                          e.target.value = '';
                        }}
                        className="flex-1 min-w-[180px] win-inset px-2 py-1 text-white text-xs"
                      >
                        <option value="">
                          {audioTracks.length === 0
                            ? '-- No songs uploaded yet (upload right ->) --'
                            : '-- Choose track from Music Library --'}
                        </option>
                        {audioTracks
                          .filter((t) => !activeEditPlaylist.trackIds.includes(t.id))
                          .map((t) => (
                            <option key={t.id} value={t.id}>
                              {t.title} — {t.artist}
                            </option>
                          ))}
                      </select>
                      <label className="win-btn win-btn-primary px-2.5 py-1 text-[10px] cursor-pointer shrink-0">
                        {uploadingAudio ? 'UPLOADING...' : '+ UPLOAD SONG & ADD'}
                        <input
                          type="file"
                          multiple
                          accept=".mp3,.wav,.ogg,.m4a,.aac,.webm,audio/*"
                          disabled={uploadingAudio}
                          className="hidden"
                          onChange={(e) => {
                            handleUploadMp3Files(e.target.files, activeEditPlaylist.id);
                            e.target.value = '';
                          }}
                        />
                      </label>
                    </div>
                  </div>

                  {/* Current Ordered Tracks */}
                  <div className="space-y-1.5">
                    <div className="font-pixel-ui text-[10px] text-[#c8b4f8]">
                      PLAYLIST TRACK ORDER ({activeEditPlaylist.tracks?.length || 0})
                    </div>
                    {(!activeEditPlaylist.tracks || activeEditPlaylist.tracks.length === 0) ? (
                      <div className="win-inset p-3 text-xs text-[#a690d6]">
                        No tracks in this playlist yet. Pick MP3s from the dropdown above!
                      </div>
                    ) : (
                      activeEditPlaylist.tracks.map((trk, idx) => (
                        <div
                          key={`${trk.id}-${idx}`}
                          className="win-inset px-2.5 py-1.5 flex items-center justify-between gap-2 text-xs"
                        >
                          <span className="truncate text-[#e6dcff]">
                            {idx + 1}. {trk.title} —{' '}
                            <span className="text-[#a690d6]">{trk.artist}</span>
                          </span>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              type="button"
                              disabled={idx === 0}
                              onClick={() => {
                                const next = [...activeEditPlaylist.trackIds];
                                const [m] = next.splice(idx, 1);
                                next.splice(idx - 1, 0, m);
                                handlePatchPlaylist(activeEditPlaylist.id, { trackIds: next });
                              }}
                              className="win-btn px-1.5 py-0.5 text-[9px] disabled:opacity-40"
                            >
                              UP
                            </button>
                            <button
                              type="button"
                              disabled={idx === activeEditPlaylist.trackIds.length - 1}
                              onClick={() => {
                                const next = [...activeEditPlaylist.trackIds];
                                const [m] = next.splice(idx, 1);
                                next.splice(idx + 1, 0, m);
                                handlePatchPlaylist(activeEditPlaylist.id, { trackIds: next });
                              }}
                              className="win-btn px-1.5 py-0.5 text-[9px] disabled:opacity-40"
                            >
                              DN
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                const next = activeEditPlaylist.trackIds.filter(
                                  (_, i) => i !== idx
                                );
                                handlePatchPlaylist(activeEditPlaylist.id, { trackIds: next });
                              }}
                              className="win-btn px-1.5 py-0.5 text-[9px] text-[#ff6bd6]"
                            >
                              X
                            </button>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
