import React, { useState } from 'react';
import { BarutBadge } from '../components/BarutBadge';
import { AvatarBox } from '../components/RetroMedia';
import { ForumCategory, ForumTopic, UserAccount, UserRole } from '../types/lostroom';

interface ForumPageProps {
  categories: ForumCategory[];
  topics: ForumTopic[];
  users: Record<string, UserAccount>;
  currentUsername: string | null;
  rolesMap?: Record<string, UserRole>;
  postingEnabled?: boolean;
  commentsEnabled?: boolean;
  selectedTopicId: string | null;
  onSelectTopicId: (topicId: string | null) => void;
  onCreateCategory: (name: string, description: string, icon: ForumCategory['icon']) => void;
  onCreateTopic: (categoryId: string, title: string, body: string) => void;
  onAddTopicReply: (topicId: string, body: string) => void;
  onOpenProfile: (username: string) => void;
}

export const ForumPage: React.FC<ForumPageProps> = ({
  categories,
  topics,
  users,
  currentUsername,
  rolesMap,
  postingEnabled = true,
  commentsEnabled = true,
  selectedTopicId,
  onSelectTopicId,
  onCreateCategory,
  onCreateTopic,
  onAddTopicReply,
  onOpenProfile,
}) => {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>(
    categories[0]?.id || 'cat-general'
  );
  const [showNewCategoryForm, setShowNewCategoryForm] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatDesc, setNewCatDesc] = useState('');
  const [newCatIcon, setNewCatIcon] = useState<ForumCategory['icon']>('chat');

  const [showNewTopicForm, setShowNewTopicForm] = useState(false);
  const [newTopicTitle, setNewTopicTitle] = useState('');
  const [newTopicBody, setNewTopicBody] = useState('');

  const [replyBody, setReplyBody] = useState('');

  const activeTopic = topics.find((t) => t.id === selectedTopicId) || null;
  const activeCategory =
    categories.find((c) => c.id === (activeTopic ? activeTopic.categoryId : selectedCategoryId)) ||
    categories[0];

  const categoryTopics = topics.filter((t) => t.categoryId === activeCategory?.id);

  const handleCreateCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;
    onCreateCategory(
      newCatName.trim(),
      newCatDesc.trim() || 'Community discussion category.',
      newCatIcon
    );
    setNewCatName('');
    setNewCatDesc('');
    setShowNewCategoryForm(false);
  };

  const handleCreateTopicSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTopicTitle.trim() || !newTopicBody.trim() || !activeCategory) return;
    onCreateTopic(activeCategory.id, newTopicTitle.trim(), newTopicBody.trim());
    setNewTopicTitle('');
    setNewTopicBody('');
    setShowNewTopicForm(false);
  };

  const handleReplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTopic || !replyBody.trim()) return;
    onAddTopicReply(activeTopic.id, replyBody.trim());
    setReplyBody('');
  };

  return (
    <div className="space-y-4">
      {/* Persistent Community Notice for Forum */}
      <div className="bg-[#1a1128] border border-[#7b42f6] p-3 text-sm text-[#c8b4f8]">
        <div className="font-pixel-ui text-xs text-[#ff6bd6] mb-1">
          FORUM_BOARDS // PROTOTYPE STORAGE NOTICE
        </div>
        <p className="text-base leading-snug">
          Categories, topics, and replies created here live in local browser storage only. A backend
          server and persistent database are necessary to share and persist community forum
          discussions across multiple devices and users.
        </p>
      </div>

      {/* Category Tabs Bar + Create Category Button */}
      <div className="bg-[#120c1c] border border-[#4e2d82] p-3 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <span className="font-pixel-ui text-xs text-[#e6dcff]">
            DISCUSSION CATEGORIES ({categories.length})
          </span>
          <button
            type="button"
            onClick={() => setShowNewCategoryForm((prev) => !prev)}
            className="win-btn win-btn-primary px-3 py-1 text-[11px]"
          >
            {showNewCategoryForm ? 'CANCEL' : '+ CREATE CATEGORY'}
          </button>
        </div>

        {showNewCategoryForm && (
          <form onSubmit={handleCreateCategorySubmit} className="win-inset p-3 space-y-2.5">
            <div className="font-pixel-ui text-[11px] text-[#52ff94]">
              NEW DISCUSSION CATEGORY
            </div>
            <input
              type="text"
              required
              value={newCatName}
              onChange={(e) => setNewCatName(e.target.value)}
              placeholder="Category name (e.g. Music & Links)"
              className="win-inset w-full px-2.5 py-1.5 text-base text-[#eee6ff]"
            />
            <input
              type="text"
              value={newCatDesc}
              onChange={(e) => setNewCatDesc(e.target.value)}
              placeholder="Short description..."
              className="win-inset w-full px-2.5 py-1.5 text-base text-[#eee6ff]"
            />
            <div className="flex items-center justify-between gap-2">
              <select
                value={newCatIcon}
                onChange={(e) => setNewCatIcon(e.target.value as ForumCategory['icon'])}
                className="win-inset px-2 py-1 text-sm text-[#eee6ff]"
              >
                <option value="chat">General Icon</option>
                <option value="help">Help Icon</option>
                <option value="wave">Intro Icon</option>
                <option value="moon">Night Icon</option>
                <option value="folder">Folder Icon</option>
              </select>
              <button type="submit" className="win-btn win-btn-primary px-3.5 py-1 text-xs">
                SAVE CATEGORY
              </button>
            </div>
          </form>
        )}

        <div className="flex flex-wrap gap-1.5">
          {categories.map((cat) => {
            const count = topics.filter((t) => t.categoryId === cat.id).length;
            const selected = activeCategory?.id === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  setSelectedCategoryId(cat.id);
                  onSelectTopicId(null);
                }}
                className={`win-btn px-3 py-1.5 text-xs flex items-center gap-2 ${
                  selected ? 'win-btn-primary' : ''
                }`}
              >
                <span>{cat.name}</span>
                <span className="text-[10px] opacity-80 tabular-nums">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Category Topics Table OR Active Thread Discussion */}
      {!activeTopic ? (
        <div className="bg-[#120c1c] border border-[#4e2d82] p-3.5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a1746] pb-2">
            <div>
              <h2 className="font-pixel-ui text-sm text-[#e6dcff]">{activeCategory?.name}</h2>
              <p className="text-sm text-[#a690d6]">{activeCategory?.description}</p>
            </div>
            <button
              type="button"
              disabled={!postingEnabled}
              onClick={() => setShowNewTopicForm((prev) => !prev)}
              className="win-btn win-btn-primary px-3 py-1.5 text-xs shrink-0 disabled:opacity-50"
            >
              {!postingEnabled ? 'POSTING PAUSED' : showNewTopicForm ? 'CANCEL' : '+ NEW TOPIC'}
            </button>
          </div>

          {showNewTopicForm && postingEnabled && (
            <form onSubmit={handleCreateTopicSubmit} className="win-inset p-3 space-y-2.5">
              <div className="font-pixel-ui text-[11px] text-[#52ff94]">
                START TOPIC IN {activeCategory?.name.toUpperCase()}
              </div>
              <input
                type="text"
                required
                value={newTopicTitle}
                onChange={(e) => setNewTopicTitle(e.target.value)}
                placeholder="Topic title..."
                className="win-inset w-full px-2.5 py-1.5 text-base text-[#eee6ff]"
              />
              <textarea
                rows={3}
                required
                value={newTopicBody}
                onChange={(e) => setNewTopicBody(e.target.value)}
                placeholder="Opening message..."
                className="win-inset w-full px-2.5 py-1.5 text-base text-[#eee6ff]"
              />
              <div className="flex justify-end">
                <button type="submit" className="win-btn win-btn-primary px-4 py-1.5 text-xs">
                  PUBLISH TOPIC &gt;&gt;
                </button>
              </div>
            </form>
          )}

          <div className="overflow-x-auto border border-[#2a1746]">
            <table className="w-full text-left border-collapse text-base">
              <thead>
                <tr className="bg-[#1a1128] text-[#c8b4f8] border-b border-[#4e2d82] font-pixel-ui text-[10px]">
                  <th className="p-2">TOPIC</th>
                  <th className="p-2">AUTHOR</th>
                  <th className="p-2 text-right">REPLIES</th>
                  <th className="p-2 text-right">VIEWS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#2a1746]">
                {categoryTopics.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="p-6 text-center text-[#a690d6]">
                      No topics in {activeCategory?.name} yet. Click &quot;+ NEW TOPIC&quot; to start
                      one.
                    </td>
                  </tr>
                ) : (
                  categoryTopics.map((topic) => (
                    <tr key={topic.id} className="hover:bg-[#1a1128]">
                      <td className="p-2">
                        <button
                          type="button"
                          onClick={() => onSelectTopicId(topic.id)}
                          className="text-left text-[#eee6ff] hover:text-[#ff6bd6] hover:underline cursor-pointer"
                        >
                          {topic.title}
                        </button>
                      </td>
                      <td className="p-2">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <button
                            type="button"
                            onClick={() => onOpenProfile(topic.author)}
                            className="font-pixel-ui text-xs text-[#c8b4f8] hover:underline cursor-pointer"
                          >
                            {topic.author}
                          </button>
                          <BarutBadge username={topic.author} rolesMap={rolesMap} compact />
                        </div>
                      </td>
                      <td className="p-2 text-right tabular-nums text-[#52ff94]">
                        {topic.replies.length}
                      </td>
                      <td className="p-2 text-right tabular-nums text-[#a690d6]">{topic.views}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="bg-[#120c1c] border border-[#4e2d82] p-3.5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#2a1746] pb-2">
            <div>
              <div className="font-pixel-ui text-[10px] text-[#a690d6]">
                {activeCategory?.name} / DISCUSSION
              </div>
              <h2 className="font-pixel-ui text-sm text-[#e6dcff] mt-0.5">{activeTopic.title}</h2>
            </div>
            <button
              type="button"
              onClick={() => onSelectTopicId(null)}
              className="win-btn px-3 py-1 text-[11px]"
            >
              ← BACK TO TOPICS
            </button>
          </div>

          {/* Original Topic Post */}
          <div className="win-inset p-3 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => onOpenProfile(activeTopic.author)}
                  className="flex items-center gap-2 font-pixel-ui text-[#52ff94] hover:underline cursor-pointer"
                >
                  <AvatarBox user={users[activeTopic.author]} sizeClass="w-7 h-7" />
                  <span>{activeTopic.author}</span>
                </button>
                <BarutBadge username={activeTopic.author} rolesMap={rolesMap} compact />
              </div>
              <span className="text-[#a690d6]">OP · {activeTopic.createdAt}</span>
            </div>
            <p className="text-lg text-[#eee6ff] whitespace-pre-line">{activeTopic.body}</p>
          </div>

          {/* Replies */}
          <div className="space-y-2">
            <div className="font-pixel-ui text-xs text-[#c8b4f8]">
              REPLIES ({activeTopic.replies.length})
            </div>

            {activeTopic.replies.length === 0 ? (
              <div className="win-inset p-3 text-sm text-[#a690d6]">
                No replies yet. Post the first response below.
              </div>
            ) : (
              activeTopic.replies.map((rep, idx) => (
                <div key={rep.id} className="bg-[#1a1128] border border-[#3b2163] p-2.5 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <button
                        type="button"
                        onClick={() => onOpenProfile(rep.author)}
                        className="flex items-center gap-2 font-pixel-ui text-[#c8b4f8] hover:underline cursor-pointer"
                      >
                        <AvatarBox user={users[rep.author]} sizeClass="w-6 h-6" />
                        <span>{rep.author}</span>
                      </button>
                      <BarutBadge username={rep.author} rolesMap={rolesMap} compact />
                    </div>
                    <span className="text-[#a690d6] tabular-nums">
                      #{idx + 1} · {rep.createdAt}
                    </span>
                  </div>
                  <p className="text-base text-[#eee6ff] whitespace-pre-line">{rep.body}</p>
                </div>
              ))
            )}
          </div>

          {/* Reply Form */}
          {commentsEnabled ? (
            <form onSubmit={handleReplySubmit} className="space-y-2 pt-2 border-t border-[#2a1746]">
              <label
                htmlFor="forum-reply-box"
                className="block font-pixel-ui text-xs text-[#c8b4f8]"
              >
                POST REPLY AS {currentUsername || 'GUEST'}:
              </label>
              <textarea
                id="forum-reply-box"
                rows={2}
                required
                value={replyBody}
                onChange={(e) => setReplyBody(e.target.value)}
                placeholder="write your reply..."
                className="win-inset w-full p-2.5 text-base text-[#eee6ff]"
              />
              <div className="flex justify-end">
                <button type="submit" className="win-btn win-btn-primary px-4 py-1.5 text-xs">
                  POST REPLY &gt;&gt;
                </button>
              </div>
            </form>
          ) : (
            <div className="win-inset p-2.5 text-xs text-[#ff6bd6]">
              Replies &amp; comments are temporarily paused by Super Admin (God Mode).
            </div>
          )}
        </div>
      )}
    </div>
  );
};
