import React from 'react';
import { BarutBadge } from '../components/BarutBadge';
import { AvatarBox } from '../components/RetroMedia';
import { FriendRequest, UserAccount, UserRole } from '../types/lostroom';

interface FriendsPageProps {
  currentUsername: string | null;
  users: Record<string, UserAccount>;
  rolesMap?: Record<string, UserRole>;
  friendRequests: FriendRequest[];
  onSendRequest: (toUsername: string) => void;
  onRespondRequest: (requestId: string, action: 'accepted' | 'declined') => void;
  onCancelRequest: (requestId: string) => void;
  onRemoveFriend: (friendUsername: string) => void;
  onOpenProfile: (username: string) => void;
  onOpenChatWith: (username: string) => void;
}

export const FriendsPage: React.FC<FriendsPageProps> = ({
  currentUsername,
  users,
  rolesMap,
  friendRequests,
  onSendRequest,
  onRespondRequest,
  onCancelRequest,
  onRemoveFriend,
  onOpenProfile,
  onOpenChatWith,
}) => {
  if (!currentUsername) {
    return (
      <div className="win-inset p-6 text-center text-[#a690d6]">
        Log in or register an account to send friend requests and manage your friends list.
      </div>
    );
  }

  const incomingPending = friendRequests.filter(
    (r) => r.to === currentUsername && r.status === 'pending'
  );
  const outgoingPending = friendRequests.filter(
    (r) => r.from === currentUsername && r.status === 'pending'
  );
  const confirmedFriends = friendRequests
    .filter(
      (r) =>
        r.status === 'accepted' && (r.from === currentUsername || r.to === currentUsername)
    )
    .map((r) => (r.from === currentUsername ? r.to : r.from))
    .filter((username, idx, arr) => arr.indexOf(username) === idx && Boolean(users[username]));

  const otherUsers = Object.values(users).filter((u) => u.username !== currentUsername);

  const getRelation = (targetUsername: string) => {
    if (confirmedFriends.includes(targetUsername)) return 'friend';
    const pendingIn = incomingPending.find((r) => r.from === targetUsername);
    if (pendingIn) return 'incoming';
    const pendingOut = outgoingPending.find((r) => r.to === targetUsername);
    if (pendingOut) return 'outgoing';
    return 'none';
  };

  return (
    <div className="space-y-4">
      {/* Explicit Backend & Persistent Database Notice for Friends System */}
      <div className="bg-[#1a1128] border border-[#7b42f6] p-3 text-sm text-[#c8b4f8]">
        <div className="font-pixel-ui text-xs text-[#ff6bd6] mb-1">
          FRIENDS_SYSTEM // BACKEND &amp; DATABASE NOTICE
        </div>
        <p className="text-base leading-snug">
          Friend requests, accept/decline responses, and confirmed friends lists are currently saved
          only in local browser storage on this device. A backend server and persistent database are
          required for the Friends system to work as a shared, persistent social network across
          devices and remote users.
        </p>
      </div>

      {/* Incoming Friend Requests */}
      <div className="bg-[#120c1c] border border-[#4e2d82] p-3.5 space-y-2.5">
        <div className="font-pixel-ui text-xs text-[#52ff94]">
          INCOMING FRIEND REQUESTS ({incomingPending.length})
        </div>
        {incomingPending.length === 0 ? (
          <div className="win-inset p-3 text-sm text-[#a690d6]">
            No pending incoming friend requests.
          </div>
        ) : (
          <div className="space-y-2">
            {incomingPending.map((req) => {
              const sender = users[req.from];
              return (
                <div
                  key={req.id}
                  className="bg-[#1a1128] border border-[#7b42f6] p-2.5 flex flex-wrap items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <AvatarBox user={sender} sizeClass="w-10 h-10" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => onOpenProfile(req.from)}
                          className="font-pixel-ui text-xs text-[#e6dcff] hover:underline cursor-pointer"
                        >
                          {req.from}
                        </button>
                        <BarutBadge username={req.from} rolesMap={rolesMap} compact />
                      </div>
                      <div className="text-xs text-[#a690d6]">
                        sent request · {req.time}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => onRespondRequest(req.id, 'accepted')}
                      className="win-btn win-btn-primary px-3 py-1 text-[11px]"
                    >
                      ACCEPT
                    </button>
                    <button
                      type="button"
                      onClick={() => onRespondRequest(req.id, 'declined')}
                      className="win-btn px-3 py-1 text-[11px] text-[#ff6bd6]"
                    >
                      DECLINE
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Confirmed Friends List */}
      <div className="bg-[#120c1c] border border-[#4e2d82] p-3.5 space-y-2.5">
        <div className="font-pixel-ui text-xs text-[#e6dcff]">
          CONFIRMED FRIENDS ({confirmedFriends.length})
        </div>
        {confirmedFriends.length === 0 ? (
          <div className="win-inset p-3 text-sm text-[#a690d6]">
            You have no confirmed friends yet. Send a request to another registered user below!
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {confirmedFriends.map((friendName) => {
              const friend = users[friendName];
              return (
                <div
                  key={friendName}
                  className="bg-[#1a1128] border border-[#4e2d82] p-2.5 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <AvatarBox user={friend} sizeClass="w-10 h-10" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => onOpenProfile(friendName)}
                          className="font-pixel-ui text-xs text-[#52ff94] hover:underline truncate cursor-pointer"
                        >
                          {friendName}
                        </button>
                        <BarutBadge username={friendName} rolesMap={rolesMap} compact />
                      </div>
                      <div className="text-xs text-[#a690d6] truncate">{friend?.bio}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => onOpenChatWith(friendName)}
                      className="win-btn win-btn-primary px-2 py-1 text-[10px]"
                    >
                      DM
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemoveFriend(friendName)}
                      className="win-btn px-2 py-1 text-[10px] text-[#ff6bd6]"
                      title="Remove friend"
                    >
                      UNFRIEND
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Sent Requests & Add Users */}
      <div className="bg-[#120c1c] border border-[#4e2d82] p-3.5 space-y-2.5">
        <div className="font-pixel-ui text-xs text-[#c8b4f8]">
          REGISTERED USERS — SEND FRIEND REQUESTS ({otherUsers.length})
        </div>
        {otherUsers.length === 0 ? (
          <div className="win-inset p-3 text-sm text-[#a690d6]">
            No other registered accounts exist on this browser yet. Register a 2nd user in Portal
            Gate to test sending &amp; accepting friend requests!
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {otherUsers.map((u) => {
              const rel = getRelation(u.username);
              const outReq = outgoingPending.find((r) => r.to === u.username);
              return (
                <div
                  key={u.username}
                  className="win-inset p-2.5 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <AvatarBox user={u} sizeClass="w-9 h-9" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => onOpenProfile(u.username)}
                          className="font-pixel-ui text-xs text-[#e6dcff] hover:underline truncate cursor-pointer"
                        >
                          {u.username}
                        </button>
                        <BarutBadge username={u.username} rolesMap={rolesMap} compact />
                      </div>
                      <div className="text-xs text-[#a690d6] truncate">{u.bio}</div>
                    </div>
                  </div>
                  <div className="shrink-0">
                    {rel === 'friend' && (
                      <span className="font-pixel-ui text-[10px] text-[#52ff94] px-2 py-1 border border-[#2a1746]">
                        FRIEND
                      </span>
                    )}
                    {rel === 'outgoing' && outReq && (
                      <button
                        type="button"
                        onClick={() => onCancelRequest(outReq.id)}
                        className="win-btn px-2 py-1 text-[10px] text-[#c8b4f8]"
                      >
                        PENDING (×)
                      </button>
                    )}
                    {rel === 'incoming' && (
                      <span className="font-pixel-ui text-[10px] text-[#ff6bd6]">
                        CHECK INCOMING ↑
                      </span>
                    )}
                    {rel === 'none' && (
                      <button
                        type="button"
                        onClick={() => onSendRequest(u.username)}
                        className="win-btn win-btn-primary px-2.5 py-1 text-[10px]"
                      >
                        + ADD FRIEND
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
