import React, { useEffect, useState } from 'react';
import { HomepageRenderer } from '../components/HomepageRenderer';
import {
  getPublicHomepage,
  postGuestbookEntry,
  PublicHomepagePayload,
} from '../utils/homepageApi';

interface PublicHomepageViewProps {
  username: string;
  currentViewerUsername: string | null;
  onReturnToLostroom: () => void;
  onEditMyHomepage: () => void;
  onNavigateInternal: (path: string) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const PublicHomepageView: React.FC<PublicHomepageViewProps> = ({
  username,
  currentViewerUsername,
  onReturnToLostroom,
  onEditMyHomepage,
  onNavigateInternal,
  onToast,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [payload, setPayload] = useState<PublicHomepagePayload | null>(null);

  const fetchPage = async (countVisit: boolean) => {
    setLoading(true);
    setError(null);
    try {
      const data = await getPublicHomepage(username, countVisit);
      setPayload(data);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : 'This personal homepage is unpublished or does not exist.'
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPage(true);
  }, [username]);

  const handleSubmitGuestbook = async (message: string) => {
    try {
      const res = await postGuestbookEntry(
        username,
        currentViewerUsername || 'visitor',
        message
      );
      setPayload((prev) =>
        prev ? { ...prev, guestbook: [res.entry, ...prev.guestbook] } : prev
      );
      onToast('Signed guestbook!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to sign guestbook.', 'error');
    }
  };

  const copyCurrentUrl = () => {
    navigator.clipboard?.writeText(window.location.href).catch(() => {});
    onToast(`Copied /user/${username}`);
  };

  return (
    <div className="min-h-screen bg-[#09060e] text-[#eee6ff] flex flex-col">
      {/* Compact Retro Top Bar */}
      <div className="bg-[#120c1c] border-b-2 border-[#7b42f6] px-3 py-2 flex flex-wrap items-center justify-between gap-2 sticky top-0 z-40">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onReturnToLostroom}
            className="win-btn win-btn-primary px-2.5 py-1 text-xs"
          >
            &lt;&lt; LOSTROOM.BXE
          </button>
          <span className="font-pixel-ui text-xs text-[#c8b4f8] hidden sm:inline">
            USER_SITE:// /user/{username}
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={copyCurrentUrl}
            className="win-btn px-2.5 py-1 text-[10px]"
          >
            COPY URL
          </button>
          {currentViewerUsername === username && (
            <button
              type="button"
              onClick={onEditMyHomepage}
              className="win-btn px-2.5 py-1 text-[10px] text-[#52ff94]"
            >
              EDIT MY HOMEPAGE
            </button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        {loading ? (
          <div className="max-w-xl mx-auto my-12 win-box p-6 text-center font-pixel-ui text-xs text-[#c8b4f8]">
            CONNECTING TO /user/{username}...
          </div>
        ) : error || !payload ? (
          <div className="max-w-xl mx-auto my-12 win-box p-6 text-center space-y-3">
            <div className="font-pixel-ui text-sm text-[#ff6bd6]">404 // HOMEPAGE UNAVAILABLE</div>
            <p className="text-base text-[#c8b4f8]">
              {error || `No published homepage found for "${username}".`}
            </p>
            <div className="flex justify-center gap-2">
              <button
                type="button"
                onClick={onReturnToLostroom}
                className="win-btn win-btn-primary px-4 py-1.5 text-xs"
              >
                RETURN TO LOSTROOM.BXE
              </button>
              {currentViewerUsername === username && (
                <button
                  type="button"
                  onClick={onEditMyHomepage}
                  className="win-btn px-4 py-1.5 text-xs text-[#52ff94]"
                >
                  BUILD &amp; PUBLISH YOURS
                </button>
              )}
            </div>
          </div>
        ) : (
          <>
            <HomepageRenderer
              document={payload.document}
              username={payload.username}
              playlistsById={payload.playlistsById}
              visitorCount={payload.visitorCount}
              guestbook={payload.guestbook}
              currentViewerUsername={currentViewerUsername}
              onSubmitGuestbook={handleSubmitGuestbook}
              onNavigateInternal={onNavigateInternal}
            />

            {payload.ownerPublicPlaylists.length > 0 && (
              <div className="max-w-3xl mx-auto px-4 py-6">
                <div className="win-box p-3 space-y-2">
                  <div className="font-pixel-ui text-xs text-[#c8b4f8]">
                    {payload.username.toUpperCase()}&apos;S PUBLIC PLAYLISTS
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {payload.ownerPublicPlaylists.map((pl) => (
                      <button
                        key={pl.id}
                        type="button"
                        onClick={() =>
                          onNavigateInternal(`/playlist/${pl.ownerUsername}/${pl.slug}`)
                        }
                        className="win-btn px-3 py-1 text-xs text-[#52ff94]"
                      >
                        ♪ {pl.name} ({pl.trackIds.length})
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};
