import React, { useEffect, useRef, useState } from 'react';
import { processImageFileToDataURL } from '../utils/media';
import { saveVideoBlob } from '../utils/mediaDb';

interface UploadPageProps {
  postingEnabled?: boolean;
  onPublishPost: (payload: {
    content: string;
    mood: string;
    tags: string[];
    mediaType: 'none' | 'image' | 'video';
    mediaUrl: string;
  }) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const UploadPage: React.FC<UploadPageProps> = ({
  postingEnabled = true,
  onPublishPost,
  onToast,
}) => {
  const [content, setContent] = useState('');
  const [mood, setMood] = useState('');
  const [rawTags, setRawTags] = useState('');
  const [mediaType, setMediaType] = useState<'none' | 'image' | 'video'>('none');
  const [mediaUrl, setMediaUrl] = useState('');
  const [pendingVideoFile, setPendingVideoFile] = useState<File | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const imageInputRef = useRef<HTMLInputElement | null>(null);
  const videoInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    return () => {
      if (mediaUrl && mediaUrl.startsWith('blob:')) {
        URL.revokeObjectURL(mediaUrl);
      }
    };
  }, [mediaUrl]);

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (videoInputRef.current) videoInputRef.current.value = '';
    setPendingVideoFile(null);

    try {
      const dataUrl = await processImageFileToDataURL(file, 900, 0.84);
      setMediaType('image');
      setMediaUrl(dataUrl);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to process image', 'error');
    }
  };

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (imageInputRef.current) imageInputRef.current.value = '';
    if (mediaUrl && mediaUrl.startsWith('blob:')) {
      URL.revokeObjectURL(mediaUrl);
    }

    const objUrl = URL.createObjectURL(file);
    setPendingVideoFile(file);
    setMediaType('video');
    setMediaUrl(objUrl);
  };

  const handleClearMedia = () => {
    if (mediaUrl && mediaUrl.startsWith('blob:')) {
      URL.revokeObjectURL(mediaUrl);
    }
    setMediaType('none');
    setMediaUrl('');
    setPendingVideoFile(null);
    if (imageInputRef.current) imageInputRef.current.value = '';
    if (videoInputRef.current) videoInputRef.current.value = '';
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = content.trim();
    if (!trimmed && mediaType === 'none') return;

    const tags = rawTags
      .split(',')
      .map((t) => t.trim().replace(/^#/, '').toLowerCase())
      .filter(Boolean);

    let finalMediaUrl = mediaUrl;

    if (mediaType === 'video' && pendingVideoFile) {
      try {
        setIsSaving(true);
        const videoId = `vid-${Date.now()}-${Math.random().toString(16).slice(2, 6)}`;
        await saveVideoBlob(videoId, pendingVideoFile);
        finalMediaUrl = `idb://${videoId}`;
      } catch (err) {
        setIsSaving(false);
        onToast(
          err instanceof Error ? err.message : 'Failed to save video in local browser DB.',
          'error'
        );
        return;
      }
      setIsSaving(false);
    }

    onPublishPost({
      content: trimmed,
      mood: mood.trim(),
      tags,
      mediaType,
      mediaUrl: finalMediaUrl,
    });
  };

  return (
    <div className="space-y-4">
      <div className="bg-[var(--bg-void)] border border-[var(--accent-violet)] p-4">
        <div className="font-pixel-ui text-sm text-[var(--green-online)] border-b border-[var(--bevel-mid)] pb-2 mb-3">
          &gt;&gt; UPLOAD_PHOTO_OR_VIDEO.EXE
        </div>

        {!postingEnabled ? (
          <div className="win-inset p-4 text-center space-y-2 border border-[#ff6bd6]">
            <div className="font-pixel-ui text-xs text-[#ff6bd6]">
              POSTING TEMPORARILY PAUSED (GOD MODE)
            </div>
            <p className="text-sm text-[var(--accent-lavender)]">
              Super Admin has temporarily paused new posts and uploads site-wide. Existing posts remain preserved.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label
              htmlFor="post-content"
              className="block font-pixel-ui text-xs text-[var(--accent-lavender)] mb-1"
            >
              CAPTION / MESSAGE:
            </label>
            <textarea
              id="post-content"
              rows={3}
              required={mediaType === 'none'}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="write something..."
              className="win-inset w-full p-2.5 text-[var(--text-bright)]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="post-mood"
                className="block font-pixel-ui text-xs text-[var(--accent-lavender)] mb-1"
              >
                MOOD (OPTIONAL):
              </label>
              <input
                id="post-mood"
                type="text"
                value={mood}
                onChange={(e) => setMood(e.target.value)}
                placeholder="e.g. midnight // chill"
                className="win-inset w-full px-2.5 py-1.5 text-[var(--text-bright)]"
              />
            </div>

            <div>
              <label
                htmlFor="post-tags"
                className="block font-pixel-ui text-xs text-[var(--accent-lavender)] mb-1"
              >
                TAGS (COMMA SEPARATED):
              </label>
              <input
                id="post-tags"
                type="text"
                value={rawTags}
                onChange={(e) => setRawTags(e.target.value)}
                placeholder="friends, music, cats"
                className="win-inset w-full px-2.5 py-1.5 text-[var(--text-bright)]"
              />
            </div>
          </div>

          <div className="bg-[var(--bg-panel)] border border-[var(--bevel-mid)] p-3 space-y-3">
            <div className="font-pixel-ui text-xs text-[var(--text-bright)]">
              SELECT PHOTO OR VIDEO FILE FROM YOUR DEVICE:
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="win-inset p-2.5">
                <label
                  htmlFor="post-image-file"
                  className="block font-pixel-ui text-[11px] text-[var(--green-online)] mb-1"
                >
                  1. UPLOAD PHOTO (.JPG, .PNG, .GIF):
                </label>
                <input
                  ref={imageInputRef}
                  id="post-image-file"
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="text-xs text-[var(--accent-lavender)] w-full"
                />
              </div>

              <div className="win-inset p-2.5">
                <label
                  htmlFor="post-video-file"
                  className="block font-pixel-ui text-[11px] text-[var(--pink-love)] mb-1"
                >
                  2. UPLOAD VIDEO (.MP4, .WEBM):
                </label>
                <input
                  ref={videoInputRef}
                  id="post-video-file"
                  type="file"
                  accept="video/*"
                  onChange={handleVideoChange}
                  className="text-xs text-[var(--accent-lavender)] w-full"
                />
              </div>
            </div>

            {mediaType !== 'none' && mediaUrl && (
              <div className="win-inset p-2 bg-black text-center space-y-2">
                {mediaType === 'image' ? (
                  <img src={mediaUrl} alt="Upload preview" className="max-h-64 mx-auto" />
                ) : (
                  <video src={mediaUrl} controls className="max-h-64 mx-auto" />
                )}
                {mediaType === 'video' && (
                  <div className="text-xs text-[var(--green-online)]">
                    Saved in local IndexedDB so it stays playable after refresh/restart.
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={handleClearMedia}
              className="win-btn px-3 py-1.5 text-xs text-[var(--pink-love)]"
            >
              CLEAR MEDIA
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="win-btn win-btn-primary px-5 py-2 text-xs disabled:opacity-60"
            >
              {isSaving ? 'SAVING VIDEO...' : 'PUBLISH TO FEED >>'}
            </button>
          </div>
        </form>
        )}
      </div>
    </div>
  );
};
