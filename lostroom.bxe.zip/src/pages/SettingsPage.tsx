import React, { useRef, useState } from 'react';
import { FlagPicker } from '../components/FlagPicker';
import { AvatarBox, PIXEL_AVATAR_OPTIONS, PixelAvatarSVG } from '../components/RetroMedia';
import { PixelAvatarKey, UserAccount } from '../types/lostroom';
import { sanitizeFlags } from '../utils/flags';
import { processImageFileToDataURL } from '../utils/media';

interface SettingsPageProps {
  currentUser: UserAccount | null;
  crtEnabled: boolean;
  strictPixelFont: boolean;
  onToggleCrt: () => void;
  onToggleStrictPixelFont: () => void;
  onSaveProfile: (updates: {
    avatarType: 'preset' | 'custom';
    avatarValue: string;
    bio: string;
    flags: string[];
  }) => void;
  onOpenThemeEditor: () => void;
  onWipeLocalData: () => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const SettingsPage: React.FC<SettingsPageProps> = ({
  currentUser,
  crtEnabled,
  strictPixelFont,
  onToggleCrt,
  onToggleStrictPixelFont,
  onSaveProfile,
  onOpenThemeEditor,
  onWipeLocalData,
  onToast,
}) => {
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [flags, setFlags] = useState<string[]>(() => sanitizeFlags(currentUser?.flags));
  const [preset, setPreset] = useState<PixelAvatarKey>(
    currentUser?.avatarType === 'preset'
      ? (currentUser.avatarValue as PixelAvatarKey)
      : 'cat_void'
  );
  const [pendingCustomPfp, setPendingCustomPfp] = useState<string | null>(
    currentUser?.avatarType === 'custom' ? currentUser.avatarValue : null
  );
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!currentUser) {
    return (
      <div className="win-inset p-6 text-center text-[#a690d6]">
        Log in first to edit your PFP, biography, and display settings.
      </div>
    );
  }

  const handlePfpFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const dataUrl = await processImageFileToDataURL(file, 256, 0.85);
      setPendingCustomPfp(dataUrl);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to load PFP', 'error');
    }
  };

  const handlePresetChange = (nextPreset: PixelAvatarKey) => {
    setPreset(nextPreset);
    setPendingCustomPfp(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanFlags = sanitizeFlags(flags);
    if (pendingCustomPfp) {
      onSaveProfile({
        avatarType: 'custom',
        avatarValue: pendingCustomPfp,
        bio: bio.trim(),
        flags: cleanFlags,
      });
    } else {
      onSaveProfile({
        avatarType: 'preset',
        avatarValue: preset,
        bio: bio.trim(),
        flags: cleanFlags,
      });
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#120c1c] border border-[#4e2d82] p-4">
        <div className="font-pixel-ui text-sm text-[#e6dcff] border-b border-[#4e2d82] pb-2 mb-3">
          &gt;&gt; EDIT_PROFILE_&amp;_PFP ({currentUser.username})
        </div>

        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="flex items-center gap-3.5">
            {pendingCustomPfp ? (
              <img
                src={pendingCustomPfp}
                alt="PFP preview"
                className="w-16 h-16 object-cover border border-[#52ff94] shrink-0 bg-black"
              />
            ) : (
              <div className="w-16 h-16 border border-[#c8b4f8] overflow-hidden shrink-0">
                <PixelAvatarSVG preset={preset} />
              </div>
            )}
            <div className="space-y-1">
              <div className="font-pixel-ui text-xs text-[#52ff94]">CURRENT PFP</div>
              <div className="text-xs text-[#a690d6]">
                Upload any image below or choose a pixel avatar fallback.
              </div>
              {currentUser.avatarType === 'custom' && !pendingCustomPfp && (
                <div className="text-xs text-[#c8b4f8]">
                  Current saved: <AvatarBox user={currentUser} sizeClass="w-5 h-5 inline-block align-middle" />
                </div>
              )}
            </div>
          </div>

          <div className="win-inset p-2.5">
            <label
              htmlFor="set-avatar-file"
              className="block font-pixel-ui text-xs text-[#e6dcff] mb-1"
            >
              UPLOAD NEW PROFILE PICTURE (PFP):
            </label>
            <input
              ref={fileInputRef}
              id="set-avatar-file"
              type="file"
              accept="image/*"
              onChange={handlePfpFile}
              className="text-xs text-[#c8b4f8] w-full"
            />
          </div>

          <div>
            <label
              htmlFor="set-avatar-preset"
              className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1"
            >
              OR CHOOSE PIXEL AVATAR FALLBACK:
            </label>
            <select
              id="set-avatar-preset"
              value={preset}
              onChange={(e) => handlePresetChange(e.target.value as PixelAvatarKey)}
              className="win-inset w-full px-3 py-1.5 text-[#eee6ff]"
            >
              {PIXEL_AVATAR_OPTIONS.map((opt) => (
                <option key={opt.key} value={opt.key}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="set-bio" className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1">
              EDIT BIOGRAPHY:
            </label>
            <textarea
              id="set-bio"
              rows={3}
              maxLength={160}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="win-inset w-full p-2.5 text-[#eee6ff]"
            />
          </div>

          <FlagPicker selectedFlags={flags} onChange={setFlags} />

          <button type="submit" className="win-btn win-btn-primary px-4 py-2 text-xs">
            SAVE PFP, BIO &amp; FLAGS
          </button>
        </form>
      </div>

      <div className="bg-[#120c1c] border border-[#4e2d82] p-4 space-y-3">
        <div className="font-pixel-ui text-sm text-[#c8b4f8] border-b border-[#4e2d82] pb-2">
          &gt;&gt; DISPLAY_&amp;_SYSTEM_CONTROLS
        </div>

        <div className="flex items-center justify-between">
          <div>
            <div className="text-base text-[#eee6ff]">CRT Scanlines &amp; Vignette</div>
            <div className="text-xs text-[#a690d6]">Toggle retro monitor scanline filter</div>
          </div>
          <button type="button" onClick={onToggleCrt} className="win-btn px-3 py-1.5 text-xs">
            {crtEnabled ? 'ON' : 'OFF'}
          </button>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-[#2a1746]">
          <div>
            <div className="text-base text-[#eee6ff]">Strict Bitmap Pixel Font</div>
            <div className="text-xs text-[#a690d6]">
              Switch between VT323 terminal and Silkscreen pixel text
            </div>
          </div>
          <button
            type="button"
            onClick={onToggleStrictPixelFont}
            className="win-btn px-3 py-1.5 text-xs"
          >
            {strictPixelFont ? 'SILKSCREEN' : 'VT323'}
          </button>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-[#2a1746]">
          <div>
            <div className="text-base text-[#eee6ff]">Color / Theme Editor</div>
            <div className="text-xs text-[#a690d6]">
              Customize CSS variable overrides and save to your account
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenThemeEditor}
            className="win-btn win-btn-primary px-3 py-1.5 text-xs"
          >
            OPEN EDITOR &gt;&gt;
          </button>
        </div>

        <div className="pt-3 border-t border-[#2a1746] flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs text-[#a690d6]">
            Wipe all accounts, posts, forum boards, and messages from this browser:
          </div>
          <button
            type="button"
            onClick={onWipeLocalData}
            className="win-btn px-3 py-1.5 text-xs text-[#ff6bd6]"
          >
            WIPE LOCAL DATA
          </button>
        </div>
      </div>
    </div>
  );
};
