import React, { useCallback, useEffect, useRef, useState } from 'react';
import { BarutBadge } from '../components/BarutBadge';
import { AvatarBox } from '../components/RetroMedia';
import { ShortsPlayerCard } from '../components/ShortsPlayerCard';
import { UserAccount, UserRole } from '../types/lostroom';
import {
  CreatorProfileSummary,
  SHORT_CATEGORIES,
  SHORT_PLAYER_SKINS,
  ShortCategory,
  ShortPlayerSkin,
  ShortReportRecord,
  ShortVideoRecord,
  ShortVisibility,
} from '../types/shorts';
import { formatBytes, uploadImageAsset } from '../utils/homepageApi';
import {
  blockCreator,
  deleteShortVideo,
  getCreatorShortsProfile,
  getUserSafetyState,
  listShortHashtags,
  listShortReports,
  listShorts,
  reportShortVideo,
  resolveShortReport,
  ShortsFeedTab,
  toggleFollowCreator,
  toggleShortLike,
  toggleShortSave,
  unblockCreator,
  updateShortVideo,
  uploadShortVideoWithProgress,
} from '../utils/shortsApi';

type ShortsSubView =
  | 'feed'
  | 'trending'
  | 'newest'
  | 'following'
  | 'saved'
  | 'discover'
  | 'upload'
  | 'safety';

interface ShortsPageProps {
  currentUsername: string | null;
  users: Record<string, UserAccount>;
  rolesMap?: Record<string, UserRole>;
  postingEnabled?: boolean;
  commentsEnabled?: boolean;
  onOpenPublicUrl: (path: string) => void;
  onNavigateAuth: () => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const ShortsPage: React.FC<ShortsPageProps> = ({
  currentUsername,
  users,
  rolesMap,
  postingEnabled = true,
  commentsEnabled = true,
  onOpenPublicUrl,
  onNavigateAuth,
  onToast,
}) => {
  const [subView, setSubView] = useState<ShortsSubView>('feed');
  const [shorts, setShorts] = useState<ShortVideoRecord[]>([]);
  const [loading, setLoading] = useState(false);

  const [activeIndex, setActiveIndex] = useState(0);
  const [muted, setMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [viewerSkinOverride, setViewerSkinOverride] = useState<ShortPlayerSkin | null>(null);

  // Discovery / Filtering state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ShortCategory>('All');
  const [activeTag, setActiveTag] = useState<string>('');
  const [hashtags, setHashtags] = useState<{ tag: string; count: number }[]>([]);

  // Creator Profile Modal/Drawer state
  const [activeCreatorUsername, setActiveCreatorUsername] = useState<string | null>(null);
  const [creatorProfile, setCreatorProfile] = useState<CreatorProfileSummary | null>(null);
  const [creatorLoading, setCreatorLoading] = useState(false);

  // Upload Form State
  const [videoFile, setVideoFile] = useState<File | null>(null);
  const [videoPreviewUrl, setVideoPreviewUrl] = useState<string>('');
  const [title, setTitle] = useState('');
  const [caption, setCaption] = useState('');
  const [hashtagsInput, setHashtagsInput] = useState('');
  const [category, setCategory] = useState<Exclude<ShortCategory, 'All'>>('Vlog & Daily');
  const [visibility, setVisibility] = useState<ShortVisibility>('public');
  const [playerSkin, setPlayerSkin] = useState<ShortPlayerSkin>('y2k_lavender');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [thumbUploading, setThumbUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<number | null>(null);
  const [uploading, setUploading] = useState(false);

  // Safety & Moderation State
  const [blockedUsers, setBlockedUsers] = useState<string[]>([]);
  const [videoBytesUsed, setVideoBytesUsed] = useState(0);
  const [videoQuotaBytes, setVideoQuotaBytes] = useState(200 * 1024 * 1024);
  const [reports, setReports] = useState<ShortReportRecord[]>([]);
  const [safetyLoading, setSafetyLoading] = useState(false);

  const feedContainerRef = useRef<HTMLDivElement | null>(null);
  const slideRefs = useRef<(HTMLDivElement | null)[]>([]);
  const uploadPreviewVideoRef = useRef<HTMLVideoElement | null>(null);
  const onToastRef = useRef(onToast);
  onToastRef.current = onToast;

  const fetchShortsFeed = useCallback(async () => {
    const tabForQuery: ShortsFeedTab =
      subView === 'trending' ||
      subView === 'newest' ||
      subView === 'following' ||
      subView === 'saved'
        ? subView
        : 'feed';

    setLoading(true);
    try {
      const res = await listShorts({
        viewer: currentUsername,
        tab: tabForQuery,
        q: subView === 'discover' ? searchQuery.trim() : undefined,
        tag: activeTag || undefined,
        category: selectedCategory !== 'All' ? selectedCategory : undefined,
      });
      setShorts(res.shorts);
      setActiveIndex(0);
    } catch (err) {
      onToastRef.current(err instanceof Error ? err.message : 'Failed to load shorts.', 'error');
    } finally {
      setLoading(false);
    }
  }, [subView, currentUsername, searchQuery, activeTag, selectedCategory]);

  const fetchHashtags = useCallback(async () => {
    try {
      const res = await listShortHashtags(currentUsername);
      setHashtags(res.hashtags);
    } catch {
      // ignore
    }
  }, [currentUsername]);

  const fetchSafetyCenter = useCallback(async () => {
    setSafetyLoading(true);
    try {
      const [reportsRes, safetyRes] = await Promise.all([
        listShortReports(),
        currentUsername ? getUserSafetyState(currentUsername) : Promise.resolve(null),
      ]);
      setReports(reportsRes.reports);
      if (safetyRes) {
        setBlockedUsers(safetyRes.blockedUsers);
        setVideoBytesUsed(safetyRes.videoBytesUsed);
        setVideoQuotaBytes(safetyRes.videoQuotaBytes);
      }
    } catch (err) {
      onToastRef.current(
        err instanceof Error ? err.message : 'Failed to load safety center.',
        'error'
      );
    } finally {
      setSafetyLoading(false);
    }
  }, [currentUsername]);

  useEffect(() => {
    if (
      subView === 'feed' ||
      subView === 'trending' ||
      subView === 'newest' ||
      subView === 'following' ||
      subView === 'saved' ||
      subView === 'discover'
    ) {
      fetchShortsFeed();
    }
    if (subView === 'discover' || subView === 'feed') {
      fetchHashtags();
    }
    if (subView === 'safety') {
      fetchSafetyCenter();
    }
  }, [subView, fetchShortsFeed, fetchHashtags, fetchSafetyCenter]);

  // IntersectionObserver for snap-scroll auto play/pause & preload next
  useEffect(() => {
    const container = feedContainerRef.current;
    if (!container || shorts.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
            const idxAttr = entry.target.getAttribute('data-index');
            if (idxAttr !== null) {
              const parsed = Number(idxAttr);
              if (Number.isFinite(parsed)) {
                setActiveIndex(parsed);
              }
            }
          }
        }
      },
      {
        root: container,
        threshold: [0.65],
      }
    );

    slideRefs.current.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, [shorts]);

  const scrollToSlide = useCallback(
    (nextIdx: number) => {
      if (shorts.length === 0) return;
      const clamped = Math.max(0, Math.min(shorts.length - 1, nextIdx));
      setActiveIndex(clamped);
      const targetEl = slideRefs.current[clamped];
      if (targetEl) {
        targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    },
    [shorts.length]
  );

  // Keyboard ArrowUp / ArrowDown navigation in feed or fullscreen
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (subView === 'upload' || subView === 'safety') return;
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        scrollToSlide(activeIndex + 1);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        scrollToSlide(activeIndex - 1);
      } else if (e.key === 'Escape' && isFullscreen) {
        setIsFullscreen(false);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [subView, activeIndex, isFullscreen, scrollToSlide]);

  // Cleanup local preview blob URL
  useEffect(() => {
    return () => {
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    };
  }, [videoPreviewUrl]);

  const handleOpenCreatorProfile = async (username: string) => {
    setActiveCreatorUsername(username);
    setCreatorLoading(true);
    try {
      const res = await getCreatorShortsProfile(username, currentUsername);
      setCreatorProfile(res.profile);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to open creator profile.', 'error');
      setActiveCreatorUsername(null);
    } finally {
      setCreatorLoading(false);
    }
  };

  const handleLike = async (shortId: string) => {
    if (!currentUsername) {
      onToast('Log in to like short videos.', 'error');
      return;
    }
    try {
      const res = await toggleShortLike(shortId, currentUsername);
      setShorts((prev) => prev.map((s) => (s.id === shortId ? res.short : s)));
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to update like.', 'error');
    }
  };

  const handleSave = async (shortId: string) => {
    if (!currentUsername) {
      onToast('Log in to save short videos.', 'error');
      return;
    }
    try {
      const res = await toggleShortSave(shortId, currentUsername);
      setShorts((prev) => prev.map((s) => (s.id === shortId ? res.short : s)));
      const saved = res.short.savedBy.includes(currentUsername);
      onToast(saved ? 'Saved to your SHORTS bookmarks!' : 'Removed from saved shorts.');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to save short.', 'error');
    }
  };

  const handleFollow = async (authorUsername: string) => {
    if (!currentUsername) {
      onToast('Log in to follow creators.', 'error');
      return;
    }
    try {
      const res = await toggleFollowCreator(authorUsername, currentUsername);
      setShorts((prev) =>
        prev.map((s) =>
          s.authorUsername === authorUsername
            ? { ...s, isFollowingAuthor: res.isFollowing, authorFollowerCount: res.followerCount }
            : s
        )
      );
      if (creatorProfile && creatorProfile.username === authorUsername) {
        setCreatorProfile({
          ...creatorProfile,
          isFollowing: res.isFollowing,
          followerCount: res.followerCount,
        });
      }
      onToast(res.isFollowing ? `Following @${authorUsername}` : `Unfollowed @${authorUsername}`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Follow action failed.', 'error');
    }
  };

  const handleShare = async (short: ShortVideoRecord) => {
    const shareUrl = `${window.location.origin}/shorts/${encodeURIComponent(short.id)}`;
    try {
      if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(shareUrl);
        onToast(`Copied share link: /shorts/${short.id}`);
      } else {
        onOpenPublicUrl(`/shorts/${short.id}`);
      }
    } catch {
      onOpenPublicUrl(`/shorts/${short.id}`);
    }
  };

  const handleBlockCreator = async (authorUsername: string) => {
    if (!currentUsername) {
      onToast('Log in to block users.', 'error');
      return;
    }
    try {
      await blockCreator(authorUsername, currentUsername);
      setShorts((prev) => prev.filter((s) => s.authorUsername !== authorUsername));
      if (creatorProfile && creatorProfile.username === authorUsername) {
        setActiveCreatorUsername(null);
        setCreatorProfile(null);
      }
      onToast(`Blocked @${authorUsername}. Their shorts are hidden from your feed.`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Block failed.', 'error');
    }
  };

  const handleUnblockCreator = async (target: string) => {
    if (!currentUsername) return;
    try {
      await unblockCreator(target, currentUsername);
      setBlockedUsers((prev) => prev.filter((u) => u !== target));
      onToast(`Unblocked @${target}.`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to unblock user.', 'error');
    }
  };

  const handleReportSubmit = async (shortId: string, reason: string, details: string) => {
    if (!currentUsername) {
      onToast('Log in to submit a report.', 'error');
      return;
    }
    try {
      await reportShortVideo(shortId, { username: currentUsername, reason, details });
      onToast('Report submitted to Moderation Queue.');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Report failed.', 'error');
    }
  };

  const handleDeleteShort = async (shortId: string) => {
    if (!currentUsername) return;
    try {
      await deleteShortVideo(shortId, currentUsername);
      setShorts((prev) => prev.filter((s) => s.id !== shortId));
      onToast('Short video permanently deleted.');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Delete failed.', 'error');
    }
  };

  const handleChangeVisibility = async (shortId: string, nextVis: ShortVisibility) => {
    if (!currentUsername) return;
    try {
      const res = await updateShortVideo(shortId, {
        username: currentUsername,
        visibility: nextVis,
      });
      setShorts((prev) => prev.map((s) => (s.id === shortId ? res.short : s)));
      onToast(`Privacy set to ${nextVis.toUpperCase()}.`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Failed to update privacy.', 'error');
    }
  };

  const handleSelectVideoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    const allowedExt = ['mp4', 'webm', 'ogv', 'ogg', 'mov'];
    if (!file.type.startsWith('video/') && !allowedExt.includes(ext)) {
      onToast('Unsupported format. Upload MP4, WEBM, OGV, or MOV video.', 'error');
      return;
    }
    if (file.size > 45 * 1024 * 1024) {
      onToast('Video exceeds 45 MB limit.', 'error');
      return;
    }
    if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
    setVideoFile(file);
    setVideoPreviewUrl(URL.createObjectURL(file));
    if (!title.trim()) {
      setTitle(file.name.replace(/\.[^/.]+$/, '').slice(0, 60));
    }
  };

  const handleUploadThumbnailFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUsername) return;
    setThumbUploading(true);
    try {
      const res = await uploadImageAsset(file, currentUsername, 'cover');
      setThumbnailUrl(res.asset.url);
      onToast('Thumbnail uploaded!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Thumbnail upload failed.', 'error');
    } finally {
      setThumbUploading(false);
    }
  };

  const handleCaptureFrameThumbnail = async () => {
    const vid = uploadPreviewVideoRef.current;
    if (!vid || !currentUsername) {
      onToast('Load a video preview first.', 'error');
      return;
    }
    if (vid.videoWidth === 0 || vid.videoHeight === 0) {
      onToast('Wait for video frame to load before capturing thumbnail.', 'error');
      return;
    }
    setThumbUploading(true);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = vid.videoWidth;
      canvas.height = vid.videoHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Canvas unavailable');
      ctx.drawImage(vid, 0, 0, canvas.width, canvas.height);
      const blob = await new Promise<Blob | null>((resolve) =>
        canvas.toBlob(resolve, 'image/png', 0.9)
      );
      if (!blob) throw new Error('Failed to capture frame.');
      const thumbFile = new File([blob], `short_thumb_${Date.now()}.png`, { type: 'image/png' });
      const res = await uploadImageAsset(thumbFile, currentUsername, 'cover');
      setThumbnailUrl(res.asset.url);
      onToast('Captured current video frame as thumbnail!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Frame capture failed.', 'error');
    } finally {
      setThumbUploading(false);
    }
  };

  const handleUploadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUsername) {
      onToast('Please log in to upload shorts.', 'error');
      return;
    }
    if (!videoFile) {
      onToast('Choose a video file (.mp4, .webm, .mov, .ogv) first.', 'error');
      return;
    }
    if (!title.trim()) {
      onToast('Enter a video title.', 'error');
      return;
    }

    setUploading(true);
    setUploadProgress(0);
    try {
      const res = await uploadShortVideoWithProgress(
        videoFile,
        {
          username: currentUsername,
          title: title.trim(),
          caption: caption.trim(),
          category,
          hashtags: hashtagsInput.trim(),
          thumbnailUrl,
          visibility,
          playerSkin,
        },
        (pct) => setUploadProgress(pct)
      );
      onToast(`Published "${res.short.title}" to SHORTyes!`);
      setVideoFile(null);
      if (videoPreviewUrl) URL.revokeObjectURL(videoPreviewUrl);
      setVideoPreviewUrl('');
      setTitle('');
      setCaption('');
      setHashtagsInput('');
      setThumbnailUrl('');
      setUploadProgress(null);
      setActiveTag('');
      setSelectedCategory('All');
      setSubView('newest');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Upload failed.', 'error');
    } finally {
      setUploading(false);
    }
  };

  const handleResolveReport = async (reportId: string, action: 'dismiss' | 'remove') => {
    try {
      await resolveShortReport(reportId, action);
      setReports((prev) =>
        prev.map((r) =>
          r.id === reportId
            ? { ...r, status: action === 'remove' ? 'removed' : 'dismissed' }
            : r
        )
      );
      onToast(
        action === 'remove'
          ? 'Video removed from public feeds.'
          : 'Report dismissed.'
      );
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Moderation action failed.', 'error');
    }
  };

  const isFeedLikeView =
    subView === 'feed' ||
    subView === 'trending' ||
    subView === 'newest' ||
    subView === 'following' ||
    subView === 'saved';

  return (
    <div className="space-y-3">
      {/* Header Banner */}
      <div className="win-inset p-3 flex flex-wrap items-center justify-between gap-2 bg-[var(--bg-void)]">
        <div>
          <div className="font-pixel-title text-xs sm:text-sm text-[#52ff94] flex items-center gap-2">
            <span>▶ SHORTyes // VERTICAL SHORT VIDEO PLATFORM</span>
          </div>
          <p className="text-sm text-[var(--accent-lavender)] mt-0.5">
            Retro vertical video stream, real MP4/WEBM uploads, customizable Y2K skins &amp; creator safety tools.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <select
            value={viewerSkinOverride || 'auto'}
            onChange={(e) =>
              setViewerSkinOverride(
                e.target.value === 'auto' ? null : (e.target.value as ShortPlayerSkin)
              )
            }
            className="win-inset px-2 py-1 text-xs text-white"
            title="Player Skin Override"
          >
            <option value="auto">SKIN: CREATOR CHOICE</option>
            {(Object.keys(SHORT_PLAYER_SKINS) as ShortPlayerSkin[]).map((k) => (
              <option key={k} value={k}>
                SKIN: {SHORT_PLAYER_SKINS[k].label}
              </option>
            ))}
          </select>

          <button
            type="button"
            onClick={() => setMuted((m) => !m)}
            className="win-btn px-2.5 py-1 text-xs"
          >
            {muted ? 'MUTED' : 'SOUND ON'}
          </button>

          {isFeedLikeView && shorts.length > 0 && (
            <button
              type="button"
              onClick={() => setIsFullscreen(true)}
              className="win-btn win-btn-primary px-2.5 py-1 text-xs"
            >
              FULLSCREEN FEED
            </button>
          )}
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex flex-wrap gap-1.5">
        {(
          [
            { id: 'feed', label: 'FOR YOU FEED' },
            { id: 'trending', label: 'TRENDING' },
            { id: 'newest', label: 'NEWEST' },
            { id: 'following', label: 'FOLLOWING' },
            { id: 'saved', label: 'SAVED' },
            { id: 'discover', label: 'DISCOVER / TAGS' },
            { id: 'upload', label: '+ UPLOAD SHORT' },
            { id: 'safety', label: 'SAFETY & MOD' },
          ] as { id: ShortsSubView; label: string }[]
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => {
              setActiveCreatorUsername(null);
              setSubView(tab.id);
            }}
            className={`win-btn px-2.5 py-1.5 text-xs ${
              subView === tab.id && !activeCreatorUsername
                ? 'win-btn-primary'
                : tab.id === 'upload'
                  ? 'text-[#52ff94]'
                  : ''
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Active Filters Banner */}
      {(activeTag || selectedCategory !== 'All') && (
        <div className="win-box p-2 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex flex-wrap items-center gap-2">
            <span className="font-pixel-ui text-[10px] text-[var(--accent-lavender)]">
              ACTIVE FILTERS:
            </span>
            {activeTag && (
              <span className="bg-[var(--bg-royal)] border border-[#52ff94] px-2 py-0.5 text-[#52ff94] font-pixel-ui text-[10px]">
                #{activeTag}
              </span>
            )}
            {selectedCategory !== 'All' && (
              <span className="bg-[var(--bg-royal)] border border-[#ff6bd6] px-2 py-0.5 text-[#ff6bd6] font-pixel-ui text-[10px]">
                CATEGORY: {selectedCategory}
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={() => {
              setActiveTag('');
              setSelectedCategory('All');
            }}
            className="win-btn px-2 py-0.5 text-[10px]"
          >
            CLEAR FILTERS
          </button>
        </div>
      )}

      {/* CREATOR PROFILE VIEW */}
      {activeCreatorUsername && (
        <div className="win-box p-3 space-y-3">
          <div className="flex items-center justify-between gap-2 border-b border-[var(--bg-royal)] pb-2">
            <span className="font-pixel-ui text-xs text-[#52ff94]">
              CREATOR_PROFILE // @{activeCreatorUsername}
            </span>
            <button
              type="button"
              onClick={() => {
                setActiveCreatorUsername(null);
                setCreatorProfile(null);
              }}
              className="win-btn px-2 py-0.5 text-[10px]"
            >
              CLOSE PROFILE
            </button>
          </div>

          {creatorLoading || !creatorProfile ? (
            <div className="p-4 text-sm text-[var(--text-muted)]">Loading creator channel...</div>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-3 bg-[var(--bg-void)] p-3 border border-[var(--bevel-mid)]">
                <div className="flex items-center gap-3">
                  <AvatarBox
                    user={
                      users[creatorProfile.username] || {
                        username: creatorProfile.username,
                        password: '',
                        avatarType: creatorProfile.avatarUrl ? 'custom' : 'preset',
                        avatarValue: creatorProfile.avatarUrl || 'cat_void',
                        bio: creatorProfile.bio,
                        joined: '',
                      }
                    }
                    sizeClass="w-14 h-14"
                  />
                  <div>
                    <div className="font-pixel-ui text-sm text-white flex items-center gap-2 flex-wrap">
                      <span>@{creatorProfile.username}</span>
                      <BarutBadge username={creatorProfile.username} rolesMap={rolesMap} />
                    </div>
                    <p className="text-sm text-[var(--accent-lavender)]">
                      {creatorProfile.bio || 'No bio set.'}
                    </p>
                    <div className="text-xs text-[var(--text-muted)] mt-1 flex gap-3">
                      <span>
                        <strong className="text-[#52ff94]">{creatorProfile.followerCount}</strong>{' '}
                        followers
                      </span>
                      <span>
                        <strong className="text-white">{creatorProfile.followingCount}</strong>{' '}
                        following
                      </span>
                      <span>
                        <strong className="text-[#ff6bd6]">{creatorProfile.videos.length}</strong>{' '}
                        shorts
                      </span>
                    </div>
                  </div>
                </div>

                {currentUsername !== creatorProfile.username && (
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleFollow(creatorProfile.username)}
                      className={`win-btn px-3 py-1.5 text-xs ${
                        creatorProfile.isFollowing ? '' : 'win-btn-primary'
                      }`}
                    >
                      {creatorProfile.isFollowing ? 'FOLLOWING' : '+ FOLLOW'}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleBlockCreator(creatorProfile.username)}
                      className="win-btn px-3 py-1.5 text-xs text-[#ff6bd6]"
                    >
                      BLOCK USER
                    </button>
                  </div>
                )}
              </div>

              {creatorProfile.videos.length === 0 ? (
                <div className="win-inset p-4 text-center text-sm text-[var(--text-muted)]">
                  No accessible shorts uploaded by @{creatorProfile.username} yet.
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {creatorProfile.videos.map((v) => (
                    <div
                      key={v.id}
                      className="bg-[var(--bg-void)] border-2 border-[var(--bevel-mid)] p-2 space-y-2"
                    >
                      <div className="aspect-[9/12] bg-black overflow-hidden relative flex items-center justify-center">
                        {v.thumbnailUrl ? (
                          <img
                            src={v.thumbnailUrl}
                            alt={v.title}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <video
                            src={v.videoUrl}
                            muted
                            preload="metadata"
                            className="w-full h-full object-cover"
                          />
                        )}
                        <span className="absolute top-1.5 right-1.5 bg-black/80 px-1.5 py-0.5 text-[10px] font-pixel-ui text-[#52ff94]">
                          {v.views} views
                        </span>
                      </div>
                      <div className="font-pixel-ui text-xs text-white truncate">{v.title}</div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-[11px] text-[var(--text-muted)]">{v.category}</span>
                        <button
                          type="button"
                          onClick={() => onOpenPublicUrl(`/shorts/${v.id}`)}
                          className="win-btn win-btn-primary px-2.5 py-1 text-[10px]"
                        >
                          WATCH SHORT
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* DISCOVER / SEARCH / HASHTAGS / CATEGORIES */}
      {!activeCreatorUsername && subView === 'discover' && (
        <div className="space-y-3">
          <div className="win-box p-3 space-y-2.5">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                fetchShortsFeed();
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search short videos, titles, #hashtags, or @creators..."
                className="flex-1 win-inset px-2.5 py-1.5 text-white text-sm"
              />
              <button type="submit" className="win-btn win-btn-primary px-3 py-1.5 text-xs">
                SEARCH
              </button>
            </form>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1.5">
              {(['All', ...SHORT_CATEGORIES] as ShortCategory[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`win-btn px-2 py-1 text-[11px] ${
                    selectedCategory === cat ? 'win-btn-primary' : ''
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>

            {/* Trending Hashtags */}
            {hashtags.length > 0 && (
              <div className="pt-1 border-t border-[var(--bg-royal)]">
                <div className="font-pixel-ui text-[10px] text-[var(--accent-lavender)] mb-1.5">
                  TRENDING HASHTAG PAGES:
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {hashtags.map((h) => (
                    <button
                      key={h.tag}
                      type="button"
                      onClick={() => {
                        setActiveTag(h.tag);
                        setSubView('feed');
                      }}
                      className="win-btn px-2 py-0.5 text-[11px] text-[#52ff94]"
                    >
                      #{h.tag} ({h.count})
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Discovery Results Grid */}
          {loading ? (
            <div className="win-inset p-4 text-center text-sm text-[var(--text-muted)]">
              Searching SHORTS database...
            </div>
          ) : shorts.length === 0 ? (
            <div className="win-inset p-6 text-center text-sm text-[var(--text-muted)]">
              No matching short videos found. Upload the first clip in this category!
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {shorts.map((item, idx) => (
                <div
                  key={item.id}
                  className="win-box p-2.5 flex flex-col justify-between gap-2"
                >
                  <div className="aspect-[9/12] bg-black overflow-hidden relative flex items-center justify-center">
                    {item.thumbnailUrl ? (
                      <img
                        src={item.thumbnailUrl}
                        alt={item.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <video
                        src={item.videoUrl}
                        muted
                        preload="metadata"
                        className="w-full h-full object-cover"
                      />
                    )}
                    <div className="absolute bottom-1.5 left-1.5 right-1.5 flex items-center justify-between text-[10px] font-pixel-ui bg-black/80 px-1.5 py-0.5">
                      <span className="text-[#52ff94]">@{item.authorUsername}</span>
                      <span className="text-white">{item.views} views</span>
                    </div>
                  </div>
                  <div>
                    <div className="font-pixel-ui text-xs text-white truncate">{item.title}</div>
                    <div className="text-xs text-[var(--text-muted)] truncate">
                      {item.caption || item.category}
                    </div>
                  </div>
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setSubView('feed');
                        setTimeout(() => scrollToSlide(idx), 60);
                      }}
                      className="flex-1 win-btn win-btn-primary py-1 text-[10px]"
                    >
                      PLAY IN FEED
                    </button>
                    <button
                      type="button"
                      onClick={() => handleOpenCreatorProfile(item.authorUsername)}
                      className="win-btn px-2 py-1 text-[10px]"
                    >
                      CREATOR
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* VIDEO UPLOAD WORKBENCH */}
      {!activeCreatorUsername && subView === 'upload' && (
        <div className="win-box p-3 sm:p-4 space-y-3">
          <div className="font-pixel-ui text-xs text-[#52ff94] border-b border-[var(--bg-royal)] pb-2">
            UPLOAD SHORT VIDEO // PERSISTENT SERVER STORAGE
          </div>

          {!currentUsername ? (
            <div className="win-inset p-4 text-center space-y-2">
              <p className="text-sm text-[var(--accent-lavender)]">
                Log in or register an account to upload short videos.
              </p>
              <button
                type="button"
                onClick={onNavigateAuth}
                className="win-btn win-btn-primary px-4 py-1.5 text-xs"
              >
                GO TO PORTAL GATE
              </button>
            </div>
          ) : !postingEnabled ? (
            <div className="win-inset p-4 text-center space-y-2 border border-[#ff6bd6]">
              <div className="font-pixel-ui text-xs text-[#ff6bd6]">
                VIDEO UPLOADS TEMPORARILY PAUSED (GOD MODE)
              </div>
              <p className="text-sm text-[var(--accent-lavender)]">
                Super Admin has paused posting &amp; uploads temporarily. Existing shorts remain safe.
              </p>
            </div>
          ) : (
            <form onSubmit={handleUploadSubmit} className="space-y-3">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {/* Left Column: Video File + Preview + Thumbnail */}
                <div className="space-y-2.5">
                  <div className="win-inset p-2.5 space-y-2">
                    <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)]">
                      1. VIDEO FILE (MP4, WEBM, OGV, MOV — MAX 45 MB)
                    </label>
                    <input
                      type="file"
                      accept="video/mp4,video/webm,video/ogg,video/quicktime,.mp4,.webm,.ogv,.mov"
                      onChange={handleSelectVideoFile}
                      className="w-full text-xs text-white"
                    />
                    {videoFile && (
                      <div className="text-xs text-[#52ff94]">
                        Selected: {videoFile.name} ({formatBytes(videoFile.size)})
                      </div>
                    )}
                  </div>

                  {videoPreviewUrl && (
                    <div className="bg-black border-2 border-[var(--bevel-mid)] p-1.5 space-y-2">
                      <video
                        ref={uploadPreviewVideoRef}
                        src={videoPreviewUrl}
                        controls
                        className="w-full max-h-64 object-contain bg-black"
                      />
                      <button
                        type="button"
                        disabled={thumbUploading}
                        onClick={handleCaptureFrameThumbnail}
                        className="w-full win-btn py-1 text-[10px] text-[#52ff94]"
                      >
                        {thumbUploading
                          ? 'CAPTURING THUMBNAIL...'
                          : 'CAPTURE CURRENT VIDEO FRAME AS THUMBNAIL'}
                      </button>
                    </div>
                  )}

                  {/* Custom Thumbnail Picker */}
                  <div className="win-inset p-2.5 space-y-2">
                    <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)]">
                      2. VIDEO THUMBNAIL (OPTIONAL)
                    </label>
                    <input
                      type="file"
                      accept="image/png,image/jpeg,image/gif,image/webp"
                      onChange={handleUploadThumbnailFile}
                      disabled={thumbUploading}
                      className="w-full text-xs text-white"
                    />
                    {thumbnailUrl && (
                      <div className="flex items-center gap-2">
                        <img
                          src={thumbnailUrl}
                          alt="Selected thumbnail"
                          className="w-16 h-20 object-cover border border-[#52ff94]"
                        />
                        <button
                          type="button"
                          onClick={() => setThumbnailUrl('')}
                          className="win-btn px-2 py-1 text-[10px] text-[#ff6bd6]"
                        >
                          REMOVE THUMB
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Right Column: Metadata, Privacy & Retro Skin */}
                <div className="space-y-2.5">
                  <div>
                    <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)] mb-1">
                      TITLE *
                    </label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      maxLength={90}
                      placeholder="Give your short video a title..."
                      className="w-full win-inset px-2.5 py-1.5 text-white text-sm"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)] mb-1">
                      CAPTION / DESCRIPTION
                    </label>
                    <textarea
                      value={caption}
                      onChange={(e) => setCaption(e.target.value)}
                      rows={3}
                      maxLength={400}
                      placeholder="Describe your clip..."
                      className="w-full win-inset px-2.5 py-1.5 text-white text-sm"
                    />
                  </div>

                  <div>
                    <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)] mb-1">
                      HASHTAGS (SPACE OR COMMA SEPARATED)
                    </label>
                    <input
                      type="text"
                      value={hashtagsInput}
                      onChange={(e) => setHashtagsInput(e.target.value)}
                      placeholder="#y2k #retro #gaming"
                      className="w-full win-inset px-2.5 py-1.5 text-white text-sm"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)] mb-1">
                        CATEGORY
                      </label>
                      <select
                        value={category}
                        onChange={(e) =>
                          setCategory(e.target.value as Exclude<ShortCategory, 'All'>)
                        }
                        className="w-full win-inset px-2 py-1.5 text-white text-xs"
                      >
                        {SHORT_CATEGORIES.map((c) => (
                          <option key={c} value={c}>
                            {c}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)] mb-1">
                        PRIVACY
                      </label>
                      <select
                        value={visibility}
                        onChange={(e) => setVisibility(e.target.value as ShortVisibility)}
                        className="w-full win-inset px-2 py-1.5 text-white text-xs"
                      >
                        <option value="public">Public (Everyone)</option>
                        <option value="followers">Followers Only</option>
                        <option value="private">Private (Only Me)</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-pixel-ui text-[10px] text-[var(--accent-lavender)] mb-1">
                      RETRO PLAYER SKIN
                    </label>
                    <select
                      value={playerSkin}
                      onChange={(e) => setPlayerSkin(e.target.value as ShortPlayerSkin)}
                      className="w-full win-inset px-2 py-1.5 text-white text-xs"
                    >
                      {(Object.keys(SHORT_PLAYER_SKINS) as ShortPlayerSkin[]).map((k) => (
                        <option key={k} value={k}>
                          {SHORT_PLAYER_SKINS[k].label}
                        </option>
                      ))}
                    </select>
                  </div>

                  {uploadProgress !== null && (
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs font-pixel-ui text-[#52ff94]">
                        <span>UPLOADING VIDEO TO SERVER...</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <div className="w-full h-3 bg-black border border-[#52ff94]">
                        <div
                          className="h-full bg-[#52ff94] transition-all duration-150"
                          style={{ width: `${uploadProgress}%` }}
                        />
                      </div>
                    </div>
                  )}

                  <button
                    type="submit"
                    disabled={uploading || thumbUploading || !videoFile}
                    className="w-full win-btn win-btn-primary py-2 text-xs font-bold"
                  >
                    {uploading ? `UPLOADING (${uploadProgress || 0}%)...` : 'PUBLISH SHORT VIDEO'}
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      )}

      {/* SAFETY & MODERATION CENTER */}
      {!activeCreatorUsername && subView === 'safety' && (
        <div className="space-y-3">
          {currentUsername && (
            <div className="win-box p-3 space-y-2">
              <div className="font-pixel-ui text-xs text-[#52ff94]">
                ACCOUNT STORAGE QUOTA &amp; ANTI-SPAM LIMITS
              </div>
              <div className="text-sm text-[var(--accent-lavender)]">
                Video Storage Used:{' '}
                <strong className="text-white">{formatBytes(videoBytesUsed)}</strong> /{' '}
                {formatBytes(videoQuotaBytes)}
              </div>
              <div className="w-full h-3 bg-black border border-[var(--bevel-mid)]">
                <div
                  className="h-full bg-[#52ff94]"
                  style={{
                    width: `${Math.min(100, (videoBytesUsed / videoQuotaBytes) * 100)}%`,
                  }}
                />
              </div>
              <ul className="text-xs text-[var(--text-muted)] list-disc pl-5 space-y-0.5">
                <li>Upload limit: 45 MB per short video (.mp4, .webm, .ogv, .mov).</li>
                <li>Anti-spam protection: maximum 6 video uploads per 5 minutes &amp; throttled commenting.</li>
                <li>Privacy enforcement: Private and Followers-Only shorts are filtered server-side.</li>
              </ul>
            </div>
          )}

          {/* Blocked Creators List */}
          <div className="win-box p-3 space-y-2">
            <div className="font-pixel-ui text-xs text-[#ff6bd6]">
              BLOCKED CREATORS ({blockedUsers.length})
            </div>
            {!currentUsername ? (
              <div className="text-xs text-[var(--text-muted)]">
                Log in to manage your blocked creators list.
              </div>
            ) : blockedUsers.length === 0 ? (
              <div className="text-xs text-[var(--text-muted)]">
                You have not blocked any creators.
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {blockedUsers.map((bu) => (
                  <div
                    key={bu}
                    className="win-inset px-2.5 py-1 flex items-center gap-2 text-xs text-white"
                  >
                    <span>@{bu}</span>
                    <button
                      type="button"
                      onClick={() => handleUnblockCreator(bu)}
                      className="win-btn px-1.5 py-0.5 text-[10px] text-[#52ff94]"
                    >
                      UNBLOCK
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Content Moderation Reports Queue */}
          <div className="win-box p-3 space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-pixel-ui text-xs text-white">
                MODERATION REPORTS QUEUE ({reports.length})
              </span>
              <button
                type="button"
                onClick={fetchSafetyCenter}
                className="win-btn px-2 py-0.5 text-[10px]"
              >
                REFRESH
              </button>
            </div>

            {safetyLoading ? (
              <div className="text-xs text-[var(--text-muted)]">Loading reports...</div>
            ) : reports.length === 0 ? (
              <div className="win-inset p-3 text-xs text-[var(--text-muted)]">
                No reported short videos in the queue.
              </div>
            ) : (
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {reports.map((rep) => (
                  <div
                    key={rep.id}
                    className="win-inset p-2.5 flex flex-wrap items-center justify-between gap-2 text-xs"
                  >
                    <div className="space-y-0.5">
                      <div className="font-pixel-ui text-[11px] text-white">
                        {rep.shortTitle || rep.shortId}{' '}
                        <span className="text-[var(--text-muted)]">by @{rep.shortAuthor}</span>
                      </div>
                      <div className="text-[#ff6bd6]">
                        Reason: {rep.reason}{' '}
                        {rep.details && <span className="text-white/80">— {rep.details}</span>}
                      </div>
                      <div className="text-[10px] text-[var(--text-muted)]">
                        Reported by @{rep.reporterUsername} · Status:{' '}
                        <strong className="uppercase text-[#52ff94]">{rep.status}</strong>
                      </div>
                    </div>

                    {rep.status === 'open' && (
                      <div className="flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => handleResolveReport(rep.id, 'dismiss')}
                          className="win-btn px-2 py-1 text-[10px]"
                        >
                          DISMISS
                        </button>
                        <button
                          type="button"
                          onClick={() => handleResolveReport(rep.id, 'remove')}
                          className="win-btn px-2 py-1 text-[10px] text-[#ff6bd6]"
                        >
                          REMOVE VIDEO
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* VERTICAL SNAP-SCROLL VIDEO FEED */}
      {!activeCreatorUsername && isFeedLikeView && (
        <div className="space-y-2">
          {/* Feed Navigation Controls Bar */}
          {shorts.length > 0 && (
            <div className="flex items-center justify-between gap-2 px-1 text-xs font-pixel-ui">
              <span className="text-[var(--accent-lavender)]">
                VIDEO {activeIndex + 1} / {shorts.length}
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={activeIndex <= 0}
                  onClick={() => scrollToSlide(activeIndex - 1)}
                  className="win-btn px-2.5 py-1 text-[10px] disabled:opacity-40"
                >
                  ▲ PREV
                </button>
                <button
                  type="button"
                  disabled={activeIndex >= shorts.length - 1}
                  onClick={() => scrollToSlide(activeIndex + 1)}
                  className="win-btn px-2.5 py-1 text-[10px] disabled:opacity-40"
                >
                  ▼ NEXT
                </button>
              </div>
            </div>
          )}

          {loading ? (
            <div className="win-inset p-8 text-center text-sm text-[var(--accent-lavender)]">
              Loading vertical video stream...
            </div>
          ) : shorts.length === 0 ? (
            <div className="win-inset p-8 text-center space-y-3">
              <div className="font-pixel-ui text-xs text-[#ff6bd6]">
                {subView === 'following'
                  ? 'NO SHORTS FROM FOLLOWED CREATORS YET'
                  : subView === 'saved'
                    ? 'NO SAVED SHORTS YET'
                    : 'NO SHORT VIDEOS UPLOADED YET'}
              </div>
              <p className="text-sm text-[var(--text-muted)]">
                Upload a real MP4/WEBM vertical clip to start the LOSTROOM.BXE short video stream.
              </p>
              <button
                type="button"
                onClick={() => setSubView('upload')}
                className="win-btn win-btn-primary px-4 py-1.5 text-xs"
              >
                + UPLOAD FIRST SHORT
              </button>
            </div>
          ) : (
            <div
              ref={feedContainerRef}
              className="h-[78vh] min-h-[540px] max-h-[760px] overflow-y-auto snap-y snap-mandatory space-y-4 pr-1 border-2 border-[var(--bevel-mid)] bg-[#050308] p-2"
            >
              {shorts.map((short, idx) => (
                <div
                  key={short.id}
                  ref={(el) => {
                    slideRefs.current[idx] = el;
                  }}
                  data-index={idx}
                  className="snap-start min-h-full flex items-center justify-center py-1"
                >
                  <ShortsPlayerCard
                    short={short}
                    isActive={!isFullscreen && idx === activeIndex}
                    shouldPreload={idx === activeIndex + 1}
                    muted={muted}
                    viewerSkinOverride={viewerSkinOverride}
                    currentUsername={currentUsername}
                    usersMap={users}
                    rolesMap={rolesMap}
                    commentsEnabled={commentsEnabled}
                    onToggleMute={() => setMuted((m) => !m)}
                    onToggleFullscreen={() => {
                      setActiveIndex(idx);
                      setIsFullscreen(true);
                    }}
                    onLike={handleLike}
                    onSave={handleSave}
                    onFollow={handleFollow}
                    onShare={handleShare}
                    onSelectHashtag={(tag) => setActiveTag(tag)}
                    onOpenCreatorProfile={handleOpenCreatorProfile}
                    onBlockCreator={handleBlockCreator}
                    onReportSubmit={handleReportSubmit}
                    onDeleteShort={handleDeleteShort}
                    onChangeVisibility={handleChangeVisibility}
                    onCommentAdded={() => {
                      setShorts((prev) =>
                        prev.map((s) =>
                          s.id === short.id ? { ...s, commentCount: s.commentCount + 1 } : s
                        )
                      );
                    }}
                    onToast={onToast}
                  />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* FULLSCREEN VERTICAL FEED OVERLAY */}
      {isFullscreen && shorts[activeIndex] && (
        <div className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center p-2 sm:p-4">
          <div className="w-full max-w-[480px] flex items-center justify-between gap-2 mb-2 text-xs font-pixel-ui">
            <span className="text-[#52ff94]">
              SHORTyes FULLSCREEN ({activeIndex + 1}/{shorts.length})
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={activeIndex <= 0}
                onClick={() => scrollToSlide(activeIndex - 1)}
                className="win-btn px-2 py-1 text-[10px] disabled:opacity-40"
              >
                ▲ PREV
              </button>
              <button
                type="button"
                disabled={activeIndex >= shorts.length - 1}
                onClick={() => scrollToSlide(activeIndex + 1)}
                className="win-btn px-2 py-1 text-[10px] disabled:opacity-40"
              >
                ▼ NEXT
              </button>
              <button
                type="button"
                onClick={() => setIsFullscreen(false)}
                className="win-btn win-btn-primary px-2.5 py-1 text-[10px]"
              >
                EXIT [ESC]
              </button>
            </div>
          </div>

          <div className="flex-1 w-full flex items-center justify-center min-h-0">
            <ShortsPlayerCard
              short={shorts[activeIndex]}
              isActive={true}
              shouldPreload={true}
              muted={muted}
              viewerSkinOverride={viewerSkinOverride}
              currentUsername={currentUsername}
              usersMap={users}
              rolesMap={rolesMap}
              commentsEnabled={commentsEnabled}
              isFullscreen={true}
              onToggleMute={() => setMuted((m) => !m)}
              onToggleFullscreen={() => setIsFullscreen(false)}
              onLike={handleLike}
              onSave={handleSave}
              onFollow={handleFollow}
              onShare={handleShare}
              onSelectHashtag={(tag) => {
                setIsFullscreen(false);
                setActiveTag(tag);
              }}
              onOpenCreatorProfile={(uname) => {
                setIsFullscreen(false);
                handleOpenCreatorProfile(uname);
              }}
              onBlockCreator={handleBlockCreator}
              onReportSubmit={handleReportSubmit}
              onDeleteShort={handleDeleteShort}
              onChangeVisibility={handleChangeVisibility}
              onCommentAdded={() => {
                const activeId = shorts[activeIndex]?.id;
                if (!activeId) return;
                setShorts((prev) =>
                  prev.map((s) =>
                    s.id === activeId ? { ...s, commentCount: s.commentCount + 1 } : s
                  )
                );
              }}
              onToast={onToast}
            />
          </div>
        </div>
      )}
    </div>
  );
};
