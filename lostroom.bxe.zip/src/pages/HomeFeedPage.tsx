import React, { useState } from 'react';
import { ForumPostCard } from '../components/ForumPostCard';
import { PageId, PostItem, UserAccount, UserRole } from '../types/lostroom';

interface HomeFeedPageProps {
  posts: PostItem[];
  users: Record<string, UserAccount>;
  currentUsername: string | null;
  rolesMap?: Record<string, UserRole>;
  flagsMap?: Record<string, string[]>;
  postingEnabled?: boolean;
  commentsEnabled?: boolean;
  confirmedFriends: string[];
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
  onDeletePost: (postId: string) => void;
  onOpenProfile: (username: string) => void;
  onOpenChatWith: (username: string) => void;
  onFilterByTag: (tag: string) => void;
  onNavigate: (page: PageId) => void;
}

export const HomeFeedPage: React.FC<HomeFeedPageProps> = ({
  posts,
  users,
  currentUsername,
  rolesMap,
  flagsMap,
  postingEnabled = true,
  commentsEnabled = true,
  confirmedFriends,
  onToggleLike,
  onAddComment,
  onDeletePost,
  onOpenProfile,
  onOpenChatWith,
  onFilterByTag,
  onNavigate,
}) => {
  const [feedScope, setFeedScope] = useState<'all' | 'friends'>('all');

  const visiblePosts =
    feedScope === 'friends'
      ? posts.filter((p) => confirmedFriends.includes(p.author))
      : posts;

  return (
    <div className="space-y-4">
      <div className="bg-[#1a1128] border border-[#7b42f6] p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
        <div>
          <div className="font-pixel-ui text-xs text-[#e6dcff]">
            PUBLIC FEED // REAL TRANSMISSIONS ONLY
          </div>
          <div className="text-sm text-[#c8b4f8]">
            Post photos, videos, or filter the stream by confirmed friends.
          </div>
        </div>
        <button
          type="button"
          onClick={() => onNavigate('upload')}
          className="win-btn win-btn-primary px-3.5 py-1.5 text-xs shrink-0"
        >
          {postingEnabled ? '+ UPLOAD PHOTO / VIDEO' : 'POSTING PAUSED'}
        </button>
      </div>

      {/* All Posts vs Friends Only Feed Filter */}
      <div className="bg-[#120c1c] border border-[#4e2d82] p-2.5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setFeedScope('all')}
            className={`win-btn px-3 py-1 text-[11px] ${
              feedScope === 'all' ? 'win-btn-primary' : ''
            }`}
          >
            ALL POSTS ({posts.length})
          </button>
          <button
            type="button"
            onClick={() => setFeedScope('friends')}
            className={`win-btn px-3 py-1 text-[11px] ${
              feedScope === 'friends' ? 'win-btn-primary' : ''
            }`}
          >
            FRIENDS ONLY ({confirmedFriends.length})
          </button>
        </div>

        <button
          type="button"
          onClick={() => onNavigate('friends')}
          className="text-xs font-pixel-ui text-[#c8b4f8] hover:text-white underline cursor-pointer"
        >
          Manage Friends &amp; Requests
        </button>
      </div>

      {visiblePosts.length === 0 ? (
        <div className="win-inset p-8 text-center space-y-3">
          <div className="font-pixel-ui text-sm text-[#c8b4f8]">
            {feedScope === 'friends'
              ? 'NO POSTS FROM CONFIRMED FRIENDS YET...'
              : 'THE FEED IS QUIET RIGHT NOW...'}
          </div>
          <p className="text-base text-[#a690d6]">
            {feedScope === 'friends'
              ? confirmedFriends.length === 0
                ? 'You have no confirmed friends yet. Send or accept friend requests to populate this feed.'
                : 'Your confirmed friends have not uploaded any posts yet.'
              : 'No bots exist here. Be the first real user to upload a photo, video, or message.'}
          </p>
          <div className="flex flex-wrap justify-center gap-2">
            {feedScope === 'friends' ? (
              <button
                type="button"
                onClick={() => onNavigate('friends')}
                className="win-btn win-btn-primary px-4 py-2 text-xs"
              >
                OPEN FRIENDS MANAGER &gt;&gt;
              </button>
            ) : (
              <button
                type="button"
                onClick={() => onNavigate('upload')}
                className="win-btn win-btn-primary px-4 py-2 text-xs"
              >
                CREATE FIRST POST &gt;&gt;
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {visiblePosts.map((post) => (
            <ForumPostCard
              key={post.id}
              post={post}
              author={users[post.author]}
              currentUsername={currentUsername}
              rolesMap={rolesMap}
              flagsMap={flagsMap}
              commentsEnabled={commentsEnabled}
              onToggleLike={onToggleLike}
              onAddComment={onAddComment}
              onDeletePost={onDeletePost}
              onOpenProfile={onOpenProfile}
              onOpenChatWith={onOpenChatWith}
              onFilterByTag={onFilterByTag}
            />
          ))}
        </div>
      )}
    </div>
  );
};
