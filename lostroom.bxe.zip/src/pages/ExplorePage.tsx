import React from 'react';
import { BarutBadge } from '../components/BarutBadge';
import { ForumPostCard } from '../components/ForumPostCard';
import { AvatarBox } from '../components/RetroMedia';
import { FriendRequest, PostItem, UserAccount, UserRole } from '../types/lostroom';

interface ExplorePageProps {
  users: Record<string, UserAccount>;
  posts: PostItem[];
  currentUsername: string | null;
  rolesMap?: Record<string, UserRole>;
  commentsEnabled?: boolean;
  friendRequests: FriendRequest[];
  searchQuery: string;
  tagFilter: string;
  onChangeSearch: (q: string) => void;
  onChangeTagFilter: (tag: string) => void;
  onSendFriendRequest: (toUsername: string) => void;
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
  onDeletePost: (postId: string) => void;
  onOpenProfile: (username: string) => void;
  onOpenChatWith: (username: string) => void;
}

export const ExplorePage: React.FC<ExplorePageProps> = ({
  users,
  posts,
  currentUsername,
  rolesMap,
  commentsEnabled = true,
  friendRequests,
  searchQuery,
  tagFilter,
  onChangeSearch,
  onChangeTagFilter,
  onSendFriendRequest,
  onToggleLike,
  onAddComment,
  onDeletePost,
  onOpenProfile,
  onOpenChatWith,
}) => {
  const q = searchQuery.trim().toLowerCase();

  const matchingUsers = Object.values(users).filter(
    (u) => !q || u.username.toLowerCase().includes(q) || u.bio.toLowerCase().includes(q)
  );

  const dynamicTags = ['all', ...Array.from(new Set(posts.flatMap((p) => p.tags)))];

  const filteredPosts = posts.filter((p) => {
    const matchesTag = tagFilter === 'all' || p.tags.includes(tagFilter);
    const matchesQuery =
      !q ||
      p.content.toLowerCase().includes(q) ||
      p.author.toLowerCase().includes(q) ||
      p.tags.some((t) => t.toLowerCase().includes(q));
    return matchesTag && matchesQuery;
  });

  const getFriendStatus = (username: string) => {
    if (!currentUsername || username === currentUsername) return 'self';
    const accepted = friendRequests.some(
      (r) =>
        r.status === 'accepted' &&
        ((r.from === currentUsername && r.to === username) ||
          (r.to === currentUsername && r.from === username))
    );
    if (accepted) return 'friend';
    const pending = friendRequests.some(
      (r) =>
        r.status === 'pending' &&
        ((r.from === currentUsername && r.to === username) ||
          (r.to === currentUsername && r.from === username))
    );
    if (pending) return 'pending';
    return 'none';
  };

  return (
    <div className="space-y-4">
      <div className="bg-[#120c1c] border border-[#4e2d82] p-3">
        <label
          htmlFor="explore-search-input"
          className="block font-pixel-ui text-xs text-[#c8b4f8] mb-1.5"
        >
          SEARCH REGISTERED USERS &amp; TAGS:
        </label>
        <div className="flex gap-2">
          <input
            id="explore-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => onChangeSearch(e.target.value)}
            placeholder="type username or keyword..."
            className="win-inset px-3 py-1.5 flex-1 text-[#eee6ff]"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => onChangeSearch('')}
              className="win-btn px-3 py-1 text-xs"
            >
              CLEAR
            </button>
          )}
        </div>

        <div className="flex flex-wrap gap-1.5 mt-3">
          {dynamicTags.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => onChangeTagFilter(t)}
              className={`win-btn px-2.5 py-1 text-[11px] ${
                tagFilter === t ? 'win-btn-primary' : ''
              }`}
            >
              {t === 'all' ? '* ALL_POSTS' : `#${t}`}
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="font-pixel-ui text-xs text-[#ff6bd6] mb-2">
          REGISTERED ACCOUNTS ({matchingUsers.length})
        </div>
        {matchingUsers.length === 0 ? (
          <div className="win-inset p-4 text-center text-[#a690d6]">
            No registered accounts match &quot;{searchQuery}&quot;.
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {matchingUsers.map((u) => {
              const status = getFriendStatus(u.username);
              return (
                <div
                  key={u.username}
                  className="bg-[#120c1c] border border-[#3b2163] p-2.5 flex items-center justify-between gap-2"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <AvatarBox user={u} sizeClass="w-10 h-10" />
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => onOpenProfile(u.username)}
                          className="font-pixel-ui text-xs text-[#e6dcff] hover:underline truncate cursor-pointer"
                        >
                          {u.username}
                        </button>
                        <BarutBadge username={u.username} rolesMap={rolesMap} compact />
                      </div>
                      <div className="text-xs text-[#a690d6] truncate">{u.bio}</div>
                    </div>
                  </div>

                  <div className="flex gap-1 shrink-0">
                    {status === 'none' && (
                      <button
                        type="button"
                        onClick={() => onSendFriendRequest(u.username)}
                        className="win-btn px-2 py-1 text-[10px] text-[#52ff94]"
                        title="Send friend request"
                      >
                        +FRIEND
                      </button>
                    )}
                    {status === 'pending' && (
                      <span className="font-pixel-ui text-[10px] text-[#c8b4f8] px-1.5 py-1">
                        REQ
                      </span>
                    )}
                    {status === 'friend' && (
                      <span className="font-pixel-ui text-[10px] text-[#52ff94] px-1.5 py-1">
                        ★
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenProfile(u.username)}
                      className="win-btn px-2 py-1 text-[10px]"
                    >
                      PFP
                    </button>
                    {u.username !== currentUsername && (
                      <button
                        type="button"
                        onClick={() => onOpenChatWith(u.username)}
                        className="win-btn win-btn-primary px-2 py-1 text-[10px]"
                      >
                        DM
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div>
        <div className="font-pixel-ui text-xs text-[#52ff94] mb-2">
          MATCHING POSTS ({filteredPosts.length})
        </div>
        <div className="space-y-4">
          {filteredPosts.length > 0 ? (
            filteredPosts.map((p) => (
              <ForumPostCard
                key={p.id}
                post={p}
                author={users[p.author]}
                currentUsername={currentUsername}
                rolesMap={rolesMap}
                commentsEnabled={commentsEnabled}
                onToggleLike={onToggleLike}
                onAddComment={onAddComment}
                onDeletePost={onDeletePost}
                onOpenProfile={onOpenProfile}
                onOpenChatWith={onOpenChatWith}
                onFilterByTag={onChangeTagFilter}
              />
            ))
          ) : (
            <div className="win-inset p-6 text-center text-[#a690d6]">
              No posts match your current search or tag filter.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
