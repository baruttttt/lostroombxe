import React, { useEffect, useState } from 'react';
import { BarutBadge } from '../components/BarutBadge';
import { FlagPicker, UserFlags } from '../components/FlagPicker';
import { ForumPostCard } from '../components/ForumPostCard';
import { AvatarBox } from '../components/RetroMedia';
import { FriendRequest, PageId, PostItem, UserAccount, UserRole } from '../types/lostroom';
import { PlaylistRecord } from '../types/homepage';
import { sanitizeFlags } from '../utils/flags';
import { getPublicHomepage, listUserPlaylists } from '../utils/homepageApi';

interface ProfilePageProps {
  profileUsername: string;
  users: Record<string, UserAccount>;
  posts: PostItem[];
  currentUsername: string | null;
  rolesMap?: Record<string, UserRole>;
  flagsMap?: Record<string, string[]>;
  commentsEnabled?: boolean;
  friendRequests: FriendRequest[];
  onSendFriendRequest: (toUsername: string) => void;
  onRespondFriendRequest: (requestId: string, action: 'accepted' | 'declined') => void;
  onRemoveFriend: (friendUsername: string) => void;
  onNavigate: (page: PageId) => void;
  onOpenProfile: (username: string) => void;
  onOpenChatWith: (username: string) => void;
  onOpenPublicUrl: (path: string) => void;
  onSaveFlags?: (flags: string[]) => void;
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
  onDeletePost: (postId: string) => void;
  onFilterByTag: (tag: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({
  profileUsername,
  users,
  posts,
  currentUsername,
  rolesMap,
  flagsMap,
  commentsEnabled = true,
  friendRequests,
  onSendFriendRequest,
  onRespondFriendRequest,
  onRemoveFriend,
  onNavigate,
  onOpenProfile,
  onOpenChatWith,
  onOpenPublicUrl,
  onSaveFlags,
  onToggleLike,
  onAddComment,
  onDeletePost,
  onFilterByTag,
}) => {
  const profileUser = users[profileUsername] || (currentUsername ? users[currentUsername] : undefined);
  const [hasPublishedSite, setHasPublishedSite] = useState(false);
  const [siteTitle, setSiteTitle] = useState('');
  const [publicPlaylists, setPublicPlaylists] = useState<PlaylistRecord[]>([]);
  const [editingFlags, setEditingFlags] = useState(false);
  const [flagDraft, setFlagDraft] = useState<string[]>([]);

  useEffect(() => {
    if (!profileUser) return;
    let active = true;
    getPublicHomepage(profileUser.username, false)
      .then((res) => {
        if (!active) return;
        setHasPublishedSite(true);
        setSiteTitle(res.document.theme.pageTitle || `${profileUser.username}'s Homepage`);
      })
      .catch(() => {
        if (!active) return;
        setHasPublishedSite(false);
        setSiteTitle('');
      });

    listUserPlaylists(profileUser.username, currentUsername)
      .then((res) => {
        if (!active) return;
        setPublicPlaylists(res.playlists.filter((p) => p.isPublic));
      })
      .catch(() => {
        if (active) setPublicPlaylists([]);
      });

    return () => {
      active = false;
    };
  }, [profileUser?.username, currentUsername]);

  if (!profileUser) {
    return (
      <div className="win-inset p-6 text-center text-[#a690d6]">
        Profile not found. Register or select a registered user.
      </div>
    );
  }

  const userPosts = posts.filter((p) => p.author === profileUser.username);
  const isOwnProfile = currentUsername === profileUser.username;

  const isConfirmedFriend =
    !!currentUsername &&
    friendRequests.some(
      (r) =>
        r.status === 'accepted' &&
        ((r.from === currentUsername && r.to === profileUser.username) ||
          (r.to === currentUsername && r.from === profileUser.username))
    );

  const incomingFromProfile = currentUsername
    ? friendRequests.find(
        (r) =>
          r.status === 'pending' &&
          r.from === profileUser.username &&
          r.to === currentUsername
      )
    : undefined;

  const outgoingToProfile = currentUsername
    ? friendRequests.find(
        (r) =>
          r.status === 'pending' &&
          r.from === currentUsername &&
          r.to === profileUser.username
      )
    : undefined;

  const resolvedFlags = sanitizeFlags(
    profileUser.flags && profileUser.flags.length > 0
      ? profileUser.flags
      : flagsMap?.[profileUser.username]
  );

  return (
    <div className="space-y-4">
      <div className="win-inset p-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <AvatarBox user={profileUser} sizeClass="w-16 h-16" />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="font-pixel-ui text-base sm:text-lg text-[#e6dcff]">
                  {profileUser.username}
                </h2>
                <UserFlags flags={resolvedFlags} />
                <BarutBadge username={profileUser.username} role={profileUser.role} rolesMap={rolesMap} />
              </div>
              <div className="text-sm text-[#a690d6] mt-0.5 tabular-nums">
                JOINED: {profileUser.joined} · POSTS: {userPosts.length}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {isOwnProfile ? (
              <>
                <button
                  type="button"
                  onClick={() => onNavigate('settings')}
                  className="win-btn win-btn-primary px-3 py-1.5 text-xs"
                >
                  CHANGE PFP / BIO
                </button>
                {onSaveFlags && (
                  <button
                    type="button"
                    onClick={() => {
                      if (!editingFlags) {
                        setFlagDraft(resolvedFlags);
                        setEditingFlags(true);
                      } else {
                        setEditingFlags(false);
                      }
                    }}
                    className="win-btn px-3 py-1.5 text-xs text-[#ff6bd6]"
                  >
                    {editingFlags ? 'CLOSE FLAGS' : '+ ADD / EDIT FLAGS'}
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => onNavigate('homepage')}
                  className="win-btn px-3 py-1.5 text-xs text-[#52ff94]"
                >
                  MY HOMEPAGE BUILDER
                </button>
              </>
            ) : (
              <>
                {isConfirmedFriend ? (
                  <button
                    type="button"
                    onClick={() => onRemoveFriend(profileUser.username)}
                    className="win-btn px-3 py-1.5 text-xs text-[#52ff94]"
                  >
                    ★ FRIEND (REMOVE)
                  </button>
                ) : incomingFromProfile ? (
                  <>
                    <button
                      type="button"
                      onClick={() => onRespondFriendRequest(incomingFromProfile.id, 'accepted')}
                      className="win-btn win-btn-primary px-3 py-1.5 text-xs"
                    >
                      ACCEPT FRIEND
                    </button>
                    <button
                      type="button"
                      onClick={() => onRespondFriendRequest(incomingFromProfile.id, 'declined')}
                      className="win-btn px-3 py-1.5 text-xs text-[#ff6bd6]"
                    >
                      DECLINE
                    </button>
                  </>
                ) : outgoingToProfile ? (
                  <span className="win-inset px-3 py-1.5 text-xs font-pixel-ui text-[#c8b4f8]">
                    REQUEST SENT
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => onSendFriendRequest(profileUser.username)}
                    className="win-btn px-3 py-1.5 text-xs text-[#52ff94]"
                  >
                    + ADD FRIEND
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => onOpenChatWith(profileUser.username)}
                  className="win-btn win-btn-primary px-3 py-1.5 text-xs"
                >
                  PRIVATE CHAT &gt;&gt;
                </button>
              </>
            )}
          </div>
        </div>

        {isOwnProfile && editingFlags && onSaveFlags && (
          <div className="mt-3 space-y-2 border border-[#7b42f6] bg-[#120c1c] p-3">
            <FlagPicker selectedFlags={flagDraft} onChange={setFlagDraft} />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  onSaveFlags(sanitizeFlags(flagDraft));
                  setEditingFlags(false);
                }}
                className="win-btn win-btn-primary px-3 py-1.5 text-xs"
              >
                SAVE FLAGS
              </button>
              <button
                type="button"
                onClick={() => setEditingFlags(false)}
                className="win-btn px-3 py-1.5 text-xs"
              >
                CANCEL
              </button>
            </div>
          </div>
        )}

        <div className="mt-3 bg-[#120c1c] border border-[#2a1746] p-3 text-base text-[#c8b4f8]">
          <span className="font-pixel-ui text-[10px] text-[#a690d6] block mb-1">
            BIOGRAPHY.TXT:
          </span>
          &quot;{profileUser.bio}&quot;
        </div>

        {(hasPublishedSite || publicPlaylists.length > 0) && (
          <div className="mt-3 bg-[#120c1c] border border-[#7b42f6] p-3 space-y-2">
            {hasPublishedSite && (
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs text-[#e6dcff]">
                  <span className="font-pixel-ui text-[10px] text-[#52ff94] mr-2">
                    PERSONAL HOMEPAGE:
                  </span>
                  {siteTitle}
                </div>
                <button
                  type="button"
                  onClick={() => onOpenPublicUrl(`/user/${profileUser.username}`)}
                  className="win-btn win-btn-primary px-2.5 py-1 text-[10px]"
                >
                  VISIT /user/{profileUser.username} &gt;&gt;
                </button>
              </div>
            )}

            {publicPlaylists.length > 0 && (
              <div className="pt-1 border-t border-[#2a1746]">
                <div className="font-pixel-ui text-[10px] text-[#c8b4f8] mb-1.5">
                  PUBLIC PLAYLISTS ({publicPlaylists.length}):
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {publicPlaylists.map((pl) => (
                    <button
                      key={pl.id}
                      type="button"
                      onClick={() =>
                        onOpenPublicUrl(`/playlist/${pl.ownerUsername}/${pl.slug}`)
                      }
                      className="win-btn px-2 py-1 text-[10px] text-[#52ff94]"
                    >
                      ♪ {pl.name} ({pl.trackIds.length})
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="font-pixel-ui text-xs text-[#e6dcff]">
        POSTS BY {profileUser.username.toUpperCase()} ({userPosts.length})
      </div>

      <div className="space-y-4">
        {userPosts.length > 0 ? (
          userPosts.map((p) => (
            <ForumPostCard
              key={p.id}
              post={p}
              author={profileUser}
              currentUsername={currentUsername}
              rolesMap={rolesMap}
              commentsEnabled={commentsEnabled}
              onToggleLike={onToggleLike}
              onAddComment={onAddComment}
              onDeletePost={onDeletePost}
              onOpenProfile={onOpenProfile}
              onOpenChatWith={onOpenChatWith}
              onFilterByTag={onFilterByTag}
            />
          ))
        ) : (
          <div className="win-inset p-5 text-center text-[#a690d6]">
            No uploads from this user yet.
          </div>
        )}
      </div>
    </div>
  );
};
