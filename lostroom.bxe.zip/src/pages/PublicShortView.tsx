import React, { useEffect, useState } from 'react';
import { ShortsPlayerCard } from '../components/ShortsPlayerCard';
import { UserAccount } from '../types/lostroom';
import { ShortPlayerSkin, ShortVideoRecord } from '../types/shorts';
import {
  blockCreator,
  deleteShortVideo,
  getShortById,
  reportShortVideo,
  toggleFollowCreator,
  toggleShortLike,
  toggleShortSave,
  updateShortVideo,
} from '../utils/shortsApi';

interface PublicShortViewProps {
  shortId: string;
  currentViewerUsername: string | null;
  users: Record<string, UserAccount>;
  onReturnToShorts: () => void;
  onReturnToLostroom: () => void;
  onOpenUserHomepage: (username: string) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const PublicShortView: React.FC<PublicShortViewProps> = ({
  shortId,
  currentViewerUsername,
  users,
  onReturnToShorts,
  onReturnToLostroom,
  onOpenUserHomepage,
  onToast,
}) => {
  const [short, setShort] = useState<ShortVideoRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [muted, setMuted] = useState(false);
  const [viewerSkinOverride, setViewerSkinOverride] = useState<ShortPlayerSkin | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setErrorMsg(null);
    getShortById(shortId, currentViewerUsername)
      .then((res) => {
        if (!active) return;
        setShort(res.short);
      })
      .catch((err) => {
        if (!active) return;
        setErrorMsg(err instanceof Error ? err.message : 'Short video unavailable.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [shortId, currentViewerUsername]);

  const handleLike = async (id: string) => {
    if (!currentViewerUsername) {
      onToast('Log in to like short videos.', 'error');
      return;
    }
    try {
      const res = await toggleShortLike(id, currentViewerUsername);
      setShort(res.short);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Like failed.', 'error');
    }
  };

  const handleSave = async (id: string) => {
    if (!currentViewerUsername) {
      onToast('Log in to save short videos.', 'error');
      return;
    }
    try {
      const res = await toggleShortSave(id, currentViewerUsername);
      setShort(res.short);
      onToast(
        res.short.savedBy.includes(currentViewerUsername)
          ? 'Saved to SHORTS!'
          : 'Removed from saved.'
      );
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Save failed.', 'error');
    }
  };

  const handleFollow = async (authorUsername: string) => {
    if (!currentViewerUsername) {
      onToast('Log in to follow creators.', 'error');
      return;
    }
    try {
      const res = await toggleFollowCreator(authorUsername, currentViewerUsername);
      setShort((prev) =>
        prev
          ? { ...prev, isFollowingAuthor: res.isFollowing, authorFollowerCount: res.followerCount }
          : prev
      );
      onToast(res.isFollowing ? `Following @${authorUsername}` : `Unfollowed @${authorUsername}`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Follow failed.', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-[var(--bg-deep)] py-4 px-3">
      <div className="max-w-3xl mx-auto space-y-4">
        {/* Top Retro Visitor Bar */}
        <div className="win-box p-2.5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onReturnToShorts}
              className="win-btn win-btn-primary px-3 py-1 text-xs"
            >
              &lt;&lt; OPEN SHORTS FEED
            </button>
            <button
              type="button"
              onClick={onReturnToLostroom}
              className="win-btn px-3 py-1 text-xs"
            >
              LOSTROOM.BXE
            </button>
          </div>

          <span className="font-pixel-ui text-xs text-[#52ff94]">
            bxe://lostroom.net/shorts/{shortId}
          </span>
        </div>

        {loading ? (
          <div className="win-box p-8 text-center text-sm text-[var(--accent-lavender)]">
            Loading short video...
          </div>
        ) : errorMsg || !short ? (
          <div className="win-box p-8 text-center space-y-3">
            <div className="font-pixel-ui text-sm text-[#ff6bd6]">
              {errorMsg || 'Short video not found or private.'}
            </div>
            <button
              type="button"
              onClick={onReturnToShorts}
              className="win-btn win-btn-primary px-4 py-1.5 text-xs"
            >
              BROWSE PUBLIC SHORTS
            </button>
          </div>
        ) : (
          <ShortsPlayerCard
            short={short}
            isActive={true}
            shouldPreload={true}
            muted={muted}
            viewerSkinOverride={viewerSkinOverride}
            currentUsername={currentViewerUsername}
            usersMap={users}
            onToggleMute={() => setMuted((m) => !m)}
            onLike={handleLike}
            onSave={handleSave}
            onFollow={handleFollow}
            onShare={async (s) => {
              const url = `${window.location.origin}/shorts/${encodeURIComponent(s.id)}`;
              try {
                await navigator.clipboard.writeText(url);
                onToast('Copied share link!');
              } catch {
                onToast(url);
              }
            }}
            onSelectHashtag={() => onReturnToShorts()}
            onOpenCreatorProfile={(uname) => onOpenUserHomepage(uname)}
            onBlockCreator={async (uname) => {
              if (!currentViewerUsername) {
                onToast('Log in to block creators.', 'error');
                return;
              }
              await blockCreator(uname, currentViewerUsername);
              onToast(`Blocked @${uname}.`);
              onReturnToShorts();
            }}
            onReportSubmit={async (id, reason, details) => {
              if (!currentViewerUsername) {
                onToast('Log in to report videos.', 'error');
                return;
              }
              await reportShortVideo(id, { username: currentViewerUsername, reason, details });
              onToast('Report sent to moderation queue.');
            }}
            onDeleteShort={async (id) => {
              if (!currentViewerUsername) return;
              await deleteShortVideo(id, currentViewerUsername);
              onToast('Short deleted.');
              onReturnToShorts();
            }}
            onChangeVisibility={async (id, nextVis) => {
              if (!currentViewerUsername) return;
              const res = await updateShortVideo(id, {
                username: currentViewerUsername,
                visibility: nextVis,
              });
              setShort(res.short);
              onToast(`Visibility updated to ${nextVis.toUpperCase()}.`);
            }}
            onCommentAdded={() => {
              setShort((prev) =>
                prev ? { ...prev, commentCount: prev.commentCount + 1 } : prev
              );
            }}
            onToast={onToast}
          />
        )}

        <div className="text-center text-xs text-[var(--text-muted)]">
          <button
            type="button"
            onClick={() => setViewerSkinOverride(null)}
            className="underline cursor-pointer"
          >
            SHORTyes // LOSTROOM.BXE
          </button>
        </div>
      </div>
    </div>
  );
};
