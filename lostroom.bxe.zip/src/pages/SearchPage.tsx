import React, { useEffect, useState } from 'react';
import { BarutBadge } from '../components/BarutBadge';
import { UserRole } from '../types/lostroom';
import {
  SearchCategory,
  searchDatabase,
  SearchResponse,
} from '../utils/homepageApi';

interface SearchPageProps {
  currentUsername: string | null;
  rolesMap?: Record<string, UserRole>;
  onOpenProfile: (username: string) => void;
  onOpenPublicUrl: (path: string) => void;
  onOpenForumTopic: (topicId: string) => void;
  onOpenBlogsFeed: () => void;
  onOpenTagInExplore: (tag: string) => void;
  onOpenChatWith: (username: string) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

const CATEGORY_OPTIONS: { id: SearchCategory; label: string }[] = [
  { id: 'all', label: 'ALL' },
  { id: 'users', label: 'USERS' },
  { id: 'websites', label: 'WEBSITES' },
  { id: 'forum', label: 'FORUM POSTS' },
  { id: 'blogs', label: 'BLOG POSTS' },
  { id: 'playlists', label: 'PLAYLISTS' },
  { id: 'tags', label: 'HASHTAGS & TAGS' },
];

export const SearchPage: React.FC<SearchPageProps> = ({
  currentUsername,
  rolesMap,
  onOpenProfile,
  onOpenPublicUrl,
  onOpenForumTopic,
  onOpenBlogsFeed,
  onOpenTagInExplore,
  onOpenChatWith,
  onToast,
}) => {
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<SearchCategory>('all');
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<SearchResponse | null>(null);

  const runSearch = async (qValue: string, catValue: SearchCategory) => {
    setLoading(true);
    try {
      const res = await searchDatabase(qValue, catValue);
      setData(res);
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Database search failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      runSearch(query, category);
    }, 180);
    return () => clearTimeout(timer);
  }, [query, category]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    runSearch(query, category);
  };

  const applySuggestion = (suggestedQuery: string, suggestedType?: string) => {
    setQuery(suggestedQuery);
    if (suggestedType === 'TAG') {
      setCategory('all');
    }
  };

  const counts = data?.counts || {
    all: 0,
    users: 0,
    websites: 0,
    forum: 0,
    blogs: 0,
    playlists: 0,
    tags: 0,
  };

  const getCountForCat = (cat: SearchCategory): number => counts[cat] ?? 0;

  return (
    <div className="space-y-4">
      {/* Search Bar & Category Filters */}
      <div className="win-inset p-3.5 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-pixel-ui text-sm sm:text-base text-[#52ff94]">
              SEARCH // LOSTROOM.BXE DATABASE
            </h2>
            <p className="text-xs text-[#a690d6]">
              Search registered users, published personal homepages, forum topics, blog posts, public playlists, and #hashtags.
            </p>
          </div>
          <span className="font-pixel-ui text-[10px] px-2 py-0.5 bg-[#120c1c] border border-[#7b42f6] text-[#c8b4f8]">
            LIVE SQLITE INDEX
          </span>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search usernames, websites, forum posts, blog entries, playlists, or #tags..."
            aria-label="Search LOSTROOM.BXE database"
            className="flex-1 win-inset px-3 py-2 text-base text-white bg-[#09060e]"
          />
          <div className="flex gap-2">
            <button type="submit" className="win-btn win-btn-primary px-4 py-2 text-xs">
              SEARCH
            </button>
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="win-btn px-3 py-2 text-xs text-[#ff6bd6]"
              >
                CLEAR
              </button>
            )}
          </div>
        </form>

        {/* Live Database Search Suggestions */}
        {data && data.suggestions.length > 0 && (
          <div className="bg-[#120c1c] border border-[#2a1746] p-2 space-y-1.5">
            <div className="font-pixel-ui text-[10px] text-[#a690d6]">
              {query.trim() ? 'SEARCH SUGGESTIONS:' : 'QUICK SUGGESTIONS FROM DATABASE:'}
            </div>
            <div className="flex flex-wrap gap-1.5">
              {data.suggestions.map((sug, idx) => (
                <button
                  key={`${sug.type}-${sug.query}-${idx}`}
                  type="button"
                  onClick={() => applySuggestion(sug.query, sug.type)}
                  className="win-btn px-2 py-0.5 text-[10px] flex items-center gap-1.5"
                >
                  <span className="text-[#52ff94]">[{sug.type}]</span>
                  <span className="text-[#e6dcff]">{sug.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Category Filters */}
        <div className="flex flex-wrap gap-1.5 pt-1 border-t border-[#2a1746]">
          {CATEGORY_OPTIONS.map((opt) => (
            <button
              key={opt.id}
              type="button"
              onClick={() => setCategory(opt.id)}
              className={`win-btn px-2.5 py-1 text-[10px] ${
                category === opt.id ? 'win-btn-primary' : ''
              }`}
            >
              {opt.label} ({getCountForCat(opt.id)})
            </button>
          ))}
        </div>
      </div>

      {/* Results Area */}
      {loading && !data ? (
        <div className="win-inset p-6 text-center font-pixel-ui text-xs text-[#c8b4f8]">
          QUERYING DATABASE...
        </div>
      ) : data && counts[category] === 0 ? (
        <div className="win-inset p-6 text-center space-y-2">
          <div className="font-pixel-ui text-xs text-[#ff6bd6]">NO MATCHING RESULTS</div>
          <p className="text-sm text-[#a690d6]">
            {query.trim()
              ? `Nothing matched "${query}" in ${category.toUpperCase()}. Try a different keyword or switch category.`
              : `No items recorded in ${category.toUpperCase()} yet.`}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {/* USERS & USERNAMES */}
          {data && data.users.length > 0 && (
            <section className="win-box p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#52ff94] border-b border-[#2a1746] pb-1.5">
                USERS &amp; USERNAMES ({data.users.length})
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {data.users.map((u) => (
                  <div
                    key={u.username}
                    className="win-inset p-2.5 flex items-center justify-between gap-2"
                  >
                    <button
                      type="button"
                      onClick={() => onOpenProfile(u.username)}
                      className="min-w-0 text-left flex-1 cursor-pointer"
                    >
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className="font-pixel-ui text-xs text-[#e6dcff] hover:underline truncate">
                          @{u.username}
                        </span>
                        <BarutBadge username={u.username} rolesMap={rolesMap} compact />
                      </div>
                      <div className="text-xs text-[#a690d6] truncate mt-0.5">
                        {u.bio || 'LOSTROOM.BXE member'}
                      </div>
                    </button>
                    <div className="flex items-center gap-1 shrink-0">
                      {u.hasPublishedWebsite && (
                        <button
                          type="button"
                          onClick={() => onOpenPublicUrl(`/user/${u.username}`)}
                          className="win-btn px-2 py-0.5 text-[10px] text-[#52ff94]"
                        >
                          SITE
                        </button>
                      )}
                      {currentUsername && currentUsername !== u.username && (
                        <button
                          type="button"
                          onClick={() => onOpenChatWith(u.username)}
                          className="win-btn px-2 py-0.5 text-[10px]"
                        >
                          CHAT
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => onOpenProfile(u.username)}
                        className="win-btn win-btn-primary px-2 py-0.5 text-[10px]"
                      >
                        PROFILE
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* PUBLISHED PERSONAL WEBSITES */}
          {data && data.websites.length > 0 && (
            <section className="win-box p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#ff6bd6] border-b border-[#2a1746] pb-1.5">
                PUBLISHED PERSONAL WEBSITES ({data.websites.length})
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {data.websites.map((site) => (
                  <button
                    key={site.username}
                    type="button"
                    onClick={() => onOpenPublicUrl(`/user/${site.username}`)}
                    className="win-inset p-3 text-left hover:border-[#52ff94] cursor-pointer space-y-1"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-pixel-ui text-xs text-[#e6dcff] truncate">
                        {site.pageTitle}
                      </span>
                      <span className="text-[10px] text-[#52ff94] shrink-0">
                        {site.visitorCount} VISITS
                      </span>
                    </div>
                    <div className="text-xs text-[#c8b4f8] line-clamp-2">
                      {site.pageDescription || 'Personal retro homepage'}
                    </div>
                    <div className="text-[10px] text-[#a690d6]">
                      /user/{site.username} · TEMPLATE: {site.templateId}
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* FORUM POSTS */}
          {data && data.forumPosts.length > 0 && (
            <section className="win-box p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#c8b4f8] border-b border-[#2a1746] pb-1.5">
                FORUM POSTS &amp; TOPICS ({data.forumPosts.length})
              </div>
              <div className="space-y-2">
                {data.forumPosts.map((topic) => (
                  <button
                    key={topic.id}
                    type="button"
                    onClick={() => onOpenForumTopic(topic.id)}
                    className="w-full win-inset p-2.5 text-left hover:border-[#7b42f6] cursor-pointer space-y-1"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <span className="font-pixel-ui text-xs text-[#e6dcff]">
                        {topic.title}
                      </span>
                      <span className="text-[10px] px-1.5 py-0.5 bg-[#1a1128] border border-[#7b42f6] text-[#c8b4f8]">
                        {topic.categoryName}
                      </span>
                    </div>
                    <p className="text-sm text-[#c8b4f8] line-clamp-2">{topic.body}</p>
                    <div className="text-[10px] text-[#a690d6] flex items-center gap-1 flex-wrap">
                      <span>BY {topic.author}</span>
                      <BarutBadge username={topic.author} rolesMap={rolesMap} compact />
                      <span>· {topic.replyCount} REPLIES · {topic.views} VIEWS</span>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* BLOG POSTS */}
          {data && data.blogPosts.length > 0 && (
            <section className="win-box p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#e6dcff] border-b border-[#2a1746] pb-1.5">
                BLOG &amp; FEED POSTS ({data.blogPosts.length})
              </div>
              <div className="space-y-2">
                {data.blogPosts.map((post) => (
                  <div key={post.id} className="win-inset p-2.5 space-y-1.5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => onOpenProfile(post.author)}
                          className="font-pixel-ui text-xs text-[#52ff94] hover:underline cursor-pointer"
                        >
                          @{post.author}
                        </button>
                        <BarutBadge username={post.author} rolesMap={rolesMap} compact />
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-[#a690d6]">
                        {post.mood && <span>MOOD: {post.mood}</span>}
                        <span>{post.timestamp}</span>
                      </div>
                    </div>
                    <p className="text-sm text-[#e6dcff] whitespace-pre-wrap line-clamp-3">
                      {post.content}
                    </p>
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                      <div className="flex flex-wrap gap-1">
                        {post.tags.map((t) => (
                          <button
                            key={t}
                            type="button"
                            onClick={() => setQuery(`#${t}`)}
                            className="px-1.5 py-0.5 text-[10px] bg-[#1a1128] border border-[#7b42f6] text-[#c8b4f8] hover:text-white cursor-pointer"
                          >
                            #{t}
                          </button>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={onOpenBlogsFeed}
                        className="win-btn px-2 py-0.5 text-[10px]"
                      >
                        OPEN BLOG FEED ({post.likeCount} ♥ · {post.commentCount} 💬)
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {/* PUBLIC PLAYLISTS */}
          {data && data.playlists.length > 0 && (
            <section className="win-box p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#52ff94] border-b border-[#2a1746] pb-1.5">
                PUBLIC PLAYLISTS ({data.playlists.length})
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {data.playlists.map((pl) => (
                  <button
                    key={pl.id}
                    type="button"
                    onClick={() => onOpenPublicUrl(`/playlist/${pl.ownerUsername}/${pl.slug}`)}
                    className="win-inset p-2.5 text-left flex items-center gap-3 hover:border-[#52ff94] cursor-pointer"
                  >
                    <div className="w-12 h-12 bg-[#09060e] border border-[#7b42f6] shrink-0 overflow-hidden flex items-center justify-center">
                      {pl.coverUrl ? (
                        <img
                          src={pl.coverUrl}
                          alt={pl.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="font-pixel-ui text-[10px] text-[#c8b4f8]">MP3</span>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="font-pixel-ui text-xs text-[#e6dcff] truncate">
                        ♪ {pl.name}
                      </div>
                      <div className="text-xs text-[#a690d6] truncate">
                        by {pl.ownerUsername} · {pl.trackIds.length} tracks · ♥ {pl.likes.length}
                      </div>
                      {pl.description && (
                        <div className="text-[11px] text-[#c8b4f8] truncate">
                          {pl.description}
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* HASHTAGS & TAGS */}
          {data && data.tags.length > 0 && (
            <section className="win-box p-3 space-y-2.5">
              <div className="font-pixel-ui text-xs text-[#ff6bd6] border-b border-[#2a1746] pb-1.5">
                HASHTAGS &amp; TAGS ({data.tags.length})
              </div>
              <div className="flex flex-wrap gap-2">
                {data.tags.map((tagItem) => (
                  <div
                    key={tagItem.tag}
                    className="win-inset px-2.5 py-1.5 flex items-center gap-2 text-xs"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        setQuery(`#${tagItem.tag}`);
                        setCategory('all');
                      }}
                      className="font-pixel-ui text-[#52ff94] hover:underline cursor-pointer"
                    >
                      #{tagItem.tag}
                    </button>
                    <span className="text-[10px] text-[#a690d6]">
                      ({tagItem.totalCount})
                    </span>
                    <button
                      type="button"
                      onClick={() => onOpenTagInExplore(tagItem.tag)}
                      className="win-btn px-1.5 py-0 text-[9px]"
                    >
                      EXPLORE
                    </button>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
};
