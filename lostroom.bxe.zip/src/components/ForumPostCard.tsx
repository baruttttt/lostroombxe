import React, { useEffect, useState } from 'react';
import { PostItem, UserAccount, UserRole } from '../types/lostroom';
import { getVideoBlob } from '../utils/mediaDb';
import { BarutBadge } from './BarutBadge';
import { UserFlags } from './FlagPicker';
import { AvatarBox } from './RetroMedia';

interface PersistedVideoPlayerProps {
  mediaUrl: string;
}

const PersistedVideoPlayer: React.FC<PersistedVideoPlayerProps> = ({ mediaUrl }) => {
  const [resolvedSrc, setResolvedSrc] = useState<string>(() =>
    mediaUrl.startsWith('idb://') ? '' : mediaUrl
  );
  const [missing, setMissing] = useState(false);

  useEffect(() => {
    if (!mediaUrl.startsWith('idb://')) {
      setResolvedSrc(mediaUrl);
      setMissing(false);
      return;
    }

    const videoId = mediaUrl.slice('idb://'.length);
    let active = true;
    let objectUrl: string | null = null;

    getVideoBlob(videoId)
      .then((blob) => {
        if (!active) return;
        if (!blob) {
          setMissing(true);
          return;
        }
        objectUrl = URL.createObjectURL(blob);
        setResolvedSrc(objectUrl);
        setMissing(false);
      })
      .catch(() => {
        if (active) setMissing(true);
      });

    return () => {
      active = false;
      if (objectUrl) {
        URL.revokeObjectURL(objectUrl);
      }
    };
  }, [mediaUrl]);

  if (missing) {
    return (
      <div className="mt-2.5 win-inset p-4 text-center text-xs text-[var(--pink-love)] font-pixel-ui">
        [VIDEO FILE NOT FOUND IN LOCAL BROWSER STORAGE]
      </div>
    );
  }

  if (!resolvedSrc) {
    return (
      <div className="mt-2.5 win-inset p-4 text-center text-xs text-[var(--text-muted)] font-pixel-ui">
        LOADING VIDEO...
      </div>
    );
  }

  return (
    <div className="mt-2.5 win-inset p-1.5 bg-black">
      <video
        src={resolvedSrc}
        controls
        playsInline
        preload="metadata"
        className="w-full max-h-96 mx-auto block"
      />
    </div>
  );
};

interface ForumPostCardProps {
  post: PostItem;
  author?: UserAccount;
  currentUsername: string | null;
  rolesMap?: Record<string, UserRole>;
  flagsMap?: Record<string, string[]>;
  commentsEnabled?: boolean;
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, text: string) => void;
  onDeletePost: (postId: string) => void;
  onOpenProfile: (username: string) => void;
  onOpenChatWith: (username: string) => void;
  onFilterByTag: (tag: string) => void;
}

export const ForumPostCard: React.FC<ForumPostCardProps> = ({
  post,
  author,
  currentUsername,
  rolesMap,
  flagsMap,
  commentsEnabled = true,
  onToggleLike,
  onAddComment,
  onDeletePost,
  onOpenProfile,
  onOpenChatWith,
  onFilterByTag,
}) => {
  const [replyText, setReplyText] = useState('');
  const isLiked = currentUsername ? post.likes.includes(currentUsername) : false;
  const isOwnPost = currentUsername === post.author;

  const handleReplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = replyText.trim();
    if (!trimmed) return;
    onAddComment(post.id, trimmed);
    setReplyText('');
  };

  return (
    <article className="bg-[var(--bg-void)] border-2 border-[var(--bevel-mid)] p-3.5 shadow-[3px_3px_0px_#07040b]">
      <div className="flex items-start justify-between gap-2 border-b border-[var(--bg-royal)] pb-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <button
            type="button"
            onClick={() => onOpenProfile(post.author)}
            className="shrink-0 cursor-pointer"
            title={`View ${post.author}'s profile`}
          >
            <AvatarBox user={author} sizeClass="w-10 h-10" />
          </button>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => onOpenProfile(post.author)}
                className="font-pixel-ui text-xs sm:text-sm text-[var(--text-bright)] hover:text-[var(--pink-love)] truncate cursor-pointer"
              >
                {post.author}
              </button>
              <UserFlags flags={author?.flags?.length ? author.flags : flagsMap?.[post.author]} />
              <BarutBadge username={post.author} rolesMap={rolesMap} compact />
              {post.activityTag && (
                <span className="text-xs text-[var(--green-online)] italic">
                  · {post.activityTag}
                </span>
              )}
            </div>
            <div className="text-xs text-[var(--text-muted)]">
              {post.timestamp} {post.mood ? `| mood: ${post.mood}` : ''}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          {!isOwnPost ? (
            <button
              type="button"
              onClick={() => onOpenChatWith(post.author)}
              className="win-btn px-2 py-0.5 text-[10px]"
            >
              DM
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onDeletePost(post.id)}
              className="win-btn px-2 py-0.5 text-[10px] text-[var(--pink-love)]"
              title="Delete your post"
            >
              DEL
            </button>
          )}
        </div>
      </div>

      {post.content && (
        <div className="mt-2.5 text-lg text-[var(--text-bright)] whitespace-pre-line break-words">
          {post.content}
        </div>
      )}

      {post.mediaType === 'image' && post.mediaUrl && (
        <div className="mt-2.5 win-inset p-1.5 bg-black">
          <img
            src={post.mediaUrl}
            alt={`Upload by ${post.author}`}
            referrerPolicy="no-referrer"
            className="w-full max-h-96 object-contain mx-auto block"
          />
        </div>
      )}

      {post.mediaType === 'video' && post.mediaUrl && (
        <PersistedVideoPlayer mediaUrl={post.mediaUrl} />
      )}

      {post.tags.length > 0 && (
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {post.tags.map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => onFilterByTag(t)}
              className="text-xs font-pixel-ui text-[var(--accent-lavender)] bg-[var(--bg-panel)] border border-[var(--bevel-mid)] px-1.5 py-0.5 hover:border-[var(--text-bright)] cursor-pointer"
            >
              #{t}
            </button>
          ))}
        </div>
      )}

      <div className="mt-3 pt-2 border-t border-[var(--bg-royal)] flex items-center gap-3">
        <button
          type="button"
          onClick={() => onToggleLike(post.id)}
          className={`win-btn px-2.5 py-1 text-xs flex items-center gap-1.5 ${
            isLiked ? 'border-[var(--pink-love)] text-[var(--pink-love)]' : ''
          }`}
        >
          <span>{isLiked ? '♥' : '♡'}</span>
          <span className="tabular-nums">LIKE ({post.likes.length})</span>
        </button>
        <span className="text-sm text-[var(--text-muted)] tabular-nums">
          COMMENTS ({post.comments.length})
        </span>
      </div>

      <div className="mt-2.5 space-y-1.5">
        {post.comments.map((c) => (
          <div
            key={c.id}
            className="bg-[var(--bg-pitch)] border border-[var(--bg-royal)] px-2.5 py-1.5 text-base"
          >
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  type="button"
                  onClick={() => onOpenProfile(c.author)}
                  className="font-pixel-ui text-[var(--accent-lavender)] hover:underline cursor-pointer"
                >
                  {c.author}
                </button>
                <BarutBadge username={c.author} rolesMap={rolesMap} compact />
              </div>
              <span className="text-[var(--text-muted)]">{c.time}</span>
            </div>
            <div className="text-[var(--text-bright)] mt-0.5 break-words">{c.text}</div>
          </div>
        ))}

        {commentsEnabled ? (
          <form onSubmit={handleReplySubmit} className="flex gap-1.5 pt-1">
            <input
              type="text"
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              placeholder="write a comment..."
              className="win-inset px-2.5 py-1 flex-1 text-base text-[var(--text-bright)] focus:outline-none"
            />
            <button type="submit" className="win-btn px-3 py-1 text-[11px]">
              REPLY
            </button>
          </form>
        ) : (
          <div className="win-inset px-2.5 py-1 text-xs text-[var(--pink-love)]">
            Comments are temporarily paused by Super Admin (God Mode).
          </div>
        )}
      </div>
    </article>
  );
};
