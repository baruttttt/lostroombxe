import React from 'react';
import { PixelAvatarKey, UserAccount } from '../types/lostroom';

export const PIXEL_AVATAR_OPTIONS: { key: PixelAvatarKey; label: string }[] = [
  { key: 'cat_void', label: 'Void Cat' },
  { key: 'blue_ghost', label: 'Blue Ghost' },
  { key: 'lavender_skull', label: 'Lavender Skull' },
  { key: 'cyber_angel', label: 'Cyber Angel' },
];

export const PixelAvatarSVG: React.FC<{ preset: string }> = ({ preset }) => {
  switch (preset) {
    case 'blue_ghost':
      return (
        <svg viewBox="0 0 16 16" className="w-full h-full pixelated" aria-hidden="true">
          <rect width="16" height="16" fill="#120c1c" />
          <path d="M4 2h8v2h2v10h-2v-2h-2v2H6v-2H4v2H2V4h2V2z" fill="#7b42f6" />
          <rect x="5" y="6" width="2" height="2" fill="#ffffff" />
          <rect x="9" y="6" width="2" height="2" fill="#ffffff" />
          <rect x="6" y="7" width="1" height="1" fill="#09060e" />
          <rect x="10" y="7" width="1" height="1" fill="#09060e" />
          <rect x="6" y="10" width="4" height="1" fill="#e6dcff" />
        </svg>
      );
    case 'lavender_skull':
      return (
        <svg viewBox="0 0 16 16" className="w-full h-full pixelated" aria-hidden="true">
          <rect width="16" height="16" fill="#09060e" />
          <path d="M4 2h8v2h2v6h-2v4H4v-4H2V4h2V2z" fill="#c8b4f8" />
          <rect x="4" y="5" width="3" height="3" fill="#120c1c" />
          <rect x="9" y="5" width="3" height="3" fill="#120c1c" />
          <rect x="7" y="8" width="2" height="2" fill="#2a1746" />
          <rect x="5" y="11" width="1" height="2" fill="#120c1c" />
          <rect x="8" y="11" width="1" height="2" fill="#120c1c" />
          <rect x="10" y="11" width="1" height="2" fill="#120c1c" />
        </svg>
      );
    case 'cyber_angel':
      return (
        <svg viewBox="0 0 16 16" className="w-full h-full pixelated" aria-hidden="true">
          <rect width="16" height="16" fill="#1e1233" />
          <rect x="5" y="1" width="6" height="1" fill="#ff6bd6" />
          <rect x="4" y="4" width="8" height="8" fill="#e6dcff" />
          <rect x="5" y="6" width="2" height="2" fill="#7b42f6" />
          <rect x="9" y="6" width="2" height="2" fill="#7b42f6" />
          <rect x="1" y="6" width="3" height="4" fill="#c8b4f8" />
          <rect x="12" y="6" width="3" height="4" fill="#c8b4f8" />
        </svg>
      );
    case 'cat_void':
    default:
      return (
        <svg viewBox="0 0 16 16" className="w-full h-full pixelated" aria-hidden="true">
          <rect width="16" height="16" fill="#1a1128" />
          <path d="M3 2h2v2H3V2zm8 0h2v2h-2V2zM2 4h12v9H2V4z" fill="#09060e" />
          <path d="M3 5h10v7H3V5z" fill="#2a1746" />
          <rect x="4" y="7" width="2" height="2" fill="#52ff94" />
          <rect x="10" y="7" width="2" height="2" fill="#52ff94" />
          <rect x="7" y="9" width="2" height="1" fill="#ff6bd6" />
          <rect x="5" y="11" width="6" height="1" fill="#c8b4f8" />
        </svg>
      );
  }
};

interface AvatarBoxProps {
  user?: UserAccount;
  fallbackPreset?: PixelAvatarKey;
  sizeClass?: string;
}

export const AvatarBox: React.FC<AvatarBoxProps> = ({
  user,
  fallbackPreset = 'lavender_skull',
  sizeClass = 'w-10 h-10',
}) => {
  if (user && user.avatarType === 'custom' && user.avatarValue) {
    return (
      <img
        src={user.avatarValue}
        alt={user.username}
        referrerPolicy="no-referrer"
        className={`${sizeClass} object-cover border border-[#c8b4f8] shrink-0 bg-black`}
      />
    );
  }

  return (
    <div className={`${sizeClass} border border-[#c8b4f8] overflow-hidden shrink-0`}>
      <PixelAvatarSVG preset={user?.avatarValue || fallbackPreset} />
    </div>
  );
};
