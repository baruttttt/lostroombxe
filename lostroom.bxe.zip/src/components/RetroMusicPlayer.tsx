import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createDefaultPlayerConfig } from '../data/homepageTemplates';
import { AudioTrack, MusicPlayerStyleConfig, PlaylistRecord } from '../types/homepage';

interface RetroMusicPlayerProps {
  playlist?: PlaylistRecord | null;
  tracks?: AudioTrack[];
  styleConfig?: MusicPlayerStyleConfig;
  title?: string;
  compact?: boolean;
}

type RepeatMode = 'off' | 'all' | 'one';

function formatDuration(seconds: number): string {
  if (!Number.isFinite(seconds) || seconds < 0) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export const RetroMusicPlayer: React.FC<RetroMusicPlayerProps> = ({
  playlist,
  tracks,
  styleConfig,
  title,
  compact = false,
}) => {
  const cfg = styleConfig || createDefaultPlayerConfig('lavender_mini');
  const resolvedTracks = useMemo(() => {
    if (tracks && tracks.length > 0) return tracks;
    if (playlist?.tracks && playlist.tracks.length > 0) return playlist.tracks;
    return [];
  }, [playlist, tracks]);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.85);
  const [muted, setMuted] = useState(false);
  const [shuffle, setShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('all');
  const [showPlaylist, setShowPlaylist] = useState(!compact);
  const [audioError, setAudioError] = useState<string | null>(null);

  useEffect(() => {
    if (currentIndex >= resolvedTracks.length) {
      setCurrentIndex(0);
      setIsPlaying(false);
    }
  }, [resolvedTracks.length, currentIndex]);

  const currentTrack = resolvedTracks[currentIndex] || null;

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.volume = muted ? 0 : volume;
  }, [volume, muted]);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    setCurrentTime(0);
    setDuration(0);
    setAudioError(null);
    if (!currentTrack) {
      audio.pause();
      return;
    }
    audio.load();
    if (isPlaying) {
      audio
        .play()
        .catch(() => {
          setIsPlaying(false);
        });
    }
  }, [currentTrack?.id, currentTrack?.url]);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio || !currentTrack) return;
    setAudioError(null);
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {
          setIsPlaying(false);
          setAudioError('Could not play track. Click play again or check MP3 file.');
        });
    }
  };

  const selectTrack = (idx: number, autoPlay = true) => {
    if (idx < 0 || idx >= resolvedTracks.length) return;
    setCurrentIndex(idx);
    setIsPlaying(autoPlay);
    if (autoPlay && audioRef.current) {
      setTimeout(() => {
        audioRef.current?.play().catch(() => {});
      }, 40);
    }
  };

  const handleNext = () => {
    if (resolvedTracks.length === 0) return;
    if (shuffle && resolvedTracks.length > 1) {
      let nextIdx = currentIndex;
      while (nextIdx === currentIndex) {
        nextIdx = Math.floor(Math.random() * resolvedTracks.length);
      }
      selectTrack(nextIdx, true);
      return;
    }
    const nextIdx = currentIndex + 1;
    if (nextIdx < resolvedTracks.length) {
      selectTrack(nextIdx, true);
    } else if (repeatMode === 'all') {
      selectTrack(0, true);
    } else {
      setIsPlaying(false);
    }
  };

  const handlePrev = () => {
    if (resolvedTracks.length === 0) return;
    if (audioRef.current && audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }
    const prevIdx =
      currentIndex - 1 >= 0 ? currentIndex - 1 : resolvedTracks.length - 1;
    selectTrack(prevIdx, isPlaying);
  };

  const handleEnded = () => {
    if (repeatMode === 'one' && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
      return;
    }
    handleNext();
  };

  const cycleRepeat = () => {
    setRepeatMode((prev) =>
      prev === 'off' ? 'all' : prev === 'all' ? 'one' : 'off'
    );
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
    }
    setCurrentTime(val);
  };

  const coverArt = currentTrack?.coverUrl || playlist?.coverUrl || '';
  const playerTitle =
    title || playlist?.name || 'LOSTROOM MP3 DECK';

  return (
    <div
      className="relative overflow-hidden mx-auto shadow-lg"
      style={{
        width: cfg.width === '100%' ? '100%' : `min(100%, ${cfg.width})`,
        backgroundColor: cfg.bgColor,
        color: cfg.textColor,
        borderColor: cfg.borderColor,
        borderStyle: cfg.borderStyle,
        borderWidth: '3px',
      }}
    >
      {cfg.glitterOverlay && (
        <div
          className="pointer-events-none absolute inset-0 glitter-pink_glitter opacity-35"
          aria-hidden="true"
        />
      )}

      {currentTrack && (
        <audio
          ref={audioRef}
          src={currentTrack.url}
          preload="metadata"
          onTimeUpdate={() => setCurrentTime(audioRef.current?.currentTime || 0)}
          onLoadedMetadata={() => setDuration(audioRef.current?.duration || 0)}
          onEnded={handleEnded}
          onError={() => {
            setIsPlaying(false);
            setAudioError('Audio stream unavailable.');
          }}
        />
      )}

      <div className="relative z-10">
        {/* Retro Player Title Bar */}
        <div
          className="px-2.5 py-1.5 flex items-center justify-between border-b-2 text-xs font-pixel-ui"
          style={{
            borderColor: cfg.borderColor,
            backgroundColor: 'rgba(0,0,0,0.4)',
          }}
        >
          <div className="flex items-center gap-1.5 min-w-0">
            {cfg.pixelIcons ? (
              <svg viewBox="0 0 12 12" className="w-3.5 h-3.5 shrink-0 pixelated" aria-hidden="true">
                <rect x="3" y="2" width="6" height="2" fill={cfg.accentColor} />
                <rect x="3" y="2" width="1.5" height="7" fill={cfg.accentColor} />
                <rect x="7.5" y="2" width="1.5" height="6" fill={cfg.accentColor} />
                <rect x="1.5" y="7.5" width="3" height="2.5" fill={cfg.accentColor} />
                <rect x="6" y="6.5" width="3" height="2.5" fill={cfg.accentColor} />
              </svg>
            ) : (
              <span style={{ color: cfg.accentColor }}>♪</span>
            )}
            <span className="truncate font-bold">{playerTitle}</span>
          </div>
          <span
            className="text-[10px] px-1.5 py-0.5 shrink-0"
            style={{
              backgroundColor: 'rgba(0,0,0,0.55)',
              color: isPlaying ? cfg.accentColor : cfg.textColor,
              border: `1px solid ${cfg.borderColor}`,
            }}
          >
            {isPlaying ? 'PLAYING' : resolvedTracks.length > 0 ? 'READY' : 'EMPTY'}
          </span>
        </div>

        {/* Cover Art + Track Info LCD */}
        <div className="p-3 flex gap-3 items-center">
          <div
            className="w-16 h-16 shrink-0 flex items-center justify-center overflow-hidden border-2"
            style={{
              borderColor: cfg.borderColor,
              backgroundColor: 'rgba(0,0,0,0.55)',
            }}
          >
            {coverArt ? (
              <img
                src={coverArt}
                alt={currentTrack?.title || 'Album cover'}
                className="w-full h-full object-cover"
              />
            ) : (
              <svg viewBox="0 0 24 24" className="w-11 h-11 pixelated" aria-hidden="true">
                <circle cx="12" cy="12" r="10" fill={cfg.buttonBg} stroke={cfg.accentColor} strokeWidth="1.5" />
                <circle cx="12" cy="12" r="4" fill={cfg.bgColor} stroke={cfg.borderColor} strokeWidth="1" />
                <circle cx="12" cy="12" r="1.5" fill={cfg.accentColor} />
              </svg>
            )}
          </div>

          <div className="min-w-0 flex-1">
            {currentTrack ? (
              <>
                <div
                  className="font-pixel-ui text-xs sm:text-sm truncate font-bold"
                  style={{ color: cfg.accentColor }}
                >
                  {currentTrack.title}
                </div>
                <div className="text-sm truncate opacity-90">
                  {currentTrack.artist}
                </div>
                {currentTrack.description && (
                  <div className="text-xs opacity-70 truncate">
                    {currentTrack.description}
                  </div>
                )}
                <div className="text-[11px] mt-1 font-mono tabular-nums opacity-85">
                  {formatDuration(currentTime)} / {formatDuration(duration)} · TRACK{' '}
                  {currentIndex + 1}/{resolvedTracks.length}
                </div>
              </>
            ) : (
              <div className="text-xs opacity-80 leading-snug">
                No MP3 tracks assigned yet. Upload MP3s in Music Library and select a playlist for this player!
              </div>
            )}
          </div>
        </div>

        {/* Progress Bar */}
        <div className="px-3 pb-2">
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.5}
            value={Math.min(currentTime, duration || 100)}
            onChange={handleSeek}
            disabled={!currentTrack || duration <= 0}
            aria-label="Track progress"
            className="w-full h-2 cursor-pointer accent-current"
            style={{ accentColor: cfg.accentColor }}
          />
          {audioError && (
            <div className="text-[11px] mt-1" style={{ color: '#ff6bd6' }}>
              {audioError}
            </div>
          )}
        </div>

        {/* Transport & Shuffle/Repeat Controls */}
        <div className="px-3 pb-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handlePrev}
              disabled={resolvedTracks.length === 0}
              className="px-2 py-1 text-xs font-pixel-ui border-2 cursor-pointer disabled:opacity-40"
              style={{
                backgroundColor: cfg.buttonBg,
                color: cfg.buttonText,
                borderColor: cfg.borderColor,
              }}
              title="Previous Track"
            >
              |&lt;&lt;
            </button>
            <button
              type="button"
              onClick={togglePlay}
              disabled={!currentTrack}
              className="px-3 py-1 text-xs font-pixel-ui border-2 cursor-pointer font-bold disabled:opacity-40"
              style={{
                backgroundColor: isPlaying ? cfg.accentColor : cfg.buttonBg,
                color: isPlaying ? '#09060e' : cfg.buttonText,
                borderColor: cfg.borderColor,
              }}
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? 'PAUSE' : 'PLAY'}
            </button>
            <button
              type="button"
              onClick={handleNext}
              disabled={resolvedTracks.length === 0}
              className="px-2 py-1 text-xs font-pixel-ui border-2 cursor-pointer disabled:opacity-40"
              style={{
                backgroundColor: cfg.buttonBg,
                color: cfg.buttonText,
                borderColor: cfg.borderColor,
              }}
              title="Next Track"
            >
              &gt;&gt;|
            </button>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShuffle((prev) => !prev)}
              className="px-1.5 py-1 text-[10px] font-pixel-ui border cursor-pointer"
              style={{
                backgroundColor: shuffle ? cfg.accentColor : 'rgba(0,0,0,0.45)',
                color: shuffle ? '#09060e' : cfg.textColor,
                borderColor: cfg.borderColor,
              }}
              title="Toggle Shuffle"
            >
              SHUF
            </button>
            <button
              type="button"
              onClick={cycleRepeat}
              className="px-1.5 py-1 text-[10px] font-pixel-ui border cursor-pointer"
              style={{
                backgroundColor: repeatMode !== 'off' ? cfg.accentColor : 'rgba(0,0,0,0.45)',
                color: repeatMode !== 'off' ? '#09060e' : cfg.textColor,
                borderColor: cfg.borderColor,
              }}
              title="Repeat Mode"
            >
              RPT:{repeatMode.toUpperCase()}
            </button>
            <button
              type="button"
              onClick={() => setShowPlaylist((prev) => !prev)}
              className="px-1.5 py-1 text-[10px] font-pixel-ui border cursor-pointer"
              style={{
                backgroundColor: 'rgba(0,0,0,0.45)',
                color: cfg.textColor,
                borderColor: cfg.borderColor,
              }}
              title="Toggle Playlist Drawer"
            >
              LIST ({resolvedTracks.length})
            </button>
          </div>
        </div>

        {/* Volume Row */}
        <div
          className="px-3 py-1.5 border-t flex items-center gap-2 text-xs"
          style={{
            borderColor: cfg.borderColor,
            backgroundColor: 'rgba(0,0,0,0.3)',
          }}
        >
          <button
            type="button"
            onClick={() => setMuted((prev) => !prev)}
            className="font-pixel-ui text-[10px] px-1.5 py-0.5 border cursor-pointer"
            style={{
              borderColor: cfg.borderColor,
              backgroundColor: cfg.buttonBg,
              color: cfg.buttonText,
            }}
          >
            {muted || volume === 0 ? 'MUTE' : 'VOL'}
          </button>
          <input
            type="range"
            min={0}
            max={1}
            step={0.02}
            value={muted ? 0 : volume}
            onChange={(e) => {
              setMuted(false);
              setVolume(Number(e.target.value));
            }}
            aria-label="Volume"
            className="flex-1 h-1.5 cursor-pointer"
            style={{ accentColor: cfg.accentColor }}
          />
          <span className="font-mono text-[11px] tabular-nums w-9 text-right">
            {Math.round((muted ? 0 : volume) * 100)}%
          </span>
        </div>

        {/* Playlist Navigation */}
        {showPlaylist && resolvedTracks.length > 0 && (
          <div
            className="border-t max-h-44 overflow-y-auto divide-y"
            style={{
              borderColor: cfg.borderColor,
              backgroundColor: 'rgba(0,0,0,0.48)',
            }}
          >
            {resolvedTracks.map((trk, idx) => {
              const active = idx === currentIndex;
              return (
                <button
                  key={`${trk.id}-${idx}`}
                  type="button"
                  onClick={() => selectTrack(idx, true)}
                  className="w-full px-3 py-1.5 text-left flex items-center justify-between gap-2 text-xs cursor-pointer transition-opacity hover:opacity-100"
                  style={{
                    backgroundColor: active ? 'rgba(255,255,255,0.12)' : 'transparent',
                    color: active ? cfg.accentColor : cfg.textColor,
                    borderColor: 'rgba(255,255,255,0.08)',
                  }}
                >
                  <span className="truncate font-mono">
                    {active ? '▶ ' : `${idx + 1}. `}
                    {trk.title} — <span className="opacity-75">{trk.artist}</span>
                  </span>
                  <span className="text-[10px] opacity-70 shrink-0">MP3</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
