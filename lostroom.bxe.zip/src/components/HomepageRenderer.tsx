import React, { useState } from 'react';
import { createDefaultPlayerConfig } from '../data/homepageTemplates';
import {
  GuestbookEntry,
  HomepageBlock,
  HomepageDocument,
  PlaylistRecord,
  StickerIconId,
} from '../types/homepage';
import { RetroMusicPlayer } from './RetroMusicPlayer';

interface HomepageRendererProps {
  document: HomepageDocument;
  username: string;
  playlistsById: Record<string, PlaylistRecord>;
  visitorCount: number;
  guestbook: GuestbookEntry[];
  currentViewerUsername?: string | null;
  onSubmitGuestbook?: (message: string) => Promise<void>;
  onNavigateInternal?: (path: string) => void;
  // Editor interaction props
  editMode?: boolean;
  selectedBlockId?: string | null;
  onSelectBlock?: (id: string) => void;
  onDragStartBlock?: (id: string) => void;
  onDropOnBlock?: (targetId: string) => void;
  onMoveBlock?: (id: string, dir: 'up' | 'down') => void;
  onDeleteBlock?: (id: string) => void;
}

const RetroStickerSvg: React.FC<{ stickerId?: StickerIconId }> = ({
  stickerId = 'sparkle_stars',
}) => {
  switch (stickerId) {
    case 'pixel_heart':
      return (
        <svg viewBox="0 0 24 24" className="w-8 h-8 pixelated shrink-0" aria-hidden="true">
          <path
            d="M4 5h5v2h2v2h2V7h2V5h5v6h-2v3h-2v2h-2v2h-2v2h-2v-2H8v-2H6v-2H4v-3H2V5h2z"
            fill="#ff4db8"
            stroke="#ffe4f6"
            strokeWidth="1.2"
          />
        </svg>
      );
    case 'under_construction':
      return (
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 border-2 border-yellow-400 bg-black text-yellow-300 font-pixel-ui text-[10px] shrink-0">
          <span>[!]</span>
          <span>UNDER CONSTRUCTION</span>
        </div>
      );
    case 'cyber_butterfly':
      return (
        <svg viewBox="0 0 24 24" className="w-8 h-8 pixelated shrink-0" aria-hidden="true">
          <path d="M2 5h7v6H5v2H2V5zm13 0h7v8h-3v-2h-4V5z" fill="#00f5d4" />
          <path d="M5 13h5v6H5v-6zm9 0h5v6h-5v-6z" fill="#a855f7" />
          <rect x="11" y="4" width="2" height="16" fill="#ffffff" />
        </svg>
      );
    case 'music_note':
      return (
        <svg viewBox="0 0 24 24" className="w-8 h-8 pixelated shrink-0" aria-hidden="true">
          <rect x="8" y="4" width="10" height="3" fill="#52ff94" />
          <rect x="8" y="4" width="2" height="12" fill="#52ff94" />
          <rect x="16" y="4" width="2" height="10" fill="#52ff94" />
          <rect x="4" y="14" width="6" height="4" fill="#c8b4f8" />
          <rect x="12" y="12" width="6" height="4" fill="#c8b4f8" />
        </svg>
      );
    case 'retro_cd':
      return (
        <svg viewBox="0 0 24 24" className="w-8 h-8 pixelated shrink-0" aria-hidden="true">
          <circle cx="12" cy="12" r="9" fill="#c8b4f8" stroke="#7b42f6" strokeWidth="2" />
          <circle cx="12" cy="12" r="3" fill="#09060e" stroke="#ffffff" strokeWidth="1" />
        </svg>
      );
    case 'sparkle_stars':
    default:
      return (
        <svg viewBox="0 0 24 24" className="w-8 h-8 pixelated shrink-0" aria-hidden="true">
          <path d="M11 2h2v5h5v2h-5v5h-2V9H6V7h5V2z" fill="#ffd166" />
          <path d="M4 15h1.5v2H8v1.5H5.5V21H4v-2.5H2V17h2v-2z" fill="#ff6bd6" />
          <path d="M18 14h1.5v2H22v1.5h-2.5V20H18v-2.5h-2V16h2v-2z" fill="#52ff94" />
        </svg>
      );
  }
};

export const HomepageRenderer: React.FC<HomepageRendererProps> = ({
  document,
  username,
  playlistsById,
  visitorCount,
  guestbook,
  currentViewerUsername,
  onSubmitGuestbook,
  onNavigateInternal,
  editMode = false,
  selectedBlockId = null,
  onSelectBlock,
  onDragStartBlock,
  onDropOnBlock,
  onMoveBlock,
  onDeleteBlock,
}) => {
  const { theme, blocks } = document;
  const [gbMessage, setGbMessage] = useState('');
  const [gbSending, setGbSending] = useState(false);

  const fontClass = `hp-font-${theme.fontFamily || 'vt323'}`;
  const glitterClass =
    theme.glitterEffect && theme.glitterEffect !== 'none'
      ? `glitter-${theme.glitterEffect}`
      : '';

  const handleLinkClick = (e: React.MouseEvent, rawUrl?: string) => {
    if (editMode) {
      e.preventDefault();
      return;
    }
    const url = (rawUrl || '').trim();
    if (!url) {
      e.preventDefault();
      return;
    }
    if (url.startsWith('/') && onNavigateInternal) {
      e.preventDefault();
      onNavigateInternal(url);
    }
  };

  const handleGuestbookSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (editMode || !onSubmitGuestbook || !gbMessage.trim()) return;
    setGbSending(true);
    try {
      await onSubmitGuestbook(gbMessage.trim());
      setGbMessage('');
    } finally {
      setGbSending(false);
    }
  };

  const renderBlockBody = (block: HomepageBlock) => {
    const alignClass =
      block.align === 'center'
        ? 'text-center'
        : block.align === 'right'
          ? 'text-right'
          : 'text-left';

    const boxStyle: React.CSSProperties = {
      backgroundColor: block.sectionBg || 'rgba(10, 6, 18, 0.72)',
      borderColor: block.sectionBorderColor || theme.borderColor,
      borderStyle: theme.borderStyle,
      borderWidth: `${Math.max(1, theme.borderWidth)}px`,
      padding: `${block.sectionPadding ?? 14}px`,
    };

    switch (block.type) {
      case 'heading':
        return (
          <div style={boxStyle} className={alignClass}>
            <h2
              className="text-xl sm:text-2xl font-bold tracking-wide break-words"
              style={{ color: theme.headingColor }}
            >
              {block.title || 'HEADING'}
            </h2>
            {block.content && (
              <p className="mt-1 text-sm sm:text-base opacity-90 whitespace-pre-wrap break-words">
                {block.content}
              </p>
            )}
          </div>
        );

      case 'text':
        return (
          <div style={boxStyle} className={alignClass}>
            {block.title && (
              <h3
                className="text-lg font-bold mb-1.5 break-words"
                style={{ color: theme.headingColor }}
              >
                {block.title}
              </h3>
            )}
            <div className="whitespace-pre-wrap break-words text-base leading-relaxed">
              {block.content || ''}
            </div>
          </div>
        );

      case 'image':
        return (
          <div style={boxStyle} className={alignClass}>
            {block.imageUrl ? (
              <figure className="inline-block max-w-full">
                <img
                  src={block.imageUrl}
                  alt={block.imageCaption || 'Homepage graphic'}
                  className="mx-auto max-w-full border-2 object-contain"
                  style={{
                    width: block.imageWidth || '100%',
                    borderColor: block.sectionBorderColor || theme.borderColor,
                  }}
                />
                {block.imageCaption && (
                  <figcaption className="mt-1.5 text-xs opacity-80">
                    {block.imageCaption}
                  </figcaption>
                )}
              </figure>
            ) : (
              <div className="p-4 border border-dashed border-current opacity-70 text-sm">
                No image selected yet. Pick or upload a PNG / JPG / GIF / WEBP in the editor!
              </div>
            )}
          </div>
        );

      case 'button_link': {
        const href = (block.linkUrl || '#').trim();
        const isExternal = /^https?:\/\//i.test(href);
        return (
          <div className={alignClass}>
            <a
              href={editMode ? '#preview' : href}
              target={isExternal && !editMode ? '_blank' : undefined}
              rel={isExternal && !editMode ? 'noopener noreferrer' : undefined}
              onClick={(e) => handleLinkClick(e, href)}
              className="inline-block px-4 py-2 text-sm font-bold border-2 transition-transform hover:-translate-y-0.5"
              style={{
                backgroundColor: block.buttonBg || theme.headingColor,
                color: block.buttonText || '#09060e',
                borderColor: theme.borderColor,
                borderStyle: theme.borderStyle,
              }}
            >
              {block.linkLabel || 'CLICK LINK >>'}
            </a>
          </div>
        );
      }

      case 'two_column':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div style={boxStyle}>
              <h3
                className="text-lg font-bold mb-1.5 break-words"
                style={{ color: theme.headingColor }}
              >
                {block.title || 'Column 1'}
              </h3>
              <p className="whitespace-pre-wrap break-words text-base">
                {block.content || ''}
              </p>
            </div>
            <div style={boxStyle}>
              <h3
                className="text-lg font-bold mb-1.5 break-words"
                style={{ color: theme.headingColor }}
              >
                {block.secondaryTitle || 'Column 2'}
              </h3>
              <p className="whitespace-pre-wrap break-words text-base">
                {block.secondaryContent || ''}
              </p>
            </div>
          </div>
        );

      case 'sticker_divider':
        return (
          <div
            className="flex flex-wrap sm:flex-nowrap items-center gap-3 px-3 py-2 border-2 overflow-hidden"
            style={{
              backgroundColor: 'rgba(0,0,0,0.45)',
              borderColor: theme.borderColor,
              borderStyle: theme.borderStyle,
            }}
          >
            <RetroStickerSvg stickerId={block.stickerId} />
            <div className="flex-1 overflow-hidden">
              <div
                className="marquee-track text-sm sm:text-base font-bold"
                style={{ color: theme.headingColor }}
              >
                {block.marqueeText || `★ ${username}'s personal corner ★`}
              </div>
            </div>
            <RetroStickerSvg stickerId={block.stickerId} />
          </div>
        );

      case 'music_player': {
        const assignedPlaylist = block.playlistId
          ? playlistsById[block.playlistId] || null
          : null;
        return (
          <div>
            <RetroMusicPlayer
              playlist={assignedPlaylist}
              styleConfig={block.playerConfig || createDefaultPlayerConfig('lavender_mini')}
              title={block.title || assignedPlaylist?.name || 'Personal Music Player'}
            />
          </div>
        );
      }

      case 'guestbook_counter': {
        const paddedCounter = String(visitorCount).padStart(6, '0');
        return (
          <div style={boxStyle} className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-white/15">
              <h3 className="text-lg font-bold" style={{ color: theme.headingColor }}>
                {block.title || 'Visitor Counter & Guestbook'}
              </h3>
              <div className="inline-flex items-center gap-2 bg-black px-2.5 py-1 border border-white/30">
                <span className="text-xs opacity-75">VISITORS:</span>
                <span
                  className="font-mono font-bold tracking-widest text-sm"
                  style={{ color: '#52ff94' }}
                >
                  {paddedCounter}
                </span>
              </div>
            </div>

            {!editMode && onSubmitGuestbook ? (
              <form onSubmit={handleGuestbookSubmit} className="flex flex-col sm:flex-row gap-2">
                <input
                  type="text"
                  value={gbMessage}
                  onChange={(e) => setGbMessage(e.target.value)}
                  maxLength={350}
                  placeholder={
                    currentViewerUsername
                      ? `Sign guestbook as ${currentViewerUsername}...`
                      : 'Sign guestbook as visitor...'
                  }
                  className="flex-1 px-2.5 py-1.5 bg-black/75 border text-sm text-white"
                  style={{ borderColor: theme.borderColor }}
                />
                <button
                  type="submit"
                  disabled={gbSending || !gbMessage.trim()}
                  className="px-3 py-1.5 text-xs font-pixel-ui border cursor-pointer disabled:opacity-50"
                  style={{
                    backgroundColor: theme.headingColor,
                    color: '#09060e',
                    borderColor: theme.borderColor,
                  }}
                >
                  {gbSending ? 'SIGNING...' : 'SIGN GUESTBOOK'}
                </button>
              </form>
            ) : (
              <div className="text-xs opacity-75 italic">
                Guestbook signing form is active on your published /user/{username} page.
              </div>
            )}

            <div className="space-y-2 max-h-56 overflow-y-auto">
              {guestbook.length === 0 ? (
                <div className="text-sm opacity-75">
                  No guestbook entries yet. Be the first visitor to sign!
                </div>
              ) : (
                guestbook.map((entry) => (
                  <div
                    key={entry.id}
                    className="p-2 bg-black/45 border text-sm"
                    style={{ borderColor: 'rgba(255,255,255,0.16)' }}
                  >
                    <div className="flex items-center justify-between gap-2 text-xs mb-0.5">
                      <span className="font-bold" style={{ color: theme.linkColor }}>
                        {entry.authorUsername}
                      </span>
                      <span className="opacity-65">
                        {new Date(entry.createdAt).toLocaleString()}
                      </span>
                    </div>
                    <div className="break-words">{entry.message}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        );
      }

      default:
        return null;
    }
  };

  return (
    <div
      className={`relative min-h-[460px] w-full overflow-hidden ${fontClass}`}
      style={{
        backgroundColor: theme.bgColor,
        backgroundImage: theme.bgImageUrl ? `url("${theme.bgImageUrl}")` : undefined,
        backgroundRepeat: theme.bgRepeat === 'repeat' ? 'repeat' : 'no-repeat',
        backgroundSize: theme.bgRepeat === 'cover' ? 'cover' : 'auto',
        backgroundPosition: 'center top',
        color: theme.textColor,
      }}
    >
      {glitterClass && (
        <div
          className={`pointer-events-none absolute inset-0 ${glitterClass}`}
          aria-hidden="true"
        />
      )}

      <div
        className="relative z-10 mx-auto"
        style={{
          maxWidth: theme.pageWidth === '100%' ? '100%' : theme.pageWidth,
          padding: `${theme.containerPadding ?? 20}px`,
        }}
      >
        {/* Optional Custom Banner Graphic */}
        {theme.bannerImageUrl && (
          <div
            className="mb-4 overflow-hidden"
            style={{
              borderColor: theme.borderColor,
              borderStyle: theme.borderStyle,
              borderWidth: `${Math.max(1, theme.borderWidth)}px`,
            }}
          >
            <img
              src={theme.bannerImageUrl}
              alt={`${username}'s banner`}
              className="w-full block"
              style={{
                height: `${theme.bannerHeight || 150}px`,
                objectFit: theme.bannerFit || 'cover',
              }}
            />
          </div>
        )}

        {/* Page Title & Description Header */}
        <header
          className="mb-4 px-4 py-3 text-center"
          style={{
            backgroundColor: 'rgba(8, 4, 15, 0.78)',
            borderColor: theme.borderColor,
            borderStyle: theme.borderStyle,
            borderWidth: `${Math.max(1, theme.borderWidth)}px`,
          }}
        >
          <h1
            className="text-2xl sm:text-3xl font-bold break-words"
            style={{ color: theme.headingColor }}
          >
            {theme.pageTitle || `${username}'s Homepage`}
          </h1>
          {theme.pageDescription && (
            <p className="mt-1 text-sm sm:text-base opacity-90 break-words">
              {theme.pageDescription}
            </p>
          )}
          <div className="mt-1.5 text-xs opacity-75">
            WEBMASTER:{' '}
            <span style={{ color: theme.linkColor }} className="font-bold">
              {username}
            </span>{' '}
            · URL: /user/{username}
          </div>
        </header>

        {/* Blocks List */}
        <div
          className="flex flex-col"
          style={{ gap: `${theme.sectionGap ?? 16}px` }}
        >
          {blocks.map((block, index) => {
            const isSelected = editMode && selectedBlockId === block.id;
            if (!editMode) {
              return <div key={block.id}>{renderBlockBody(block)}</div>;
            }
            return (
              <div
                key={block.id}
                draggable
                onDragStart={() => onDragStartBlock?.(block.id)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => onDropOnBlock?.(block.id)}
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectBlock?.(block.id);
                }}
                className={`relative group cursor-pointer transition-all ${
                  isSelected
                    ? 'ring-2 ring-[#52ff94] ring-offset-2 ring-offset-black'
                    : 'hover:ring-1 hover:ring-[#c8b4f8]/70'
                }`}
              >
                <div className="flex items-center justify-between bg-[#120c1c] border border-[#7b42f6] px-2 py-1 text-[10px] font-pixel-ui text-[#e6dcff]">
                  <span className="flex items-center gap-1.5 truncate">
                    <span className="cursor-grab text-[#52ff94]">:: DRAG</span>
                    <span>
                      #{index + 1} [{block.type.toUpperCase()}]
                    </span>
                  </span>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onMoveBlock?.(block.id, 'up');
                      }}
                      disabled={index === 0}
                      className="win-btn px-1.5 py-0 text-[9px] disabled:opacity-40"
                    >
                      UP
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onMoveBlock?.(block.id, 'down');
                      }}
                      disabled={index === blocks.length - 1}
                      className="win-btn px-1.5 py-0 text-[9px] disabled:opacity-40"
                    >
                      DN
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteBlock?.(block.id);
                      }}
                      className="win-btn px-1.5 py-0 text-[9px] text-[#ff6bd6]"
                    >
                      DEL
                    </button>
                  </div>
                </div>
                {renderBlockBody(block)}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
