import React, { useMemo, useState } from 'react';
import { FLAG_OPTIONS, MAX_USER_FLAGS, sanitizeFlags } from '../utils/flags';

export const UserFlags: React.FC<{
  flags?: string[];
  className?: string;
}> = ({ flags, className = '' }) => {
  const clean = sanitizeFlags(flags);
  if (clean.length === 0) return null;
  return (
    <span
      className={`inline-flex items-center gap-1 align-middle ${className}`}
      title="User Flags"
    >
      {clean.map((flag, idx) => (
        <span
          key={`${flag}-${idx}`}
          className="inline-flex items-center justify-center px-1 py-0.2 bg-[#1a102b] border border-[#4e2d82] text-sm leading-none"
        >
          {flag}
        </span>
      ))}
    </span>
  );
};

interface FlagPickerProps {
  selectedFlags: string[];
  onChange: (nextFlags: string[]) => void;
}

export const FlagPicker: React.FC<FlagPickerProps> = ({ selectedFlags, onChange }) => {
  const [search, setSearch] = useState('');
  const [customFlag, setCustomFlag] = useState('');
  const cleanSelected = sanitizeFlags(selectedFlags);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return FLAG_OPTIONS;
    return FLAG_OPTIONS.filter(
      (f) =>
        f.label.toLowerCase().includes(q) ||
        f.code.toLowerCase().includes(q) ||
        f.emoji.includes(q)
    );
  }, [search]);

  const toggleFlag = (emoji: string) => {
    if (cleanSelected.includes(emoji)) {
      onChange(cleanSelected.filter((f) => f !== emoji));
      return;
    }
    if (cleanSelected.length >= MAX_USER_FLAGS) {
      return;
    }
    onChange([...cleanSelected, emoji]);
  };

  const handleAddCustom = () => {
    const val = customFlag.trim();
    if (!val || cleanSelected.includes(val) || cleanSelected.length >= MAX_USER_FLAGS) return;
    onChange([...cleanSelected, val]);
    setCustomFlag('');
  };

  return (
    <div className="win-inset p-3 space-y-2.5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="font-pixel-ui text-xs text-[#e6dcff]">
          PROFILE FLAGS ({cleanSelected.length}/{MAX_USER_FLAGS})
        </span>
        {cleanSelected.length > 0 && (
          <button
            type="button"
            onClick={() => onChange([])}
            className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
          >
            CLEAR FLAGS
          </button>
        )}
      </div>

      {/* Currently Selected */}
      <div className="flex flex-wrap items-center gap-1.5 min-h-[28px] bg-[#0c0713] border border-[#2a1746] p-1.5">
        {cleanSelected.length === 0 ? (
          <span className="text-xs text-[#a690d6]">
            No flags selected yet. Click flags below to add!
          </span>
        ) : (
          cleanSelected.map((flag) => (
            <button
              key={flag}
              type="button"
              onClick={() => toggleFlag(flag)}
              className="win-btn px-2 py-0.5 text-sm flex items-center gap-1 border-[#52ff94]"
              title="Click to remove"
            >
              <span>{flag}</span>
              <span className="text-[10px] text-[#ff6bd6]">×</span>
            </button>
          ))
        )}
      </div>

      {/* Search + Custom Input */}
      <div className="flex flex-wrap gap-1.5">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search country or flag (e.g. Turkiye, Japan, Pride...)"
          className="flex-1 min-w-[180px] win-inset px-2 py-1 text-xs text-white"
        />
        <div className="flex gap-1">
          <input
            type="text"
            value={customFlag}
            onChange={(e) => setCustomFlag(e.target.value)}
            maxLength={12}
            placeholder="Custom flag/tag"
            className="w-28 win-inset px-2 py-1 text-xs text-white"
          />
          <button
            type="button"
            onClick={handleAddCustom}
            disabled={!customFlag.trim() || cleanSelected.length >= MAX_USER_FLAGS}
            className="win-btn px-2 py-1 text-[10px] disabled:opacity-40"
          >
            + ADD
          </button>
        </div>
      </div>

      {/* Preset Grid */}
      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-1.5 max-h-40 overflow-y-auto pr-1">
        {filtered.map((opt) => {
          const active = cleanSelected.includes(opt.emoji);
          return (
            <button
              key={`${opt.code}-${opt.emoji}`}
              type="button"
              onClick={() => toggleFlag(opt.emoji)}
              disabled={!active && cleanSelected.length >= MAX_USER_FLAGS}
              title={opt.label}
              className={`win-btn px-1.5 py-1 text-xs flex items-center justify-center gap-1 disabled:opacity-40 ${
                active ? 'win-btn-primary ring-1 ring-[#52ff94]' : ''
              }`}
            >
              <span className="text-base leading-none">{opt.emoji}</span>
              <span className="text-[9px] truncate">{opt.code}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
