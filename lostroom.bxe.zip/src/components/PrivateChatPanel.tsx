import React, { useEffect, useRef, useState } from 'react';
import { ChatMessage, UserAccount, UserRole } from '../types/lostroom';
import { BarutBadge } from './BarutBadge';

interface PrivateChatPanelProps {
  currentUsername: string | null;
  users: Record<string, UserAccount>;
  rolesMap?: Record<string, UserRole>;
  chatEnabled?: boolean;
  activePartner: string;
  onSelectPartner: (username: string) => void;
  messages: ChatMessage[];
  onSendMessage: (partner: string, text: string) => void;
  chatSeenStatus: boolean;
  onToggleSeenStatus: () => void;
  onMinimizeMobile: () => void;
}

export const PrivateChatPanel: React.FC<PrivateChatPanelProps> = ({
  currentUsername,
  users,
  rolesMap,
  chatEnabled = true,
  activePartner,
  onSelectPartner,
  messages,
  onSendMessage,
  chatSeenStatus,
  onToggleSeenStatus,
  onMinimizeMobile,
}) => {
  const [draft, setDraft] = useState('');
  const logRef = useRef<HTMLDivElement | null>(null);

  const otherUsers = Object.keys(users).filter((u) => u !== currentUsername);
  const resolvedPartner =
    activePartner && otherUsers.includes(activePartner) ? activePartner : otherUsers[0] || '';

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [messages.length, resolvedPartner]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatEnabled) return;
    const trimmed = draft.trim();
    if (!trimmed || !resolvedPartner || !currentUsername) return;
    onSendMessage(resolvedPartner, trimmed);
    setDraft('');
  };

  return (
    <div className="win-box">
      <div className="win-titlebar">
        <span className="font-pixel-ui text-xs text-white flex items-center gap-1.5">
          <span className="w-2 h-2 bg-[#ff6bd6] inline-block" />
          <span>private chats</span>
        </span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onToggleSeenStatus}
            className={`win-btn px-1.5 py-0.5 text-[10px] ${
              chatSeenStatus ? 'text-[#52ff94]' : 'text-[#ff6bd6]'
            }`}
            title="Toggle Seen / Dont Seen privacy status"
          >
            {chatSeenStatus ? 'seen' : 'dont seen'}
          </button>
          <button
            type="button"
            onClick={onMinimizeMobile}
            className="win-ctrl-btn lg:hidden"
            title="Minimize"
          >
            _
          </button>
        </div>
      </div>

      {/* Recipient Selector */}
      <div className="bg-[#120c1c] p-2 border-b border-[#4e2d82] space-y-1.5">
        <label
          htmlFor="chat-recipient-select"
          className="block font-pixel-ui text-[10px] text-[#a690d6]"
        >
          SELECT REGISTERED USER TO DM:
        </label>
        <select
          id="chat-recipient-select"
          value={resolvedPartner}
          onChange={(e) => onSelectPartner(e.target.value)}
          className="win-inset w-full px-2 py-1 text-sm text-[#eee6ff]"
        >
          {!currentUsername ? (
            <option value="">-- log in first --</option>
          ) : otherUsers.length === 0 ? (
            <option value="">-- register a 2nd user to DM --</option>
          ) : (
            otherUsers.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))
          )}
        </select>
      </div>

      {/* Chat Header */}
      <div className="bg-[#211238] px-2.5 py-1.5 border-b border-[#4e2d82] flex items-center justify-between text-sm">
        <div className="truncate flex items-center gap-1.5">
          <span className="text-[#a690d6]">chatting with</span>
          <strong className="text-[#e6dcff] font-pixel-ui text-xs">
            {!currentUsername
              ? 'offline'
              : resolvedPartner
                ? resolvedPartner
                : 'waiting for users'}
          </strong>
          {currentUsername && resolvedPartner && (
            <BarutBadge username={resolvedPartner} rolesMap={rolesMap} compact />
          )}
        </div>
        <span
          className={`font-pixel-ui text-[10px] px-1.5 py-0.5 bg-[#09060e] border border-[#4e2d82] shrink-0 ${
            chatSeenStatus ? 'text-[#52ff94]' : 'text-[#ff6bd6]'
          }`}
        >
          {chatSeenStatus ? '● seen' : '○ dont seen'}
        </span>
      </div>

      {/* Chat Message Log */}
      <div
        ref={logRef}
        className="win-inset m-2 p-2.5 h-72 overflow-y-auto flex flex-col gap-2 text-base"
      >
        {!currentUsername ? (
          <div className="text-sm text-[#a690d6] text-center my-auto p-3">
            Log in or register an account to chat privately with other registered users.
          </div>
        ) : otherUsers.length === 0 ? (
          <div className="text-sm text-[#c8b4f8] text-center my-auto p-3 space-y-2">
            <div>No other registered accounts exist on this local node yet.</div>
            <div className="text-xs text-[#a690d6]">
              Log out and register a 2nd account to exchange real messages back and forth.
            </div>
          </div>
        ) : messages.length === 0 ? (
          <div className="text-sm text-[#a690d6] text-center my-auto p-3">
            Start of whisper log with <strong className="text-[#e6dcff]">{resolvedPartner}</strong>.
          </div>
        ) : (
          messages.map((m) => {
            const isMe = m.sender === currentUsername;
            return (
              <div key={m.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <div className="text-[11px] text-[#a690d6] mb-0.5 flex items-center gap-1 flex-wrap">
                  <span
                    className={`font-pixel-ui text-[10px] ${
                      isMe ? 'text-[#52ff94]' : 'text-[#ff6bd6]'
                    }`}
                  >
                    {m.sender}
                  </span>
                  <BarutBadge username={m.sender} rolesMap={rolesMap} compact />
                  <span>· {m.time}</span>
                </div>
                <div
                  className={`px-2.5 py-1.5 max-w-[88%] break-words border ${
                    isMe
                      ? 'bg-[#2a1746] border-[#a98ee8] text-[#eee6ff]'
                      : 'bg-[#160e24] border-[#4e2d82] text-[#c8b4f8]'
                  }`}
                >
                  {m.text}
                </div>
              </div>
            );
          })
        )}
      </div>

      {!chatEnabled && (
        <div className="mx-2 mb-2 px-2 py-1 bg-[#2b0b18] border border-[#ff6bd6] text-[11px] text-[#ffd6f0]">
          Chatroom messaging is currently paused by Super Admin.
        </div>
      )}

      {/* Chat Input Form */}
      <form onSubmit={handleSubmit} className="p-2 pt-0 flex gap-1.5">
        <input
          type="text"
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          disabled={!currentUsername || !resolvedPartner || !chatEnabled}
          placeholder={chatEnabled ? 'whisper to user...' : 'chat paused by admin...'}
          autoComplete="off"
          className="win-inset px-2 py-1.5 flex-1 text-[#eee6ff] text-base focus:outline-none disabled:opacity-50"
        />
        <button
          type="submit"
          disabled={!currentUsername || !resolvedPartner || !chatEnabled}
          className="win-btn win-btn-primary px-3 py-1 text-xs disabled:opacity-50"
        >
          SEND
        </button>
      </form>

      <div className="px-2.5 pb-2 text-[11px] text-[#a690d6] flex justify-between">
        <span>NO BOTS · HUMAN DM</span>
        <button
          type="button"
          onClick={onToggleSeenStatus}
          className="underline hover:text-[#e6dcff] cursor-pointer"
        >
          seen / dont seen
        </button>
      </div>
    </div>
  );
};
