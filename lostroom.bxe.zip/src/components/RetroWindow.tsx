import React from 'react';

interface RetroWindowProps {
  title: string;
  rightControls?: React.ReactNode;
  className?: string;
  bodyClassName?: string;
  children: React.ReactNode;
}

export const RetroWindow: React.FC<RetroWindowProps> = ({
  title,
  rightControls,
  className = '',
  bodyClassName = 'p-3',
  children,
}) => {
  return (
    <section className={`win-box flex flex-col ${className}`}>
      <header className="win-titlebar">
        <span className="font-pixel-ui text-xs text-white flex items-center gap-1.5 truncate">
          <span className="inline-block w-2 h-2 bg-[#c8b4f8] shrink-0" />
          <span className="truncate">{title}</span>
        </span>
        {rightControls && <div className="flex items-center gap-1 shrink-0">{rightControls}</div>}
      </header>
      <div className={bodyClassName}>{children}</div>
    </section>
  );
};
