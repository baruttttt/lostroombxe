import React, { useEffect, useState } from 'react';

type GameTab = 'minesweeper' | 'snake';

interface MineCell {
  isMine: boolean;
  revealed: boolean;
  flagged: boolean;
  adjacent: number;
}

function buildMineBoard(rows = 8, cols = 8, mines = 10): MineCell[][] {
  const board: MineCell[][] = Array.from({ length: rows }, () =>
    Array.from({ length: cols }, () => ({
      isMine: false,
      revealed: false,
      flagged: false,
      adjacent: 0,
    }))
  );

  let placed = 0;
  while (placed < mines) {
    const r = Math.floor(Math.random() * rows);
    const c = Math.floor(Math.random() * cols);
    if (!board[r][c].isMine) {
      board[r][c].isMine = true;
      placed += 1;
    }
  }

  for (let r = 0; r < rows; r += 1) {
    for (let c = 0; c < cols; c += 1) {
      if (board[r][c].isMine) continue;
      let count = 0;
      for (let dr = -1; dr <= 1; dr += 1) {
        for (let dc = -1; dc <= 1; dc += 1) {
          const nr = r + dr;
          const nc = c + dc;
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && board[nr][nc].isMine) {
            count += 1;
          }
        }
      }
      board[r][c].adjacent = count;
    }
  }

  return board;
}

export const DesktopGames: React.FC = () => {
  const [gameTab, setGameTab] = useState<GameTab>('minesweeper');

  // Minesweeper state
  const [board, setBoard] = useState<MineCell[][]>(() => buildMineBoard());
  const [mineStatus, setMineStatus] = useState<'playing' | 'won' | 'lost'>('playing');
  const [flagMode, setFlagMode] = useState(false);

  const toggleFlagCell = (r: number, c: number) => {
    if (mineStatus !== 'playing') return;
    setBoard((prev) => {
      const next = prev.map((row) => row.map((cell) => ({ ...cell })));
      if (!next[r][c].revealed) {
        next[r][c].flagged = !next[r][c].flagged;
      }
      return next;
    });
  };

  const revealCell = (r: number, c: number) => {
    if (mineStatus !== 'playing') return;
    if (flagMode) {
      toggleFlagCell(r, c);
      return;
    }
    setBoard((prev) => {
      const next = prev.map((row) => row.map((cell) => ({ ...cell })));
      const target = next[r][c];
      if (target.revealed || target.flagged) return prev;

      if (target.isMine) {
        for (const row of next) {
          for (const cell of row) {
            if (cell.isMine) cell.revealed = true;
          }
        }
        setMineStatus('lost');
        return next;
      }

      const queue: [number, number][] = [[r, c]];
      while (queue.length > 0) {
        const [cr, cc] = queue.shift()!;
        const cell = next[cr][cc];
        if (cell.revealed || cell.flagged) continue;
        cell.revealed = true;
        if (cell.adjacent === 0 && !cell.isMine) {
          for (let dr = -1; dr <= 1; dr += 1) {
            for (let dc = -1; dc <= 1; dc += 1) {
              const nr = cr + dr;
              const nc = cc + dc;
              if (nr >= 0 && nr < next.length && nc >= 0 && nc < next[0].length) {
                if (!next[nr][nc].revealed) queue.push([nr, nc]);
              }
            }
          }
        }
      }

      const safeRemaining = next
        .flat()
        .filter((cell) => !cell.isMine && !cell.revealed).length;
      if (safeRemaining === 0) {
        setMineStatus('won');
      }
      return next;
    });
  };

  const toggleFlag = (e: React.MouseEvent, r: number, c: number) => {
    e.preventDefault();
    toggleFlagCell(r, c);
  };

  const flaggedCount = board.flat().filter((c) => c.flagged).length;

  // Snake state
  const GRID = 12;
  const [snake, setSnake] = useState<[number, number][]>([
    [5, 5],
    [5, 4],
  ]);
  const [dir, setDir] = useState<[number, number]>([0, 1]);
  const [food, setFood] = useState<[number, number]>([2, 8]);
  const [snakeAlive, setSnakeAlive] = useState(true);
  const [snakeRunning, setSnakeRunning] = useState(false);
  const [score, setScore] = useState(0);

  useEffect(() => {
    if (gameTab !== 'snake' || !snakeRunning || !snakeAlive) return;
    const timer = setInterval(() => {
      setSnake((prev) => {
        const head = prev[0];
        const nr = head[0] + dir[0];
        const nc = head[1] + dir[1];
        if (
          nr < 0 ||
          nr >= GRID ||
          nc < 0 ||
          nc >= GRID ||
          prev.some(([sr, sc]) => sr === nr && sc === nc)
        ) {
          setSnakeAlive(false);
          setSnakeRunning(false);
          return prev;
        }
        const nextSnake: [number, number][] = [[nr, nc], ...prev];
        if (nr === food[0] && nc === food[1]) {
          setScore((s) => s + 10);
          setFood([Math.floor(Math.random() * GRID), Math.floor(Math.random() * GRID)]);
        } else {
          nextSnake.pop();
        }
        return nextSnake;
      });
    }, 180);
    return () => clearInterval(timer);
  }, [gameTab, snakeRunning, snakeAlive, dir, food]);

  const resetSnake = () => {
    setSnake([
      [5, 5],
      [5, 4],
    ]);
    setDir([0, 1]);
    setFood([2, 8]);
    setSnakeAlive(true);
    setSnakeRunning(true);
    setScore(0);
  };

  return (
    <div className="space-y-2 text-xs">
      <div className="flex gap-1.5 border-b border-current/25 pb-1.5">
        <button
          type="button"
          onClick={() => setGameTab('minesweeper')}
          className={`px-2.5 py-1 border font-bold cursor-pointer ${
            gameTab === 'minesweeper' ? 'bg-black/25 border-current' : 'border-current/40'
          }`}
        >
          MINESWEEPER
        </button>
        <button
          type="button"
          onClick={() => setGameTab('snake')}
          className={`px-2.5 py-1 border font-bold cursor-pointer ${
            gameTab === 'snake' ? 'bg-black/25 border-current' : 'border-current/40'
          }`}
        >
          PIXEL SNAKE
        </button>
      </div>

      {gameTab === 'minesweeper' ? (
        <div className="space-y-2">
          <div className="flex flex-wrap items-center justify-between gap-1.5">
            <span>
              Status:{' '}
              <strong>
                {mineStatus === 'playing'
                  ? `🚩 ${flaggedCount}/10 (${flagMode ? 'Click = Flag' : 'Right-click or Flag Mode'})`
                  : mineStatus === 'won'
                    ? 'YOU WIN!'
                    : 'BOOM! GAME OVER'}
              </strong>
            </span>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setFlagMode((f) => !f)}
                className={`px-2 py-0.5 border cursor-pointer font-bold ${
                  flagMode ? 'bg-[#52ff94] text-black border-[#52ff94]' : 'border-current'
                }`}
              >
                🚩 FLAG MODE: {flagMode ? 'ON' : 'OFF'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setBoard(buildMineBoard());
                  setMineStatus('playing');
                }}
                className="px-2 py-0.5 border border-current cursor-pointer"
              >
                NEW GAME
              </button>
            </div>
          </div>
          <div className="grid grid-cols-8 gap-0.5 max-w-[260px] mx-auto bg-black/20 p-1">
            {board.map((row, r) =>
              row.map((cell, c) => (
                <button
                  key={`${r}-${c}`}
                  type="button"
                  onClick={() => revealCell(r, c)}
                  onContextMenu={(e) => toggleFlag(e, r, c)}
                  className={`w-7 h-7 text-[11px] font-bold border flex items-center justify-center cursor-pointer ${
                    cell.revealed
                      ? 'bg-black/15 border-current/30'
                      : 'bg-white/25 border-current shadow-inner'
                  }`}
                >
                  {cell.revealed
                    ? cell.isMine
                      ? '💣'
                      : cell.adjacent > 0
                        ? cell.adjacent
                        : ''
                    : cell.flagged
                      ? '🚩'
                      : ''}
                </button>
              ))
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span>
              Score: <strong>{score}</strong> {!snakeAlive && '· CRASHED'}
            </span>
            <div className="flex gap-1">
              <button
                type="button"
                onClick={() => setSnakeRunning((r) => !r)}
                disabled={!snakeAlive}
                className="px-2 py-0.5 border border-current cursor-pointer"
              >
                {snakeRunning ? 'PAUSE' : 'START'}
              </button>
              <button
                type="button"
                onClick={resetSnake}
                className="px-2 py-0.5 border border-current cursor-pointer"
              >
                RESET
              </button>
            </div>
          </div>

          <div
            className="grid gap-px mx-auto bg-black/80 p-1 border border-current"
            style={{
              gridTemplateColumns: `repeat(${GRID}, minmax(0, 1fr))`,
              width: '216px',
            }}
          >
            {Array.from({ length: GRID * GRID }).map((_, idx) => {
              const r = Math.floor(idx / GRID);
              const c = idx % GRID;
              const isHead = snake[0][0] === r && snake[0][1] === c;
              const isBody = snake.some(([sr, sc]) => sr === r && sc === c);
              const isFood = food[0] === r && food[1] === c;
              return (
                <div
                  key={idx}
                  className="w-4 h-4"
                  style={{
                    backgroundColor: isHead
                      ? '#52ff94'
                      : isBody
                        ? '#a855f7'
                        : isFood
                          ? '#ff6bd6'
                          : '#111111',
                  }}
                />
              );
            })}
          </div>

          <div className="flex justify-center gap-1.5">
            <button
              type="button"
              onClick={() => setDir([-1, 0])}
              className="px-2 py-1 border border-current cursor-pointer"
            >
              ▲
            </button>
            <button
              type="button"
              onClick={() => setDir([0, -1])}
              className="px-2 py-1 border border-current cursor-pointer"
            >
              ◀
            </button>
            <button
              type="button"
              onClick={() => setDir([1, 0])}
              className="px-2 py-1 border border-current cursor-pointer"
            >
              ▼
            </button>
            <button
              type="button"
              onClick={() => setDir([0, 1])}
              className="px-2 py-1 border border-current cursor-pointer"
            >
              ▶
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
