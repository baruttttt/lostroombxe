import React from 'react';
import { UserRole } from '../types/lostroom';

interface BarutBadgeProps {
  username?: string | null;
  role?: UserRole | null;
  rolesMap?: Record<string, UserRole>;
  compact?: boolean;
}

export function isSuperAdminAccount(
  username?: string | null,
  role?: UserRole | null,
  rolesMap?: Record<string, UserRole>
): boolean {
  if (role === 'super_admin') return true;
  if (!username) return false;
  if (rolesMap && rolesMap[username] === 'super_admin') return true;
  return false;
}

export const BarutBadge: React.FC<BarutBadgeProps> = ({
  username,
  role,
  rolesMap,
  compact = false,
}) => {
  if (!isSuperAdminAccount(username, role, rolesMap)) return null;

  return (
    <span
      title="Exclusive Super Admin Badge — BARUT"
      className={`inline-flex items-center gap-1 align-middle select-none font-pixel-ui border border-[#ffd700] text-[#ffd700] shadow-[0_0_8px_rgba(255,215,0,0.45)] ${
        compact ? 'px-1 py-0 text-[9px]' : 'px-1.5 py-0.5 text-[10px]'
      }`}
      style={{
        background: 'linear-gradient(90deg, #3b0764 0%, #6b21a8 50%, #4c1d95 100%)',
      }}
    >
      <svg
        viewBox="0 0 12 10"
        className={compact ? 'w-2.5 h-2 shrink-0' : 'w-3 h-2.5 shrink-0'}
        aria-hidden="true"
      >
        <path
          d="M1 9V3l2.5 2L6 1l2.5 4L11 3v6H1z"
          fill="#ffd700"
        />
        <rect x="1" y="9" width="10" height="1" fill="#ff6bd6" />
      </svg>
      <span>BARUT</span>
    </span>
  );
};
