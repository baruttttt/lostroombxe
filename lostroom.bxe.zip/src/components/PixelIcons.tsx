import React from 'react';

interface IconProps {
  className?: string;
}

export const DeskPortalIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="1" y="2" width="14" height="10" fill="#7b42f6" stroke="#e6dcff" strokeWidth="1" />
    <rect x="3" y="4" width="10" height="6" fill="#09060e" />
    <rect x="5" y="6" width="6" height="2" fill="#52ff94" />
    <rect x="5" y="13" width="6" height="2" fill="#c8b4f8" />
  </svg>
);

export const DeskFeedIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="2" y="1" width="12" height="14" fill="#2a1746" stroke="#c8b4f8" strokeWidth="1" />
    <rect x="4" y="4" width="8" height="2" fill="#ff6bd6" />
    <rect x="4" y="7" width="8" height="1" fill="#e6dcff" />
    <rect x="4" y="9" width="6" height="1" fill="#e6dcff" />
    <rect x="4" y="11" width="7" height="1" fill="#9882c7" />
  </svg>
);

export const DeskForumIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <path d="M1 3h5l2 2h7v9H1V3z" fill="#2a1746" stroke="#c8b4f8" strokeWidth="1" />
    <rect x="3" y="7" width="10" height="1.5" fill="#52ff94" />
    <rect x="3" y="10" width="7" height="1.5" fill="#e6dcff" />
  </svg>
);

export const DeskExploreIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <circle cx="7" cy="7" r="5" fill="#120c1c" stroke="#c8b4f8" strokeWidth="1.5" />
    <rect x="10" y="10" width="4" height="2" transform="rotate(45 10 10)" fill="#ff6bd6" />
    <rect x="6" y="5" width="2" height="2" fill="#52ff94" />
  </svg>
);

export const DeskUploadIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="2" y="10" width="12" height="4" fill="#2a1746" stroke="#c8b4f8" strokeWidth="1" />
    <path d="M8 2L4 6h3v5h2V6h3L8 2z" fill="#52ff94" />
  </svg>
);

export const DeskChatIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <path d="M2 3h12v8H6l-3 3v-3H2V3z" fill="#7b42f6" stroke="#e6dcff" strokeWidth="1" />
    <rect x="5" y="6" width="2" height="2" fill="#ffffff" />
    <rect x="9" y="6" width="2" height="2" fill="#ffffff" />
  </svg>
);

export const DeskThemeIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="2" y="2" width="12" height="12" fill="#1a1128" stroke="#c8b4f8" strokeWidth="1" />
    <rect x="4" y="4" width="3" height="3" fill="#7b42f6" />
    <rect x="9" y="4" width="3" height="3" fill="#ff6bd6" />
    <rect x="4" y="9" width="3" height="3" fill="#52ff94" />
    <rect x="9" y="9" width="3" height="3" fill="#c8b4f8" />
  </svg>
);

export const DeskHomepageIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <path d="M8 1L1 7h2v7h10V7h2L8 1z" fill="#2a1746" stroke="#c8b4f8" strokeWidth="1" />
    <rect x="6" y="9" width="4" height="5" fill="#ff6bd6" />
    <rect x="4" y="6" width="2" height="2" fill="#52ff94" />
    <rect x="10" y="6" width="2" height="2" fill="#52ff94" />
  </svg>
);

export const DeskMusicIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="1" y="2" width="14" height="12" fill="#1a1128" stroke="#c8b4f8" strokeWidth="1" />
    <rect x="5" y="4" width="6" height="2" fill="#52ff94" />
    <rect x="5" y="4" width="1.5" height="7" fill="#52ff94" />
    <rect x="9.5" y="4" width="1.5" height="6" fill="#52ff94" />
    <rect x="3.5" y="9.5" width="3" height="2.5" fill="#ff6bd6" />
    <rect x="8" y="8.5" width="3" height="2.5" fill="#ff6bd6" />
  </svg>
);

export const DeskSearchIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="1" y="1" width="14" height="14" fill="#120c1c" stroke="#52ff94" strokeWidth="1" />
    <circle cx="7" cy="7" r="3.5" fill="#1a1128" stroke="#c8b4f8" strokeWidth="1.5" />
    <rect x="9.5" y="9.5" width="4" height="2" transform="rotate(45 9.5 9.5)" fill="#ff6bd6" />
  </svg>
);

export const DeskShortsIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="3" y="1" width="10" height="14" fill="#1a1128" stroke="#ff6bd6" strokeWidth="1.2" />
    <rect x="5" y="3" width="6" height="8" fill="#09060e" stroke="#c8b4f8" strokeWidth="0.8" />
    <polygon points="7,5 7,9 10,7" fill="#52ff94" />
    <rect x="6" y="12.5" width="4" height="1.2" fill="#c8b4f8" />
  </svg>
);

export const DeskDesktopIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="1" y="2" width="14" height="10" fill="#008080" stroke="#e6dcff" strokeWidth="1" />
    <rect x="2" y="3" width="3" height="3" fill="#ffd700" />
    <rect x="2" y="7" width="3" height="2" fill="#52ff94" />
    <rect x="6" y="4" width="7" height="5" fill="#c0c0c0" stroke="#000080" strokeWidth="1" />
    <rect x="1" y="10" width="14" height="2" fill="#c0c0c0" />
    <rect x="5" y="13" width="6" height="2" fill="#c8b4f8" />
  </svg>
);

export const DeskAdminIcon: React.FC<IconProps> = ({ className = 'w-8 h-8' }) => (
  <svg viewBox="0 0 16 16" className={`${className} pixelated`} aria-hidden="true">
    <rect x="1" y="2" width="14" height="12" fill="#2e0648" stroke="#ffd700" strokeWidth="1" />
    <path d="M3 10V5l2.5 2L8 4l2.5 3L13 5v5H3z" fill="#ffd700" />
    <rect x="3" y="11" width="10" height="1.5" fill="#ff6bd6" />
  </svg>
);

export const PixelBubble: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 16 16" fill="none" shapeRendering="crispEdges" className={className} aria-hidden="true">
    <path d="M2 2h12v9H7l-3 3v-3H2V2z" stroke="currentColor" strokeWidth="1.5" />
    <rect x="4" y="6" width="2" height="2" fill="currentColor" />
    <rect x="7" y="6" width="2" height="2" fill="currentColor" />
    <rect x="10" y="6" width="2" height="2" fill="currentColor" />
  </svg>
);

export const PixelQuestion: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 16 16" fill="none" shapeRendering="crispEdges" className={className} aria-hidden="true">
    <rect x="5" y="2" width="6" height="2" fill="currentColor" />
    <rect x="3" y="4" width="2" height="2" fill="currentColor" />
    <rect x="11" y="4" width="2" height="3" fill="currentColor" />
    <rect x="9" y="7" width="2" height="2" fill="currentColor" />
    <rect x="7" y="9" width="2" height="2" fill="currentColor" />
    <rect x="7" y="13" width="2" height="2" fill="currentColor" />
  </svg>
);

export const PixelFolder: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 16 16" fill="none" shapeRendering="crispEdges" className={className} aria-hidden="true">
    <path d="M1 3h5l2 2h7v9H1V3z" stroke="currentColor" strokeWidth="1.5" />
  </svg>
);

export const PixelForum: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 16 16" fill="none" shapeRendering="crispEdges" className={className} aria-hidden="true">
    <rect x="1" y="2" width="14" height="12" stroke="currentColor" strokeWidth="1.5" />
    <rect x="2" y="4" width="12" height="2" fill="currentColor" />
    <rect x="3" y="8" width="6" height="2" fill="currentColor" />
    <rect x="3" y="11" width="9" height="1.5" fill="currentColor" />
  </svg>
);
