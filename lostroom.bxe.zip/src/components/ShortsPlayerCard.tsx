import React, { useEffect, useRef, useState } from 'react';
import { BarutBadge } from './BarutBadge';
import { AvatarBox } from './RetroMedia';
import { UserAccount, UserRole } from '../types/lostroom';
import {
  SHORT_PLAYER_SKINS,
  ShortCommentReply,
  ShortPlayerSkin,
  ShortVideoRecord,
} from '../types/shorts';
import {
  addShortComment,
  incrementShortView,
  listShortComments,
} from '../utils/shortsApi';

interface ShortsPlayerCardProps {
  short: ShortVideoRecord;
  isActive: boolean;
  shouldPreload: boolean;
  muted: boolean;
  viewerSkinOverride: ShortPlayerSkin | null;
  currentUsername: string | null;
  usersMap: Record<string, UserAccount>;
  rolesMap?: Record<string, UserRole>;
  commentsEnabled?: boolean;
  isFullscreen?: boolean;
  onToggleMute: () => void;
  onToggleFullscreen?: () => void;
  onLike: (shortId: string) => void;
  onSave: (shortId: string) => void;
  onFollow: (authorUsername: string) => void;
  onShare: (short: ShortVideoRecord) => void;
  onSelectHashtag: (tag: string) => void;
  onOpenCreatorProfile: (username: string) => void;
  onBlockCreator: (authorUsername: string) => void;
  onReportSubmit: (shortId: string, reason: string, details: string) => Promise<void>;
  onDeleteShort: (shortId: string) => void;
  onChangeVisibility: (shortId: string, visibility: ShortVideoRecord['visibility']) => void;
  onCommentAdded: () => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

export const ShortsPlayerCard: React.FC<ShortsPlayerCardProps> = ({
  short,
  isActive,
  shouldPreload,
  muted,
  viewerSkinOverride,
  currentUsername,
  usersMap,
  rolesMap,
  commentsEnabled = true,
  isFullscreen = false,
  onToggleMute,
  onToggleFullscreen,
  onLike,
  onSave,
  onFollow,
  onShare,
  onSelectHashtag,
  onOpenCreatorProfile,
  onBlockCreator,
  onReportSubmit,
  onDeleteShort,
  onChangeVisibility,
  onCommentAdded,
  onToast,
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const countedShortIdRef = useRef<string | null>(null);

  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState<ShortCommentReply[]>([]);
  const [commentsLoading, setCommentsLoading] = useState(false);
  const [commentText, setCommentText] = useState('');
  const [replyToId, setReplyToId] = useState<string | null>(null);

  const [showReportModal, setShowReportModal] = useState(false);
  const [reportReason, setReportReason] = useState('Spam or misleading');
  const [reportDetails, setReportDetails] = useState('');

  const skinKey = viewerSkinOverride || short.playerSkin || 'y2k_lavender';
  const skin = SHORT_PLAYER_SKINS[skinKey] || SHORT_PLAYER_SKINS.y2k_lavender;

  const isLiked = !!currentUsername && short.likes.includes(currentUsername);
  const isSaved = !!currentUsername && short.savedBy.includes(currentUsername);
  const isOwner = currentUsername === short.authorUsername;

  const localUserObj: UserAccount = usersMap[short.authorUsername] || {
    username: short.authorUsername,
    password: '',
    avatarType: short.authorAvatarUrl ? 'custom' : 'preset',
    avatarValue: short.authorAvatarUrl || 'cat_void',
    bio: short.authorBio || '',
    joined: '',
  };

  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;
    vid.muted = muted;
  }, [muted]);

  useEffect(() => {
    const vid = videoRef.current;
    if (!vid) return;
    if (isActive) {
      vid
        .play()
        .then(() => {
          setIsPlaying(true);
          if (countedShortIdRef.current !== short.id) {
            countedShortIdRef.current = short.id;
            incrementShortView(short.id).catch(() => {});
          }
        })
        .catch(() => {
          setIsPlaying(false);
        });
    } else {
      vid.pause();
      setIsPlaying(false);
    }
  }, [isActive, short.id]);

  const togglePlayPause = () => {
    const vid = videoRef.current;
    if (!vid) return;
    if (vid.paused) {
      vid
        .play()
        .then(() => {
          setIsPlaying(true);
          if (countedShortIdRef.current !== short.id) {
            countedShortIdRef.current = short.id;
            incrementShortView(short.id).catch(() => {});
          }
        })
        .catch(() => {});
    } else {
      vid.pause();
      setIsPlaying(false);
    }
  };

  const openComments = async () => {
    const next = !showComments;
    setShowComments(next);
    if (next) {
      setCommentsLoading(true);
      try {
        const res = await listShortComments(short.id, currentUsername);
        setComments(res.comments);
      } catch (err) {
        onToast(err instanceof Error ? err.message : 'Failed to load comments.', 'error');
      } finally {
        setCommentsLoading(false);
      }
    }
  };

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUsername) {
      onToast('Log in to comment or reply.', 'error');
      return;
    }
    if (!commentText.trim()) return;
    try {
      const res = await addShortComment(short.id, {
        username: currentUsername,
        body: commentText.trim(),
        parentId: replyToId,
      });
      setComments((prev) => [...prev, res.comment]);
      setCommentText('');
      setReplyToId(null);
      onCommentAdded();
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Comment failed.', 'error');
    }
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onReportSubmit(short.id, reportReason, reportDetails);
    setShowReportModal(false);
    setReportDetails('');
  };

  const topLevelComments = comments.filter((c) => !c.parentId);
  const repliesByParent = new Map<string, ShortCommentReply[]>();
  for (const c of comments) {
    if (c.parentId) {
      const list = repliesByParent.get(c.parentId) || [];
      list.push(c);
      repliesByParent.set(c.parentId, list);
    }
  }

  return (
    <div
      className={`relative flex flex-col border-4 overflow-hidden select-none ${
        isFullscreen ? 'h-full w-full max-w-[460px] mx-auto' : 'w-full max-w-[430px] mx-auto'
      }`}
      style={{
        backgroundColor: skin.frameBg,
        borderColor: skin.borderColor,
        color: skin.textColor,
      }}
    >
      {/* Retro Player Header Bar */}
      <div
        className="px-2.5 py-1.5 flex items-center justify-between gap-2 border-b-2 text-xs font-pixel-ui"
        style={{ borderColor: skin.borderColor, backgroundColor: skin.badgeBg }}
      >
        <div className="flex items-center gap-1.5 min-w-0">
          <span
            className="inline-block w-2 h-2 shrink-0"
            style={{ backgroundColor: isPlaying ? skin.accentColor : '#ff6bd6' }}
          />
          <span className="truncate font-bold">{short.title}</span>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <span className="text-[10px] px-1 border border-current opacity-85">
            {short.category}
          </span>
          {short.visibility !== 'public' && (
            <span className="text-[10px] px-1 bg-black text-[#ff6bd6] border border-[#ff6bd6]">
              {short.visibility.toUpperCase()}
            </span>
          )}
        </div>
      </div>

      {/* Vertical Video Stage + Floating Overlay Controls */}
      <div
        className={`relative bg-black flex items-center justify-center overflow-hidden ${
          isFullscreen ? 'flex-1 min-h-[360px]' : 'h-[52vh] min-h-[340px] max-h-[540px]'
        }`}
      >
        <video
          ref={videoRef}
          src={short.videoUrl}
          poster={short.thumbnailUrl || undefined}
          loop
          playsInline
          muted={muted}
          preload={isActive || shouldPreload ? 'auto' : 'metadata'}
          onClick={togglePlayPause}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onTimeUpdate={() => {
            const vid = videoRef.current;
            if (vid && vid.duration > 0) {
              setProgress((vid.currentTime / vid.duration) * 100);
            }
          }}
          className="w-full h-full object-contain cursor-pointer"
        />

        {/* Center Play Indicator when paused */}
        {!isPlaying && (
          <button
            type="button"
            onClick={togglePlayPause}
            aria-label="Play video"
            className="absolute inset-0 m-auto w-14 h-14 flex items-center justify-center border-2 bg-black/70 font-pixel-ui text-lg cursor-pointer"
            style={{ borderColor: skin.accentColor, color: skin.accentColor }}
          >
            ▶
          </button>
        )}

        {/* Top-Right Video Controls (Mute / Fullscreen / Play-Pause) */}
        <div className="absolute top-2.5 right-2.5 flex flex-col gap-1.5 z-20">
          <button
            type="button"
            onClick={togglePlayPause}
            className="win-btn px-2 py-1 text-[10px]"
            title="Play / Pause"
          >
            {isPlaying ? 'PAUSE' : 'PLAY'}
          </button>
          <button
            type="button"
            onClick={onToggleMute}
            className="win-btn px-2 py-1 text-[10px]"
            title="Mute / Unmute"
          >
            {muted ? 'MUTED' : 'SOUND'}
          </button>
          {onToggleFullscreen && (
            <button
              type="button"
              onClick={onToggleFullscreen}
              className="win-btn px-2 py-1 text-[10px]"
              title="Toggle Fullscreen"
            >
              {isFullscreen ? 'EXIT FS' : 'FULL'}
            </button>
          )}
        </div>

        {/* Right Side Social Action Rail (Like, Comment, Share, Save) */}
        <div className="absolute right-2.5 bottom-20 flex flex-col gap-2 z-20">
          <button
            type="button"
            onClick={() => onLike(short.id)}
            className="win-btn px-2 py-1.5 text-[10px] flex flex-col items-center min-w-[46px]"
            style={isLiked ? { color: '#ff6bd6', borderColor: '#ff6bd6' } : undefined}
          >
            <span className="text-sm leading-none">♥</span>
            <span>{short.likes.length}</span>
          </button>

          <button
            type="button"
            onClick={openComments}
            className="win-btn px-2 py-1.5 text-[10px] flex flex-col items-center min-w-[46px]"
          >
            <span className="text-sm leading-none">💬</span>
            <span>{Math.max(short.commentCount, comments.length)}</span>
          </button>

          <button
            type="button"
            onClick={() => onSave(short.id)}
            className="win-btn px-2 py-1.5 text-[10px] flex flex-col items-center min-w-[46px]"
            style={isSaved ? { color: '#52ff94', borderColor: '#52ff94' } : undefined}
          >
            <span className="text-sm leading-none">★</span>
            <span>{isSaved ? 'SAVED' : 'SAVE'}</span>
          </button>

          <button
            type="button"
            onClick={() => onShare(short)}
            className="win-btn px-2 py-1.5 text-[10px] flex flex-col items-center min-w-[46px]"
          >
            <span className="text-sm leading-none">↗</span>
            <span>SHARE</span>
          </button>
        </div>

        {/* Bottom Overlay: Creator Info, Follow, Description, Hashtags */}
        <div
          className="absolute bottom-0 left-0 right-0 p-3 pr-16 bg-gradient-to-t from-black/95 via-black/75 to-transparent z-10 space-y-1.5"
        >
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={() => onOpenCreatorProfile(short.authorUsername)}
              className="flex items-center gap-2 cursor-pointer text-left"
            >
              <AvatarBox user={localUserObj} sizeClass="w-8 h-8" />
              <span
                className="font-pixel-ui text-xs font-bold hover:underline"
                style={{ color: skin.accentColor }}
              >
                @{short.authorUsername}
              </span>
              <BarutBadge username={short.authorUsername} rolesMap={rolesMap} compact />
            </button>

            {!isOwner && (
              <button
                type="button"
                onClick={() => onFollow(short.authorUsername)}
                className="win-btn px-2 py-0.5 text-[10px]"
                style={
                  short.isFollowingAuthor
                    ? { color: '#52ff94', borderColor: '#52ff94' }
                    : undefined
                }
              >
                {short.isFollowingAuthor ? 'FOLLOWING' : '+ FOLLOW'}
              </button>
            )}
            <span className="text-[10px] opacity-75">{short.views} views</span>
          </div>

          {short.caption && (
            <p className="text-sm leading-snug text-white/95 break-words line-clamp-3">
              {short.caption}
            </p>
          )}

          {short.hashtags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {short.hashtags.map((tag) => (
                <button
                  key={tag}
                  type="button"
                  onClick={() => onSelectHashtag(tag)}
                  className="text-[11px] font-pixel-ui hover:underline cursor-pointer"
                  style={{ color: skin.accentColor }}
                >
                  #{tag}
                </button>
              ))}
            </div>
          )}

          {/* Slim Retro Progress Bar */}
          <div className="w-full h-1 bg-white/20 mt-1">
            <div
              className="h-full transition-all duration-100"
              style={{ width: `${progress}%`, backgroundColor: skin.accentColor }}
            />
          </div>
        </div>
      </div>

      {/* Bottom Moderation / Owner Controls Strip */}
      <div
        className="px-2.5 py-1.5 border-t-2 flex flex-wrap items-center justify-between gap-1.5 text-[10px] font-pixel-ui"
        style={{ borderColor: skin.borderColor, backgroundColor: skin.badgeBg }}
      >
        {isOwner ? (
          <div className="flex items-center gap-1.5 flex-wrap">
            <select
              value={short.visibility}
              onChange={(e) =>
                onChangeVisibility(
                  short.id,
                  e.target.value as ShortVideoRecord['visibility']
                )
              }
              className="win-inset px-1.5 py-0.5 text-[10px] text-white"
              aria-label="Video privacy"
            >
              <option value="public">PUBLIC</option>
              <option value="followers">FOLLOWERS ONLY</option>
              <option value="private">PRIVATE</option>
            </select>
            <button
              type="button"
              onClick={() => onDeleteShort(short.id)}
              className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
            >
              DELETE
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setShowReportModal((p) => !p)}
              className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
            >
              REPORT
            </button>
            <button
              type="button"
              onClick={() => onBlockCreator(short.authorUsername)}
              className="win-btn px-2 py-0.5 text-[10px]"
            >
              BLOCK USER
            </button>
          </div>
        )}

        <button
          type="button"
          onClick={openComments}
          className="win-btn px-2 py-0.5 text-[10px]"
        >
          {showComments ? 'HIDE COMMENTS' : `COMMENTS (${Math.max(short.commentCount, comments.length)})`}
        </button>
      </div>

      {/* Report Drawer */}
      {showReportModal && (
        <form
          onSubmit={handleReportSubmit}
          className="p-2.5 bg-[#120c1c] border-t-2 border-[#ff6bd6] space-y-2 text-xs"
        >
          <div className="font-pixel-ui text-[10px] text-[#ff6bd6]">
            REPORT SHORT VIDEO FOR MODERATION
          </div>
          <select
            value={reportReason}
            onChange={(e) => setReportReason(e.target.value)}
            className="w-full win-inset px-2 py-1 text-white"
          >
            <option value="Spam or misleading">Spam or misleading</option>
            <option value="Harassment or hate">Harassment or hate</option>
            <option value="Inappropriate content">Inappropriate content</option>
            <option value="Copyright / unauthorized upload">Copyright / unauthorized upload</option>
          </select>
          <input
            type="text"
            value={reportDetails}
            onChange={(e) => setReportDetails(e.target.value)}
            placeholder="Optional details for moderation..."
            className="w-full win-inset px-2 py-1 text-white"
          />
          <div className="flex gap-1.5">
            <button type="submit" className="win-btn win-btn-primary px-2.5 py-1 text-[10px]">
              SUBMIT REPORT
            </button>
            <button
              type="button"
              onClick={() => setShowReportModal(false)}
              className="win-btn px-2.5 py-1 text-[10px]"
            >
              CANCEL
            </button>
          </div>
        </form>
      )}

      {/* Comments & Replies Drawer */}
      {showComments && (
        <div className="p-3 bg-[#09060e] border-t-2 border-[#7b42f6] space-y-2.5 max-h-64 overflow-y-auto text-sm">
          {commentsEnabled ? (
            <form onSubmit={handleSubmitComment} className="space-y-1.5">
              {replyToId && (
                <div className="flex items-center justify-between text-[10px] text-[#52ff94]">
                  <span>Replying to comment...</span>
                  <button
                    type="button"
                    onClick={() => setReplyToId(null)}
                    className="underline cursor-pointer"
                  >
                    Cancel reply
                  </button>
                </div>
              )}
              <div className="flex gap-1.5">
                <input
                  type="text"
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder={replyToId ? 'Write a reply...' : 'Add a comment...'}
                  maxLength={400}
                  className="flex-1 win-inset px-2 py-1 text-white text-sm"
                />
                <button type="submit" className="win-btn win-btn-primary px-2.5 py-1 text-[10px]">
                  POST
                </button>
              </div>
            </form>
          ) : (
            <div className="win-inset px-2.5 py-1.5 text-xs text-[#ff6bd6]">
              Commenting is temporarily paused by Super Admin (God Mode).
            </div>
          )}

          {commentsLoading ? (
            <div className="text-xs text-[#a690d6]">Loading comments...</div>
          ) : topLevelComments.length === 0 ? (
            <div className="text-xs text-[#a690d6]">No comments yet. Start the conversation!</div>
          ) : (
            <div className="space-y-2">
              {topLevelComments.map((c) => {
                const childReplies = repliesByParent.get(c.id) || [];
                return (
                  <div key={c.id} className="bg-[#120c1c] border border-[#2a1746] p-2 space-y-1">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          type="button"
                          onClick={() => onOpenCreatorProfile(c.authorUsername)}
                          className="font-pixel-ui text-[#52ff94] hover:underline cursor-pointer"
                        >
                          @{c.authorUsername}
                        </button>
                        <BarutBadge username={c.authorUsername} rolesMap={rolesMap} compact />
                      </div>
                      <button
                        type="button"
                        onClick={() => setReplyToId(c.id)}
                        className="text-[10px] text-[#c8b4f8] hover:underline cursor-pointer"
                      >
                        REPLY
                      </button>
                    </div>
                    <p className="text-sm text-[#e6dcff] break-words">{c.body}</p>

                    {childReplies.length > 0 && (
                      <div className="pl-3 mt-1.5 border-l-2 border-[#7b42f6] space-y-1">
                        {childReplies.map((rep) => (
                          <div key={rep.id} className="text-xs flex items-center gap-1 flex-wrap">
                            <span className="font-pixel-ui text-[#ff6bd6]">
                              @{rep.authorUsername}:
                            </span>
                            <BarutBadge username={rep.authorUsername} rolesMap={rolesMap} compact />
                            <span className="text-[#c8b4f8]">{rep.body}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
