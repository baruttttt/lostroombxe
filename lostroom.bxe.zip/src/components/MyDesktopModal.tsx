import React, { useEffect, useRef, useState } from 'react';
import { AudioTrack, MediaAsset } from '../types/homepage';
import {
  createDefaultDesktopConfig,
  DESKTOP_THEME_PRESETS,
  DesktopAppId,
  DesktopCalendarEvent,
  DesktopConfig,
  DesktopFileItem,
  DesktopNote,
  DesktopThemePreset,
  DesktopWindowState,
} from '../types/desktop';
import { PageId, UserAccount } from '../types/lostroom';
import { listAudioTracks, listMediaAssets, uploadImageAsset } from '../utils/homepageApi';
import { getUserDesktop, saveUserDesktop } from '../utils/desktopApi';
import { BarutBadge } from './BarutBadge';
import { DesktopGames } from './DesktopGames';
import { AvatarBox } from './RetroMedia';

interface MyDesktopModalProps {
  isOpen: boolean;
  currentUsername: string | null;
  users: Record<string, UserAccount>;
  rolesMap: Record<string, 'super_admin' | 'admin' | 'moderator' | 'member'>;
  onClose: () => void;
  onNavigateAppPage: (page: PageId) => void;
  onOpenPublicUrl: (path: string) => void;
  onOpenProfile: (username: string) => void;
  onToast: (msg: string, type?: 'info' | 'error') => void;
}

const APP_TITLES: Record<DesktopAppId, string> = {
  files: 'My Files',
  music: 'Music Player',
  gallery: 'Personal Gallery',
  notepad: 'Notepad',
  calculator: 'Calculator',
  calendar: 'Calendar',
  browser: 'LOSTROOM Browser',
  settings: 'Desktop Settings',
  games: 'Retro Games',
  profile: 'My Profile',
};

function createInitialWindows(): Record<DesktopAppId, DesktopWindowState> {
  const base: Partial<Record<DesktopAppId, DesktopWindowState>> = {};
  (Object.keys(APP_TITLES) as DesktopAppId[]).forEach((id, idx) => {
    base[id] = {
      id,
      title: APP_TITLES[id],
      isOpen: false,
      isMinimized: false,
      isMaximized: false,
      x: 165 + (idx % 4) * 26,
      y: 28 + (idx % 4) * 24,
      width: id === 'music' || id === 'gallery' || id === 'settings' ? 430 : 370,
      height: id === 'calculator' ? 330 : 340,
      zIndex: 10 + idx,
    };
  });
  return base as Record<DesktopAppId, DesktopWindowState>;
}

export const MyDesktopModal: React.FC<MyDesktopModalProps> = ({
  isOpen,
  currentUsername,
  users,
  rolesMap,
  onClose,
  onNavigateAppPage,
  onOpenPublicUrl,
  onOpenProfile,
  onToast,
}) => {
  // Outer Popup Window State (minimize, maximize, drag, resize)
  const [outerMinimized, setOuterMinimized] = useState(false);
  const [outerMaximized, setOuterMaximized] = useState(false);
  const [outerPos, setOuterPos] = useState({ x: 40, y: 28 });
  const [outerSize, setOuterSize] = useState({ w: 980, h: 640 });

  // Visitor / Owner Switcher inside My Desktop
  const [viewingOwner, setViewingOwner] = useState<string>('');
  const [visitInput, setVisitInput] = useState('');
  const [desktopError, setDesktopError] = useState<string | null>(null);
  const [loadingDesktop, setLoadingDesktop] = useState(false);
  const [savingDesktop, setSavingDesktop] = useState(false);

  // Persisted Desktop State
  const [isPublic, setIsPublic] = useState(false);
  const [config, setConfig] = useState<DesktopConfig>(() => createDefaultDesktopConfig());
  const [notes, setNotes] = useState<DesktopNote[]>([
    {
      id: 'welcome-note',
      title: 'readme.txt',
      body: 'Welcome to My Desktop!\nThis optional OS space saves notes, wallpapers, layout, and files to your account.',
      updatedAt: new Date().toISOString(),
    },
  ]);
  const [files, setFiles] = useState<DesktopFileItem[]>([
    {
      id: 'folder-docs',
      name: 'Documents',
      type: 'folder',
      parentId: null,
      content: '',
      createdAt: new Date().toISOString(),
    },
    {
      id: 'file-hello',
      name: 'hello_2000.txt',
      type: 'text',
      parentId: null,
      content: 'sometime, everytime... LOSTROOM.BXE virtual desktop.',
      createdAt: new Date().toISOString(),
    },
  ]);
  const [calendarEvents, setCalendarEvents] = useState<DesktopCalendarEvent[]>([]);

  // Desktop UI state
  const [windows, setWindows] = useState<Record<DesktopAppId, DesktopWindowState>>(
    createInitialWindows
  );
  const [topZ, setTopZ] = useState(30);
  const [startMenuOpen, setStartMenuOpen] = useState(false);
  const [nowTime, setNowTime] = useState(() => new Date());

  // Built-in App Specific States
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const [newFileName, setNewFileName] = useState('');
  const [newFileType, setNewFileType] = useState<'folder' | 'text'>('text');

  const [activeNoteId, setActiveNoteId] = useState<string>('welcome-note');
  const [calcDisplay, setCalcDisplay] = useState('0');
  const [calcPrev, setCalcPrev] = useState<number | null>(null);
  const [calcOp, setCalcOp] = useState<string | null>(null);
  const [calcResetNext, setCalcResetNext] = useState(false);

  const [calYear, setCalYear] = useState(() => new Date().getFullYear());
  const [calMonth, setCalMonth] = useState(() => new Date().getMonth());
  const [selectedDateStr, setSelectedDateStr] = useState(() =>
    new Date().toISOString().slice(0, 10)
  );
  const [newEventTitle, setNewEventTitle] = useState('');

  // Audio & Image Libraries for Music Player & Gallery apps
  const [tracks, setTracks] = useState<AudioTrack[]>([]);
  const [activeTrackIdx, setActiveTrackIdx] = useState(0);
  const [isPlayingTrack, setIsPlayingTrack] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [galleryAssets, setGalleryAssets] = useState<MediaAsset[]>([]);
  const [lightboxAsset, setLightboxAsset] = useState<MediaAsset | null>(null);

  // Dragging refs (outer popup, inner windows, desktop icons, outer resize)
  const dragOuterRef = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(null);
  const resizeOuterRef = useRef<{ startX: number; startY: number; origW: number; origH: number } | null>(null);
  const dragWinRef = useRef<{
    id: DesktopAppId;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
  } | null>(null);
  const dragIconRef = useRef<{
    id: DesktopAppId;
    startX: number;
    startY: number;
    origX: number;
    origY: number;
    moved: boolean;
  } | null>(null);

  const activeDesktopTarget = viewingOwner || currentUsername || '';
  const isOwnerMode = Boolean(
    currentUsername && (!viewingOwner || viewingOwner === currentUsername)
  );

  // Live Clock inside My Desktop
  useEffect(() => {
    if (!isOpen) return;
    const t = setInterval(() => setNowTime(new Date()), 1000);
    return () => clearInterval(t);
  }, [isOpen]);

  // Center outer popup nicely when first opened
  useEffect(() => {
    if (isOpen) {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const w = Math.min(1020, Math.max(320, vw - 28));
      const h = Math.min(680, Math.max(440, vh - 40));
      setOuterSize({ w, h });
      setOuterPos({
        x: Math.max(12, Math.floor((vw - w) / 2)),
        y: Math.max(12, Math.floor((vh - h) / 2)),
      });
      setOuterMinimized(false);
    }
  }, [isOpen]);

  // Load persisted desktop when opened or switching target owner
  useEffect(() => {
    if (!isOpen || !activeDesktopTarget) return;
    let active = true;
    setLoadingDesktop(true);
    setDesktopError(null);

    getUserDesktop(activeDesktopTarget, currentUsername)
      .then((res) => {
        if (!active) return;
        const d = res.desktop;
        setIsPublic(d.isPublic);
        if (d.config && Object.keys(d.config).length > 0) {
          setConfig({
            ...createDefaultDesktopConfig(),
            ...d.config,
            icons:
              Array.isArray(d.config.icons) && d.config.icons.length > 0
                ? d.config.icons
                : createDefaultDesktopConfig().icons,
          });
        } else {
          setConfig(createDefaultDesktopConfig());
        }
        if (d.isOwner) {
          if (Array.isArray(d.notes) && d.notes.length > 0) {
            setNotes(d.notes);
            setActiveNoteId(d.notes[0].id);
          }
          if (Array.isArray(d.files) && d.files.length > 0) {
            setFiles(d.files);
          }
          if (Array.isArray(d.calendarEvents)) {
            setCalendarEvents(d.calendarEvents);
          }
        }
      })
      .catch((err) => {
        if (!active) return;
        setDesktopError(err instanceof Error ? err.message : 'Unable to load desktop.');
      })
      .finally(() => {
        if (active) setLoadingDesktop(false);
      });

    if (isOwnerMode && currentUsername) {
      listAudioTracks(currentUsername)
        .then((res) => active && setTracks(res.tracks))
        .catch(() => {});
      listMediaAssets(currentUsername)
        .then((res) => active && setGalleryAssets(res.assets))
        .catch(() => {});
    }

    return () => {
      active = false;
    };
  }, [isOpen, activeDesktopTarget, currentUsername, isOwnerMode]);

  // Global mousemove / mouseup handlers for dragging/resizing
  useEffect(() => {
    const onMouseMove = (e: MouseEvent) => {
      if (dragOuterRef.current) {
        const d = dragOuterRef.current;
        setOuterPos({
          x: Math.max(0, d.origX + (e.clientX - d.startX)),
          y: Math.max(0, d.origY + (e.clientY - d.startY)),
        });
      }
      if (resizeOuterRef.current) {
        const r = resizeOuterRef.current;
        setOuterSize({
          w: Math.max(320, r.origW + (e.clientX - r.startX)),
          h: Math.max(360, r.origH + (e.clientY - r.startY)),
        });
      }
      if (dragWinRef.current) {
        const dw = dragWinRef.current;
        setWindows((prev) => ({
          ...prev,
          [dw.id]: {
            ...prev[dw.id],
            x: Math.max(0, dw.origX + (e.clientX - dw.startX)),
            y: Math.max(0, dw.origY + (e.clientY - dw.startY)),
          },
        }));
      }
      if (dragIconRef.current) {
        const di = dragIconRef.current;
        const dx = e.clientX - di.startX;
        const dy = e.clientY - di.startY;
        if (Math.abs(dx) > 4 || Math.abs(dy) > 4) {
          di.moved = true;
          setConfig((prev) => ({
            ...prev,
            icons: prev.icons.map((ic) =>
              ic.id === di.id
                ? { ...ic, x: Math.max(6, di.origX + dx), y: Math.max(6, di.origY + dy) }
                : ic
            ),
          }));
        }
      }
    };
    const onMouseUp = () => {
      dragOuterRef.current = null;
      resizeOuterRef.current = null;
      dragWinRef.current = null;
      dragIconRef.current = null;
    };
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
    };
  }, []);

  if (!isOpen) return null;

  // Minimized Floating Dock Pill (user can use rest of website normally and restore anytime)
  if (outerMinimized) {
    return (
      <div className="fixed bottom-14 right-4 z-50 win-box p-1.5 flex items-center gap-2 bg-[var(--bg-panel)]">
        <span className="font-pixel-ui text-[10px] text-[#52ff94]">🖥️ MY DESKTOP</span>
        <button
          type="button"
          onClick={() => setOuterMinimized(false)}
          className="win-btn win-btn-primary px-2 py-0.5 text-[10px]"
        >
          RESTORE
        </button>
        <button
          type="button"
          onClick={onClose}
          className="win-btn px-2 py-0.5 text-[10px] text-[#ff6bd6]"
        >
          CLOSE
        </button>
      </div>
    );
  }

  const openApp = (id: DesktopAppId) => {
    setStartMenuOpen(false);
    // Strict privacy: never open private apps on another user's public desktop
    if (!isOwnerMode && ['files', 'notepad', 'calendar', 'gallery'].includes(id)) {
      onToast('Private apps are hidden on public desktop visits.', 'error');
      return;
    }
    const nextZ = topZ + 1;
    setTopZ(nextZ);
    setWindows((prev) => ({
      ...prev,
      [id]: {
        ...prev[id],
        isOpen: true,
        isMinimized: false,
        zIndex: nextZ,
      },
    }));
  };

  const focusWindow = (id: DesktopAppId) => {
    const nextZ = topZ + 1;
    setTopZ(nextZ);
    setWindows((prev) => ({
      ...prev,
      [id]: { ...prev[id], isMinimized: false, zIndex: nextZ },
    }));
  };

  const closeAppWindow = (id: DesktopAppId) => {
    setWindows((prev) => ({
      ...prev,
      [id]: { ...prev[id], isOpen: false, isMinimized: false },
    }));
  };

  const handleSaveDesktopLayout = async (overridePublic?: boolean) => {
    if (!currentUsername || !isOwnerMode) {
      onToast('Log in as the desktop owner to save settings.', 'error');
      return;
    }
    setSavingDesktop(true);
    try {
      await saveUserDesktop(currentUsername, {
        isPublic: overridePublic !== undefined ? overridePublic : isPublic,
        config,
        notes,
        files,
        calendarEvents,
      });
      onToast('My Desktop layout & files saved to your account!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Save failed.', 'error');
    } finally {
      setSavingDesktop(false);
    }
  };

  const applyThemePreset = (presetKey: DesktopThemePreset) => {
    const p = DESKTOP_THEME_PRESETS[presetKey];
    setConfig((prev) => ({
      ...prev,
      themePreset: presetKey,
      wallpaperBg: p.wallpaperBg,
      windowBg: p.windowBg,
      windowTitleBg: p.windowTitleBg,
      windowBorder: p.windowBorder,
      textColor: p.textColor,
      taskbarBg: p.taskbarBg,
      taskbarText: p.taskbarText,
    }));
  };

  const handleWallpaperUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUsername) return;
    try {
      const res = await uploadImageAsset(file, currentUsername, 'background');
      setConfig((prev) => ({ ...prev, wallpaperUrl: res.asset.url }));
      setGalleryAssets((prev) => [res.asset, ...prev]);
      onToast('Wallpaper uploaded!');
    } catch (err) {
      onToast(err instanceof Error ? err.message : 'Wallpaper upload failed.', 'error');
    }
  };

  // Calculator helpers
  const pressCalcDigit = (digit: string) => {
    if (calcResetNext) {
      setCalcDisplay(digit === '.' ? '0.' : digit);
      setCalcResetNext(false);
    } else if (calcDisplay === '0' && digit !== '.') {
      setCalcDisplay(digit);
    } else if (digit === '.' && calcDisplay.includes('.')) {
      return;
    } else {
      setCalcDisplay(calcDisplay + digit);
    }
  };

  const pressCalcOp = (op: string) => {
    const cur = parseFloat(calcDisplay);
    if (calcPrev !== null && calcOp && !calcResetNext) {
      const result = computeCalc(calcPrev, cur, calcOp);
      setCalcDisplay(String(result));
      setCalcPrev(result);
    } else {
      setCalcPrev(cur);
    }
    setCalcOp(op);
    setCalcResetNext(true);
  };

  const computeCalc = (a: number, b: number, op: string): number => {
    switch (op) {
      case '+':
        return a + b;
      case '-':
        return a - b;
      case '*':
        return a * b;
      case '/':
        return b === 0 ? 0 : Number((a / b).toFixed(8));
      default:
        return b;
    }
  };

  const pressCalcEquals = () => {
    if (calcPrev === null || !calcOp) return;
    const cur = parseFloat(calcDisplay);
    const result = computeCalc(calcPrev, cur, calcOp);
    setCalcDisplay(String(result));
    setCalcPrev(null);
    setCalcOp(null);
    setCalcResetNext(true);
  };

  const formattedClock = nowTime.toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    hour12: config.clockFormat === '12h',
  });
  const formattedDate = nowTime.toLocaleDateString([], {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  const openWindowsList = (Object.values(windows) as DesktopWindowState[]).filter(
    (w) => w.isOpen
  );
  const activeNote = notes.find((n) => n.id === activeNoteId) || notes[0] || null;
  const activeTrack = tracks[activeTrackIdx] || null;

  // Calendar grid build
  const firstDayOfMonth = new Date(calYear, calMonth, 1).getDay();
  const daysInMonth = new Date(calYear, calMonth + 1, 0).getDate();
  const monthLabel = new Date(calYear, calMonth, 1).toLocaleDateString([], {
    month: 'long',
    year: 'numeric',
  });

  const renderAppBody = (appId: DesktopAppId) => {
    switch (appId) {
      case 'files': {
        const visibleFiles = files.filter((f) => f.parentId === currentFolderId);
        return (
          <div className="space-y-2 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-1 border-b border-current/25 pb-1.5">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={!currentFolderId}
                  onClick={() => setCurrentFolderId(null)}
                  className="px-2 py-0.5 border border-current disabled:opacity-40 cursor-pointer"
                >
                  ⬆ ROOT
                </button>
                <span className="font-bold">
                  {currentFolderId
                    ? files.find((f) => f.id === currentFolderId)?.name || 'Folder'
                    : 'C:\\MY_FILES'}
                </span>
              </div>
              <span className="opacity-70">{visibleFiles.length} items</span>
            </div>

            <div className="flex gap-1">
              <select
                value={newFileType}
                onChange={(e) => setNewFileType(e.target.value as 'folder' | 'text')}
                className="px-1.5 py-1 border border-current bg-black/15 text-xs"
              >
                <option value="text">File</option>
                <option value="folder">Folder</option>
              </select>
              <input
                type="text"
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                placeholder="New file or folder name..."
                className="flex-1 px-2 py-1 border border-current bg-black/15 text-xs"
              />
              <button
                type="button"
                onClick={() => {
                  const clean = newFileName.trim();
                  if (!clean) return;
                  const newItem: DesktopFileItem = {
                    id: `df-${Date.now()}`,
                    name: clean,
                    type: newFileType,
                    parentId: currentFolderId,
                    content: newFileType === 'text' ? 'New file created in My Files.' : '',
                    createdAt: new Date().toISOString(),
                  };
                  setFiles((prev) => [newItem, ...prev]);
                  setNewFileName('');
                }}
                className="px-2.5 py-1 border border-current font-bold cursor-pointer"
              >
                + ADD
              </button>
            </div>

            <div className="space-y-1 max-h-48 overflow-y-auto">
              {visibleFiles.length === 0 ? (
                <div className="opacity-70 p-3 text-center">Empty folder.</div>
              ) : (
                visibleFiles.map((f) => (
                  <div
                    key={f.id}
                    className="flex items-center justify-between gap-2 p-1.5 border border-current/25 bg-black/10"
                  >
                    <button
                      type="button"
                      onClick={() => {
                        if (f.type === 'folder') {
                          setCurrentFolderId(f.id);
                        } else {
                          const existingNote = notes.find((n) => n.id === f.id);
                          if (!existingNote) {
                            setNotes((prev) => [
                              {
                                id: f.id,
                                title: f.name,
                                body: f.content,
                                updatedAt: new Date().toISOString(),
                              },
                              ...prev,
                            ]);
                          }
                          setActiveNoteId(f.id);
                          openApp('notepad');
                        }
                      }}
                      className="flex items-center gap-1.5 text-left truncate cursor-pointer hover:underline"
                    >
                      <span>{f.type === 'folder' ? '📁' : '📄'}</span>
                      <span className="truncate font-bold">{f.name}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        setFiles((prev) =>
                          prev.filter((item) => item.id !== f.id && item.parentId !== f.id)
                        )
                      }
                      className="px-1.5 py-0.5 border border-current text-[10px] cursor-pointer"
                    >
                      DEL
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        );
      }

      case 'music':
        return (
          <div className="space-y-2.5 text-xs">
            <audio
              ref={audioRef}
              src={activeTrack?.url || undefined}
              onEnded={() => {
                if (tracks.length > 0) {
                  setActiveTrackIdx((i) => (i + 1) % tracks.length);
                }
              }}
              onTimeUpdate={() => {
                const a = audioRef.current;
                if (a && a.duration > 0) {
                  setAudioProgress((a.currentTime / a.duration) * 100);
                }
              }}
            />
            {!currentUsername ? (
              <div className="p-3 border border-current/30 text-center">
                Log in to play your uploaded MP3 library.
              </div>
            ) : tracks.length === 0 ? (
              <div className="p-3 border border-current/30 text-center space-y-2">
                <div>No MP3 tracks uploaded yet.</div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigateAppPage('playlists');
                  }}
                  className="px-2.5 py-1 border border-current font-bold cursor-pointer"
                >
                  OPEN PLAYLISTS TO UPLOAD MP3
                </button>
              </div>
            ) : (
              <>
                <div className="p-2 border border-current bg-black/20 space-y-1">
                  <div className="font-bold truncate">
                    {activeTrack?.title || 'Select track'}
                  </div>
                  <div className="opacity-80 truncate">{activeTrack?.artist}</div>
                  <div className="w-full h-2 bg-black/40 border border-current/40">
                    <div
                      className="h-full bg-[#52ff94]"
                      style={{ width: `${audioProgress}%` }}
                    />
                  </div>
                  <div className="flex gap-1.5 pt-1">
                    <button
                      type="button"
                      onClick={() =>
                        setActiveTrackIdx((i) => (i - 1 + tracks.length) % tracks.length)
                      }
                      className="px-2 py-0.5 border border-current cursor-pointer"
                    >
                      ⏮
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const a = audioRef.current;
                        if (!a) return;
                        if (a.paused) {
                          a.play().then(() => setIsPlayingTrack(true)).catch(() => {});
                        } else {
                          a.pause();
                          setIsPlayingTrack(false);
                        }
                      }}
                      className="px-3 py-0.5 border border-current font-bold cursor-pointer"
                    >
                      {isPlayingTrack ? '⏸ PAUSE' : '▶ PLAY'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTrackIdx((i) => (i + 1) % tracks.length)}
                      className="px-2 py-0.5 border border-current cursor-pointer"
                    >
                      ⏭
                    </button>
                  </div>
                </div>
                <div className="max-h-36 overflow-y-auto space-y-1">
                  {tracks.map((tr, i) => (
                    <button
                      key={tr.id}
                      type="button"
                      onClick={() => {
                        setActiveTrackIdx(i);
                        setTimeout(() => {
                          audioRef.current?.play().then(() => setIsPlayingTrack(true)).catch(() => {});
                        }, 60);
                      }}
                      className={`w-full text-left px-2 py-1 border truncate cursor-pointer ${
                        i === activeTrackIdx
                          ? 'border-current bg-black/25 font-bold'
                          : 'border-current/25'
                      }`}
                    >
                      {i + 1}. {tr.title} — {tr.artist}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        );

      case 'gallery':
        return (
          <div className="space-y-2 text-xs">
            {lightboxAsset ? (
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-bold truncate">{lightboxAsset.filename}</span>
                  <button
                    type="button"
                    onClick={() => setLightboxAsset(null)}
                    className="px-2 py-0.5 border border-current cursor-pointer"
                  >
                    BACK
                  </button>
                </div>
                <img
                  src={lightboxAsset.url}
                  alt={lightboxAsset.filename}
                  className="w-full max-h-48 object-contain bg-black border border-current/40"
                />
                <button
                  type="button"
                  onClick={() => {
                    setConfig((prev) => ({ ...prev, wallpaperUrl: lightboxAsset.url }));
                    onToast('Wallpaper updated from Gallery!');
                  }}
                  className="w-full py-1 border border-current font-bold cursor-pointer"
                >
                  SET AS WALLPAPER
                </button>
              </div>
            ) : galleryAssets.length === 0 ? (
              <div className="p-4 text-center opacity-80 space-y-2">
                <div>No uploaded images in your media library yet.</div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigateAppPage('homepage');
                  }}
                  className="px-2.5 py-1 border border-current font-bold cursor-pointer"
                >
                  UPLOAD IN MY HOMEPAGE
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-1.5 max-h-60 overflow-y-auto">
                {galleryAssets.map((a) => (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => setLightboxAsset(a)}
                    className="border border-current/40 p-1 bg-black/20 hover:border-current cursor-pointer"
                  >
                    <img
                      src={a.url}
                      alt={a.filename}
                      className="w-full h-16 object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>
        );

      case 'notepad':
        return (
          <div className="space-y-2 text-xs h-full flex flex-col">
            <div className="flex items-center gap-1 flex-wrap">
              <select
                value={activeNote?.id || ''}
                onChange={(e) => setActiveNoteId(e.target.value)}
                className="flex-1 px-1.5 py-1 border border-current bg-black/15"
              >
                {notes.map((n) => (
                  <option key={n.id} value={n.id}>
                    {n.title}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => {
                  const fresh: DesktopNote = {
                    id: `note-${Date.now()}`,
                    title: `note_${notes.length + 1}.txt`,
                    body: '',
                    updatedAt: new Date().toISOString(),
                  };
                  setNotes((prev) => [fresh, ...prev]);
                  setActiveNoteId(fresh.id);
                }}
                className="px-2 py-1 border border-current cursor-pointer"
              >
                + NEW
              </button>
              {notes.length > 1 && activeNote && (
                <button
                  type="button"
                  onClick={() => {
                    const remaining = notes.filter((n) => n.id !== activeNote.id);
                    setNotes(remaining);
                    if (remaining[0]) setActiveNoteId(remaining[0].id);
                  }}
                  className="px-2 py-1 border border-current cursor-pointer"
                >
                  DEL
                </button>
              )}
            </div>
            {activeNote && (
              <>
                <input
                  type="text"
                  value={activeNote.title}
                  onChange={(e) =>
                    setNotes((prev) =>
                      prev.map((n) =>
                        n.id === activeNote.id ? { ...n, title: e.target.value } : n
                      )
                    )
                  }
                  className="px-2 py-1 border border-current bg-black/15 font-bold"
                />
                <textarea
                  value={activeNote.body}
                  onChange={(e) =>
                    setNotes((prev) =>
                      prev.map((n) =>
                        n.id === activeNote.id
                          ? { ...n, body: e.target.value, updatedAt: new Date().toISOString() }
                          : n
                      )
                    )
                  }
                  rows={7}
                  className="w-full flex-1 p-2 border border-current bg-black/15 font-mono text-xs resize-none"
                />
              </>
            )}
            <button
              type="button"
              onClick={() => handleSaveDesktopLayout()}
              className="py-1 border border-current font-bold cursor-pointer"
            >
              SAVE NOTES TO ACCOUNT
            </button>
          </div>
        );

      case 'calculator':
        return (
          <div className="space-y-2 text-xs">
            <div className="p-2 border-2 border-current bg-black text-[#52ff94] font-mono text-right text-lg truncate">
              {calcDisplay}
            </div>
            <div className="grid grid-cols-4 gap-1">
              {[
                'C',
                '+/-',
                '%',
                '/',
                '7',
                '8',
                '9',
                '*',
                '4',
                '5',
                '6',
                '-',
                '1',
                '2',
                '3',
                '+',
                '0',
                '.',
                '=',
              ].map((btn) => (
                <button
                  key={btn}
                  type="button"
                  onClick={() => {
                    if (btn === 'C') {
                      setCalcDisplay('0');
                      setCalcPrev(null);
                      setCalcOp(null);
                    } else if (btn === '+/-') {
                      setCalcDisplay(String(parseFloat(calcDisplay) * -1));
                    } else if (btn === '%') {
                      setCalcDisplay(String(parseFloat(calcDisplay) / 100));
                    } else if (['+', '-', '*', '/'].includes(btn)) {
                      pressCalcOp(btn);
                    } else if (btn === '=') {
                      pressCalcEquals();
                    } else {
                      pressCalcDigit(btn);
                    }
                  }}
                  className={`py-2 border border-current font-bold cursor-pointer bg-black/15 hover:bg-black/30 ${
                    btn === '0' ? 'col-span-2' : ''
                  }`}
                >
                  {btn}
                </button>
              ))}
            </div>
          </div>
        );

      case 'calendar': {
        const eventsForDay = calendarEvents.filter((ev) => ev.date === selectedDateStr);
        return (
          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  if (calMonth === 0) {
                    setCalMonth(11);
                    setCalYear((y) => y - 1);
                  } else {
                    setCalMonth((m) => m - 1);
                  }
                }}
                className="px-2 py-0.5 border border-current cursor-pointer"
              >
                ◀
              </button>
              <span className="font-bold">{monthLabel}</span>
              <button
                type="button"
                onClick={() => {
                  if (calMonth === 11) {
                    setCalMonth(0);
                    setCalYear((y) => y + 1);
                  } else {
                    setCalMonth((m) => m + 1);
                  }
                }}
                className="px-2 py-0.5 border border-current cursor-pointer"
              >
                ▶
              </button>
            </div>
            <div className="grid grid-cols-7 gap-0.5 text-center text-[10px]">
              {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map((d) => (
                <div key={d} className="font-bold opacity-75">
                  {d}
                </div>
              ))}
              {Array.from({ length: firstDayOfMonth }).map((_, i) => (
                <div key={`empty-${i}`} />
              ))}
              {Array.from({ length: daysInMonth }).map((_, idx) => {
                const dayNum = idx + 1;
                const dStr = `${calYear}-${String(calMonth + 1).padStart(2, '0')}-${String(
                  dayNum
                ).padStart(2, '0')}`;
                const hasEvent = calendarEvents.some((ev) => ev.date === dStr);
                const isSelected = selectedDateStr === dStr;
                return (
                  <button
                    key={dStr}
                    type="button"
                    onClick={() => setSelectedDateStr(dStr)}
                    className={`py-1 border cursor-pointer ${
                      isSelected
                        ? 'border-current bg-black/35 font-bold'
                        : hasEvent
                          ? 'border-[#ff6bd6]'
                          : 'border-current/20'
                    }`}
                  >
                    {dayNum}
                  </button>
                );
              })}
            </div>
            <div className="border-t border-current/25 pt-1.5 space-y-1">
              <div className="font-bold">Events on {selectedDateStr}:</div>
              <div className="flex gap-1">
                <input
                  type="text"
                  value={newEventTitle}
                  onChange={(e) => setNewEventTitle(e.target.value)}
                  placeholder="Add reminder..."
                  className="flex-1 px-1.5 py-0.5 border border-current bg-black/15"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (!newEventTitle.trim()) return;
                    setCalendarEvents((prev) => [
                      ...prev,
                      { id: `ev-${Date.now()}`, date: selectedDateStr, title: newEventTitle.trim() },
                    ]);
                    setNewEventTitle('');
                  }}
                  className="px-2 py-0.5 border border-current font-bold cursor-pointer"
                >
                  +
                </button>
              </div>
              {eventsForDay.map((ev) => (
                <div key={ev.id} className="flex justify-between items-center">
                  <span>• {ev.title}</span>
                  <button
                    type="button"
                    onClick={() =>
                      setCalendarEvents((prev) => prev.filter((item) => item.id !== ev.id))
                    }
                    className="text-[10px] underline cursor-pointer"
                  >
                    remove
                  </button>
                </div>
              ))}
            </div>
          </div>
        );
      }

      case 'browser':
        return (
          <div className="space-y-2 text-xs">
            <div className="p-2 border border-current bg-black/15 font-mono">
              bxe://lostroom.net/internal-navigator
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {(
                [
                  { id: 'feed', label: 'Public Feed' },
                  { id: 'forum', label: 'Forum Boards' },
                  { id: 'shorts', label: 'SHORTS TV' },
                  { id: 'playlists', label: 'Music Playlists' },
                  { id: 'homepage', label: 'My Homepage' },
                  { id: 'search', label: 'Global Search' },
                  { id: 'friends', label: 'Friends List' },
                  { id: 'theme', label: 'Theme Editor' },
                ] as { id: PageId; label: string }[]
              ).map((dest) => (
                <button
                  key={dest.id}
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigateAppPage(dest.id);
                  }}
                  className="px-2 py-1.5 border border-current text-left hover:bg-black/20 cursor-pointer font-bold"
                >
                  🌐 {dest.label}
                </button>
              ))}
            </div>
            {currentUsername && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenPublicUrl(`/user/${currentUsername}`);
                }}
                className="w-full py-1 border border-current font-bold cursor-pointer"
              >
                OPEN MY PUBLIC WEBSITE (/user/{currentUsername})
              </button>
            )}
          </div>
        );

      case 'settings':
        return (
          <div className="space-y-2.5 text-xs max-h-[260px] overflow-y-auto pr-1">
            <div>
              <label className="block font-bold mb-1">THEME PRESET:</label>
              <div className="flex flex-wrap gap-1">
                {(Object.keys(DESKTOP_THEME_PRESETS) as DesktopThemePreset[]).map((key) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => applyThemePreset(key)}
                    className={`px-2 py-1 border cursor-pointer ${
                      config.themePreset === key ? 'border-current font-bold bg-black/25' : 'border-current/40'
                    }`}
                  >
                    {DESKTOP_THEME_PRESETS[key].label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <label className="block">
                Window BG:
                <input
                  type="color"
                  value={config.windowBg.startsWith('#') ? config.windowBg : '#1a1128'}
                  onChange={(e) =>
                    setConfig((p) => ({ ...p, themePreset: 'custom', windowBg: e.target.value }))
                  }
                  className="w-full h-6 mt-0.5"
                />
              </label>
              <label className="block">
                Taskbar BG:
                <input
                  type="color"
                  value={config.taskbarBg.startsWith('#') ? config.taskbarBg : '#120c1c'}
                  onChange={(e) =>
                    setConfig((p) => ({ ...p, themePreset: 'custom', taskbarBg: e.target.value }))
                  }
                  className="w-full h-6 mt-0.5"
                />
              </label>
            </div>

            <div>
              <label className="block font-bold mb-1">UPLOAD WALLPAPER:</label>
              <input
                type="file"
                accept="image/png,image/jpeg,image/gif,image/webp"
                onChange={handleWallpaperUpload}
                className="w-full text-[11px]"
              />
              {config.wallpaperUrl && (
                <button
                  type="button"
                  onClick={() => setConfig((p) => ({ ...p, wallpaperUrl: '' }))}
                  className="mt-1 px-2 py-0.5 border border-current text-[10px] cursor-pointer"
                >
                  CLEAR WALLPAPER IMAGE
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-bold">Clock Format:</label>
                <select
                  value={config.clockFormat}
                  onChange={(e) =>
                    setConfig((p) => ({ ...p, clockFormat: e.target.value as '12h' | '24h' }))
                  }
                  className="w-full px-1 py-1 border border-current bg-black/15"
                >
                  <option value="24h">24-Hour</option>
                  <option value="12h">12-Hour</option>
                </select>
              </div>
              <div>
                <label className="block font-bold">Taskbar:</label>
                <select
                  value={config.taskbarPosition}
                  onChange={(e) =>
                    setConfig((p) => ({
                      ...p,
                      taskbarPosition: e.target.value as 'bottom' | 'top',
                    }))
                  }
                  className="w-full px-1 py-1 border border-current bg-black/15"
                >
                  <option value="bottom">Bottom</option>
                  <option value="top">Top</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block font-bold mb-1">PRIVACY:</label>
              <select
                value={isPublic ? 'public' : 'private'}
                onChange={(e) => {
                  const nextPub = e.target.value === 'public';
                  setIsPublic(nextPub);
                  handleSaveDesktopLayout(nextPub);
                }}
                className="w-full px-2 py-1 border border-current bg-black/15"
              >
                <option value="private">Private Desktop (Only Me)</option>
                <option value="public">Public Desktop (Visitors see theme/icons only, no private notes/files)</option>
              </select>
            </div>

            <button
              type="button"
              disabled={savingDesktop}
              onClick={() => handleSaveDesktopLayout()}
              className="w-full py-1.5 border border-current font-bold cursor-pointer bg-black/20"
            >
              {savingDesktop ? 'SAVING...' : 'SAVE DESKTOP LAYOUT & SETTINGS'}
            </button>
          </div>
        );

      case 'games':
        return <DesktopGames />;

      case 'profile': {
        const target = activeDesktopTarget;
        const userObj = target ? users[target] : undefined;
        return (
          <div className="space-y-3 text-xs">
            {target ? (
              <>
                <div className="flex items-center gap-2.5">
                  <AvatarBox user={userObj} sizeClass="w-12 h-12" />
                  <div>
                    <div className="font-bold text-sm flex items-center gap-1.5">
                      <span>{target}</span>
                      <BarutBadge username={target} rolesMap={rolesMap} compact />
                    </div>
                    <div className="opacity-80">{userObj?.bio || 'LOSTROOM.BXE member'}</div>
                  </div>
                </div>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenProfile(target);
                    }}
                    className="flex-1 py-1.5 border border-current font-bold cursor-pointer"
                  >
                    OPEN PROFILE PAGE
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenPublicUrl(`/user/${target}`);
                    }}
                    className="flex-1 py-1.5 border border-current font-bold cursor-pointer"
                  >
                    OPEN WEBSITE
                  </button>
                </div>
              </>
            ) : (
              <div>Log in to view your profile shortcut.</div>
            )}
          </div>
        );
      }
    }
  };

  const taskbarBar = (
    <div
      className="px-2 py-1 flex items-center justify-between gap-2 border-y border-current/40 relative z-40 shrink-0"
      style={{ backgroundColor: config.taskbarBg, color: config.taskbarText }}
    >
      <div className="flex items-center gap-1.5 min-w-0 flex-1 overflow-x-auto">
        <button
          type="button"
          onClick={() => setStartMenuOpen((s) => !s)}
          className="px-2.5 py-1 border-2 border-current font-pixel-ui text-[10px] font-bold shrink-0 cursor-pointer"
        >
          ⊞ START
        </button>

        {openWindowsList.map((win) => (
          <button
            key={win.id}
            type="button"
            onClick={() =>
              win.isMinimized ? focusWindow(win.id) : setWindows((p) => ({
                ...p,
                [win.id]: { ...p[win.id], isMinimized: true },
              }))
            }
            className={`px-2 py-0.5 border text-[11px] truncate max-w-[130px] cursor-pointer ${
              win.isMinimized ? 'opacity-65' : 'font-bold bg-black/15'
            }`}
          >
            {win.title}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-2 shrink-0 text-[11px] font-pixel-ui px-2 border-l border-current/30">
        <span>{formattedClock}</span>
        {config.showDateInClock && <span className="hidden sm:inline">{formattedDate}</span>}
      </div>

      {startMenuOpen && (
        <div
          className={`absolute left-2 w-56 border-2 p-1.5 space-y-1 z-50 shadow-xl ${
            config.taskbarPosition === 'bottom' ? 'bottom-9' : 'top-9'
          }`}
          style={{
            backgroundColor: config.windowBg,
            borderColor: config.windowBorder,
            color: config.textColor,
          }}
        >
          <div
            className="px-2 py-1 font-pixel-ui text-[10px] text-white"
            style={{ background: config.windowTitleBg }}
          >
            MY DESKTOP // {activeDesktopTarget || 'GUEST'}
          </div>
          {(Object.keys(APP_TITLES) as DesktopAppId[]).map((appId) => {
            const ic = config.icons.find((x) => x.id === appId);
            return (
              <button
                key={appId}
                type="button"
                onClick={() => openApp(appId)}
                className="w-full text-left px-2 py-1 text-xs hover:bg-black/15 flex items-center gap-2 cursor-pointer"
              >
                <span>{ic?.iconGlyph || '▪'}</span>
                <span>{APP_TITLES[appId]}</span>
              </button>
            );
          })}
          {isOwnerMode && (
            <button
              type="button"
              onClick={() => {
                setStartMenuOpen(false);
                handleSaveDesktopLayout();
              }}
              className="w-full text-left px-2 py-1 text-xs font-bold border-t border-current/25 cursor-pointer"
            >
              💾 Save Desktop Layout
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="w-full text-left px-2 py-1 text-xs text-[#ff6bd6] font-bold border-t border-current/25 cursor-pointer"
          >
            ⏻ Exit My Desktop
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="fixed inset-0 z-50 bg-black/65">
      <div
        className="fixed win-box flex flex-col overflow-hidden shadow-2xl"
        style={
          outerMaximized
            ? { inset: '8px', zIndex: 60 }
            : {
                left: `${outerPos.x}px`,
                top: `${outerPos.y}px`,
                width: `${outerSize.w}px`,
                height: `${outerSize.h}px`,
                maxWidth: 'calc(100vw - 16px)',
                maxHeight: 'calc(100vh - 16px)',
                zIndex: 60,
              }
        }
      >
        {/* Outer Popup Titlebar (Drag, Visit Public Desktop, Save, Min/Max/Close) */}
        <div
          onMouseDown={(e) => {
            if (outerMaximized) return;
            dragOuterRef.current = {
              startX: e.clientX,
              startY: e.clientY,
              origX: outerPos.x,
              origY: outerPos.y,
            };
          }}
          className="win-titlebar cursor-move flex-wrap gap-2"
        >
          <div className="flex items-center gap-2 min-w-0">
            <span className="font-pixel-ui text-xs text-white truncate">
              🖥️ MY DESKTOP {viewingOwner ? `// VISITING @${viewingOwner}` : '// PERSONAL OS'}
            </span>
            {!isOwnerMode && (
              <span className="text-[10px] bg-black/60 px-1.5 text-[#52ff94]">
                PUBLIC VIEW (PRIVATE DATA HIDDEN)
              </span>
            )}
          </div>

          <div
            className="flex items-center gap-1.5 flex-wrap"
            onMouseDown={(e) => e.stopPropagation()}
          >
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (visitInput.trim()) {
                  setViewingOwner(visitInput.trim());
                }
              }}
              className="hidden sm:flex items-center gap-1"
            >
              <input
                type="text"
                value={visitInput}
                onChange={(e) => setVisitInput(e.target.value)}
                placeholder="visit user desktop..."
                className="win-inset px-1.5 py-0.5 text-[11px] text-white w-32"
              />
              <button type="submit" className="win-btn px-1.5 py-0.5 text-[10px]">
                VISIT
              </button>
              {viewingOwner && (
                <button
                  type="button"
                  onClick={() => {
                    setViewingOwner('');
                    setVisitInput('');
                    setDesktopError(null);
                  }}
                  className="win-btn px-1.5 py-0.5 text-[10px]"
                >
                  MY OS
                </button>
              )}
            </form>

            {isOwnerMode && (
              <button
                type="button"
                disabled={savingDesktop}
                onClick={() => handleSaveDesktopLayout()}
                className="win-btn px-2 py-0.5 text-[10px] text-[#52ff94]"
              >
                {savingDesktop ? 'SAVING' : 'SAVE'}
              </button>
            )}

            <button
              type="button"
              onClick={() => setOuterMinimized(true)}
              className="win-ctrl-btn"
              title="Minimize My Desktop"
            >
              _
            </button>
            <button
              type="button"
              onClick={() => setOuterMaximized((m) => !m)}
              className="win-ctrl-btn"
              title="Maximize / Restore"
            >
              □
            </button>
            <button
              type="button"
              onClick={onClose}
              className="win-ctrl-btn"
              title="Close My Desktop"
            >
              ×
            </button>
          </div>
        </div>

        {/* Desktop Workspace Canvas */}
        <div
          className={`flex-1 flex ${
            config.taskbarPosition === 'top' ? 'flex-col-reverse' : 'flex-col'
          } min-h-0 overflow-hidden`}
        >
          <div
            className="flex-1 relative overflow-hidden"
            style={{
              background: config.wallpaperUrl
                ? `url("${config.wallpaperUrl}") center / cover no-repeat`
                : config.wallpaperBg,
              color: config.textColor,
            }}
          >
            {loadingDesktop ? (
              <div className="m-6 p-4 bg-black/75 text-white border border-white/40 text-sm inline-block">
                Booting My Desktop...
              </div>
            ) : desktopError ? (
              <div className="m-6 p-4 bg-black/85 text-[#ff6bd6] border border-[#ff6bd6] space-y-2 max-w-sm">
                <div className="font-bold">{desktopError}</div>
                {viewingOwner && (
                  <button
                    type="button"
                    onClick={() => {
                      setViewingOwner('');
                      setDesktopError(null);
                    }}
                    className="win-btn px-3 py-1 text-xs"
                  >
                    RETURN TO MY DESKTOP
                  </button>
                )}
              </div>
            ) : (
              <>
                {/* Draggable Desktop Icons */}
                {config.icons.map((ic) => {
                  const lockedInPublic =
                    !isOwnerMode && ['files', 'notepad', 'calendar', 'gallery'].includes(ic.id);
                  return (
                    <button
                      key={ic.id}
                      type="button"
                      onMouseDown={(e) => {
                        dragIconRef.current = {
                          id: ic.id,
                          startX: e.clientX,
                          startY: e.clientY,
                          origX: ic.x,
                          origY: ic.y,
                          moved: false,
                        };
                      }}
                      onClick={() => {
                        if (!dragIconRef.current?.moved) openApp(ic.id);
                      }}
                      style={{ left: `${ic.x}px`, top: `${ic.y}px` }}
                      className={`absolute w-20 p-1.5 flex flex-col items-center text-center select-none cursor-pointer hover:bg-white/15 border border-transparent hover:border-white/40 ${
                        lockedInPublic ? 'opacity-45' : ''
                      }`}
                    >
                      <span className="text-2xl leading-none drop-shadow">{ic.iconGlyph}</span>
                      <span className="mt-1 px-1 bg-black/65 text-white text-[11px] leading-tight">
                        {ic.label}
                      </span>
                    </button>
                  );
                })}

                {/* Movable Mini-App Windows */}
                {openWindowsList
                  .filter((w) => !w.isMinimized)
                  .map((win) => (
                    <div
                      key={win.id}
                      onMouseDown={() => focusWindow(win.id)}
                      className="absolute flex flex-col border-2 shadow-xl overflow-hidden"
                      style={
                        win.isMaximized
                          ? {
                              inset: '6px',
                              zIndex: win.zIndex,
                              backgroundColor: config.windowBg,
                              borderColor: config.windowBorder,
                              color: config.textColor,
                            }
                          : {
                              left: `${win.x}px`,
                              top: `${win.y}px`,
                              width: `${win.width}px`,
                              maxWidth: 'calc(100% - 16px)',
                              maxHeight: 'calc(100% - 16px)',
                              zIndex: win.zIndex,
                              backgroundColor: config.windowBg,
                              borderColor: config.windowBorder,
                              color: config.textColor,
                            }
                      }
                    >
                      <div
                        onMouseDown={(e) => {
                          if (win.isMaximized) return;
                          dragWinRef.current = {
                            id: win.id,
                            startX: e.clientX,
                            startY: e.clientY,
                            origX: win.x,
                            origY: win.y,
                          };
                        }}
                        className="px-2 py-1 flex items-center justify-between text-white text-xs font-pixel-ui cursor-move"
                        style={{ background: config.windowTitleBg }}
                      >
                        <span className="truncate">{win.title}</span>
                        <div
                          className="flex items-center gap-1"
                          onMouseDown={(e) => e.stopPropagation()}
                        >
                          <button
                            type="button"
                            onClick={() =>
                              setWindows((p) => ({
                                ...p,
                                [win.id]: { ...p[win.id], isMinimized: true },
                              }))
                            }
                            className="win-ctrl-btn"
                          >
                            _
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              setWindows((p) => ({
                                ...p,
                                [win.id]: {
                                  ...p[win.id],
                                  isMaximized: !p[win.id].isMaximized,
                                },
                              }))
                            }
                            className="win-ctrl-btn"
                          >
                            □
                          </button>
                          <button
                            type="button"
                            onClick={() => closeAppWindow(win.id)}
                            className="win-ctrl-btn"
                          >
                            ×
                          </button>
                        </div>
                      </div>

                      <div className="p-2.5 overflow-y-auto flex-1">{renderAppBody(win.id)}</div>
                    </div>
                  ))}
              </>
            )}
          </div>

          {/* Desktop Taskbar */}
          {taskbarBar}
        </div>

        {/* Bottom-right Outer Resize Grip */}
        {!outerMaximized && (
          <div
            onMouseDown={(e) => {
              e.stopPropagation();
              resizeOuterRef.current = {
                startX: e.clientX,
                startY: e.clientY,
                origW: outerSize.w,
                origH: outerSize.h,
              };
            }}
            title="Drag to resize My Desktop window"
            className="hidden sm:block absolute bottom-0 right-0 w-4 h-4 cursor-nwse-resize z-50"
            style={{
              background:
                'linear-gradient(135deg, transparent 50%, var(--accent-lavender) 50%)',
            }}
          />
        )}
      </div>
    </div>
  );
};
