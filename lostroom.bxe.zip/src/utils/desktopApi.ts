import {
  DesktopCalendarEvent,
  DesktopConfig,
  DesktopFileItem,
  DesktopNote,
  UserDesktopPayload,
} from '../types/desktop';
import { getAuthHeaders } from './adminApi';

async function parseJson<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errMsg = (data as { error?: string })?.error || `Request failed (${res.status})`;
    throw new Error(errMsg);
  }
  return data as T;
}

export async function getUserDesktop(
  username: string,
  viewer?: string | null
): Promise<{ desktop: UserDesktopPayload }> {
  const q = viewer ? `?viewer=${encodeURIComponent(viewer)}` : '';
  const res = await fetch(`/api/desktop/${encodeURIComponent(username)}${q}`, {
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function saveUserDesktop(
  username: string,
  payload: {
    isPublic: boolean;
    config: DesktopConfig;
    notes: DesktopNote[];
    files: DesktopFileItem[];
    calendarEvents: DesktopCalendarEvent[];
  }
): Promise<{ desktop: UserDesktopPayload }> {
  const res = await fetch(`/api/desktop/${encodeURIComponent(username)}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      ...getAuthHeaders(),
    },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}
