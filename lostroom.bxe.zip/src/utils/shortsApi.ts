import {
  CreatorProfileSummary,
  ShortCommentReply,
  ShortPlayerSkin,
  ShortReportRecord,
  ShortVideoRecord,
  ShortVisibility,
} from '../types/shorts';

async function parseJson<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errMsg = (data as { error?: string })?.error || `Request failed (${res.status})`;
    throw new Error(errMsg);
  }
  return data as T;
}

export type ShortsFeedTab = 'feed' | 'trending' | 'newest' | 'following' | 'saved';

export async function listShorts(params: {
  viewer?: string | null;
  tab?: ShortsFeedTab;
  q?: string;
  tag?: string;
  category?: string;
  author?: string;
}): Promise<{ shorts: ShortVideoRecord[] }> {
  const sp = new URLSearchParams();
  if (params.viewer) sp.set('viewer', params.viewer);
  if (params.tab) sp.set('tab', params.tab);
  if (params.q) sp.set('q', params.q);
  if (params.tag) sp.set('tag', params.tag);
  if (params.category) sp.set('category', params.category);
  if (params.author) sp.set('author', params.author);
  const res = await fetch(`/api/shorts?${sp.toString()}`);
  return parseJson(res);
}

export async function getShortById(
  id: string,
  viewer?: string | null
): Promise<{ short: ShortVideoRecord }> {
  const q = viewer ? `?viewer=${encodeURIComponent(viewer)}` : '';
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}${q}`);
  return parseJson(res);
}

export async function listShortHashtags(
  viewer?: string | null
): Promise<{ hashtags: { tag: string; count: number }[] }> {
  const q = viewer ? `?viewer=${encodeURIComponent(viewer)}` : '';
  const res = await fetch(`/api/shorts/hashtags${q}`);
  return parseJson(res);
}

export function uploadShortVideoWithProgress(
  file: File,
  meta: {
    username: string;
    title: string;
    caption: string;
    category: string;
    hashtags: string;
    thumbnailUrl: string;
    visibility: ShortVisibility;
    playerSkin: ShortPlayerSkin;
  },
  onProgress: (percent: number) => void
): Promise<{ short: ShortVideoRecord }> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', '/api/shorts/upload', true);
    xhr.setRequestHeader('Content-Type', file.type || 'video/mp4');
    xhr.setRequestHeader('x-username', encodeURIComponent(meta.username));
    xhr.setRequestHeader('x-filename', encodeURIComponent(file.name));
    xhr.setRequestHeader('x-title', encodeURIComponent(meta.title));
    xhr.setRequestHeader('x-caption', encodeURIComponent(meta.caption));
    xhr.setRequestHeader('x-category', encodeURIComponent(meta.category));
    xhr.setRequestHeader('x-hashtags', encodeURIComponent(meta.hashtags));
    xhr.setRequestHeader('x-thumbnail-url', encodeURIComponent(meta.thumbnailUrl));
    xhr.setRequestHeader('x-visibility', meta.visibility);
    xhr.setRequestHeader('x-player-skin', meta.playerSkin);

    xhr.upload.onprogress = (evt) => {
      if (evt.lengthComputable && evt.total > 0) {
        onProgress(Math.min(99, Math.round((evt.loaded / evt.total) * 100)));
      }
    };

    xhr.onload = () => {
      try {
        const parsed = JSON.parse(xhr.responseText || '{}');
        if (xhr.status >= 200 && xhr.status < 300) {
          onProgress(100);
          resolve(parsed as { short: ShortVideoRecord });
        } else {
          reject(new Error(parsed?.error || `Upload failed (${xhr.status})`));
        }
      } catch {
        reject(new Error(`Upload failed (${xhr.status})`));
      }
    };

    xhr.onerror = () => {
      reject(new Error('Network error while uploading short video.'));
    };

    xhr.send(file);
  });
}

export async function updateShortVideo(
  id: string,
  patch: {
    username: string;
    title?: string;
    caption?: string;
    category?: string;
    hashtags?: string[];
    visibility?: ShortVisibility;
    playerSkin?: ShortPlayerSkin;
    thumbnailUrl?: string;
  }
): Promise<{ short: ShortVideoRecord }> {
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  return parseJson(res);
}

export async function deleteShortVideo(id: string, username: string): Promise<{ ok: boolean }> {
  const res = await fetch(
    `/api/shorts/${encodeURIComponent(id)}?username=${encodeURIComponent(username)}`,
    { method: 'DELETE' }
  );
  return parseJson(res);
}

export async function incrementShortView(id: string): Promise<{ views: number }> {
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}/view`, {
    method: 'POST',
  });
  return parseJson(res);
}

export async function toggleShortLike(
  id: string,
  username: string
): Promise<{ short: ShortVideoRecord }> {
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}/like`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username }),
  });
  return parseJson(res);
}

export async function toggleShortSave(
  id: string,
  username: string
): Promise<{ short: ShortVideoRecord }> {
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}/save`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username }),
  });
  return parseJson(res);
}

export async function listShortComments(
  id: string,
  viewer?: string | null
): Promise<{ comments: ShortCommentReply[] }> {
  const q = viewer ? `?viewer=${encodeURIComponent(viewer)}` : '';
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}/comments${q}`);
  return parseJson(res);
}

export async function addShortComment(
  id: string,
  payload: { username: string; body: string; parentId?: string | null }
): Promise<{ comment: ShortCommentReply }> {
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}/comments`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function reportShortVideo(
  id: string,
  payload: { username: string; reason: string; details: string }
): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/shorts/${encodeURIComponent(id)}/report`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function listShortReports(): Promise<{ reports: ShortReportRecord[] }> {
  const res = await fetch('/api/shorts/reports');
  return parseJson(res);
}

export async function resolveShortReport(
  reportId: string,
  action: 'dismiss' | 'remove'
): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/shorts/reports/${encodeURIComponent(reportId)}/resolve`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action }),
  });
  return parseJson(res);
}

export async function toggleFollowCreator(
  targetUsername: string,
  followerUsername: string
): Promise<{ isFollowing: boolean; followerCount: number }> {
  const res = await fetch(`/api/users/${encodeURIComponent(targetUsername)}/follow`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: followerUsername }),
  });
  return parseJson(res);
}

export async function blockCreator(
  targetUsername: string,
  blockerUsername: string
): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/users/${encodeURIComponent(targetUsername)}/block`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: blockerUsername }),
  });
  return parseJson(res);
}

export async function unblockCreator(
  targetUsername: string,
  blockerUsername: string
): Promise<{ ok: boolean }> {
  const res = await fetch(
    `/api/users/${encodeURIComponent(targetUsername)}/block?username=${encodeURIComponent(
      blockerUsername
    )}`,
    { method: 'DELETE' }
  );
  return parseJson(res);
}

export async function getCreatorShortsProfile(
  targetUsername: string,
  viewer?: string | null
): Promise<{ profile: CreatorProfileSummary }> {
  const q = viewer ? `?viewer=${encodeURIComponent(viewer)}` : '';
  const res = await fetch(
    `/api/users/${encodeURIComponent(targetUsername)}/creator-profile${q}`
  );
  return parseJson(res);
}

export async function getUserSafetyState(username: string): Promise<{
  blockedUsers: string[];
  videoBytesUsed: number;
  videoQuotaBytes: number;
}> {
  const res = await fetch(`/api/users/${encodeURIComponent(username)}/safety`);
  return parseJson(res);
}
