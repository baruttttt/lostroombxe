import {
  AudioTrack,
  GuestbookEntry,
  HomepageDocument,
  HomepageRecord,
  HomepageTemplateId,
  MediaAsset,
  PlaylistRecord,
} from '../types/homepage';
import { getAuthHeaders } from './adminApi';

async function parseJson<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errMsg = (data as { error?: string })?.error || `Request failed (${res.status})`;
    throw new Error(errMsg);
  }
  return data as T;
}

export interface PublishedDirectoryItem {
  username: string;
  pageTitle: string;
  pageDescription: string;
  templateId: HomepageTemplateId;
  visitorCount: number;
  publishedAt: string | null;
}

export interface PublicHomepagePayload {
  username: string;
  document: HomepageDocument;
  visitorCount: number;
  publishedAt: string | null;
  playlistsById: Record<string, PlaylistRecord>;
  ownerPublicPlaylists: PlaylistRecord[];
  guestbook: GuestbookEntry[];
}

export async function syncAccount(payload: {
  username: string;
  password?: string;
  bio?: string;
  avatarUrl?: string;
  flags?: string[];
}): Promise<{ ok: boolean; username: string }> {
  const res = await fetch('/api/auth/sync', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function saveUserFlags(
  username: string,
  flags: string[]
): Promise<{ ok: boolean; username: string; flags: string[] }> {
  const res = await fetch(`/api/users/${encodeURIComponent(username)}/flags`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify({ flags }),
  });
  return parseJson(res);
}

export async function listMediaAssets(username: string): Promise<{
  assets: MediaAsset[];
  totalBytes: number;
  quotaBytes: number;
}> {
  const res = await fetch(`/api/media/${encodeURIComponent(username)}`);
  return parseJson(res);
}

export async function uploadImageAsset(
  file: File,
  username: string,
  kind: MediaAsset['kind'] = 'image'
): Promise<{ asset: MediaAsset }> {
  const res = await fetch('/api/media/upload', {
    method: 'POST',
    headers: {
      'Content-Type': file.type || 'image/png',
      'x-username': encodeURIComponent(username),
      'x-filename': encodeURIComponent(file.name),
      'x-kind': kind,
    },
    body: file,
  });
  return parseJson(res);
}

export async function deleteMediaAsset(id: string): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/media/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
  return parseJson(res);
}

export async function listAudioTracks(username: string): Promise<{
  tracks: AudioTrack[];
  totalBytes: number;
  quotaBytes: number;
}> {
  const res = await fetch(`/api/audio/${encodeURIComponent(username)}`);
  return parseJson(res);
}

export async function uploadAudioTrack(
  file: File,
  meta: {
    username: string;
    title: string;
    artist: string;
    description: string;
    coverUrl: string;
    rightsConfirmed: boolean;
  }
): Promise<{ track: AudioTrack }> {
  const res = await fetch('/api/audio/upload', {
    method: 'POST',
    headers: {
      'Content-Type': file.type || 'audio/mpeg',
      'x-username': encodeURIComponent(meta.username),
      'x-filename': encodeURIComponent(file.name),
      'x-title': encodeURIComponent(meta.title),
      'x-artist': encodeURIComponent(meta.artist),
      'x-description': encodeURIComponent(meta.description),
      'x-cover-url': encodeURIComponent(meta.coverUrl),
      'x-rights-confirmed': meta.rightsConfirmed ? 'true' : 'false',
    },
    body: file,
  });
  return parseJson(res);
}

export async function updateAudioTrack(
  id: string,
  patch: { title?: string; artist?: string; description?: string; coverUrl?: string }
): Promise<{ track: AudioTrack }> {
  const res = await fetch(`/api/audio/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  return parseJson(res);
}

export async function deleteAudioTrack(id: string): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/audio/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
  return parseJson(res);
}

export async function listPublicPlaylists(): Promise<{ playlists: PlaylistRecord[] }> {
  const res = await fetch('/api/playlists/public');
  return parseJson(res);
}

export async function listUserPlaylists(
  username: string,
  viewer?: string | null
): Promise<{ playlists: PlaylistRecord[]; savedPlaylists: PlaylistRecord[] }> {
  const q = viewer ? `?viewer=${encodeURIComponent(viewer)}` : '';
  const res = await fetch(`/api/playlists/user/${encodeURIComponent(username)}${q}`);
  return parseJson(res);
}

export async function getPlaylistDetail(
  username: string,
  slug: string,
  viewer?: string | null
): Promise<{ playlist: PlaylistRecord }> {
  const q = viewer ? `?viewer=${encodeURIComponent(viewer)}` : '';
  const res = await fetch(
    `/api/playlists/detail/${encodeURIComponent(username)}/${encodeURIComponent(slug)}${q}`
  );
  return parseJson(res);
}

export async function createPlaylist(payload: {
  ownerUsername: string;
  name: string;
  description: string;
  coverUrl: string;
  isPublic: boolean;
  trackIds: string[];
}): Promise<{ playlist: PlaylistRecord }> {
  const res = await fetch('/api/playlists', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function updatePlaylist(
  id: string,
  patch: {
    name?: string;
    description?: string;
    coverUrl?: string;
    isPublic?: boolean;
    trackIds?: string[];
  }
): Promise<{ playlist: PlaylistRecord }> {
  const res = await fetch(`/api/playlists/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  });
  return parseJson(res);
}

export async function deletePlaylist(id: string): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/playlists/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
  return parseJson(res);
}

export async function toggleLikePlaylist(
  id: string,
  username: string
): Promise<{ playlist: PlaylistRecord }> {
  const res = await fetch(`/api/playlists/${encodeURIComponent(id)}/like`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username }),
  });
  return parseJson(res);
}

export async function toggleSavePlaylist(
  id: string,
  username: string
): Promise<{ playlist: PlaylistRecord }> {
  const res = await fetch(`/api/playlists/${encodeURIComponent(id)}/save`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username }),
  });
  return parseJson(res);
}

export async function getPublishedDirectory(): Promise<{
  homepages: PublishedDirectoryItem[];
}> {
  const res = await fetch('/api/homepages/directory');
  return parseJson(res);
}

export async function getEditorHomepage(username: string): Promise<{
  homepage: HomepageRecord;
  guestbook: GuestbookEntry[];
}> {
  const res = await fetch(`/api/homepage/editor/${encodeURIComponent(username)}`);
  return parseJson(res);
}

export async function saveHomepageDraft(
  username: string,
  document: HomepageDocument
): Promise<{ homepage: HomepageRecord }> {
  const res = await fetch(`/api/homepage/draft/${encodeURIComponent(username)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ document }),
  });
  return parseJson(res);
}

export async function publishHomepage(
  username: string,
  document: HomepageDocument
): Promise<{ homepage: HomepageRecord }> {
  const res = await fetch(`/api/homepage/publish/${encodeURIComponent(username)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ document }),
  });
  return parseJson(res);
}

export async function unpublishHomepage(username: string): Promise<{ homepage: HomepageRecord }> {
  const res = await fetch(`/api/homepage/unpublish/${encodeURIComponent(username)}`, {
    method: 'POST',
  });
  return parseJson(res);
}

export async function getPublicHomepage(
  username: string,
  countVisit = true
): Promise<PublicHomepagePayload> {
  const res = await fetch(
    `/api/homepage/public/${encodeURIComponent(username)}?count=${countVisit ? 'true' : 'false'}`
  );
  return parseJson(res);
}

export async function postGuestbookEntry(
  homepageUsername: string,
  authorUsername: string,
  message: string
): Promise<{ entry: GuestbookEntry }> {
  const res = await fetch(`/api/guestbook/${encodeURIComponent(homepageUsername)}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ authorUsername, message }),
  });
  return parseJson(res);
}

export type SearchCategory =
  | 'all'
  | 'users'
  | 'websites'
  | 'forum'
  | 'blogs'
  | 'playlists'
  | 'tags';

export interface SearchUserResult {
  username: string;
  bio: string;
  avatarUrl: string;
  createdAt: string;
  hasPublishedWebsite: boolean;
}

export interface SearchWebsiteResult {
  username: string;
  pageTitle: string;
  pageDescription: string;
  templateId: string;
  visitorCount: number;
  publishedAt: string | null;
}

export interface SearchForumResult {
  id: string;
  categoryId: string;
  categoryName: string;
  title: string;
  author: string;
  body: string;
  createdAt: string;
  views: number;
  replyCount: number;
}

export interface SearchBlogResult {
  id: string;
  author: string;
  timestamp: string;
  activityTag: string;
  mood: string;
  content: string;
  mediaType: string;
  tags: string[];
  likeCount: number;
  commentCount: number;
}

export interface SearchTagResult {
  tag: string;
  blogCount: number;
  forumCount: number;
  totalCount: number;
}

export interface SearchSuggestion {
  label: string;
  type: string;
  query: string;
}

export interface SearchResponse {
  query: string;
  category: SearchCategory;
  counts: {
    all: number;
    users: number;
    websites: number;
    forum: number;
    blogs: number;
    playlists: number;
    tags: number;
  };
  users: SearchUserResult[];
  websites: SearchWebsiteResult[];
  forumPosts: SearchForumResult[];
  blogPosts: SearchBlogResult[];
  playlists: PlaylistRecord[];
  tags: SearchTagResult[];
  suggestions: SearchSuggestion[];
}

export async function searchDatabase(
  query: string,
  category: SearchCategory = 'all'
): Promise<SearchResponse> {
  const params = new URLSearchParams({
    q: query,
    category,
  });
  const res = await fetch(`/api/search?${params.toString()}`);
  return parseJson(res);
}

export async function syncCommunityToDatabase(payload: {
  accounts?: Array<{
    username: string;
    password?: string;
    bio?: string;
    avatarUrl?: string;
    joined?: string;
  }>;
  posts?: Array<{
    id: string;
    author: string;
    timestamp: string;
    activityTag?: string;
    mood?: string;
    content: string;
    mediaType?: string;
    mediaUrl?: string;
    tags?: string[];
    likes?: string[];
    comments?: unknown[];
  }>;
  topics?: Array<{
    id: string;
    categoryId: string;
    categoryName?: string;
    title: string;
    author: string;
    body: string;
    createdAt: string;
    views?: number;
    replies?: unknown[];
  }>;
}): Promise<{ ok: boolean }> {
  const res = await fetch('/api/community/sync', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function upsertBlogPostToDb(post: {
  id: string;
  author: string;
  timestamp: string;
  activityTag?: string;
  mood?: string;
  content: string;
  mediaType?: string;
  mediaUrl?: string;
  tags?: string[];
  likes?: string[];
  comments?: unknown[];
}): Promise<{ ok: boolean }> {
  const res = await fetch('/api/blog-posts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(post),
  });
  return parseJson(res);
}

export async function deleteBlogPostFromDb(id: string): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/blog-posts/${encodeURIComponent(id)}`, {
    method: 'DELETE',
  });
  return parseJson(res);
}

export async function upsertForumTopicToDb(topic: {
  id: string;
  categoryId: string;
  categoryName?: string;
  title: string;
  author: string;
  body: string;
  createdAt: string;
  views?: number;
  replies?: unknown[];
}): Promise<{ ok: boolean }> {
  const res = await fetch('/api/forum-topics', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(topic),
  });
  return parseJson(res);
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 KB';
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}
