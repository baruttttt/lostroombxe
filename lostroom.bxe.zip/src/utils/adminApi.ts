import {
  AdminAuditLogItem,
  AdminOverviewData,
  AdminPostRecord,
  AdminUserRecord,
  AnnouncementCategory,
  AnnouncementItem,
  SitePublicState,
  SiteSettings,
} from '../types/admin';
import { UserAccountStatus, UserRole } from '../types/lostroom';

const AUTH_TOKEN_KEY = 'lostroom_bxe_auth_token_v1';

export function getAuthToken(): string {
  try {
    return localStorage.getItem(AUTH_TOKEN_KEY) || '';
  } catch {
    return '';
  }
}

export function setAuthToken(token: string) {
  try {
    if (token) {
      localStorage.setItem(AUTH_TOKEN_KEY, token);
    } else {
      localStorage.removeItem(AUTH_TOKEN_KEY);
    }
  } catch {
    // ignore
  }
}

export function getAuthHeaders(): Record<string, string> {
  const token = getAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function parseJson<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errMsg = (data as { error?: string })?.error || `Request failed (${res.status})`;
    throw new Error(errMsg);
  }
  return data as T;
}

export interface ServerAuthUser {
  username: string;
  bio: string;
  avatarUrl: string;
  flags?: string[];
  role: UserRole;
  status: UserAccountStatus;
  joined: string;
}

export async function loginWithServer(
  username: string,
  password: string
): Promise<{ token: string; user: ServerAuthUser }> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  const data = await parseJson<{ token: string; user: ServerAuthUser }>(res);
  setAuthToken(data.token);
  return data;
}

export async function registerWithServer(payload: {
  username: string;
  password: string;
  bio: string;
  avatarUrl: string;
}): Promise<{ token: string; user: ServerAuthUser }> {
  const res = await fetch('/api/auth/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await parseJson<{ token: string; user: ServerAuthUser }>(res);
  setAuthToken(data.token);
  return data;
}

export async function fetchSessionMe(): Promise<{ user: ServerAuthUser | null }> {
  const token = getAuthToken();
  if (!token) return { user: null };
  const res = await fetch('/api/auth/me', {
    headers: getAuthHeaders(),
  });
  if (!res.ok) {
    setAuthToken('');
    return { user: null };
  }
  return parseJson(res);
}

export async function fetchSiteState(): Promise<SitePublicState> {
  const res = await fetch('/api/site-state');
  return parseJson(res);
}

// ============================================================================
// ADMIN & GOD MODE ENDPOINTS
// ============================================================================

export async function fetchAdminOverview(): Promise<AdminOverviewData> {
  const res = await fetch('/api/admin/overview', {
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function fetchAdminUsers(search = ''): Promise<{ users: AdminUserRecord[] }> {
  const q = search ? `?q=${encodeURIComponent(search)}` : '';
  const res = await fetch(`/api/admin/users${q}`, {
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function adminEditUser(
  username: string,
  payload: { bio?: string; avatarUrl?: string }
): Promise<{ user: AdminUserRecord }> {
  const res = await fetch(`/api/admin/users/${encodeURIComponent(username)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function adminRenameUser(
  username: string,
  newUsername: string
): Promise<{ user: AdminUserRecord }> {
  const res = await fetch(`/api/admin/users/${encodeURIComponent(username)}/rename`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify({ newUsername }),
  });
  return parseJson(res);
}

export async function adminSetUserStatus(
  username: string,
  status: UserAccountStatus
): Promise<{ user: AdminUserRecord }> {
  const res = await fetch(`/api/admin/users/${encodeURIComponent(username)}/status`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify({ status }),
  });
  return parseJson(res);
}

export async function adminSetUserRole(
  username: string,
  role: 'admin' | 'moderator' | 'member'
): Promise<{ user: AdminUserRecord }> {
  const res = await fetch(`/api/admin/users/${encodeURIComponent(username)}/role`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify({ role }),
  });
  return parseJson(res);
}

export async function adminDeleteUser(username: string): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/admin/users/${encodeURIComponent(username)}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function fetchAdminPosts(search = ''): Promise<{ posts: AdminPostRecord[] }> {
  const q = search ? `?q=${encodeURIComponent(search)}` : '';
  const res = await fetch(`/api/admin/posts${q}`, {
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function adminUpdatePost(
  id: string,
  kind: 'blog' | 'forum',
  payload: { content?: string; title?: string; isPinned?: boolean }
): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/admin/posts/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify({ kind, ...payload }),
  });
  return parseJson(res);
}

export async function adminDeletePost(
  id: string,
  kind: 'blog' | 'forum'
): Promise<{ ok: boolean }> {
  const res = await fetch(
    `/api/admin/posts/${encodeURIComponent(id)}?kind=${encodeURIComponent(kind)}`,
    {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }
  );
  return parseJson(res);
}

export async function adminRestorePost(
  id: string,
  kind: 'blog' | 'forum'
): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/admin/posts/${encodeURIComponent(id)}/restore`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify({ kind }),
  });
  return parseJson(res);
}

export async function adminDeleteComment(
  postId: string,
  commentId: string,
  kind: 'blog' | 'forum'
): Promise<{ ok: boolean }> {
  const res = await fetch(
    `/api/admin/posts/${encodeURIComponent(postId)}/comments/${encodeURIComponent(
      commentId
    )}?kind=${encodeURIComponent(kind)}`,
    {
      method: 'DELETE',
      headers: getAuthHeaders(),
    }
  );
  return parseJson(res);
}

export async function adminGetGodMode(): Promise<{ settings: SiteSettings }> {
  const res = await fetch('/api/admin/god-mode', {
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function adminUpdateGodMode(
  patch: Partial<SiteSettings>
): Promise<{ settings: SiteSettings }> {
  const res = await fetch('/api/admin/god-mode', {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify(patch),
  });
  return parseJson(res);
}

export async function adminRestoreAllFeatures(): Promise<{ settings: SiteSettings }> {
  const res = await fetch('/api/admin/god-mode/restore-all', {
    method: 'POST',
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function adminListAnnouncements(): Promise<{
  announcements: AnnouncementItem[];
}> {
  const res = await fetch('/api/admin/announcements', {
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function adminCreateAnnouncement(payload: {
  title: string;
  body: string;
  category: AnnouncementCategory;
  isPinned: boolean;
  showBanner: boolean;
  sendToNotifications: boolean;
  scheduledAt: string | null;
}): Promise<{ announcement: AnnouncementItem }> {
  const res = await fetch('/api/admin/announcements', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function adminUpdateAnnouncement(
  id: string,
  payload: Partial<{
    title: string;
    body: string;
    category: AnnouncementCategory;
    isPinned: boolean;
    showBanner: boolean;
    sendToNotifications: boolean;
    scheduledAt: string | null;
  }>
): Promise<{ announcement: AnnouncementItem }> {
  const res = await fetch(`/api/admin/announcements/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json', ...getAuthHeaders() },
    body: JSON.stringify(payload),
  });
  return parseJson(res);
}

export async function adminDeleteAnnouncement(id: string): Promise<{ ok: boolean }> {
  const res = await fetch(`/api/admin/announcements/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function adminListLogs(params?: {
  q?: string;
  action?: string;
}): Promise<{ logs: AdminAuditLogItem[] }> {
  const sp = new URLSearchParams();
  if (params?.q) sp.set('q', params.q);
  if (params?.action && params.action !== 'all') sp.set('action', params.action);
  const q = sp.toString() ? `?${sp.toString()}` : '';
  const res = await fetch(`/api/admin/logs${q}`, {
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}

export async function adminRotateAllTokens(): Promise<{ ok: boolean; message: string }> {
  const res = await fetch('/api/admin/security/rotate-tokens', {
    method: 'POST',
    headers: getAuthHeaders(),
  });
  return parseJson(res);
}
