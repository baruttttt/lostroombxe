export interface FlagOption {
  emoji: string;
  label: string;
  code: string;
}

export const FLAG_OPTIONS: FlagOption[] = [
  { emoji: '🇹🇷', label: 'Turkiye', code: 'TR' },
  { emoji: '🇺🇸', label: 'United States', code: 'US' },
  { emoji: '🇯🇵', label: 'Japan', code: 'JP' },
  { emoji: '🇬🇧', label: 'United Kingdom', code: 'GB' },
  { emoji: '🇩🇪', label: 'Germany', code: 'DE' },
  { emoji: '🇫🇷', label: 'France', code: 'FR' },
  { emoji: '🇰🇷', label: 'South Korea', code: 'KR' },
  { emoji: '🇦🇿', label: 'Azerbaijan', code: 'AZ' },
  { emoji: '🇮🇹', label: 'Italy', code: 'IT' },
  { emoji: '🇪🇸', label: 'Spain', code: 'ES' },
  { emoji: '🇵🇹', label: 'Portugal', code: 'PT' },
  { emoji: '🇧🇷', label: 'Brazil', code: 'BR' },
  { emoji: '🇨🇦', label: 'Canada', code: 'CA' },
  { emoji: '🇲🇽', label: 'Mexico', code: 'MX' },
  { emoji: '🇦🇷', label: 'Argentina', code: 'AR' },
  { emoji: '🇳🇱', label: 'Netherlands', code: 'NL' },
  { emoji: '🇵🇱', label: 'Poland', code: 'PL' },
  { emoji: '🇺🇦', label: 'Ukraine', code: 'UA' },
  { emoji: '🇷🇺', label: 'Russia', code: 'RU' },
  { emoji: '🇸🇪', label: 'Sweden', code: 'SE' },
  { emoji: '🇳🇴', label: 'Norway', code: 'NO' },
  { emoji: '🇫🇮', label: 'Finland', code: 'FI' },
  { emoji: '🇬🇷', label: 'Greece', code: 'GR' },
  { emoji: '🇨🇭', label: 'Switzerland', code: 'CH' },
  { emoji: '🇮🇪', label: 'Ireland', code: 'IE' },
  { emoji: '🇦🇺', label: 'Australia', code: 'AU' },
  { emoji: '🇮🇳', label: 'India', code: 'IN' },
  { emoji: '🇨🇳', label: 'China', code: 'CN' },
  { emoji: '🇵🇭', label: 'Philippines', code: 'PH' },
  { emoji: '🇹🇭', label: 'Thailand', code: 'TH' },
  { emoji: '🇮🇩', label: 'Indonesia', code: 'ID' },
  { emoji: '🇻🇳', label: 'Vietnam', code: 'VN' },
  { emoji: '🇪🇬', label: 'Egypt', code: 'EG' },
  { emoji: '🇸🇦', label: 'Saudi Arabia', code: 'SA' },
  { emoji: '🏳️‍🌈', label: 'Pride', code: 'PRIDE' },
  { emoji: '🏳️‍⚧️', label: 'Trans', code: 'TRANS' },
  { emoji: '🏴‍☠️', label: 'Pirate', code: 'PIRATE' },
  { emoji: '🏁', label: 'Cyber Race', code: 'RACE' },
  { emoji: '🚩', label: 'Red Flag', code: 'RED' },
  { emoji: '🎌', label: 'Festive', code: 'FEST' },
];

export const MAX_USER_FLAGS = 6;

export function sanitizeFlags(flags?: string[] | null): string[] {
  if (!Array.isArray(flags)) return [];
  const cleaned: string[] = [];
  for (const item of flags) {
    const val = String(item || '').trim();
    if (!val || cleaned.includes(val)) continue;
    cleaned.push(val);
    if (cleaned.length >= MAX_USER_FLAGS) break;
  }
  return cleaned;
}
