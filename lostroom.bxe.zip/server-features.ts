import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { DatabaseSync } from 'node:sqlite';
import express from 'express';

export interface FeatureDeps {
  db: DatabaseSync;
  dataDir: string;
  getAuthenticatedUser: (req: express.Request) => {
    username: string;
    role: 'super_admin' | 'admin' | 'moderator' | 'member';
    status: string;
  } | null;
  requireStaff: (
    req: express.Request,
    res: express.Response,
    minRole?: 'super_admin' | 'admin' | 'moderator'
  ) => {
    username: string;
    role: 'super_admin' | 'admin' | 'moderator' | 'member';
    status: string;
  } | null;
  writeAuditLog: (
    actor: {
      username: string;
      role: 'super_admin' | 'admin' | 'moderator' | 'member';
    },
    action: string,
    targetType: string,
    targetId: string,
    details?: string,
    result?: string
  ) => void;
}

// ============================================================================
// PURE TS MULTI-FRAME ANIMATED GIF89a GENERATOR (FOR BUILT-IN Y2K GIF LIBRARY)
// ============================================================================
function encodeGif89a(
  width: number,
  height: number,
  paletteRgb: [number, number, number][],
  frames: Uint8Array[],
  delayCs = 18
): Buffer {
  // Pad palette to 16 colors (4-bit color table)
  const palette: [number, number, number][] = [];
  for (let i = 0; i < 16; i++) {
    palette.push(paletteRgb[i] || [0, 0, 0]);
  }

  const out: number[] = [];
  const pushStr = (s: string) => {
    for (let i = 0; i < s.length; i++) out.push(s.charCodeAt(i));
  };
  const pushU16 = (n: number) => {
    out.push(n & 0xff, (n >> 8) & 0xff);
  };

  // Header
  pushStr('GIF89a');
  // Logical Screen Descriptor
  pushU16(width);
  pushU16(height);
  out.push(0x83, 0x00, 0x00); // Global Color Table flag=1, size=3 (16 colors)

  // Global Color Table
  for (const [r, g, b] of palette) {
    out.push(r & 0xff, g & 0xff, b & 0xff);
  }

  // NETSCAPE 2.0 Looping Extension
  out.push(0x21, 0xff, 0x0b);
  pushStr('NETSCAPE2.0');
  out.push(0x03, 0x01, 0x00, 0x00, 0x00);

  // Encode each frame with fixed 5-bit LZW codes using frequent Clear codes
  for (const pixels of frames) {
    // Graphic Control Extension
    out.push(0x21, 0xf9, 0x04, 0x04);
    pushU16(delayCs);
    out.push(0x00, 0x00);

    // Image Descriptor
    out.push(0x2c);
    pushU16(0);
    pushU16(0);
    pushU16(width);
    pushU16(height);
    out.push(0x00);

    // LZW minimum code size = 4 (5-bit codes; Clear=16, EOI=17)
    out.push(0x04);

    const bytes: number[] = [];
    let bitBuf = 0;
    let bitCount = 0;
    const emitCode = (code: number) => {
      bitBuf |= (code & 0x1f) << bitCount;
      bitCount += 5;
      while (bitCount >= 8) {
        bytes.push(bitBuf & 0xff);
        bitBuf >>= 8;
        bitCount -= 8;
      }
    };

    emitCode(16); // Initial Clear
    let codesSinceClear = 0;
    for (let i = 0; i < pixels.length; i++) {
      emitCode(pixels[i] & 0x0f);
      codesSinceClear++;
      if (codesSinceClear >= 12) {
        emitCode(16); // Clear before code table reaches 32
        codesSinceClear = 0;
      }
    }
    emitCode(17); // EOI
    if (bitCount > 0) {
      bytes.push(bitBuf & 0xff);
    }

    // Write LZW Data Sub-blocks (max 255 bytes each)
    for (let offset = 0; offset < bytes.length; offset += 255) {
      const chunkLen = Math.min(255, bytes.length - offset);
      out.push(chunkLen);
      for (let j = 0; j < chunkLen; j++) {
        out.push(bytes[offset + j]);
      }
    }
    out.push(0x00); // Block terminator
  }

  out.push(0x3b); // GIF Trailer
  return Buffer.from(out);
}

function drawBuiltinRetroGif(theme: string): Buffer {
  const w = 64;
  const h = 64;
  const palette: [number, number, number][] = [
    [9, 6, 14],      // 0: bg void
    [42, 23, 70],    // 1: deep purple
    [123, 66, 246],  // 2: neon violet
    [200, 180, 248], // 3: lavender
    [255, 107, 214], // 4: love pink
    [82, 255, 148],  // 5: matrix green
    [255, 215, 0],   // 6: gold
    [56, 189, 248],  // 7: cyan
    [255, 255, 255], // 8: white
    [255, 60, 110],  // 9: crimson
  ];

  const frames: Uint8Array[] = [];
  for (let f = 0; f < 4; f++) {
    const px = new Uint8Array(w * h);
    px.fill(0);

    // Subtle retro grid background
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        if ((x + f * 2) % 16 === 0 || (y + f * 2) % 16 === 0) {
          px[y * w + x] = 1;
        }
      }
    }

    const setPx = (x: number, y: number, c: number) => {
      const xi = Math.round(x);
      const yi = Math.round(y);
      if (xi >= 0 && xi < w && yi >= 0 && yi < h) {
        px[yi * w + xi] = c;
      }
    };
    const fillRect = (x: number, y: number, rw: number, rh: number, c: number) => {
      for (let yy = y; yy < y + rh; yy++) {
        for (let xx = x; xx < x + rw; xx++) setPx(xx, yy, c);
      }
    };

    // Border frame
    const borderCol = f % 2 === 0 ? 2 : 4;
    fillRect(0, 0, w, 2, borderCol);
    fillRect(0, h - 2, w, 2, borderCol);
    fillRect(0, 0, 2, h, borderCol);
    fillRect(w - 2, 0, 2, h, borderCol);

    if (theme === 'heart') {
      const scale = f % 2 === 0 ? 1 : 1.12;
      for (let y = -18; y <= 18; y++) {
        for (let x = -18; x <= 18; x++) {
          const nx = x / (11 * scale);
          const ny = -y / (11 * scale);
          const v = Math.pow(nx * nx + ny * ny - 1, 3) - nx * nx * ny * ny * ny;
          if (v <= 0) setPx(32 + x, 33 + y, v > -0.18 ? 8 : f % 2 === 0 ? 4 : 9);
        }
      }
      setPx(12 + f * 2, 12, 6);
      setPx(52 - f * 2, 14, 8);
      setPx(14, 50 - f * 2, 5);
    } else if (theme === 'star') {
      const col = [6, 5, 4, 7][f];
      for (let r = 0; r < 18; r++) {
        setPx(32 + r, 32, col);
        setPx(32 - r, 32, col);
        setPx(32, 32 + r, col);
        setPx(32, 32 - r, col);
        if (r < 12) {
          setPx(32 + r, 32 + r, 8);
          setPx(32 - r, 32 - r, 8);
          setPx(32 + r, 32 - r, 8);
          setPx(32 - r, 32 + r, 8);
        }
      }
      fillRect(28, 28, 8, 8, 8);
      setPx(10 + f * 12, 10, 6);
      setPx(54 - f * 10, 52, 4);
    } else if (theme === 'cat') {
      const bounce = f % 2 === 0 ? 0 : -3;
      // Ears
      fillRect(18, 18 + bounce, 6, 8, 3);
      fillRect(40, 18 + bounce, 6, 8, 3);
      // Head
      fillRect(18, 24 + bounce, 28, 22, 3);
      fillRect(20, 26 + bounce, 24, 18, 1);
      // Glowing eyes
      fillRect(24, 32 + bounce, 4, 4, f === 2 ? 4 : 5);
      fillRect(36, 32 + bounce, 4, 4, f === 2 ? 4 : 5);
      // Nose & blush
      fillRect(30, 38 + bounce, 4, 2, 4);
      fillRect(21, 38 + bounce, 3, 2, 9);
      fillRect(40, 38 + bounce, 3, 2, 9);
    } else if (theme === 'fire') {
      for (let y = 16; y < 56; y++) {
        for (let x = 18; x < 46; x++) {
          const dist = Math.abs(x - 32) + (56 - y) * 0.45;
          const wave = Math.sin((y + f * 4) * 0.35) * 3;
          if (dist + wave < 18) {
            const col = y > 42 ? 6 : y > 30 ? 4 : 9;
            setPx(x, y, col);
          }
        }
      }
    } else if (theme === 'thumbs') {
      const shift = f % 2 === 0 ? 0 : -2;
      fillRect(16, 30 + shift, 10, 18, 7); // cuff
      fillRect(26, 28 + shift, 18, 20, 5); // palm
      fillRect(30, 14 + shift, 6, 14, 5); // thumb
      fillRect(44, 28 + shift, 4, 4, 8);
      fillRect(44, 34 + shift, 4, 4, 8);
      fillRect(44, 40 + shift, 4, 4, 8);
    } else if (theme === 'alien') {
      const floatY = [0, -2, -3, -2][f];
      fillRect(20, 18 + floatY, 24, 24, 5);
      fillRect(24, 26 + floatY, 6, 6, 0);
      fillRect(34, 26 + floatY, 6, 6, 0);
      fillRect(29, 36 + floatY, 6, 2, 0);
      fillRect(22, 42 + floatY, 20, 8, 2);
    } else if (theme === 'glitch') {
      const offset = [0, 4, -4, 2][f];
      fillRect(14 + offset, 18, 36, 8, 7);
      fillRect(14 - offset, 28, 36, 8, 4);
      fillRect(14 + offset, 38, 36, 8, 5);
      fillRect(26, 24, 12, 16, 8);
    } else {
      // sparkle / party
      for (let i = 0; i < 18; i++) {
        const x = ((i * 19 + f * 7) % 52) + 6;
        const y = ((i * 23 + f * 11) % 52) + 6;
        const c = [4, 5, 6, 7, 8][i % 5];
        fillRect(x, y, 3, 3, c);
      }
      fillRect(22, 26, 20, 12, 2);
      fillRect(25, 29, 14, 6, f % 2 === 0 ? 6 : 5);
    }

    frames.push(px);
  }

  return encodeGif89a(w, h, palette, frames, 16);
}

// ============================================================================
// INIT DATABASE TABLES & SEEDS
// ============================================================================
export function initFeatureTablesAndSeeds(db: DatabaseSync, dataDir: string) {
  const gifsDir = path.join(dataDir, 'uploads', 'gifs');
  const notifAudioDir = path.join(dataDir, 'uploads', 'notif_audio');
  fs.mkdirSync(gifsDir, { recursive: true });
  fs.mkdirSync(notifAudioDir, { recursive: true });

  db.exec(`
    CREATE TABLE IF NOT EXISTS notification_settings (
      username TEXT PRIMARY KEY,
      settings_json TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS custom_badges (
      id TEXT PRIMARY KEY,
      creator_username TEXT NOT NULL,
      name TEXT NOT NULL,
      description TEXT DEFAULT '',
      rarity TEXT NOT NULL DEFAULT 'common',
      image_url TEXT NOT NULL,
      is_official INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS user_badges (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL,
      badge_id TEXT NOT NULL,
      awarded_by TEXT NOT NULL,
      is_showcased INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      UNIQUE(username, badge_id)
    );

    CREATE TABLE IF NOT EXISTS gif_library (
      id TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      tags_json TEXT NOT NULL DEFAULT '[]',
      url TEXT NOT NULL,
      uploader_username TEXT NOT NULL,
      is_builtin INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS comment_reports (
      id TEXT PRIMARY KEY,
      target_type TEXT NOT NULL DEFAULT 'post_comment',
      post_id TEXT NOT NULL,
      comment_id TEXT NOT NULL,
      reporter_username TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS confessions (
      id TEXT PRIMARY KEY,
      category TEXT NOT NULL DEFAULT 'Secrets',
      anon_alias TEXT NOT NULL,
      body TEXT NOT NULL,
      author_username TEXT NOT NULL,
      likes_json TEXT NOT NULL DEFAULT '[]',
      is_deleted INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS confession_comments (
      id TEXT PRIMARY KEY,
      confession_id TEXT NOT NULL,
      anon_alias TEXT NOT NULL,
      author_username TEXT NOT NULL,
      body TEXT NOT NULL,
      is_deleted INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS confession_reports (
      id TEXT PRIMARY KEY,
      confession_id TEXT NOT NULL,
      reporter_username TEXT NOT NULL,
      reason TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'open',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS polls (
      id TEXT PRIMARY KEY,
      creator_username TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      allow_multiple INTEGER NOT NULL DEFAULT 0,
      ends_at TEXT NOT NULL,
      options_json TEXT NOT NULL,
      is_closed INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS poll_votes (
      id TEXT PRIMARY KEY,
      poll_id TEXT NOT NULL,
      username TEXT NOT NULL,
      option_ids_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      UNIQUE(poll_id, username)
    );

    CREATE TABLE IF NOT EXISTS photo_albums (
      id TEXT PRIMARY KEY,
      owner_username TEXT NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      privacy TEXT NOT NULL DEFAULT 'public',
      cover_url TEXT DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS album_photos (
      id TEXT PRIMARY KEY,
      album_id TEXT NOT NULL,
      owner_username TEXT NOT NULL,
      title TEXT NOT NULL,
      caption TEXT DEFAULT '',
      image_url TEXT NOT NULL,
      likes_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS album_photo_comments (
      id TEXT PRIMARY KEY,
      photo_id TEXT NOT NULL,
      author_username TEXT NOT NULL,
      body TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS friendships (
      user_a TEXT NOT NULL,
      user_b TEXT NOT NULL,
      created_at TEXT NOT NULL,
      PRIMARY KEY (user_a, user_b)
    );
  `);

  // Seed built-in animated retro GIFs on disk & DB
  const builtinSpecs = [
    { id: 'gif-retro-heart', title: 'Y2K Pixel Heart', tags: ['love', 'heart', 'pink', 'cute'], theme: 'heart' },
    { id: 'gif-cyber-star', title: 'Sparkle Star', tags: ['sparkle', 'star', 'glitter', 'win'], theme: 'star' },
    { id: 'gif-void-cat', title: 'Bouncing Void Cat', tags: ['cat', 'kitty', 'cute', 'lol'], theme: 'cat' },
    { id: 'gif-pixel-fire', title: 'Neon Fire Vibe', tags: ['fire', 'hot', 'lit', 'cool'], theme: 'fire' },
    { id: 'gif-thumbs-up', title: 'Pixel Thumbs Up', tags: ['yes', 'ok', 'thumbs', 'good', 'like'], theme: 'thumbs' },
    { id: 'gif-y2k-alien', title: 'Cyber Alien Wave', tags: ['alien', 'ufo', 'cyber', 'weird'], theme: 'alien' },
    { id: 'gif-vhs-glitch', title: 'VHS Glitch Wave', tags: ['glitch', 'vhs', 'retro', 'vaporwave'], theme: 'glitch' },
    { id: 'gif-confetti-party', title: 'Confetti Party', tags: ['party', 'yay', 'celebrate', 'fun'], theme: 'party' },
  ];

  const now = new Date().toISOString();
  for (const spec of builtinSpecs) {
    const filename = `${spec.id}.gif`;
    const diskPath = path.join(gifsDir, filename);
    if (!fs.existsSync(diskPath)) {
      fs.writeFileSync(diskPath, drawBuiltinRetroGif(spec.theme));
    }
    const existing = db.prepare('SELECT id FROM gif_library WHERE id = ?').get(spec.id);
    if (!existing) {
      db.prepare(
        `INSERT INTO gif_library (id, title, tags_json, url, uploader_username, is_builtin, created_at)
         VALUES (?, ?, ?, ?, 'barut', 1, ?)`
      ).run(spec.id, spec.title, JSON.stringify(spec.tags), `/uploads/gifs/${filename}`, now);
    }
  }
}

// ============================================================================
// REGISTER ROUTES
// ============================================================================
export function registerFeatureBinaryRoutes(app: express.Express, deps: FeatureDeps) {
  const { db, dataDir, getAuthenticatedUser } = deps;
  const gifsDir = path.join(dataDir, 'uploads', 'gifs');
  const notifAudioDir = path.join(dataDir, 'uploads', 'notif_audio');

  app.use('/uploads/gifs', express.static(gifsDir));
  app.use('/uploads/notif_audio', express.static(notifAudioDir));

  // Upload custom notification sound (MP3 / WAV / OGG / WEBM, max 3 MB)
  app.post(
    '/api/notifications/sound-upload',
    express.raw({ type: '*/*', limit: '4mb' }),
    (req, res) => {
      try {
        const authed = getAuthenticatedUser(req);
        const username =
          authed?.username ||
          decodeURIComponent(String(req.headers['x-username'] || '')).trim();
        if (!username) {
          res.status(401).json({ error: 'Log in to upload custom notification sounds.' });
          return;
        }
        const rawFilename = decodeURIComponent(String(req.headers['x-filename'] || 'chime.mp3'));
        const mimeType = String(req.headers['content-type'] || '')
          .split(';')[0]
          .trim()
          .toLowerCase();

        const allowedAudio: Record<string, string> = {
          'audio/mpeg': 'mp3',
          'audio/mp3': 'mp3',
          'audio/wav': 'wav',
          'audio/x-wav': 'wav',
          'audio/wave': 'wav',
          'audio/ogg': 'ogg',
          'audio/webm': 'webm',
        };
        let ext = allowedAudio[mimeType];
        if (!ext) {
          const lower = rawFilename.toLowerCase();
          if (lower.endsWith('.mp3')) ext = 'mp3';
          else if (lower.endsWith('.wav')) ext = 'wav';
          else if (lower.endsWith('.ogg')) ext = 'ogg';
          else if (lower.endsWith('.webm')) ext = 'webm';
        }
        if (!ext) {
          res.status(400).json({ error: 'Only MP3, WAV, OGG, or WEBM notification sounds allowed.' });
          return;
        }
        const buffer = req.body as Buffer;
        if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
          res.status(400).json({ error: 'Empty audio file.' });
          return;
        }
        if (buffer.length > 3 * 1024 * 1024) {
          res.status(400).json({ error: 'Notification sound must be under 3 MB.' });
          return;
        }

        const id = `snd-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
        const filename = `${id}.${ext}`;
        fs.writeFileSync(path.join(notifAudioDir, filename), buffer);

        res.status(201).json({
          sound: {
            id,
            name: rawFilename.replace(/\.[^.]+$/, '').slice(0, 40) || 'Custom Sound',
            url: `/uploads/notif_audio/${filename}`,
          },
        });
      } catch (err) {
        console.error('Notif sound upload error:', err);
        res.status(500).json({ error: 'Failed to save notification sound.' });
      }
    }
  );

  // Upload custom GIF to GIF Library (GIF only, max 8 MB)
  app.post(
    '/api/gifs/upload',
    express.raw({ type: '*/*', limit: '9mb' }),
    (req, res) => {
      try {
        const authed = getAuthenticatedUser(req);
        const username =
          authed?.username ||
          decodeURIComponent(String(req.headers['x-username'] || '')).trim();
        if (!username) {
          res.status(401).json({ error: 'Log in to upload GIFs.' });
          return;
        }
        const rawFilename = decodeURIComponent(String(req.headers['x-filename'] || 'reaction.gif'));
        const title =
          decodeURIComponent(String(req.headers['x-title'] || '')).trim() ||
          rawFilename.replace(/\.gif$/i, '');
        const rawTags = decodeURIComponent(String(req.headers['x-tags'] || ''));
        const mimeType = String(req.headers['content-type'] || '')
          .split(';')[0]
          .trim()
          .toLowerCase();

        if (mimeType !== 'image/gif' && !rawFilename.toLowerCase().endsWith('.gif')) {
          res.status(400).json({ error: 'Only .GIF files are allowed in the GIF comment uploader.' });
          return;
        }
        const buffer = req.body as Buffer;
        if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
          res.status(400).json({ error: 'Empty GIF file.' });
          return;
        }
        if (buffer.length > 8 * 1024 * 1024) {
          res.status(400).json({ error: 'GIF exceeds 8 MB max size.' });
          return;
        }

        const id = `gif-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
        const filename = `${id}.gif`;
        fs.writeFileSync(path.join(gifsDir, filename), buffer);

        const tags = Array.from(
          new Set(
            [...rawTags.split(/[\s,]+/), ...title.toLowerCase().split(/\s+/)]
              .map((t) => t.replace(/^#/, '').trim().toLowerCase())
              .filter((t) => t.length >= 2 && t.length <= 24)
          )
        ).slice(0, 10);

        const url = `/uploads/gifs/${filename}`;
        const now = new Date().toISOString();
        db.prepare(
          `INSERT INTO gif_library (id, title, tags_json, url, uploader_username, is_builtin, created_at)
           VALUES (?, ?, ?, ?, ?, 0, ?)`
        ).run(id, title.slice(0, 60), JSON.stringify(tags), url, username, now);

        res.status(201).json({
          gif: {
            id,
            title: title.slice(0, 60),
            tags,
            url,
            uploaderUsername: username,
            isBuiltin: false,
            createdAt: now,
          },
        });
      } catch (err) {
        console.error('GIF upload error:', err);
        res.status(500).json({ error: 'Failed to save GIF.' });
      }
    }
  );
}

export function registerFeatureJsonRoutes(app: express.Express, deps: FeatureDeps) {
  const { db, getAuthenticatedUser, requireStaff, writeAuditLog } = deps;
  const confessionSpamMap = new Map<string, number[]>();
  const confessionCommentSpamMap = new Map<string, number[]>();

  const checkLimit = (map: Map<string, number[]>, key: string, max: number, winMs: number) => {
    const now = Date.now();
    const list = (map.get(key) || []).filter((t) => now - t < winMs);
    if (list.length >= max) {
      map.set(key, list);
      return true;
    }
    list.push(now);
    map.set(key, list);
    return false;
  };

  // ============================================================================
  // 13. NOTIFICATION SOUND SETTINGS
  // ============================================================================
  app.get('/api/notifications/settings', (req, res) => {
    const authed = getAuthenticatedUser(req);
    const username = authed?.username || String(req.query.username || '').trim();
    if (!username) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const row = db
      .prepare('SELECT settings_json FROM notification_settings WHERE username = ?')
      .get(username) as { settings_json?: string } | undefined;
    res.json({
      settings: row?.settings_json ? JSON.parse(row.settings_json) : null,
    });
  });

  app.put('/api/notifications/settings', (req, res) => {
    const authed = getAuthenticatedUser(req);
    const username = authed?.username || String(req.body?.username || '').trim();
    if (!username) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const settings = req.body?.settings;
    if (!settings || typeof settings !== 'object') {
      res.status(400).json({ error: 'Invalid notification settings payload.' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO notification_settings (username, settings_json, updated_at)
       VALUES (?, ?, ?)
       ON CONFLICT(username) DO UPDATE SET settings_json = excluded.settings_json, updated_at = excluded.updated_at`
    ).run(username, JSON.stringify(settings), now);
    res.json({ settings });
  });

  // ============================================================================
  // FEATURE 1: USER-CREATED CUSTOM BADGES SYSTEM
  // ============================================================================
  const formatBadgeRow = (b: Record<string, unknown>) => {
    const cnt = db
      .prepare('SELECT COUNT(*) AS cnt FROM user_badges WHERE badge_id = ?')
      .get(String(b.id)) as { cnt: number };
    return {
      id: String(b.id),
      creatorUsername: String(b.creator_username),
      name: String(b.name),
      description: String(b.description || ''),
      rarity: String(b.rarity || 'common'),
      imageUrl: String(b.image_url),
      isOfficial: Number(b.is_official) === 1,
      holdersCount: Number(cnt?.cnt || 0),
      createdAt: String(b.created_at),
    };
  };

  app.get('/api/badges', (_req, res) => {
    const rows = db
      .prepare('SELECT * FROM custom_badges ORDER BY created_at DESC')
      .all() as Record<string, unknown>[];
    res.json({ badges: rows.map(formatBadgeRow) });
  });

  app.get('/api/badges/user/:username', (req, res) => {
    const target = req.params.username;
    const rows = db
      .prepare(
        `SELECT ub.*, cb.creator_username, cb.name, cb.description, cb.rarity, cb.image_url, cb.is_official, cb.created_at AS badge_created_at
         FROM user_badges ub
         JOIN custom_badges cb ON cb.id = ub.badge_id
         WHERE ub.username = ?
         ORDER BY ub.is_showcased DESC, ub.created_at DESC`
      )
      .all(target) as Record<string, unknown>[];

    const awards = rows.map((r) => ({
      id: String(r.id),
      username: String(r.username),
      badgeId: String(r.badge_id),
      awardedBy: String(r.awarded_by),
      isShowcased: Number(r.is_showcased) === 1,
      createdAt: String(r.created_at),
      badge: {
        id: String(r.badge_id),
        creatorUsername: String(r.creator_username),
        name: String(r.name),
        description: String(r.description || ''),
        rarity: String(r.rarity || 'common'),
        imageUrl: String(r.image_url),
        isOfficial: Number(r.is_official) === 1,
        holdersCount: 1,
        createdAt: String(r.badge_created_at),
      },
    }));
    res.json({ awards });
  });

  app.post('/api/badges', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to create custom badges.' });
      return;
    }
    const { name, description, rarity, imageUrl } = req.body as {
      name?: string;
      description?: string;
      rarity?: string;
      imageUrl?: string;
    };
    const cleanName = String(name || '').trim();
    const cleanImg = String(imageUrl || '').trim();
    if (cleanName.length < 2 || cleanName.length > 40) {
      res.status(400).json({ error: 'Badge name must be 2-40 characters.' });
      return;
    }
    if (!cleanImg) {
      res.status(400).json({ error: 'PNG badge image is required.' });
      return;
    }
    const allowedRarities = new Set(['common', 'uncommon', 'rare', 'epic', 'legendary']);
    const finalRarity = allowedRarities.has(String(rarity || '').toLowerCase())
      ? String(rarity).toLowerCase()
      : 'common';

    const id = `bdg-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    const isOfficial = authed.role === 'super_admin' || authed.role === 'admin' ? 1 : 0;

    db.prepare(
      `INSERT INTO custom_badges (id, creator_username, name, description, rarity, image_url, is_official, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, authed.username, cleanName, String(description || '').trim().slice(0, 200), finalRarity, cleanImg, isOfficial, now);

    // Creator automatically receives their own created badge to wear & showcase
    const awardId = `ub-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    db.prepare(
      `INSERT OR IGNORE INTO user_badges (id, username, badge_id, awarded_by, is_showcased, created_at)
       VALUES (?, ?, ?, ?, 1, ?)`
    ).run(awardId, authed.username, id, authed.username, now);

    const row = db
      .prepare('SELECT * FROM custom_badges WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.status(201).json({ badge: formatBadgeRow(row) });
  });

  app.patch('/api/badges/:id', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM custom_badges WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Badge not found.' });
      return;
    }
    const isStaff = authed.role === 'super_admin' || authed.role === 'admin';
    if (String(row.creator_username) !== authed.username && !isStaff) {
      res.status(403).json({ error: 'You can only edit your own badges.' });
      return;
    }
    const { name, description, rarity, imageUrl } = req.body as {
      name?: string;
      description?: string;
      rarity?: string;
      imageUrl?: string;
    };
    const allowedRarities = new Set(['common', 'uncommon', 'rare', 'epic', 'legendary']);
    const nextRarity =
      rarity && allowedRarities.has(rarity.toLowerCase())
        ? rarity.toLowerCase()
        : String(row.rarity);

    db.prepare(
      `UPDATE custom_badges SET name = ?, description = ?, rarity = ?, image_url = ? WHERE id = ?`
    ).run(
      name !== undefined ? name.trim().slice(0, 40) : String(row.name),
      description !== undefined ? description.trim().slice(0, 200) : String(row.description || ''),
      nextRarity,
      imageUrl !== undefined ? imageUrl : String(row.image_url),
      req.params.id
    );
    if (isStaff && String(row.creator_username) !== authed.username) {
      writeAuditLog(authed, 'ADMIN_EDIT_BADGE', 'badge', req.params.id, name || '');
    }
    const updated = db
      .prepare('SELECT * FROM custom_badges WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ badge: formatBadgeRow(updated) });
  });

  app.delete('/api/badges/:id', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM custom_badges WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Badge not found.' });
      return;
    }
    const isStaff = authed.role === 'super_admin' || authed.role === 'admin';
    if (String(row.creator_username) !== authed.username && !isStaff) {
      res.status(403).json({ error: 'Only badge creator or Admin can delete this badge.' });
      return;
    }
    db.prepare('DELETE FROM user_badges WHERE badge_id = ?').run(req.params.id);
    db.prepare('DELETE FROM custom_badges WHERE id = ?').run(req.params.id);
    if (isStaff) {
      writeAuditLog(authed, 'DELETE_CUSTOM_BADGE', 'badge', req.params.id, String(row.name));
    }
    res.json({ ok: true });
  });

  // Equip/claim or toggle showcase on user profile
  app.post('/api/badges/:id/claim', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to collect badges.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM custom_badges WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Badge not found.' });
      return;
    }
    if (Number(row.is_official) === 1 && String(row.creator_username) !== authed.username) {
      res.status(403).json({ error: 'Official/Admin badges can only be awarded by Administrators.' });
      return;
    }
    const awardId = `ub-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    db.prepare(
      `INSERT OR IGNORE INTO user_badges (id, username, badge_id, awarded_by, is_showcased, created_at)
       VALUES (?, ?, ?, ?, 1, ?)`
    ).run(awardId, authed.username, req.params.id, authed.username, new Date().toISOString());
    res.json({ ok: true });
  });

  app.put('/api/badges/showcase', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const { badgeId, isShowcased } = req.body as { badgeId?: string; isShowcased?: boolean };
    if (!badgeId) {
      res.status(400).json({ error: 'badgeId is required.' });
      return;
    }
    db.prepare(
      'UPDATE user_badges SET is_showcased = ? WHERE username = ? AND badge_id = ?'
    ).run(isShowcased ? 1 : 0, authed.username, badgeId);
    res.json({ ok: true });
  });

  app.post('/api/admin/badges/award', (req, res) => {
    const staff = requireStaff(req, res, 'admin');
    if (!staff) return;
    const { targetUsername, badgeId } = req.body as { targetUsername?: string; badgeId?: string };
    if (!targetUsername || !badgeId) {
      res.status(400).json({ error: 'targetUsername and badgeId required.' });
      return;
    }
    const userExists = db.prepare('SELECT username FROM accounts WHERE username = ?').get(targetUsername);
    if (!userExists) {
      res.status(404).json({ error: 'Target user not found.' });
      return;
    }
    const badgeExists = db.prepare('SELECT id, name FROM custom_badges WHERE id = ?').get(badgeId) as
      | { id: string; name: string }
      | undefined;
    if (!badgeExists) {
      res.status(404).json({ error: 'Badge not found.' });
      return;
    }
    const awardId = `ub-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    db.prepare(
      `INSERT OR IGNORE INTO user_badges (id, username, badge_id, awarded_by, is_showcased, created_at)
       VALUES (?, ?, ?, ?, 1, ?)`
    ).run(awardId, targetUsername, badgeId, staff.username, new Date().toISOString());
    writeAuditLog(staff, 'ADMIN_AWARD_BADGE', 'user', targetUsername, `Badge: ${badgeExists.name}`);
    res.json({ ok: true });
  });

  // ============================================================================
  // FEATURE 2: GIF LIBRARY & COMMENT REPORTS
  // ============================================================================
  app.get('/api/gifs', (req, res) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    const rows = db
      .prepare('SELECT * FROM gif_library ORDER BY is_builtin DESC, created_at DESC LIMIT 120')
      .all() as Record<string, unknown>[];

    const filtered = rows
      .map((r) => ({
        id: String(r.id),
        title: String(r.title),
        tags: JSON.parse(String(r.tags_json || '[]')) as string[],
        url: String(r.url),
        uploaderUsername: String(r.uploader_username),
        isBuiltin: Number(r.is_builtin) === 1,
        createdAt: String(r.created_at),
      }))
      .filter((g) => {
        if (!q) return true;
        return (
          g.title.toLowerCase().includes(q) ||
          g.tags.some((t) => t.toLowerCase().includes(q)) ||
          g.uploaderUsername.toLowerCase().includes(q)
        );
      });

    res.json({ gifs: filtered });
  });

  app.post('/api/comments/report', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to report comments.' });
      return;
    }
    const { postId, commentId, reason } = req.body as {
      postId?: string;
      commentId?: string;
      reason?: string;
    };
    if (!postId || !commentId) {
      res.status(400).json({ error: 'postId and commentId are required.' });
      return;
    }
    const id = `crep-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO comment_reports (id, target_type, post_id, comment_id, reporter_username, reason, status, created_at)
       VALUES (?, 'post_comment', ?, ?, ?, ?, 'open', ?)`
    ).run(id, postId, commentId, authed.username, String(reason || 'Inappropriate comment').slice(0, 120), now);
    res.status(201).json({ ok: true });
  });

  app.get('/api/admin/comment-reports', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const rows = db
      .prepare('SELECT * FROM comment_reports ORDER BY created_at DESC LIMIT 120')
      .all() as Record<string, unknown>[];
    res.json({
      reports: rows.map((r) => ({
        id: String(r.id),
        targetType: String(r.target_type),
        postId: String(r.post_id),
        commentId: String(r.comment_id),
        reporterUsername: String(r.reporter_username),
        reason: String(r.reason),
        status: String(r.status),
        createdAt: String(r.created_at),
      })),
    });
  });

  app.post('/api/admin/comment-reports/:id/resolve', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const row = db
      .prepare('SELECT * FROM comment_reports WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Comment report not found.' });
      return;
    }
    const action = req.body?.action === 'remove' ? 'remove' : 'dismiss';
    if (action === 'remove') {
      const post = db
        .prepare('SELECT comments_json FROM blog_posts WHERE id = ?')
        .get(String(row.post_id)) as { comments_json?: string } | undefined;
      if (post?.comments_json) {
        const list = JSON.parse(post.comments_json) as { id: string }[];
        const next = list.filter((c) => c.id !== String(row.comment_id));
        db.prepare('UPDATE blog_posts SET comments_json = ? WHERE id = ?').run(
          JSON.stringify(next),
          String(row.post_id)
        );
      }
    }
    db.prepare('UPDATE comment_reports SET status = ? WHERE id = ?').run(
      action === 'remove' ? 'removed' : 'dismissed',
      req.params.id
    );
    writeAuditLog(staff, 'RESOLVE_COMMENT_REPORT', 'comment_report', req.params.id, `Action: ${action}`);
    res.json({ ok: true });
  });

  // ============================================================================
  // FEATURE 3: ANONYMOUS CONFESSION BOARD (PRIVACY-SAFE)
  // ============================================================================
  app.get('/api/confessions', (req, res) => {
    const authed = getAuthenticatedUser(req);
    const viewer = authed?.username || '';
    const category = String(req.query.category || 'All').trim();

    const rows = db
      .prepare('SELECT * FROM confessions WHERE is_deleted = 0 ORDER BY created_at DESC LIMIT 150')
      .all() as Record<string, unknown>[];

    const confessions = rows
      .filter((r) => category === 'All' || String(r.category) === category)
      .map((r) => {
        const likes = JSON.parse(String(r.likes_json || '[]')) as string[];
        const cntRow = db
          .prepare('SELECT COUNT(*) AS cnt FROM confession_comments WHERE confession_id = ? AND is_deleted = 0')
          .get(String(r.id)) as { cnt: number };
        // STRICT PRIVACY: NEVER return author_username in public endpoints
        return {
          id: String(r.id),
          category: String(r.category),
          anonAlias: String(r.anon_alias),
          body: String(r.body),
          likesCount: likes.length,
          likedByViewer: Boolean(viewer && likes.includes(viewer)),
          commentCount: Number(cntRow?.cnt || 0),
          createdAt: String(r.created_at),
        };
      });

    res.json({ confessions });
  });

  app.post('/api/confessions', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to post an anonymous confession (your username stays hidden).' });
      return;
    }
    if (checkLimit(confessionSpamMap, authed.username, 4, 10 * 60 * 1000)) {
      res.status(429).json({ error: 'Anti-spam limit: max 4 confessions every 10 minutes.' });
      return;
    }
    const { category, body } = req.body as { category?: string; body?: string };
    const cleanBody = String(body || '').trim();
    if (cleanBody.length < 5 || cleanBody.length > 800) {
      res.status(400).json({ error: 'Confession must be between 5 and 800 characters.' });
      return;
    }

    // Duplicate spam check within last hour
    const recentDup = db
      .prepare('SELECT 1 FROM confessions WHERE author_username = ? AND body = ? AND is_deleted = 0')
      .get(authed.username, cleanBody);
    if (recentDup) {
      res.status(400).json({ error: 'Duplicate confession detected.' });
      return;
    }

    const id = `conf-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const anonCode = crypto.randomBytes(2).toString('hex').toUpperCase();
    const anonAlias = `Anon #${anonCode}`;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO confessions (id, category, anon_alias, body, author_username, likes_json, is_deleted, created_at)
       VALUES (?, ?, ?, ?, ?, '[]', 0, ?)`
    ).run(id, String(category || 'Secrets').slice(0, 40), anonAlias, cleanBody, authed.username, now);

    res.status(201).json({
      confession: {
        id,
        category: String(category || 'Secrets').slice(0, 40),
        anonAlias,
        body: cleanBody,
        likesCount: 0,
        likedByViewer: false,
        commentCount: 0,
        createdAt: now,
      },
    });
  });

  app.post('/api/confessions/:id/like', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to like confessions.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM confessions WHERE id = ? AND is_deleted = 0')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Confession not found.' });
      return;
    }
    const likes = JSON.parse(String(row.likes_json || '[]')) as string[];
    const already = likes.includes(authed.username);
    const nextLikes = already
      ? likes.filter((u) => u !== authed.username)
      : [...likes, authed.username];
    db.prepare('UPDATE confessions SET likes_json = ? WHERE id = ?').run(
      JSON.stringify(nextLikes),
      req.params.id
    );
    res.json({ likesCount: nextLikes.length, likedByViewer: !already });
  });

  app.get('/api/confessions/:id/comments', (req, res) => {
    const rows = db
      .prepare('SELECT id, confession_id, anon_alias, body, created_at FROM confession_comments WHERE confession_id = ? AND is_deleted = 0 ORDER BY created_at ASC')
      .all(req.params.id) as Record<string, unknown>[];
    res.json({
      comments: rows.map((r) => ({
        id: String(r.id),
        confessionId: String(r.confession_id),
        anonAlias: String(r.anon_alias),
        body: String(r.body),
        createdAt: String(r.created_at),
      })),
    });
  });

  app.post('/api/confessions/:id/comments', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to post anonymous replies.' });
      return;
    }
    if (checkLimit(confessionCommentSpamMap, authed.username, 12, 5 * 60 * 1000)) {
      res.status(429).json({ error: 'Anti-spam rate limit reached for confession replies.' });
      return;
    }
    const confExists = db
      .prepare('SELECT id FROM confessions WHERE id = ? AND is_deleted = 0')
      .get(req.params.id);
    if (!confExists) {
      res.status(404).json({ error: 'Confession not found.' });
      return;
    }
    const cleanBody = String(req.body?.body || '').trim();
    if (!cleanBody || cleanBody.length > 400) {
      res.status(400).json({ error: 'Reply must be 1-400 characters.' });
      return;
    }
    const id = `cc-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const anonAlias = `Anon #${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO confession_comments (id, confession_id, anon_alias, author_username, body, is_deleted, created_at)
       VALUES (?, ?, ?, ?, ?, 0, ?)`
    ).run(id, req.params.id, anonAlias, authed.username, cleanBody, now);

    res.status(201).json({
      comment: {
        id,
        confessionId: req.params.id,
        anonAlias,
        body: cleanBody,
        createdAt: now,
      },
    });
  });

  app.post('/api/confessions/:id/report', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to report a confession.' });
      return;
    }
    const id = `cr-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    db.prepare(
      `INSERT INTO confession_reports (id, confession_id, reporter_username, reason, status, created_at)
       VALUES (?, ?, ?, ?, 'open', ?)`
    ).run(
      id,
      req.params.id,
      authed.username,
      String(req.body?.reason || 'Abuse or spam').slice(0, 120),
      new Date().toISOString()
    );
    res.status(201).json({ ok: true });
  });

  app.get('/api/admin/confessions', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const rows = db
      .prepare('SELECT * FROM confessions ORDER BY created_at DESC LIMIT 120')
      .all() as Record<string, unknown>[];
    const reportRows = db
      .prepare(
        `SELECT cr.*, c.body AS confession_body, c.category AS confession_category
         FROM confession_reports cr
         LEFT JOIN confessions c ON c.id = cr.confession_id
         ORDER BY cr.created_at DESC LIMIT 120`
      )
      .all() as Record<string, unknown>[];

    res.json({
      confessions: rows.map((r) => ({
        id: String(r.id),
        category: String(r.category),
        anonAlias: String(r.anon_alias),
        body: String(r.body),
        likesCount: (JSON.parse(String(r.likes_json || '[]')) as string[]).length,
        likedByViewer: false,
        commentCount: 0,
        isDeleted: Number(r.is_deleted) === 1,
        adminAuthorUsername: staff.role === 'super_admin' ? String(r.author_username) : '[PROTECTED]',
        createdAt: String(r.created_at),
      })),
      reports: reportRows.map((rr) => ({
        id: String(rr.id),
        confessionId: String(rr.confession_id),
        confessionBody: String(rr.confession_body || '[Deleted]'),
        confessionCategory: String(rr.confession_category || 'General'),
        reporterUsername: String(rr.reporter_username),
        reason: String(rr.reason),
        status: String(rr.status),
        createdAt: String(rr.created_at),
      })),
    });
  });

  app.delete('/api/admin/confessions/:id', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    db.prepare('UPDATE confessions SET is_deleted = 1 WHERE id = ?').run(req.params.id);
    db.prepare("UPDATE confession_reports SET status = 'removed' WHERE confession_id = ?").run(
      req.params.id
    );
    writeAuditLog(staff, 'DELETE_CONFESSION', 'confession', req.params.id, 'Moderation removal');
    res.json({ ok: true });
  });

  app.post('/api/admin/confessions/reports/:id/resolve', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const row = db
      .prepare('SELECT * FROM confession_reports WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Report not found.' });
      return;
    }
    const action = req.body?.action === 'remove' ? 'remove' : 'dismiss';
    if (action === 'remove') {
      db.prepare('UPDATE confessions SET is_deleted = 1 WHERE id = ?').run(
        String(row.confession_id)
      );
    }
    db.prepare('UPDATE confession_reports SET status = ? WHERE id = ?').run(
      action === 'remove' ? 'removed' : 'dismissed',
      req.params.id
    );
    writeAuditLog(staff, 'RESOLVE_CONFESSION_REPORT', 'confession_report', req.params.id, action);
    res.json({ ok: true });
  });

  // ============================================================================
  // FEATURE 4: POLL CONTESTS
  // ============================================================================
  const formatPollRow = (row: Record<string, unknown>, viewer: string) => {
    const baseOptions = JSON.parse(String(row.options_json || '[]')) as {
      id: string;
      text: string;
      imageUrl?: string;
    }[];
    const votes = db
      .prepare('SELECT username, option_ids_json FROM poll_votes WHERE poll_id = ?')
      .all(String(row.id)) as { username: string; option_ids_json: string }[];

    const counts = new Map<string, number>();
    let viewerVotedOptionIds: string[] = [];
    for (const v of votes) {
      const selected = JSON.parse(String(v.option_ids_json || '[]')) as string[];
      if (viewer && v.username === viewer) {
        viewerVotedOptionIds = selected;
      }
      for (const optId of selected) {
        counts.set(optId, (counts.get(optId) || 0) + 1);
      }
    }

    const endsAt = String(row.ends_at);
    const isClosed = Number(row.is_closed) === 1;
    const isEnded = isClosed || new Date(endsAt).getTime() <= Date.now();

    return {
      id: String(row.id),
      creatorUsername: String(row.creator_username),
      title: String(row.title),
      description: String(row.description || ''),
      imageUrl: String(row.image_url || ''),
      allowMultiple: Number(row.allow_multiple) === 1,
      endsAt,
      isClosed,
      isEnded,
      totalVotes: votes.length,
      viewerVotedOptionIds,
      options: baseOptions.map((o) => ({
        ...o,
        votes: counts.get(o.id) || 0,
      })),
      createdAt: String(row.created_at),
    };
  };

  app.get('/api/polls', (req, res) => {
    const authed = getAuthenticatedUser(req);
    const viewer = authed?.username || '';
    const rows = db
      .prepare('SELECT * FROM polls ORDER BY created_at DESC LIMIT 100')
      .all() as Record<string, unknown>[];
    res.json({ polls: rows.map((r) => formatPollRow(r, viewer)) });
  });

  app.get('/api/polls/:id', (req, res) => {
    const authed = getAuthenticatedUser(req);
    const viewer = authed?.username || '';
    const row = db
      .prepare('SELECT * FROM polls WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Poll contest not found.' });
      return;
    }
    res.json({ poll: formatPollRow(row, viewer) });
  });

  app.post('/api/polls', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to create a poll contest.' });
      return;
    }
    const { title, description, imageUrl, allowMultiple, endsAt, options } = req.body as {
      title?: string;
      description?: string;
      imageUrl?: string;
      allowMultiple?: boolean;
      endsAt?: string;
      options?: { text: string; imageUrl?: string }[];
    };
    const cleanTitle = String(title || '').trim();
    if (cleanTitle.length < 3) {
      res.status(400).json({ error: 'Poll title must be at least 3 characters.' });
      return;
    }
    const validOptions = (Array.isArray(options) ? options : [])
      .map((o, idx) => ({
        id: `opt-${idx + 1}-${crypto.randomBytes(2).toString('hex')}`,
        text: String(o.text || '').trim().slice(0, 80),
        imageUrl: o.imageUrl ? String(o.imageUrl) : '',
      }))
      .filter((o) => o.text.length > 0)
      .slice(0, 10);

    if (validOptions.length < 2) {
      res.status(400).json({ error: 'Poll contests require at least 2 options.' });
      return;
    }

    const endMs = endsAt ? new Date(endsAt).getTime() : Date.now() + 7 * 24 * 60 * 60 * 1000;
    const finalEndsAt = Number.isFinite(endMs)
      ? new Date(endMs).toISOString()
      : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

    const id = `poll-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO polls (id, creator_username, title, description, image_url, allow_multiple, ends_at, options_json, is_closed, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)`
    ).run(
      id,
      authed.username,
      cleanTitle.slice(0, 120),
      String(description || '').trim().slice(0, 400),
      String(imageUrl || ''),
      allowMultiple ? 1 : 0,
      finalEndsAt,
      JSON.stringify(validOptions),
      now
    );

    const created = db
      .prepare('SELECT * FROM polls WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.status(201).json({ poll: formatPollRow(created, authed.username) });
  });

  app.post('/api/polls/:id/vote', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to vote in poll contests.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM polls WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Poll contest not found.' });
      return;
    }
    const isClosed = Number(row.is_closed) === 1;
    const endsAt = String(row.ends_at);
    if (isClosed || new Date(endsAt).getTime() <= Date.now()) {
      res.status(400).json({ error: 'This poll contest has already ended.' });
      return;
    }

    const allowMultiple = Number(row.allow_multiple) === 1;
    const allowedOptionIds = new Set(
      (JSON.parse(String(row.options_json || '[]')) as { id: string }[]).map((o) => o.id)
    );
    const chosen = (Array.isArray(req.body?.optionIds) ? req.body.optionIds : []).filter(
      (id: unknown): id is string => typeof id === 'string' && allowedOptionIds.has(id)
    );

    if (chosen.length === 0) {
      res.status(400).json({ error: 'Select at least one valid option.' });
      return;
    }
    const finalChosen = allowMultiple ? Array.from(new Set(chosen)) : [chosen[0]];
    const id = `pv-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO poll_votes (id, poll_id, username, option_ids_json, created_at)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(poll_id, username) DO UPDATE SET option_ids_json = excluded.option_ids_json, created_at = excluded.created_at`
    ).run(id, req.params.id, authed.username, JSON.stringify(finalChosen), now);

    res.json({ poll: formatPollRow(row, authed.username) });
  });

  app.patch('/api/admin/polls/:id', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    const isClosed = Boolean(req.body?.isClosed);
    db.prepare('UPDATE polls SET is_closed = ? WHERE id = ?').run(isClosed ? 1 : 0, req.params.id);
    writeAuditLog(staff, isClosed ? 'CLOSE_POLL' : 'REOPEN_POLL', 'poll', req.params.id);
    res.json({ ok: true });
  });

  app.delete('/api/admin/polls/:id', (req, res) => {
    const staff = requireStaff(req, res, 'moderator');
    if (!staff) return;
    db.prepare('DELETE FROM poll_votes WHERE poll_id = ?').run(req.params.id);
    db.prepare('DELETE FROM polls WHERE id = ?').run(req.params.id);
    writeAuditLog(staff, 'DELETE_POLL', 'poll', req.params.id, 'Removed poll contest');
    res.json({ ok: true });
  });

  // ============================================================================
  // FEATURE 5: PHOTO ALBUMS & FRIENDSHIP PRIVACY SYNC
  // ============================================================================
  app.post('/api/friends/sync', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const friends = Array.isArray(req.body?.friends) ? req.body.friends : [];
    const now = new Date().toISOString();
    db.prepare('DELETE FROM friendships WHERE user_a = ? OR user_b = ?').run(
      authed.username,
      authed.username
    );
    for (const f of friends) {
      if (typeof f === 'string' && f && f !== authed.username) {
        const [a, b] = [authed.username, f].sort();
        db.prepare(
          'INSERT OR IGNORE INTO friendships (user_a, user_b, created_at) VALUES (?, ?, ?)'
        ).run(a, b, now);
      }
    }
    res.json({ ok: true });
  });

  const isConfirmedFriend = (u1: string, u2: string): boolean => {
    if (!u1 || !u2) return false;
    if (u1 === u2) return true;
    const [a, b] = [u1, u2].sort();
    const row = db
      .prepare('SELECT 1 FROM friendships WHERE user_a = ? AND user_b = ?')
      .get(a, b);
    return Boolean(row);
  };

  const canAccessAlbum = (
    album: Record<string, unknown>,
    viewer: string,
    viewerRole?: string
  ): boolean => {
    const owner = String(album.owner_username);
    const privacy = String(album.privacy || 'public');
    if (viewer === owner || viewerRole === 'super_admin') return true;
    if (privacy === 'public') return true;
    if (privacy === 'friends') return isConfirmedFriend(owner, viewer);
    return false;
  };

  const formatAlbumRow = (row: Record<string, unknown>) => {
    const photos = db
      .prepare('SELECT image_url FROM album_photos WHERE album_id = ? ORDER BY created_at DESC')
      .all(String(row.id)) as { image_url: string }[];
    return {
      id: String(row.id),
      ownerUsername: String(row.owner_username),
      title: String(row.title),
      description: String(row.description || ''),
      privacy: String(row.privacy || 'public'),
      coverUrl: String(row.cover_url || photos[0]?.image_url || ''),
      photoCount: photos.length,
      createdAt: String(row.created_at),
      updatedAt: String(row.updated_at),
    };
  };

  const formatAlbumPhoto = (p: Record<string, unknown>) => {
    const cnt = db
      .prepare('SELECT COUNT(*) AS cnt FROM album_photo_comments WHERE photo_id = ?')
      .get(String(p.id)) as { cnt: number };
    return {
      id: String(p.id),
      albumId: String(p.album_id),
      ownerUsername: String(p.owner_username),
      title: String(p.title),
      caption: String(p.caption || ''),
      imageUrl: String(p.image_url),
      likes: JSON.parse(String(p.likes_json || '[]')) as string[],
      commentCount: Number(cnt?.cnt || 0),
      createdAt: String(p.created_at),
    };
  };

  app.get('/api/albums', (req, res) => {
    const authed = getAuthenticatedUser(req);
    const viewer = authed?.username || '';
    const ownerFilter = String(req.query.owner || '').trim();

    const rows = (
      ownerFilter
        ? db
            .prepare('SELECT * FROM photo_albums WHERE owner_username = ? ORDER BY updated_at DESC')
            .all(ownerFilter)
        : db.prepare('SELECT * FROM photo_albums ORDER BY updated_at DESC LIMIT 100').all()
    ) as Record<string, unknown>[];

    const visible = rows
      .filter((r) => canAccessAlbum(r, viewer, authed?.role))
      .map(formatAlbumRow);
    res.json({ albums: visible });
  });

  app.get('/api/albums/:id', (req, res) => {
    const authed = getAuthenticatedUser(req);
    const viewer = authed?.username || '';
    const row = db
      .prepare('SELECT * FROM photo_albums WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Album not found.' });
      return;
    }
    if (!canAccessAlbum(row, viewer, authed?.role)) {
      res.status(403).json({ error: 'This album is private or restricted to friends only.' });
      return;
    }
    const photos = db
      .prepare('SELECT * FROM album_photos WHERE album_id = ? ORDER BY created_at DESC')
      .all(req.params.id) as Record<string, unknown>[];
    res.json({
      album: formatAlbumRow(row),
      photos: photos.map(formatAlbumPhoto),
    });
  });

  app.post('/api/albums', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to create photo albums.' });
      return;
    }
    const { title, description, privacy } = req.body as {
      title?: string;
      description?: string;
      privacy?: string;
    };
    const cleanTitle = String(title || '').trim();
    if (!cleanTitle) {
      res.status(400).json({ error: 'Album title is required.' });
      return;
    }
    const validPrivacy = privacy === 'private' || privacy === 'friends' ? privacy : 'public';
    const id = `alb-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();

    db.prepare(
      `INSERT INTO photo_albums (id, owner_username, title, description, privacy, cover_url, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, '', ?, ?)`
    ).run(id, authed.username, cleanTitle.slice(0, 80), String(description || '').trim().slice(0, 300), validPrivacy, now, now);

    const created = db
      .prepare('SELECT * FROM photo_albums WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.status(201).json({ album: formatAlbumRow(created) });
  });

  app.patch('/api/albums/:id', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM photo_albums WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Album not found.' });
      return;
    }
    if (String(row.owner_username) !== authed.username && authed.role !== 'super_admin') {
      res.status(403).json({ error: 'Only album owner can edit this album.' });
      return;
    }
    const { title, description, privacy } = req.body as {
      title?: string;
      description?: string;
      privacy?: string;
    };
    const validPrivacy =
      privacy === 'private' || privacy === 'friends' || privacy === 'public'
        ? privacy
        : String(row.privacy);
    const now = new Date().toISOString();

    db.prepare(
      'UPDATE photo_albums SET title = ?, description = ?, privacy = ?, updated_at = ? WHERE id = ?'
    ).run(
      title !== undefined ? title.trim().slice(0, 80) : String(row.title),
      description !== undefined ? description.trim().slice(0, 300) : String(row.description || ''),
      validPrivacy,
      now,
      req.params.id
    );
    const updated = db
      .prepare('SELECT * FROM photo_albums WHERE id = ?')
      .get(req.params.id) as Record<string, unknown>;
    res.json({ album: formatAlbumRow(updated) });
  });

  app.delete('/api/albums/:id', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const row = db
      .prepare('SELECT * FROM photo_albums WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Album not found.' });
      return;
    }
    const isAdmin = authed.role === 'super_admin' || authed.role === 'admin';
    if (String(row.owner_username) !== authed.username && !isAdmin) {
      res.status(403).json({ error: 'Only owner or admin can delete album.' });
      return;
    }
    const photos = db
      .prepare('SELECT id FROM album_photos WHERE album_id = ?')
      .all(req.params.id) as { id: string }[];
    for (const p of photos) {
      db.prepare('DELETE FROM album_photo_comments WHERE photo_id = ?').run(p.id);
    }
    db.prepare('DELETE FROM album_photos WHERE album_id = ?').run(req.params.id);
    db.prepare('DELETE FROM photo_albums WHERE id = ?').run(req.params.id);
    res.json({ ok: true });
  });

  app.post('/api/albums/:id/photos', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const album = db
      .prepare('SELECT * FROM photo_albums WHERE id = ?')
      .get(req.params.id) as Record<string, unknown> | undefined;
    if (!album) {
      res.status(404).json({ error: 'Album not found.' });
      return;
    }
    if (String(album.owner_username) !== authed.username) {
      res.status(403).json({ error: 'Only the album owner can add photos.' });
      return;
    }
    const { title, caption, imageUrl } = req.body as {
      title?: string;
      caption?: string;
      imageUrl?: string;
    };
    if (!imageUrl) {
      res.status(400).json({ error: 'Photo image URL is required.' });
      return;
    }
    const id = `aph-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO album_photos (id, album_id, owner_username, title, caption, image_url, likes_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, '[]', ?)`
    ).run(
      id,
      req.params.id,
      authed.username,
      String(title || 'Untitled Photo').trim().slice(0, 80),
      String(caption || '').trim().slice(0, 300),
      imageUrl,
      now
    );
    db.prepare('UPDATE photo_albums SET updated_at = ? WHERE id = ?').run(now, req.params.id);

    const created = db
      .prepare('SELECT * FROM album_photos WHERE id = ?')
      .get(id) as Record<string, unknown>;
    res.status(201).json({ photo: formatAlbumPhoto(created) });
  });

  app.delete('/api/albums/photos/:photoId', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Authentication required.' });
      return;
    }
    const photo = db
      .prepare('SELECT * FROM album_photos WHERE id = ?')
      .get(req.params.photoId) as Record<string, unknown> | undefined;
    if (!photo) {
      res.status(404).json({ error: 'Photo not found.' });
      return;
    }
    const isAdmin = authed.role === 'super_admin' || authed.role === 'admin';
    if (String(photo.owner_username) !== authed.username && !isAdmin) {
      res.status(403).json({ error: 'Only owner or admin can remove this photo.' });
      return;
    }
    db.prepare('DELETE FROM album_photo_comments WHERE photo_id = ?').run(req.params.photoId);
    db.prepare('DELETE FROM album_photos WHERE id = ?').run(req.params.photoId);
    res.json({ ok: true });
  });

  app.post('/api/albums/photos/:photoId/like', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to like album photos.' });
      return;
    }
    const photo = db
      .prepare('SELECT * FROM album_photos WHERE id = ?')
      .get(req.params.photoId) as Record<string, unknown> | undefined;
    if (!photo) {
      res.status(404).json({ error: 'Photo not found.' });
      return;
    }
    const likes = JSON.parse(String(photo.likes_json || '[]')) as string[];
    const already = likes.includes(authed.username);
    const nextLikes = already
      ? likes.filter((u) => u !== authed.username)
      : [...likes, authed.username];
    db.prepare('UPDATE album_photos SET likes_json = ? WHERE id = ?').run(
      JSON.stringify(nextLikes),
      req.params.photoId
    );
    res.json({ likes: nextLikes });
  });

  app.get('/api/albums/photos/:photoId/comments', (req, res) => {
    const rows = db
      .prepare('SELECT * FROM album_photo_comments WHERE photo_id = ? ORDER BY created_at ASC')
      .all(req.params.photoId) as Record<string, unknown>[];
    res.json({
      comments: rows.map((r) => ({
        id: String(r.id),
        photoId: String(r.photo_id),
        authorUsername: String(r.author_username),
        body: String(r.body),
        createdAt: String(r.created_at),
      })),
    });
  });

  app.post('/api/albums/photos/:photoId/comments', (req, res) => {
    const authed = getAuthenticatedUser(req);
    if (!authed) {
      res.status(401).json({ error: 'Log in to comment on photos.' });
      return;
    }
    const photo = db
      .prepare('SELECT * FROM album_photos WHERE id = ?')
      .get(req.params.photoId) as Record<string, unknown> | undefined;
    if (!photo) {
      res.status(404).json({ error: 'Photo not found.' });
      return;
    }
    const cleanBody = String(req.body?.body || '').trim();
    if (!cleanBody || cleanBody.length > 300) {
      res.status(400).json({ error: 'Comment must be 1-300 characters.' });
      return;
    }
    const id = `apc-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO album_photo_comments (id, photo_id, author_username, body, created_at)
       VALUES (?, ?, ?, ?, ?)`
    ).run(id, req.params.photoId, authed.username, cleanBody, now);
    res.status(201).json({
      comment: {
        id,
        photoId: req.params.photoId,
        authorUsername: authed.username,
        body: cleanBody,
        createdAt: now,
      },
    });
  });
}
